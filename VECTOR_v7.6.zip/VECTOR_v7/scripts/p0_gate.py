#!/usr/bin/env python3
"""v6-P0 gate: is the CAV control stack feasible before any learning?

Runs paired configurations on ONE scenario and seed, with the signal side frozen
to Max-Pressure inside the agent's own envelope (``--signal-rule maxpressure``),
so differences come only from how CAVs are driven:

  G0_native   SUMO's own IDM drives every CAV             (reference)
  G1_v524     v5.2.4 rule stack, RL residual forced to 0  (where we start)
  G2_p0       v6-P0 rule stack, RL residual forced to 0   (the fix)
  G3_p0_rl    v6-P0 rule stack + learning Lon residual    (does RL hurt?)
  G4_v524_rl  v5.2.4 full stack + learning residual       (optional, --with-v524-rl)

Verdict (means over the Lon-stage episodes):
  GATE-1 feasibility : G2 TIS <= (1 + tol) * G0 TIS, backlog/teleports/collisions not worse
  GATE-2 learning    : G3 TIS <= (1 + tol) * G2 TIS
Diagnostics printed alongside: speed, [Diag-JStall] controlled-CAV junction events,
[Diag-Auth] stack residual and positive-residual execution ratio.

Usage (Windows PowerShell or bash, from the VECTOR folder):
  python scripts/p0_gate.py --sumocfg "environment/sumo_net/4-leg(4phases)/4-leg(4phases).sumocfg" ^
      --lon-episodes 6 --control-seconds 600 --seed 7 --workers 4
  python scripts/p0_gate.py --parse-only --out-dir logs/p0_gate/4-leg_seed7
Anything after ``--`` is passed to every train_RL run unchanged.
"""
from __future__ import annotations

import argparse
import csv
import os
import re
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from typing import Dict, List, Optional

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
TRAIN = os.path.join(ROOT, "train", "train_RL.py")

CONFIGS = {
    "G0_native": ["--profile", "v6p0", "--ablate-cav-native-idm"],
    "G1_v524": ["--profile", "v524", "--ablate-zero-lon-residual"],
    "G2_p0": ["--profile", "v6p0", "--ablate-zero-lon-residual"],
    "G3_p0_rl": ["--profile", "v6p0"],
    "G4_v524_rl": ["--profile", "v524"],
    "G5_p1": ["--profile", "v6p1"],
    # VECTOR v7 learnable stack (signal stays Max-Pressure via --signal-rule).
    # Needs far more Lon episodes than the P0 feasibility runs, e.g.
    #   --configs G2_p0,G6_v7 --lon-episodes 120 --control-seconds 900
    "G6_v7": ["--profile", "v7"],
}
DEFAULT_SET = ("G0_native", "G1_v524", "G2_p0", "G3_p0_rl")

RE_EP = re.compile(
    r"Stage (?P<stage>\S+) \| Episode (?P<ep>\d+)/\d+ - .*?Speed: (?P<speed>[-\d.]+) m/s"
    r".*?TIS: (?P<tis>[-\d.]+)s \| Backlog: (?P<backlog>[-\d.]+) \| "
    r"Teleports: (?P<tele>[-\d.]+) \| Collisions: (?P<coll>[-\d.]+)"
)
RE_JSTALL = re.compile(r"\[Diag-JStall\] ep=(?P<ep>\d+) stage=(?P<stage>\S+) .*?>=10s events ctrlCAV=(?P<ctrl_ev>[\d.]+)")
RE_AUTH = re.compile(
    r"\[Diag-Auth\] ep=(?P<ep>\d+) stage=(?P<stage>\S+) n=(?P<n>[\d.]+) "
    r"res\(policy=(?P<pol>[-+\d.]+) stack=(?P<stack>[-+\d.]+) realized=(?P<real>[-+\d.]+)\) "
    r"stack_cut=(?P<cut>[\d.]+) .*?pos_exec_ratio=(?P<posx>[\d.]+)"
)

FIELDS = ("speed", "tis", "backlog", "tele", "coll", "ctrl_ev", "stack", "real", "posx", "cut")


def _scenario_tag(sumocfg: str) -> str:
    base = os.path.splitext(os.path.basename(sumocfg))[0]
    return re.sub(r"[^A-Za-z0-9_-]+", "", base.replace("(", "_").replace(")", "")) or "scenario"


def build_cmd(cfg: str, a, extra: List[str]) -> List[str]:
    return [
        sys.executable, TRAIN,
        "--sumocfg", a.sumocfg,
        "--seed", str(a.seed),
        "--gate-lon-episodes", str(a.lon_episodes),
        "--control-seconds", str(a.control_seconds),
        "--signal-rule", a.signal_rule,
        "--no-vision",
        "--num-envs", "1",
        "--results-method", f"p0gate_{cfg}",
        *CONFIGS[cfg],
        *extra,
    ]


def run_one(cfg: str, a, extra: List[str], out_dir: str) -> int:
    log_path = os.path.join(out_dir, f"{cfg}.log")
    cmd = build_cmd(cfg, a, extra)
    with open(os.path.join(out_dir, f"{cfg}.cmd.txt"), "w", encoding="utf-8") as fh:
        fh.write(" ".join(f'"{c}"' if " " in c or "(" in c else c for c in cmd) + "\n")
    if a.dry_run:
        print(f"[dry-run] {cfg}: {' '.join(cmd)}")
        return 0
    env = dict(os.environ)
    env.setdefault("PYTHONUNBUFFERED", "1")
    t0 = time.time()
    print(f"[gate] start {cfg} -> {log_path}", flush=True)
    with open(log_path, "w", encoding="utf-8") as fh:
        rc = subprocess.call(cmd, cwd=ROOT, stdout=fh, stderr=subprocess.STDOUT, env=env)
    print(f"[gate] done  {cfg} rc={rc} in {(time.time() - t0) / 60.0:.1f} min", flush=True)
    return rc


def parse_log(path: str, stage: str = "Lon") -> Dict[str, Optional[float]]:
    rows: Dict[int, Dict[str, float]] = {}
    if not os.path.exists(path):
        return {}
    with open(path, encoding="utf-8", errors="replace") as fh:
        for line in fh:
            m = RE_EP.search(line)
            if m and m.group("stage") == stage:
                r = rows.setdefault(int(m.group("ep")), {})
                for k in ("speed", "tis", "backlog", "tele", "coll"):
                    r[k] = float(m.group(k))
                continue
            m = RE_JSTALL.search(line)
            if m and m.group("stage") == stage:
                rows.setdefault(int(m.group("ep")), {})["ctrl_ev"] = float(m.group("ctrl_ev"))
                continue
            m = RE_AUTH.search(line)
            if m and m.group("stage") == stage:
                r = rows.setdefault(int(m.group("ep")), {})
                r["stack"] = float(m.group("stack"))
                r["real"] = float(m.group("real"))
                r["posx"] = float(m.group("posx"))
                r["cut"] = float(m.group("cut"))
    eps = [r for r in rows.values() if "tis" in r]
    out: Dict[str, Optional[float]] = {"n_ep": float(len(eps))}
    for k in FIELDS:
        vals = [r[k] for r in eps if k in r]
        out[k] = (sum(vals) / len(vals)) if vals else None
    out["tis_list"] = [float(r["tis"]) for r in eps]
    out["coll_list"] = [float(r["coll"]) for r in eps if "coll" in r]
    return out


def _fmt(v, nd=2):
    return "-" if v is None else f"{v:.{nd}f}"


def paired_bootstrap_rel(a, b, n_boot=4000, seed=7):
    """Paired relative TIS change (a-b)/b. Returns (mean, lo, hi) of 95% bootstrap CI."""
    xa = [float(x) for x in (a or [])]
    xb = [float(x) for x in (b or [])]
    n = min(len(xa), len(xb))
    if n < 2:
        return None
    diffs = [(xa[i] - xb[i]) / max(xb[i], 1e-6) for i in range(n)]
    rng = __import__("random").Random(int(seed))
    means = []
    for _ in range(int(n_boot)):
        sample = [diffs[rng.randrange(n)] for _ in range(n)]
        means.append(sum(sample) / n)
    means.sort()
    lo = means[int(0.025 * (len(means) - 1))]
    hi = means[int(0.975 * (len(means) - 1))]
    return sum(diffs) / n, lo, hi


def verdict(res: Dict[str, Dict[str, Optional[float]]], tol: float, window: int = 10) -> List[str]:
    lines = []

    def ok_vs(cand, ref, name):
        c, r = res.get(cand) or {}, res.get(ref) or {}
        if not c.get("tis") or not r.get("tis"):
            lines.append(f"{name}: NOT EVALUATED (missing {cand} or {ref} Lon episodes)")
            return None
        checks = {
            "TIS": c["tis"] <= (1.0 + tol) * r["tis"],
            "Backlog": (c.get("backlog") or 0.0) <= (r.get("backlog") or 0.0) + max(10.0, 0.05 * (r.get("backlog") or 0.0)),
            "Teleports": (c.get("tele") or 0.0) <= (r.get("tele") or 0.0) + 2.0,
            "Collisions": (c.get("coll") or 0.0) <= (r.get("coll") or 0.0) + 0.5,
        }
        passed = all(checks.values())
        detail = ", ".join(f"{k}={'ok' if v else 'FAIL'}" for k, v in checks.items())
        rel = 100.0 * (c["tis"] / r["tis"] - 1.0)
        lines.append(f"{name}: {'PASS' if passed else 'FAIL'}  (TIS {rel:+.1f}% vs {ref}; {detail})")
        return passed

    g1 = ok_vs("G2_p0", "G0_native", "GATE-1 feasibility (G2 vs G0)")
    g2 = ok_vs("G3_p0_rl", "G2_p0", "GATE-2 learning    (G3 vs G2)")
    ref = ok_vs("G1_v524", "G0_native", "info   v5.2.4 stack (G1 vs G0)")
    del ref
    if g1 is False:
        lines.append("-> Do not start P1. Read [Diag-JStall]/[Diag-Auth] of G2 and bisect with --no-lon-no-floors, "
                     "--lon-actuation accel, --gap-policy legacy one at a time.")
    elif g1 and g2 is False:
        lines.append("-> Stack is feasible but the residual RL degrades it: proceed to P1 (individual critic, "
                     "target-speed action); keep the RL residual off for any paper run until then.")
    elif g1 and g2:
        lines.append("-> P0 accepted. Repeat on 3-leg and 5-leg (and seeds 7/11/13), then start P1.")
    g2r = res.get("G2_p0") or {}
    v7 = res.get("G6_v7") or {}
    if v7.get("tis") and g2r.get("tis"):
        # v7.5: threshold and CI use the SAME window (last K episodes). v7.0-v7.4
        # compared the all-episode mean (incl. exploration) against the threshold
        # but bootstrapped only the last 10, while labelling the line "last 10".
        k = max(2, int(window))
        a_all, b_all = list(v7.get("tis_list") or []), list(g2r.get("tis_list") or [])
        n = min(len(a_all), len(b_all))
        a_w, b_w = a_all[:n][-k:], b_all[:n][-k:]
        rel_w = 100.0 * (sum(a_w) / max(sum(b_w), 1e-9) - 1.0) if a_w and b_w else float("nan")
        rel_all = 100.0 * (v7["tis"] / g2r["tis"] - 1.0)
        boot = paired_bootstrap_rel(a_w, b_w)
        safer = (
            (v7.get("coll") or 0.0) <= (g2r.get("coll") or 0.0) + 0.5
            and (v7.get("tele") or 0.0) <= (g2r.get("tele") or 0.0) + 2.0
        )
        ci_ok = boot is not None and boot[2] < 0.0
        passed = bool(rel_w <= -1.0 and ci_ok and safer)
        ci_txt = "-" if boot is None else f"[{100.0 * boot[1]:+.2f}%, {100.0 * boot[2]:+.2f}%]"
        lines.append(
            f"GATE-V7 screen vs G2 (last {len(a_w)} Lon eps): {'PASS' if passed else 'FAIL'}  "
            f"(TIS {rel_w:+.2f}%, paired bootstrap 95% {ci_txt}; safety={'ok' if safer else 'FAIL'}; "
            f"info: all {n} eps {rel_all:+.2f}%)"
        )
        lines.append(
            "-> Training-episode TIS is only a screen. Confirm with scripts/evaluate_policy.py "
            "on VALIDATION seeds (deterministic policy) before any paper claim."
        )
    p1 = res.get("G5_p1") or {}
    if p1.get("tis") and g2r.get("tis"):
        rel = 100.0 * (p1["tis"] / g2r["tis"] - 1.0)
        boot = paired_bootstrap_rel(p1.get("tis_list"), g2r.get("tis_list"))
        safer = (
            (p1.get("coll") or 0.0) <= (g2r.get("coll") or 0.0) + 0.5
            and (p1.get("tele") or 0.0) <= (g2r.get("tele") or 0.0) + 2.0
        )
        ci_ok = boot is not None and boot[2] < 0.0
        improve = rel <= -1.0
        passed = bool(improve and ci_ok and safer)
        ci_txt = "-" if boot is None else f"[{100.0 * boot[1]:+.1f}%, {100.0 * boot[2]:+.1f}%]"
        lines.append(
            f"GATE-P1 vs G2: {'PASS' if passed else 'FAIL'}  "
            f"(TIS {rel:+.1f}%, bootstrap 95% {ci_txt}; "
            f"safety={'ok' if safer else 'FAIL'})"
        )
        if passed:
            lines.append("-> P1 accepted on this scenario/seed. Repeat validation seeds, then P2.")
        else:
            lines.append("-> P1 not accepted yet: keep the P0 rule stack for paper runs; inspect G5_p1 logs.")
    return lines


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--sumocfg", default="environment/sumo_net/4-leg(4phases)/4-leg(4phases).sumocfg")
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--lon-episodes", type=int, default=6)
    ap.add_argument("--control-seconds", type=float, default=600.0)
    ap.add_argument("--signal-rule", default="maxpressure", choices=["maxpressure", "longest_queue", "none"])
    ap.add_argument("--configs", default=",".join(DEFAULT_SET),
                    help="comma list from " + ",".join(CONFIGS))
    ap.add_argument("--with-v524-rl", action="store_true", help="also run G4_v524_rl")
    ap.add_argument("--workers", type=int, default=2, help="parallel runs (each uses 1 env + 2 torch threads)")
    ap.add_argument("--tol", type=float, default=0.02, help="relative TIS tolerance (default 2%%)")
    ap.add_argument("--gate-window", type=int, default=10,
                    help="GATE-V7: last K Lon episodes used for BOTH the 1%% threshold and the bootstrap CI")
    ap.add_argument("--out-dir", default="")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--parse-only", action="store_true")
    argv = sys.argv[1:]
    extra: List[str] = []
    if "--" in argv:
        i = argv.index("--")
        argv, extra = argv[:i], argv[i + 1:]
    a = ap.parse_args(argv)

    cfgs = [c.strip() for c in a.configs.split(",") if c.strip()]
    if a.with_v524_rl and "G4_v524_rl" not in cfgs:
        cfgs.append("G4_v524_rl")
    for c in cfgs:
        if c not in CONFIGS:
            ap.error(f"unknown config {c}")
    out_dir = a.out_dir or os.path.join(ROOT, "logs", "p0_gate", f"{_scenario_tag(a.sumocfg)}_seed{a.seed}")
    os.makedirs(out_dir, exist_ok=True)

    if not a.parse_only:
        with ThreadPoolExecutor(max_workers=max(1, int(a.workers))) as ex:
            rcs = dict(zip(cfgs, ex.map(lambda c: run_one(c, a, extra, out_dir), cfgs)))
        bad = {c: rc for c, rc in rcs.items() if rc != 0}
        if bad:
            print(f"[gate] WARNING non-zero exit codes: {bad} (see the .log files)", flush=True)
        if a.dry_run:
            return 0

    res = {c: parse_log(os.path.join(out_dir, f"{c}.log")) for c in cfgs}
    header = ["config", "lon_eps", "speed_mps", "TIS_s", "backlog", "teleports", "collisions",
              "ctrlCAV_jstall_events", "stack_res", "realized_res", "pos_exec_ratio", "stack_cut"]
    table = []
    for c in cfgs:
        r = res[c]
        table.append([c, _fmt(r.get("n_ep"), 0), _fmt(r.get("speed")), _fmt(r.get("tis"), 1),
                      _fmt(r.get("backlog"), 0), _fmt(r.get("tele"), 1), _fmt(r.get("coll"), 1),
                      _fmt(r.get("ctrl_ev"), 1), _fmt(r.get("stack"), 3), _fmt(r.get("real"), 3),
                      _fmt(r.get("posx")), _fmt(r.get("cut"))])
    with open(os.path.join(out_dir, "gate_summary.csv"), "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(header)
        w.writerows(table)
    lines = verdict(res, float(a.tol), window=int(a.gate_window))
    md = ["| " + " | ".join(header) + " |", "|" + "---|" * len(header)]
    md += ["| " + " | ".join(row) + " |" for row in table]
    md += [""] + lines
    with open(os.path.join(out_dir, "gate_summary.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(md) + "\n")
    print("\n".join(md))
    print(f"\n[gate] summary written to {out_dir}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
