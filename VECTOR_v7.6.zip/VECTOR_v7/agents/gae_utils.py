"""Pure-numpy advantage helpers (unit-tested without torch / SUMO).

VECTOR v4: SMDP (option-level) lambda placement.
v7: optional ``truncateds`` / ``bootstrap_values`` for env-level time limits.
train_RL already bootstraps V(s_T) when the controlled horizon ends (SUMO only
reports done on traffic_exhausted / gridlock), so the default path is used
and is bit-identical to v5 (tested).
"""
from __future__ import annotations

import numpy as np


def smdp_gae(rewards, values, dones, next_value=0.0, gamma=0.99, gae_lambda=0.95,
             decision_mask=None, truncateds=None, bootstrap_values=None):
    """GAE with lambda applied only at option boundaries, truncation-aware.

    ``decision_mask[t]`` is True when step ``t`` starts a real decision (option).
    Inside an option the recursion propagates pure ``gamma``; ``lambda`` is
    applied when step ``t+1`` starts the next decision. This equals option-level
    GAE exactly:

        A(t0) = sum_{k<tau} gamma^k delta_{t0+k} + gamma^tau * lambda * A(t0+tau)

    Episode boundaries:
      * ``dones[t]`` (or ``truncateds[t]``) marks the end of an episode after step t.
      * terminal (done and not truncated): bootstrap 0.
      * truncated (time limit): bootstrap ``bootstrap_values[t]`` = V(s_{t+1}) of the
        final observation; if not provided, falls back to ``values[t]``
        (V(s_T) ~= V(s_{T-1}), far better than 0).
      * the GAE recursion is cut at every boundary in both cases.

    With ``decision_mask=None`` and ``truncateds=None`` this is bit-identical to v5.
    Returns ``(returns, advantages)`` as float32 arrays.
    """
    r = np.asarray(rewards, dtype=np.float64).reshape(-1)
    v = np.asarray(values, dtype=np.float64).reshape(-1)
    d = np.asarray(dones, dtype=np.float64).reshape(-1)
    n = int(r.shape[0])
    if not (v.shape[0] == n and d.shape[0] == n):
        raise ValueError("smdp_gae expects rewards, values and dones of equal length")
    if not (np.isfinite(r).all() and np.isfinite(v).all() and np.isfinite(d).all()):
        raise ValueError("smdp_gae received non-finite rollout data")
    gamma = float(gamma)
    lam = float(gae_lambda)

    dec = None
    if decision_mask is not None:
        dm = np.asarray(decision_mask, dtype=bool).reshape(-1)
        if dm.shape[0] == n:
            dec = dm

    trunc = None
    if truncateds is not None:
        tr = np.asarray(truncateds, dtype=bool).reshape(-1)
        if tr.shape[0] != n:
            raise ValueError("smdp_gae: truncateds must match rewards length")
        trunc = tr

    boot = None
    if bootstrap_values is not None:
        b = np.asarray(bootstrap_values, dtype=np.float64).reshape(-1)
        if b.shape[0] != n:
            raise ValueError("smdp_gae: bootstrap_values must match rewards length")
        boot = b

    adv = np.zeros(n, dtype=np.float64)
    gae = 0.0
    try:
        following = float(next_value)
    except (TypeError, ValueError, OverflowError):
        following = 0.0
    if not np.isfinite(following):
        following = 0.0

    if trunc is None:
        # v5 path (kept bit-identical for regression safety).
        for t in range(n - 1, -1, -1):
            not_done = 1.0 - d[t]
            delta = r[t] + gamma * following * not_done - v[t]
            if dec is None:
                lam_t = lam
            else:
                lam_t = lam if (t + 1 >= n or bool(dec[t + 1])) else 1.0
            gae = delta + gamma * lam_t * not_done * gae
            adv[t] = gae
            following = v[t]
    else:
        for t in range(n - 1, -1, -1):
            is_trunc = bool(trunc[t])
            boundary = is_trunc or d[t] > 0.5
            if boundary:
                if is_trunc:
                    nxt = v[t]
                    if boot is not None and np.isfinite(boot[t]):
                        nxt = float(boot[t])
                else:
                    nxt = 0.0
                cont = 0.0
            else:
                nxt = following
                cont = 1.0
            delta = r[t] + gamma * nxt - v[t]
            if dec is None:
                lam_t = lam
            else:
                lam_t = lam if (t + 1 >= n or bool(dec[t + 1])) else 1.0
            gae = delta + gamma * lam_t * cont * gae
            adv[t] = gae
            following = v[t]

    ret = adv + v
    return ret.astype(np.float32), adv.astype(np.float32)
