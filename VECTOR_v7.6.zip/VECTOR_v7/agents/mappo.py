"""MAPPO with hierarchical CAV: Signal + Lateral + Longitudinal (VECTOR v7).

API-compatible with the uploaded v5.2.4/v6-P1 agent (same public methods,
rollout keys, attributes). Legacy profiles keep their numbers; v7 adds:

Bug fixes (active for every profile)
  F1  joint-stage anchor KL in the same tempered logit space as the executed
      signal policy (v5: tempered policy vs raw anchor -> BC drove raw logits
      to T*anchor and undid the sharpening; KL != 0 at the anchor).
  F2  team return RMS not reset on stage switches that keep critic.net
      (v5 reset it at Lon->Lat, which the shipped schedule hits because
      joint_lon_sig=0): first flush of Lat denormalised with (0, 1).
  F4  fit_individual pairs each sample with its own graph (v5: graphs[0]).
  F5  ndarray-safe zero-DoF filtering in update().
  F7  temperature floor 0.05 instead of the silent fallback to T=1.
  F9  epoch-0 importance-ratio check per head (sampler/evaluator mismatch).

v7 learning machinery (opt-in, enabled by train_RL --profile v7)
  * agent value net V(o_i (+) c) with ValueNorm + PopArt, trained here on
    'v7_value_inputs' / 'v7_value_returns' produced by train/cav_gae_v7.py
  * joint-stage temperature annealed per signal update (no Lat->JointAll
    argmax->T=0.65 shock), adaptive anchor-KL, per-head entropy and LR,
    KL early stop at kl_stop_factor * target.
"""
from __future__ import annotations

import copy
import math

import numpy as np

from agents.gae_utils import smdp_gae
from agents.running_norm import RunningMeanStd
from agents.signal_buffer import SIGNAL_SAMPLE_KEYS, SignalSampleBuffer
from agents.value_norm import ValueNorm
import torch
import torch.multiprocessing as mp  # noqa: F401  (legacy import kept)
import torch.nn.functional as F
import torch.optim as optim
from torch.distributions import Categorical
from torch_geometric.data import Batch, Data

# Stage-S signal GAE: longer effective horizon across 10 s decision gaps.
# NOTE: both gammas are *per simulation step*; if the env step is not 1 s,
# use gamma_step = gamma_per_second ** step_length.
SIGNAL_GAE_GAMMA = 0.998
SIGNAL_GAE_LAMBDA = 0.98
TEACHER_CONFIDENCE_THRESHOLD = 0.60

CURRICULUM_STAGES = ("S", "Lon", "JointLonSig", "Lat", "JointAll")
JOINT_STAGES = frozenset(("JointLonSig", "JointAll"))
# Joint-stage knobs keep the v5 values; --profile v7 de-stacks them
# (see train_RL.V7_AGENT_OVERRIDES).
DEFAULT_JOINT_SIGNAL_LR_SCALE = 0.08        # v7 profile: 0.20
DEFAULT_JOINT_LON_LR_SCALE = 1.0
DEFAULT_JOINT_ALL_SIGNAL_LR_SCALE = 0.05    # v7 profile: 0.10
DEFAULT_JOINT_ALL_LON_LR_SCALE = 0.10
DEFAULT_JOINT_ALL_LAT_LR_SCALE = 1.0
DEFAULT_JOINT_SIGNAL_ENTROPY_SCALE = 0.20
DEFAULT_JOINT_SIGNAL_ADV_SCALE = 0.5         # v7 profile: 1.0
DEFAULT_JOINT_SIGNAL_TEMPERATURE = 0.65     # end temperature
DEFAULT_JOINT_SIGNAL_TEMP_START = None      # v7 profile: 0.25 (anneal off = v5)
DEFAULT_JOINT_SIGNAL_TEMP_ANNEAL_UPDATES = 30
MIN_SIGNAL_TEMPERATURE = 0.05
DEFAULT_ANCHOR_BC_SIGNAL = 0.50
DEFAULT_ANCHOR_BC_LON = 0.25
DEFAULT_ANCHOR_BC_LAT = 0.25
DEFAULT_ANCHOR_KL_TARGET = 0.01
_ILLEGAL_LOGIT = -1e8
_HEADS = ("signal", "lon", "lat")

# mp.set_start_method("spawn") belongs in train_RL main — not at import time.


def _seq_len(x) -> int:
    """Length of list/tuple/ndarray without truth-value tests (F5)."""
    if x is None:
        return 0
    if isinstance(x, np.ndarray):
        return int(x.shape[0]) if x.ndim > 0 else 1
    try:
        return len(x)
    except TypeError:
        return 0


class MAPPOAgent:
    """CTDE MAPPO: S → Lon → JointLonSig → Lat → JointAll."""

    def __init__(
        self,
        lon_actor=None,
        lat_actor=None,
        signal_actor=None,
        critic=None,
        # Legacy kwargs accepted for older call sites
        cav_actor=None,
        cav_residual_actor=None,
        actor_lr=3e-4,
        critic_lr=1e-4,
        gamma=0.99,
        gae_lambda=0.95,
        clip_param=0.2,
        ppo_epochs=4,
        minibatch_size=256,
        entropy_coef=0.01,
        device="cpu",
        delta_max=1.5,
        coop_on=False,
        lambda_mode="fixed",
        target_kl=0.02,
        max_grad_norm=0.5,
        obs_norm=False,
        obs_clip=10.0,
    ):
        del cav_residual_actor, delta_max, coop_on, lambda_mode
        self.device = torch.device(device) if not isinstance(device, torch.device) else device
        self.lon_actor = lon_actor if lon_actor is not None else cav_actor
        self.lat_actor = lat_actor
        self.signal_actor = signal_actor
        self.critic = critic
        self.cav_actor = self.lon_actor
        self.cav_residual_actor = None
        self.actor_lr = float(actor_lr)
        self.critic_lr = float(critic_lr)

        self.lon_optimizer = (
            optim.Adam(self.lon_actor.parameters(), lr=self.actor_lr) if self.lon_actor else None
        )
        self.cav_optimizer = self.lon_optimizer
        self.cav_residual_optimizer = None
        self.lat_optimizer = (
            optim.Adam(self.lat_actor.parameters(), lr=self.actor_lr) if self.lat_actor else None
        )
        self.signal_optimizer = (
            optim.Adam(self.signal_actor.parameters(), lr=self.actor_lr) if self.signal_actor else None
        )
        self.critic_optimizer = (
            optim.Adam(self.critic.parameters(), lr=self.critic_lr) if self.critic else None
        )
        self.gamma = float(gamma)
        self.gae_lambda = float(gae_lambda)
        self.clip_param = float(clip_param)
        self.ppo_epochs = max(1, int(ppo_epochs))
        try:
            target_kl = float(target_kl)
        except (TypeError, ValueError, OverflowError):
            target_kl = 0.02
        self.TARGET_KL = target_kl if np.isfinite(target_kl) and target_kl > 0.0 else 0.02
        try:
            max_grad_norm = float(max_grad_norm)
        except (TypeError, ValueError, OverflowError):
            max_grad_norm = 0.5
        self.max_grad_norm = (
            max_grad_norm if np.isfinite(max_grad_norm) and max_grad_norm > 0.0 else 0.5
        )
        self._last_approx_kl = 0.0
        self._last_clipfrac = 0.0
        self._force_signal_one_epoch = False
        self.minibatch_size = max(1, int(minibatch_size))
        self.entropy_coef = float(entropy_coef)
        # F11: per-head entropy (None -> entropy_coef). Continuous lon entropy
        # lives on a different scale than categorical entropy.
        self.entropy_coef_signal = None
        self.entropy_coef_lon = None
        self.entropy_coef_lat = None
        # F11: SB3 convention, stop when KL > 1.5 * target.
        self.kl_stop_factor = 1.0  # v5 semantics; v7 profile: 1.5
        self.training_stage = "S"
        self.action_blend_beta = 1.0
        self.imitation_coef = 0.0
        self.enable_lateral = True
        self.enable_longitudinal = True
        self._ret_rms_mean = 0.0
        self._ret_rms_var = 1.0
        self._ret_rms_count = 1e-4
        self._sig_ret_rms_mean = 0.0
        self._sig_ret_rms_var = 1.0
        self._sig_ret_rms_count = 1e-4
        self.ret_rms_alpha = 0.15
        self.sig_ret_rms_alpha = 0.12
        self.popart_enabled = True
        # F2: legacy behaviour switch (False = keep stats, PopArt handles scale).
        self.reset_rms_on_stage_switch = False
        self.dual_clip_c = 3.0
        self.teacher_beta = 0.0
        self.signal_teacher_beta = 0.0
        self.teacher_conf_threshold = float(TEACHER_CONFIDENCE_THRESHOLD)
        self._last_teacher_stats = self._empty_teacher_stats(0.0)
        self.joint_signal_lr_scale = float(DEFAULT_JOINT_SIGNAL_LR_SCALE)
        self.joint_lon_lr_scale = float(DEFAULT_JOINT_LON_LR_SCALE)
        self.joint_all_signal_lr_scale = float(DEFAULT_JOINT_ALL_SIGNAL_LR_SCALE)
        self.joint_all_lon_lr_scale = float(DEFAULT_JOINT_ALL_LON_LR_SCALE)
        self.joint_all_lat_lr_scale = float(DEFAULT_JOINT_ALL_LAT_LR_SCALE)
        self.joint_signal_entropy_scale = float(DEFAULT_JOINT_SIGNAL_ENTROPY_SCALE)
        self.joint_signal_adv_scale = float(DEFAULT_JOINT_SIGNAL_ADV_SCALE)
        # F7: temperature schedule (end value keeps the v5 attribute name).
        self.joint_signal_temperature = float(DEFAULT_JOINT_SIGNAL_TEMPERATURE)
        self.joint_signal_temp_start = DEFAULT_JOINT_SIGNAL_TEMP_START
        self.joint_signal_temp_anneal_updates = int(DEFAULT_JOINT_SIGNAL_TEMP_ANNEAL_UPDATES)
        self._joint_sig_updates = 0
        self.anchor_bc_coef_signal = float(DEFAULT_ANCHOR_BC_SIGNAL)
        self.anchor_bc_coef_lon = float(DEFAULT_ANCHOR_BC_LON)
        self.anchor_bc_coef_lat = float(DEFAULT_ANCHOR_BC_LAT)
        # F10: adaptive anchor KL (discrete heads).
        self.anchor_kl_adaptive = False  # v5 fixed coefficients; v7 profile: True
        self.anchor_kl_target = float(DEFAULT_ANCHOR_KL_TARGET)
        self.anchor_mult_bounds = (0.1, 20.0)
        self._anchor_mult = {"signal": 1.0, "lat": 1.0}
        self._anchor_kl_obs = {"signal": [], "lat": []}
        self._anchor_signal = None
        self._anchor_lon = None
        self._anchor_lat = None
        self.joint_abort = False
        self.freeze_team_critic_in_stage_s = True
        self.cross_approach_baseline = True
        self.cacc_soft_platoon_enabled = True
        self.cacc_rl_authority_floor = 0.25
        self.cacc_ppo_authority_min = 0.20
        # F8: beta actually used by the last lat sampling call.
        self._last_lat_beta = 1.0
        # F9: sampler/evaluator consistency diagnostics.
        self.ratio_check_tol = 1e-3
        self._ratio_warned = set()
        self._epoch0_ratio_dev = {h: 0.0 for h in _HEADS}
        # F6: per-head observation normalisers.
        self.obs_norm = bool(obs_norm)
        self.obs_clip = float(obs_clip)
        self._obs_rms = {
            h: RunningMeanStd(clip=self.obs_clip, name=h) for h in ("signal", "lon", "lat", "critic")
        }
        self._signal_buffer = None
        self._signal_deferred = False
        # v7: per-agent value net V(o_i (+) c) for CAV credit (train/cav_gae_v7.py).
        self.agent_value_net = None
        self.agent_value_optimizer = None
        self.agent_value_norm = ValueNorm()
        self.agent_value_lr = 5e-4
        self.agent_value_minibatch = 512
        self.agent_value_epochs = None  # None -> ppo_epochs
        self.agent_value_max_grad_norm = 1.0
        self._last_agent_value_stats = {}

    @staticmethod
    def _empty_teacher_stats(beta_t: float) -> dict:
        return {
            "valid_samples": 0,
            "teacher_valid_samples": 0.0,
            "teacher_loss": 0.0,
            "teacher_beta": float(beta_t),
            "teacher_severity_mean": 0.0,
            "agreement_rate": 0.0,
            "teacher_agreement_rate": 0.0,
            "teacher_argmax_agreement": 0.0,
            "entropy": 0.0,
            "signal_entropy": 0.0,
            "grad_norm": 0.0,
            "signal_grad_norm": 0.0,
        }

    # ------------------------------------------------------------------ stages
    @staticmethod
    def _normalize_stage(stage):
        """Map to S / Lon / JointLonSig / Lat / JointAll."""
        if stage in (1, "1", "S", "s", "stage-s", "STAGE-S"):
            return "S"
        if stage in (
            "Lon", "lon", "stage-lon", "STAGE-LON",
            "L2", "l2", "stage-l2", "STAGE-L2",
            2, "2", "V1", "v1", "stage-v1", "STAGE-V1",
        ):
            return "Lon"
        if stage in (
            "JointLonSig", "jointlonsig", "joint_lon_sig", "JOINT_LON_SIG",
            "JLS", "jls", "joint-lon-sig",
        ):
            return "JointLonSig"
        if stage in (
            "JointAll", "jointall", "joint_all", "JOINT_ALL",
            "JA", "ja", "joint-all",
        ):
            return "JointAll"
        if stage in (
            "Lat", "lat", "stage-lat", "STAGE-LAT",
            "L1", "l1", "stage-l1", "STAGE-L1",
            3, "3", "V2", "v2", "stage-v2", "STAGE-V2",
            "T", "t", "Transition", "TRANSITION", "transition",
            "stage-transition", "STAGE-TRANSITION",
        ):
            return "Lat"
        key = str(stage).strip().upper().replace("-", "").replace("_", "")
        aliases = {
            "S": "S", "STAGES": "S", "SIGNAL": "S",
            "LON": "Lon", "STAGELON": "Lon", "L2": "Lon", "STAGEL2": "Lon",
            "V1": "Lon", "STAGEV1": "Lon",
            "JOINTLONSIG": "JointLonSig", "JLS": "JointLonSig",
            "JOINTALL": "JointAll", "JA": "JointAll",
            "LAT": "Lat", "STAGELAT": "Lat", "L1": "Lat", "STAGEL1": "Lat",
            "V2": "Lat", "STAGEV2": "Lat", "TRANSITION": "Lat", "T": "Lat",
        }
        if key in aliases:
            return aliases[key]
        raise ValueError(f"Invalid training stage: {stage}")

    @staticmethod
    def is_joint_stage(stage) -> bool:
        try:
            return MAPPOAgent._normalize_stage(stage) in JOINT_STAGES
        except (TypeError, ValueError):
            return False

    @staticmethod
    def cav_env_stage(stage) -> str:
        """Map training stage → env control mode (S / Lon / Lat)."""
        st = MAPPOAgent._normalize_stage(stage)
        if st in ("Lon", "JointLonSig"):
            return "Lon"
        if st in ("Lat", "JointAll"):
            return "Lat"
        return "S"

    @staticmethod
    def eval_stage(stage) -> str:
        """Checkpoint / eval stage: joint maps to last pure CAV stage."""
        st = MAPPOAgent._normalize_stage(stage)
        if st == "JointLonSig":
            return "Lon"
        if st == "JointAll":
            return "Lat"
        return st

    @staticmethod
    def stage_train_flags(stage, enable_lon=True, enable_lat=True, joint_abort=False):
        """Which actor heads train under ``stage`` (respects joint abort)."""
        st = MAPPOAgent._normalize_stage(stage)
        enable_lon = bool(enable_lon)
        enable_lat = bool(enable_lat)
        if joint_abort and st == "JointLonSig":
            return {"signal": False, "lon": enable_lon, "lat": False}
        if joint_abort and st == "JointAll":
            return {"signal": False, "lon": False, "lat": enable_lat}
        if st == "S":
            return {"signal": True, "lon": False, "lat": False}
        if st == "Lon":
            return {"signal": False, "lon": enable_lon, "lat": False}
        if st == "JointLonSig":
            return {"signal": True, "lon": enable_lon, "lat": False}
        if st == "Lat":
            return {"signal": False, "lon": False, "lat": enable_lat}
        if st == "JointAll":
            return {"signal": True, "lon": enable_lon, "lat": enable_lat}
        return {"signal": False, "lon": False, "lat": False}

    def clear_policy_anchors(self):
        self._anchor_signal = None
        self._anchor_lon = None
        self._anchor_lat = None

    def set_policy_anchors(self, signal_state=None, lon_state=None, lat_state=None):
        """Freeze-copy actors used as BC/KL anchors during joint fine-tune."""

        def _clone(module, state):
            if module is None or state is None:
                return None
            twin = copy.deepcopy(module)
            twin.load_state_dict(state)
            twin.to(self.device)
            twin.eval()
            for p in twin.parameters():
                p.requires_grad = False
            return twin

        if signal_state is not None:
            self._anchor_signal = _clone(self.signal_actor, signal_state)
        if lon_state is not None:
            self._anchor_lon = _clone(self.lon_actor, lon_state)
        if lat_state is not None:
            self._anchor_lat = _clone(self.lat_actor, lat_state)

    def set_training_stage(self, stage, coop_on=None, lambda_mode=None):
        del coop_on, lambda_mode
        stage = self._normalize_stage(stage)
        prev = getattr(self, "training_stage", None)
        self.training_stage = stage
        if stage not in JOINT_STAGES:
            self.joint_abort = False
            self.clear_policy_anchors()

        flags = self.stage_train_flags(
            stage,
            enable_lon=bool(getattr(self, "enable_longitudinal", True)),
            enable_lat=bool(getattr(self, "enable_lateral", True)),
            joint_abort=bool(getattr(self, "joint_abort", False)),
        )
        train_signal = bool(flags["signal"])
        train_lat = bool(flags["lat"])
        train_lon = bool(flags["lon"])
        train_critic = True

        def _set_req(module, flag):
            if module is None:
                return
            for p in module.parameters():
                p.requires_grad = flag

        _set_req(self.signal_actor, train_signal)
        _set_req(self.lat_actor, train_lat)
        _set_req(self.lon_actor, train_lon)
        _set_req(self.critic, train_critic)
        team_head_reset = False
        if (
            self.critic is not None
            and hasattr(self.critic, "net")
            and hasattr(self.critic, "signal_head")
        ):
            freeze_team_s = bool(getattr(self, "freeze_team_critic_in_stage_s", True))
            if stage == "S" and freeze_team_s:
                _set_req(self.critic.net, False)
                _set_req(self.critic.signal_head, True)
            elif prev == "S" and stage != "S" and freeze_team_s:
                self.reset_team_value_head()
                team_head_reset = True

        self.apply_active_actor_lr_scale(1.0)
        if self.critic_optimizer:
            for g in self.critic_optimizer.param_groups:
                g["lr"] = self.critic_lr if train_critic else 0.0

        if prev != stage:
            same_team_scale = (
                (prev == "Lon" and stage == "JointLonSig")
                or (prev == "Lat" and stage == "JointAll")
                or (prev == "JointLonSig" and stage == "Lon")
                or (prev == "JointAll" and stage == "Lat")
            )
            # F2: v5 reset (mu, sigma) here while keeping critic.net, so the
            # first flush of the new stage denormalised calibrated outputs
            # with (0, 1). PopArt (_update_ret_rms) already tracks scale
            # changes smoothly; only reset when the head itself was reset.
            if (
                prev is not None
                and not same_team_scale
                and not team_head_reset
                and bool(getattr(self, "reset_rms_on_stage_switch", False))
            ):
                self._ret_rms_mean = 0.0
                self._ret_rms_var = 1.0
                self._ret_rms_count = 1e-4
            active_heads = [h for h, f in (("signal", train_signal), ("lon", train_lon), ("lat", train_lat)) if f]
            self.reset_actor_optimizer_states(heads=active_heads)
            self._joint_sig_updates = 0
            self._anchor_mult = {"signal": 1.0, "lat": 1.0}
            self._ratio_warned = set()
            print(
                f"[MAPPO] Enter stage {stage} "
                f"(signal={train_signal}, lat={train_lat}, lon={train_lon}, "
                f"critic={train_critic}, same_team_scale={same_team_scale}, "
                f"team_head_reset={team_head_reset}, joint_abort={bool(self.joint_abort)})"
            )

    def reset_actor_optimizer_states(self, heads=None):
        """Clear Adam exp_avg / exp_avg_sq buffers after weight rollback or head unfreeze."""
        target = set(heads or ("signal", "lon", "lat"))
        mapping = (
            ("signal", self.signal_optimizer),
            ("lon", self.lon_optimizer),
            ("lat", self.lat_optimizer),
        )
        for name, opt in mapping:
            if name in target and opt is not None:
                opt.state.clear()

    # ------------------------------------------------------- signal temperature
    def current_signal_temperature(self) -> float:
        """F7: executed signal temperature (1.0 outside joint stages).

        Annealed from ``joint_signal_temp_start`` to ``joint_signal_temperature``
        over ``joint_signal_temp_anneal_updates`` *signal updates* (not
        episodes), so it never changes while the signal buffer is filling.
        """
        if self.training_stage not in JOINT_STAGES:
            return 1.0
        end = getattr(self, "joint_signal_temperature", DEFAULT_JOINT_SIGNAL_TEMPERATURE)
        try:
            end = float(end)
        except (TypeError, ValueError):
            end = DEFAULT_JOINT_SIGNAL_TEMPERATURE
        if not np.isfinite(end) or end <= 0.0:
            end = DEFAULT_JOINT_SIGNAL_TEMPERATURE
        start = getattr(self, "joint_signal_temp_start", None)
        n_anneal = int(getattr(self, "joint_signal_temp_anneal_updates", 0) or 0)
        temp = end
        if start is not None and n_anneal > 0:
            try:
                start = float(start)
            except (TypeError, ValueError):
                start = end
            frac = min(1.0, float(self._joint_sig_updates) / float(n_anneal))
            temp = start + (end - start) * frac
        return float(min(10.0, max(MIN_SIGNAL_TEMPERATURE, temp)))

    @staticmethod
    def _legal_mask(logits: torch.Tensor, action_mask=None) -> torch.Tensor:
        if torch.is_tensor(action_mask) and action_mask.shape == logits.shape:
            return action_mask > 0
        return logits > _ILLEGAL_LOGIT

    def _effective_signal_logits(self, raw_logits: torch.Tensor, action_mask=None) -> torch.Tensor:
        """Temperature on legal signal logits during joint stages.

        Shared identically by ``select_actions``, ``_update_signal_actor`` and
        the anchor KL, so epoch-0 ratios are exactly 1 and the anchor is
        compared in the same space as the executed policy (F1).
        """
        if self.training_stage not in JOINT_STAGES:
            return raw_logits
        temp = self.current_signal_temperature()
        if abs(temp - 1.0) < 1e-6:
            return raw_logits
        legal = self._legal_mask(raw_logits, action_mask)
        return torch.where(legal, raw_logits / float(temp), raw_logits)

    def apply_active_actor_lr_scale(self, scale: float):
        """Scale active-stage actor LRs; inactive stay at 0."""
        try:
            scale = float(scale)
        except (TypeError, ValueError, OverflowError):
            scale = 0.0
        scale = max(0.0, scale) if np.isfinite(scale) else 0.0
        stage = str(getattr(self, "training_stage", "S") or "S")
        base = float(self.actor_lr)
        flags = self.stage_train_flags(
            stage,
            enable_lon=bool(getattr(self, "enable_longitudinal", True)),
            enable_lat=bool(getattr(self, "enable_lateral", True)),
            joint_abort=bool(getattr(self, "joint_abort", False)),
        )

        def _rel(head: str) -> float:
            if stage == "JointLonSig":
                if head == "signal":
                    return float(getattr(self, "joint_signal_lr_scale", DEFAULT_JOINT_SIGNAL_LR_SCALE))
                if head == "lon":
                    return float(getattr(self, "joint_lon_lr_scale", DEFAULT_JOINT_LON_LR_SCALE))
            if stage == "JointAll":
                if head == "signal":
                    return float(getattr(self, "joint_all_signal_lr_scale", DEFAULT_JOINT_ALL_SIGNAL_LR_SCALE))
                if head == "lon":
                    return float(getattr(self, "joint_all_lon_lr_scale", DEFAULT_JOINT_ALL_LON_LR_SCALE))
                if head == "lat":
                    return float(getattr(self, "joint_all_lat_lr_scale", DEFAULT_JOINT_ALL_LAT_LR_SCALE))
            return 1.0

        # Optional per-head base LR (actor_lr_signal / actor_lr_lon / actor_lr_lat).
        def _base(head: str) -> float:
            v = getattr(self, f"actor_lr_{head}", None)
            try:
                return float(v) if v is not None else base
            except (TypeError, ValueError):
                return base

        if self.signal_optimizer:
            for g in self.signal_optimizer.param_groups:
                g["lr"] = (_base("signal") * scale * _rel("signal")) if flags["signal"] else 0.0
        if self.lat_optimizer:
            for g in self.lat_optimizer.param_groups:
                g["lr"] = (_base("lat") * scale * _rel("lat")) if flags["lat"] else 0.0
        if self.lon_optimizer:
            for g in self.lon_optimizer.param_groups:
                g["lr"] = (_base("lon") * scale * _rel("lon")) if flags["lon"] else 0.0

    # ------------------------------------------------------------- observations
    def _single_observation(self, obs):
        result = {
            "vector": torch.as_tensor(obs["vector"], dtype=torch.float32, device=self.device).unsqueeze(0),
            "graph": {
                "node_features": torch.as_tensor(
                    obs["graph"]["node_features"], dtype=torch.float32, device=self.device
                ),
                "edge_index": torch.as_tensor(
                    obs["graph"]["edge_index"], dtype=torch.long, device=self.device
                ),
            },
        }
        if "action_mask" in obs:
            result["action_mask"] = torch.as_tensor(
                obs["action_mask"], dtype=torch.float32, device=self.device
            ).unsqueeze(0)
        return result

    @staticmethod
    def _to_graph_data(graph):
        """Legacy static helper (no normalisation)."""
        return Data(
            x=torch.as_tensor(graph["node_features"], dtype=torch.float32),
            edge_index=torch.as_tensor(graph["edge_index"], dtype=torch.long),
        )

    def _graph_to_data(self, graph):
        x = np.asarray(graph["node_features"], dtype=np.float32)
        if self.obs_norm:
            x = np.nan_to_num(x, nan=0.0, posinf=1e6, neginf=-1e6)
            x = self._obs_rms["critic"].normalize(x)
        return Data(
            x=torch.as_tensor(x, dtype=torch.float32),
            edge_index=torch.as_tensor(graph["edge_index"], dtype=torch.long),
        )

    def _batch_graphs(self, graphs, data_list=None):
        datas = data_list if data_list is not None else [self._graph_to_data(g) for g in graphs]
        graph_batch = Batch.from_data_list(datas).to(self.device)
        lim = float(self.obs_clip) if self.obs_norm else 10.0
        x = torch.nan_to_num(graph_batch.x, nan=0.0, posinf=lim, neginf=-lim)
        x = torch.clamp(x, -lim, lim)
        return {
            "node_features": x,
            "edge_index": graph_batch.edge_index,
            "batch_index": graph_batch.batch,
        }

    def _batch_observations(self, observations, need_graph=False, head=None):
        if len(observations) == 0:
            raise ValueError("_batch_observations requires at least one observation")
        vector_array = np.stack([obs["vector"] for obs in observations]).astype(np.float32, copy=False)
        rms = self._obs_rms.get(head) if (self.obs_norm and head is not None) else None
        if rms is not None:
            vector_array = np.nan_to_num(vector_array, nan=0.0, posinf=1e6, neginf=-1e6)
            vector_array = rms.normalize(vector_array)
            lim = float(self.obs_clip)
        else:
            vector_array = np.nan_to_num(vector_array, nan=0.0, posinf=10.0, neginf=-10.0)
            lim = 10.0
        vectors = torch.as_tensor(vector_array, dtype=torch.float32, device=self.device)
        vectors = torch.clamp(vectors, -lim, lim)
        result = {"vector": vectors}
        if need_graph or bool(getattr(self, "actor_needs_graph", False)):
            result["graph"] = self._batch_graphs([obs["graph"] for obs in observations])
        if all("action_mask" in obs for obs in observations):
            mask_array = np.stack([obs["action_mask"] for obs in observations]).astype(np.float32, copy=False)
            mask_array = np.nan_to_num(mask_array, nan=0.0, posinf=0.0, neginf=0.0)
            result["action_mask"] = torch.as_tensor(mask_array, dtype=torch.float32, device=self.device)
        return result

    def _update_obs_rms(self, head: str, observations) -> int:
        rms = self._obs_rms.get(head)
        if rms is None or _seq_len(observations) == 0:
            return 0
        rows = []
        for obs in observations:
            if isinstance(obs, dict) and obs.get("vector") is not None:
                rows.append(np.asarray(obs["vector"], dtype=np.float64))
        if not rows:
            return 0
        try:
            arr = np.stack(rows)
        except ValueError:
            return 0
        arr = np.nan_to_num(arr, nan=0.0, posinf=1e6, neginf=-1e6)
        return rms.update(arr)

    def _update_graph_rms(self, graphs) -> int:
        if _seq_len(graphs) == 0:
            return 0
        chunks = []
        for g in graphs:
            if isinstance(g, dict) and g.get("node_features") is not None:
                chunks.append(np.asarray(g["node_features"], dtype=np.float64))
        if not chunks:
            return 0
        try:
            arr = np.concatenate([c.reshape(-1, c.shape[-1]) for c in chunks], axis=0)
        except ValueError:
            return 0
        arr = np.nan_to_num(arr, nan=0.0, posinf=1e6, neginf=-1e6)
        return self._obs_rms["critic"].update(arr)

    def warmup_obs_norm(self, rollouts) -> dict:
        """Fit all normalisers from a warm-up rollout (e.g. fixed-time / Max-Pressure).

        Call once before the first PPO update of a *fresh* run with obs_norm=True.
        Do not enable obs_norm on checkpoints trained without it.
        """
        used = {
            "signal": self._update_obs_rms("signal", self._pick_rollout(rollouts, "signal_obs")),
            "lon": self._update_obs_rms("lon", self._pick_rollout(rollouts, "lon_obs", "cav_obs")),
            "lat": self._update_obs_rms("lat", self._pick_rollout(rollouts, "lat_obs")),
            "critic": self._update_graph_rms(self._pick_rollout(rollouts, "global_obs")),
        }
        return used

    # ------------------------------------------------------------ act / values
    def select_actions(
        self,
        obs_dict,
        deterministic=False,
        *,
        cav_decision=True,
        cav_action_cache=None,
        cav_logp_cache=None,
    ):
        """Sample actions; on CAV hold ticks skip cached lon/lat actor forwards.

        Store ``agent.last_lat_beta`` per lat sample as ``lat_soft_betas`` in the
        rollout (F8); the signal temperature is handled internally (F7).
        """
        actions = {}
        log_probs = {}
        lon_ids = [aid for aid in obs_dict if aid.startswith("cav_lon_")]
        lat_ids = [aid for aid in obs_dict if aid.startswith("cav_lat_")]
        legacy = [
            aid
            for aid in obs_dict
            if aid.startswith("cav_") and not aid.startswith("cav_lon_") and not aid.startswith("cav_lat_")
        ]
        signal_ids = [aid for aid in obs_dict if aid.startswith("signal_")]
        stage = self.training_stage
        cache_a = cav_action_cache if isinstance(cav_action_cache, dict) else {}
        cache_lp = cav_logp_cache if isinstance(cav_logp_cache, dict) else {}
        flags = self._train_flags()
        det_signal = bool(deterministic) or (not bool(flags.get("signal", False)))
        det_lon = bool(deterministic) or (not bool(flags.get("lon", False)))
        det_lat = bool(deterministic) or (not bool(flags.get("lat", False)))

        with torch.no_grad():
            env_st = self.cav_env_stage(stage)
            emit_lon = env_st in ("Lon", "Lat") and bool(getattr(self, "enable_longitudinal", True))
            emit_lat = env_st == "Lat" and bool(getattr(self, "enable_lateral", True))

            if self.lon_actor and (lon_ids or legacy) and emit_lon:
                ids = lon_ids or legacy
                if cav_decision:
                    to_sample = list(ids)
                else:
                    to_sample = [aid for aid in ids if aid not in cache_a]
                    for agent_id in ids:
                        if agent_id not in cache_a:
                            continue
                        actions[agent_id] = cache_a[agent_id]
                        if agent_id in cache_lp:
                            log_probs[agent_id] = cache_lp[agent_id]
                if to_sample:
                    batch_obs = self._batch_observations([obs_dict[aid] for aid in to_sample], head="lon")
                    action_tensor, log_prob_tensor = self.lon_actor.get_action(batch_obs, deterministic=det_lon)
                    action_np = action_tensor.cpu().numpy()
                    log_np = log_prob_tensor.reshape(-1).cpu().numpy()
                    for index, agent_id in enumerate(to_sample):
                        actions[agent_id] = action_np[index]
                        log_probs[agent_id] = float(log_np[index])

            if self.lat_actor and lat_ids and emit_lat:
                if cav_decision:
                    batch_obs = self._batch_observations([obs_dict[aid] for aid in lat_ids], head="lat")
                    beta = float(getattr(self, "action_blend_beta", 1.0) or 1.0)
                    eff_beta = float(np.clip(beta, 0.0, 1.0)) if stage == "Lat" else 1.0
                    self._last_lat_beta = eff_beta
                    if hasattr(self.lat_actor, "get_action"):
                        action_tensor, log_prob_tensor = self.lat_actor.get_action(
                            batch_obs, deterministic=det_lat, soft_start_beta=eff_beta,
                        )
                    else:
                        logits = self._lat_forward(batch_obs, eff_beta)
                        dist = Categorical(logits=logits)
                        action_tensor = torch.argmax(logits, dim=-1) if det_lat else dist.sample()
                        log_prob_tensor = dist.log_prob(action_tensor)
                    action_np = action_tensor.detach().cpu().numpy().reshape(-1)
                    log_np = log_prob_tensor.detach().reshape(-1).cpu().numpy()
                    for index, agent_id in enumerate(lat_ids):
                        actions[agent_id] = int(action_np[index])
                        log_probs[agent_id] = float(log_np[index])
                else:
                    for agent_id in lat_ids:
                        actions[agent_id] = 1

            if self.signal_actor and signal_ids:
                batch_obs = self._batch_observations([obs_dict[aid] for aid in signal_ids], head="signal")
                logits = self._effective_signal_logits(
                    self.signal_actor(batch_obs), batch_obs.get("action_mask")
                )
                dist = Categorical(logits=logits)
                action_tensor = torch.argmax(logits, dim=-1) if det_signal else dist.sample()
                log_prob_tensor = dist.log_prob(action_tensor)
                action_np = action_tensor.detach().cpu().numpy()
                log_np = log_prob_tensor.detach().cpu().numpy()
                for index, agent_id in enumerate(signal_ids):
                    actions[agent_id] = int(action_np[index])
                    log_probs[agent_id] = float(log_np[index])

        return actions, log_probs

    @property
    def last_lat_beta(self) -> float:
        return float(self._last_lat_beta)

    def reset_team_value_head(self) -> None:
        """Reset ``critic.net`` and team return RMS before CAV stages (keep GNN + signal_head)."""
        if self.critic is not None and hasattr(self.critic, "reset_team_head"):
            self.critic.reset_team_head()
            if hasattr(self.critic, "net"):
                for p in self.critic.net.parameters():
                    p.requires_grad = True
        self._ret_rms_mean = 0.0
        self._ret_rms_var = 1.0
        self._ret_rms_count = 1e-4

    def _ret_rms_std(self) -> float:
        return float(math.sqrt(max(float(self._ret_rms_var), 1e-8)))

    def _update_ret_rms(self, returns) -> None:
        """EMA update of team return statistics with PopArt output preservation."""
        batch = np.asarray(returns, dtype=np.float64).reshape(-1)
        if batch.size == 0 or not np.isfinite(batch).all():
            return
        batch_mean = float(batch.mean())
        batch_var = max(float(batch.var(ddof=0)), 1e-4)
        if float(self._ret_rms_count) <= 1e-3:
            self._ret_rms_mean = batch_mean
            self._ret_rms_var = batch_var
            self._ret_rms_count = float(batch.size)
            return
        old_mean, old_std = float(self._ret_rms_mean), float(self._ret_rms_std())
        alpha = float(getattr(self, "ret_rms_alpha", 0.15))
        delta = batch_mean - float(self._ret_rms_mean)
        self._ret_rms_mean = float((1.0 - alpha) * float(self._ret_rms_mean) + alpha * batch_mean)
        self._ret_rms_var = float(
            max((1.0 - alpha) * float(self._ret_rms_var) + alpha * batch_var + alpha * (1.0 - alpha) * (delta ** 2), 1e-4)
        )
        self._ret_rms_count = float(min(1e6, float(self._ret_rms_count) + float(batch.size)))
        self._popart_preserve(
            getattr(getattr(self, "critic", None), "net", None),
            old_mean, old_std, float(self._ret_rms_mean), float(self._ret_rms_std()),
        )

    def _popart_preserve(self, head, old_mean, old_std, new_mean, new_std) -> None:
        """PopArt output preservation (van Hasselt et al., 2016)."""
        if not bool(getattr(self, "popart_enabled", True)) or head is None:
            return
        try:
            layer = head[-1] if isinstance(head, torch.nn.Sequential) else head
            if not isinstance(layer, torch.nn.Linear):
                return
            new_std = max(float(new_std), 1e-8)
            scale = float(old_std) / new_std
            shift = (float(old_mean) - float(new_mean)) / new_std
            if not (np.isfinite(scale) and np.isfinite(shift)):
                return
            with torch.no_grad():
                layer.weight.mul_(scale)
                layer.bias.mul_(scale).add_(shift)
        except Exception as exc:  # pragma: no cover - defensive
            print(f"[PopArt] skip rescale: {exc}", flush=True)

    def _sig_ret_rms_std(self) -> float:
        return float(math.sqrt(max(float(self._sig_ret_rms_var), 1e-8)))

    def _update_sig_ret_rms(self, signal_returns) -> None:
        batch = np.asarray(signal_returns, dtype=np.float64).reshape(-1)
        if batch.size == 0 or not np.isfinite(batch).all():
            return
        batch_mean = float(batch.mean())
        batch_var = max(float(batch.var(ddof=0)), 1e-4)
        if float(self._sig_ret_rms_count) <= 1e-3:
            self._sig_ret_rms_mean = batch_mean
            self._sig_ret_rms_var = batch_var
            self._sig_ret_rms_count = float(batch.size)
            return
        old_mean, old_std = float(self._sig_ret_rms_mean), float(self._sig_ret_rms_std())
        alpha = float(getattr(self, "sig_ret_rms_alpha", 0.12))
        delta = batch_mean - float(self._sig_ret_rms_mean)
        self._sig_ret_rms_mean = float((1.0 - alpha) * float(self._sig_ret_rms_mean) + alpha * batch_mean)
        self._sig_ret_rms_var = float(
            max((1.0 - alpha) * float(self._sig_ret_rms_var) + alpha * batch_var + alpha * (1.0 - alpha) * (delta ** 2), 1e-4)
        )
        self._sig_ret_rms_count = float(min(1e6, float(self._sig_ret_rms_count) + float(batch.size)))
        self._popart_preserve(
            getattr(getattr(self, "critic", None), "signal_head", None),
            old_mean, old_std, float(self._sig_ret_rms_mean), float(self._sig_ret_rms_std()),
        )

    def _denormalize_value(self, raw_val: float) -> float:
        return float(raw_val * self._ret_rms_std() + float(self._ret_rms_mean))

    def _denormalize_signal_value(self, raw_sig_val: float) -> float:
        return float(raw_sig_val * self._sig_ret_rms_std() + float(self._sig_ret_rms_mean))

    def get_value(self, global_graph):
        if self.critic is None:
            return 0.0
        graph_data = self._batch_graphs([global_graph])
        with torch.no_grad():
            value = self.critic(graph_data).reshape(-1)
            if value.numel() == 0 or not bool(torch.isfinite(value).all()):
                return 0.0
            raw = float(value[0].detach().cpu().item())
            if not np.isfinite(raw):
                return 0.0
            return self._denormalize_value(raw)

    def get_signal_value(self, global_graph):
        if self.critic is None:
            return 0.0
        if not hasattr(self.critic, "forward_signal"):
            return self.get_value(global_graph)
        graph_data = self._batch_graphs([global_graph])
        with torch.no_grad():
            value = self.critic.forward_signal(graph_data).reshape(-1)
            if value.numel() == 0 or not bool(torch.isfinite(value).all()):
                return 0.0
            raw = float(value[0].detach().cpu().item())
            if not np.isfinite(raw):
                return 0.0
            return self._denormalize_signal_value(raw)

    def get_dual_values(self, global_graph):
        """Single-pass GNN evaluation returning (team_value, signal_value) in raw scale."""
        if self.critic is None:
            return 0.0, 0.0
        if not hasattr(self.critic, "forward_dual"):
            vt = self.get_value(global_graph)
            return vt, vt
        graph_data = self._batch_graphs([global_graph])
        with torch.no_grad():
            v_team, v_sig = self.critic.forward_dual(graph_data)
            vt_t = v_team.reshape(-1)
            vs_t = v_sig.reshape(-1)
            vt = (
                self._denormalize_value(float(vt_t[0].detach().cpu().item()))
                if vt_t.numel() > 0 and bool(torch.isfinite(vt_t).all())
                else 0.0
            )
            vs = (
                self._denormalize_signal_value(float(vs_t[0].detach().cpu().item()))
                if vs_t.numel() > 0 and bool(torch.isfinite(vs_t).all())
                else vt
            )
            return vt, vs

    def batch_dual_values(self, global_graphs, chunk_size: int = 256):
        """F12: (team_values, signal_values) for a whole rollout in raw scale.

        Bit-for-bit equivalent to calling get_dual_values per step as long as it
        runs *before* update() (critic and normalisers only change inside
        update). Replacing the per-step critic call in train_RL removes one PyG
        batch + GNN forward per simulation step.
        """
        n = _seq_len(global_graphs)
        team = np.zeros(n, dtype=np.float32)
        sig = np.zeros(n, dtype=np.float32)
        if self.critic is None or n == 0:
            return team, sig
        has_dual = hasattr(self.critic, "forward_dual")
        t_mu, t_sd = float(self._ret_rms_mean), self._ret_rms_std()
        s_mu, s_sd = float(self._sig_ret_rms_mean), self._sig_ret_rms_std()
        step = max(1, int(chunk_size))
        with torch.no_grad():
            for s in range(0, n, step):
                chunk = [global_graphs[i] for i in range(s, min(n, s + step))]
                gd = self._batch_graphs(chunk)
                if has_dual:
                    vt, vs = self.critic.forward_dual(gd)
                else:
                    vt = self.critic(gd)
                    vs = None
                vt = vt.reshape(-1).float().cpu().numpy().astype(np.float64)
                vt_raw = np.where(np.isfinite(vt), vt * t_sd + t_mu, 0.0)
                team[s:s + len(chunk)] = vt_raw
                if vs is not None:
                    vs = vs.reshape(-1).float().cpu().numpy().astype(np.float64)
                    sig[s:s + len(chunk)] = np.where(np.isfinite(vs), vs * s_sd + s_mu, vt_raw)
                else:
                    sig[s:s + len(chunk)] = vt_raw
        return team, sig

    def individual_values(self, obs) -> dict:
        """V(g(s) ⊕ o_i) for each CAV observation. Empty when the head is off."""
        if self.critic is None or not hasattr(self.critic, "forward_individual"):
            return {}
        if not isinstance(obs, dict):
            return {}
        keys, rows = [], []
        for key, item in obs.items():
            if not str(key).startswith("cav_"):
                continue
            vector = (item or {}).get("vector") if isinstance(item, dict) else None
            if vector is None:
                continue
            keys.append(str(key))
            rows.append(np.nan_to_num(np.asarray(vector, dtype=np.float32).reshape(-1)))
        if not keys:
            return {}
        graph = obs.get("__graph__")
        if not isinstance(graph, dict):
            graph = {
                "node_features": obs.get("node_features"),
                "edge_index": obs.get("edge_index"),
                "batch_index": obs.get("batch_index"),
            }
        if graph.get("node_features") is None:
            return {}
        graph_data = self._batch_graphs([graph])
        width = max(int(r.size) for r in rows)
        packed = np.zeros((len(rows), width), dtype=np.float32)
        for i, row in enumerate(rows):
            packed[i, : row.size] = row
        with torch.no_grad():
            values = self.critic.forward_individual(graph_data, packed).reshape(-1)
            values = values.detach().cpu().numpy()
        out = {}
        for key, raw in zip(keys, values):
            raw = float(raw)
            out[key] = self._denormalize_value(raw) if np.isfinite(raw) else 0.0
        return out

    def fit_individual(self, samples, max_samples=64) -> float:
        """One regression step of V(g ⊕ o_i) toward per-agent returns.

        F4: v5 evaluated every sample against ``graphs[0]`` (the first sample's
        global state). v6 groups samples by their own graph object.
        Each sample is (vector, target_return, global_graph).
        """
        if (
            self.critic is None
            or not getattr(self, "individual_critic", False)
            or not samples
            or self.critic_optimizer is None
        ):
            return 0.0
        batch = list(samples)[: int(max_samples)]
        groups = {}
        for i, s in enumerate(batch):
            groups.setdefault(id(s[2]), []).append(i)
        mean = float(self._ret_rms_mean)
        std = max(float(self._ret_rms_std()), 1e-3)
        self.critic_optimizer.zero_grad(set_to_none=True)
        total = None
        count = 0
        for idxs in groups.values():
            graph = batch[idxs[0]][2]
            if not isinstance(graph, dict) or graph.get("node_features") is None:
                continue
            vectors = [np.nan_to_num(np.asarray(batch[i][0], dtype=np.float32).reshape(-1)) for i in idxs]
            width = max(int(v.size) for v in vectors)
            packed = np.zeros((len(vectors), width), dtype=np.float32)
            for j, row in enumerate(vectors):
                packed[j, : row.size] = row
            graph_data = self._batch_graphs([graph])
            pred = self.critic.forward_individual(graph_data, packed).reshape(-1)
            tgt = torch.as_tensor([float(batch[i][1]) for i in idxs], dtype=torch.float32, device=self.device)
            tgt = ((tgt - mean) / std).reshape(-1)
            if pred.numel() != tgt.numel():
                continue
            sq = ((pred - tgt) ** 2).sum()
            total = sq if total is None else total + sq
            count += len(idxs)
        if total is None or count == 0:
            return 0.0
        loss = total / float(count)
        if not bool(torch.isfinite(loss)):
            return 0.0
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.critic.parameters(), self.max_grad_norm)
        self.critic_optimizer.step()
        return float(loss.detach().cpu().item())

    def compute_gae(
        self,
        rewards,
        values,
        dones,
        next_value=0.0,
        gamma=None,
        gae_lambda=None,
        decision_mask=None,
        truncateds=None,
        bootstrap_values=None,
    ):
        """SMDP GAE; pass ``truncateds`` (+ ``bootstrap_values``) for time limits (F3)."""
        rewards = np.asarray(rewards, dtype=np.float32).reshape(-1)
        values = np.asarray(values, dtype=np.float32).reshape(-1)
        dones = np.asarray(dones, dtype=np.float32).reshape(-1)
        if not (len(rewards) == len(values) == len(dones)):
            raise ValueError("compute_gae expects rewards, values, and dones with equal lengths")
        if not (np.isfinite(rewards).all() and np.isfinite(values).all() and np.isfinite(dones).all()):
            raise ValueError("compute_gae received non-finite rollout data")
        try:
            gamma = float(self.gamma if gamma is None else gamma)
        except (TypeError, ValueError, OverflowError):
            gamma = float(self.gamma)
        try:
            gae_lambda = float(self.gae_lambda if gae_lambda is None else gae_lambda)
        except (TypeError, ValueError, OverflowError):
            gae_lambda = float(self.gae_lambda)
        if not np.isfinite(gamma) or gamma <= 0.0:
            gamma = float(self.gamma)
        if not np.isfinite(gae_lambda) or gae_lambda <= 0.0:
            gae_lambda = float(self.gae_lambda)
        dec_arr = None
        if decision_mask is not None and len(decision_mask) == len(rewards):
            dec_arr = np.asarray(decision_mask, dtype=bool).reshape(-1)
        tr_arr = None
        if truncateds is not None and _seq_len(truncateds) == len(rewards):
            tr_arr = np.asarray(truncateds, dtype=bool).reshape(-1)
        bv_arr = None
        if bootstrap_values is not None and _seq_len(bootstrap_values) == len(rewards):
            bv_arr = np.asarray(bootstrap_values, dtype=np.float64).reshape(-1)
        return smdp_gae(
            rewards, values, dones, next_value=next_value, gamma=gamma,
            gae_lambda=gae_lambda, decision_mask=dec_arr,
            truncateds=tr_arr, bootstrap_values=bv_arr,
        )

    # --------------------------------------------------------------- PPO core
    def _minibatches(self, size):
        """F12: evenly sized minibatches (v5 could emit a 1-3 sample tail batch)."""
        size = max(0, int(size))
        if size == 0:
            return
        n_mb = max(1, int(math.ceil(size / float(self.minibatch_size))))
        perm = np.random.permutation(size)
        for chunk in np.array_split(perm, n_mb):
            if chunk.size:
                yield chunk

    @staticmethod
    def _pick_rollout(rollouts, *keys):
        """Fetch first non-empty rollout field; safe for ndarray (no truth-value tests)."""
        for key in keys:
            val = rollouts.get(key)
            if val is None:
                continue
            if isinstance(val, np.ndarray) and val.size == 0:
                continue
            if isinstance(val, (list, tuple)) and len(val) == 0:
                continue
            return val
        return []

    @staticmethod
    def _signal_epoch_cap(n_sig, ppo_epochs, force_one=False):
        """Limit PPO epochs on tiny signal flushes to slow entropy collapse."""
        n = int(n_sig)
        epochs = max(1, int(ppo_epochs))
        if force_one or (0 < n < 8):
            return 1
        if 0 < n < 32:
            return min(2, epochs)
        return epochs

    def _entropy_coef_for(self, head: str) -> float:
        v = getattr(self, f"entropy_coef_{head}", None)
        try:
            return float(v) if v is not None else float(self.entropy_coef)
        except (TypeError, ValueError):
            return float(self.entropy_coef)

    def _kl_limit(self, head: str) -> float:
        tgt = getattr(self, f"target_kl_{head}", None)
        try:
            tgt = float(tgt) if tgt is not None else float(self.TARGET_KL)
        except (TypeError, ValueError):
            tgt = float(self.TARGET_KL)
        factor = float(getattr(self, "kl_stop_factor", 1.5) or 1.5)
        return tgt * factor

    def _dual_clip_loss(self, new_log_probs, old_log_probs, advantages, entropy_term, entropy_coef=None):
        """PPO clip plus Dual-Clip (Ye et al., AAAI 2020) on negative advantages."""
        coef = float(self.entropy_coef if entropy_coef is None else entropy_coef)
        log_ratio = new_log_probs - old_log_probs
        log_ratio = torch.clamp(log_ratio, min=-20.0, max=20.0)
        ratio = torch.exp(log_ratio)
        s1 = ratio * advantages
        s2 = torch.clamp(ratio, 1.0 - self.clip_param, 1.0 + self.clip_param) * advantages
        surr = torch.min(s1, s2)
        dual_clip = max(1.0 + float(self.clip_param) + 1e-3, float(getattr(self, "dual_clip_c", 3.0)))
        surr = torch.where(advantages < 0, torch.max(surr, dual_clip * advantages), surr)
        loss = -surr.mean() - coef * entropy_term
        with torch.no_grad():
            approx_kl = float(((ratio - 1.0) - log_ratio).mean().item())
            self._last_clipfrac = float(((ratio - 1.0).abs() > self.clip_param).float().mean().item())
        return loss, approx_kl

    def _check_epoch0_ratio(self, head: str, new_log_probs, old_log_probs) -> float:
        """F9: at epoch 0 / first minibatch the policy is the behaviour policy.

        Any deviation means the distribution PPO evaluates is not the one that
        generated the data (tanh/atanh inversion at bounds, soft-start beta,
        temperature, observation normaliser, dropout, stale log-probs ...).
        """
        with torch.no_grad():
            dev = (new_log_probs.detach().reshape(-1) - old_log_probs.reshape(-1)).abs()
            mean_dev = float(dev.mean().item()) if dev.numel() else 0.0
            max_dev = float(dev.max().item()) if dev.numel() else 0.0
        self._epoch0_ratio_dev[head] = mean_dev
        tol = float(getattr(self, "ratio_check_tol", 1e-3))
        if (mean_dev > tol or max_dev > 50.0 * tol) and head not in self._ratio_warned:
            self._ratio_warned.add(head)
            print(
                f"[MAPPO][WARN] {head}: epoch-0 |log pi_new - log pi_old| mean={mean_dev:.2e} "
                f"max={max_dev:.2e}. The PPO evaluation distribution differs from the "
                f"sampling distribution; ratios/clipping/KL-stop are biased until fixed.",
                flush=True,
            )
        return mean_dev

    def _train_flags(self):
        return self.stage_train_flags(
            self.training_stage,
            enable_lon=bool(getattr(self, "enable_longitudinal", True)),
            enable_lat=bool(getattr(self, "enable_lateral", True)),
            joint_abort=bool(getattr(self, "joint_abort", False)),
        )

    def _anchor_coef(self, head: str, base: float) -> float:
        if not bool(getattr(self, "anchor_kl_adaptive", True)):
            return float(base)
        return float(base) * float(self._anchor_mult.get(head, 1.0))

    def _anchor_bc_discrete(self, logits, anchor_module, batch_obs, coef: float, tempered: bool = False):
        """Full-support KL(pi_anchor || pi_theta) on the legal support.

        F1: with ``tempered=True`` the anchor logits go through the same
        temperature as the policy logits, so the KL is 0 at the anchor and
        does not fight the joint-stage sharpening. Returns (loss, kl_value).
        """
        if anchor_module is None or coef <= 0.0:
            return None, None
        action_mask = batch_obs.get("action_mask") if isinstance(batch_obs, dict) else None
        with torch.no_grad():
            a_logits = anchor_module(batch_obs)
            if not bool(torch.isfinite(a_logits).all()):
                return None, None
            if tempered:
                a_logits = self._effective_signal_logits(a_logits, action_mask)
            legal = self._legal_mask(a_logits, action_mask) & self._legal_mask(logits.detach(), action_mask)
            row_ok = legal.any(dim=-1)
            if not bool(row_ok.any()):
                return None, None
            lg = legal[row_ok]
            p = F.softmax(a_logits[row_ok].masked_fill(~lg, float("-inf")), dim=-1)
            log_p = torch.where(lg, torch.log(p.clamp_min(1e-12)), torch.zeros_like(p))
        q_logits = logits[row_ok].masked_fill(~lg, float("-inf"))
        log_q = F.log_softmax(q_logits, dim=-1)
        log_q = torch.where(lg, log_q, torch.zeros_like(log_q))
        kl = (p * (log_p - log_q)).sum(dim=-1).mean()
        if not bool(torch.isfinite(kl)):
            return None, None
        return float(coef) * kl, float(kl.detach().item())

    def _anchor_bc_continuous(self, batch_obs, batch_actions, coef: float):
        """Bounded Smooth-L1 + latent W2 toward frozen lon anchor."""
        del batch_actions
        if self._anchor_lon is None or coef <= 0.0 or self.lon_actor is None:
            return None
        if not hasattr(self.lon_actor, "anchor_loss"):
            return None
        try:
            bc = self.lon_actor.anchor_loss(batch_obs, self._anchor_lon)
        except Exception:
            return None
        if bc is None or not bool(torch.isfinite(bc)):
            return None
        return float(coef) * bc

    @staticmethod
    def _zero_dof_keep(observations):
        keep = []
        for i, obs in enumerate(observations):
            mask = obs.get("action_mask") if isinstance(obs, dict) else None
            if mask is None:
                keep.append(i)
                continue
            if int(np.sum(np.asarray(mask, dtype=np.float32).reshape(-1) > 0)) <= 1:
                continue
            keep.append(i)
        return keep

    @staticmethod
    def _filter_zero_dof_discrete(observations, actions, old_log_probs, advantages):
        """Drop samples whose action_mask has ≤1 legal action (zero freedom)."""
        keep = MAPPOAgent._zero_dof_keep(observations)
        if not keep:
            return [], np.zeros(0, dtype=actions.dtype), np.zeros(0, dtype=np.float32), np.zeros(0, dtype=np.float32)
        if len(keep) == len(observations):
            return observations, actions, old_log_probs, advantages
        idx = np.asarray(keep, dtype=np.int64)
        return [observations[i] for i in idx], actions[idx], old_log_probs[idx], advantages[idx]

    # ---------------------------------------------------------- lat helpers F8
    def _lat_forward(self, batch_obs, beta: float):
        """Logits of the distribution get_action samples from at ``beta``.

        Requires lat_actor.forward(obs, soft_start_beta=beta) to return the
        *blended* logits whenever beta < 1. If the actor does not accept the
        argument we fall back to raw logits and the F9 check will report it.
        """
        if beta >= 1.0 - 1e-6:
            return self.lat_actor(batch_obs)
        try:
            return self.lat_actor(batch_obs, soft_start_beta=float(beta))
        except TypeError:
            if "lat_beta_api" not in self._ratio_warned:
                self._ratio_warned.add("lat_beta_api")
                print(
                    "[MAPPO][WARN] lat_actor.forward() does not accept soft_start_beta; "
                    "PPO evaluates raw logits while rollouts were sampled at beta<1. "
                    "Implement forward(obs, soft_start_beta=1.0) returning the blended logits.",
                    flush=True,
                )
            return self.lat_actor(batch_obs)

    def _slice_obs(self, batch_obs, sel_np):
        idx = torch.as_tensor(np.asarray(sel_np, dtype=np.int64), dtype=torch.long, device=self.device)
        n_total = int(batch_obs["vector"].shape[0])
        out = {}
        for k, v in batch_obs.items():
            if torch.is_tensor(v) and v.dim() > 0 and int(v.shape[0]) == n_total:
                out[k] = v.index_select(0, idx)
            elif k == "graph":
                continue  # actors do not read the graph (v4 perf note)
            else:
                out[k] = v
        return out

    def _lat_logits(self, batch_obs, betas_np):
        b = np.asarray(betas_np, dtype=np.float64).reshape(-1)
        uniq = np.unique(np.round(b, 6))
        if uniq.size <= 1:
            return self._lat_forward(batch_obs, float(uniq[0]) if uniq.size else 1.0)
        out = None
        for val in uniq:
            sel = np.where(np.abs(b - val) < 1e-6)[0]
            lg = self._lat_forward(self._slice_obs(batch_obs, sel), float(val))
            if out is None:
                out = lg.new_zeros((b.size, lg.shape[-1]))
            out = out.index_copy(0, torch.as_tensor(sel, dtype=torch.long, device=lg.device), lg)
        return out

    # ------------------------------------------------------------ actor updates
    def _update_lon_actor(self, rollouts, epoch=0):
        self._last_approx_kl = 0.0
        self._last_clipfrac = 0.0
        if not self._train_flags()["lon"] or self.lon_actor is None or self.lon_optimizer is None:
            return 0.0
        observations = self._pick_rollout(rollouts, "lon_obs", "cav_obs")
        if _seq_len(observations) == 0:
            return 0.0
        actions = np.asarray(self._pick_rollout(rollouts, "lon_actions", "cav_actions"), dtype=np.float32).reshape(-1, 1)
        old_log_probs = np.asarray(self._pick_rollout(rollouts, "lon_log_probs", "cav_log_probs"), dtype=np.float32).reshape(-1)
        sample_advantages = np.asarray(
            self._pick_rollout(rollouts, "lon_ind_advantages", "ind_advantages"), dtype=np.float32
        ).reshape(-1)
        n = _seq_len(observations)
        if not (len(actions) == len(old_log_probs) == len(sample_advantages) == n):
            return 0.0
        if not (np.isfinite(actions).all() and np.isfinite(old_log_probs).all() and np.isfinite(sample_advantages).all()):
            return 0.0

        bc_coef = (
            float(getattr(self, "anchor_bc_coef_lon", 0.0) or 0.0)
            if self.training_stage in JOINT_STAGES and self._anchor_lon is not None
            else 0.0
        )
        im_coef = float(getattr(self, "imitation_coef", 0.0) or 0.0)
        applied = self._pick_rollout(rollouts, "lon_applied_actions", "applied_cav_actions")
        applied_np = None
        if im_coef > 0.0 and hasattr(self.lon_actor, "imitation_loss") and _seq_len(applied) == n:
            try:
                applied_np = np.asarray(applied, dtype=np.float32)
            except (TypeError, ValueError):
                applied_np = None
        ent_coef = self._entropy_coef_for("lon")
        kl_limit = self._kl_limit("lon")
        losses = []
        first = True
        for batch_indices in self._minibatches(n):
            batch_obs = self._batch_observations([observations[i] for i in batch_indices], head="lon")
            batch_actions = torch.as_tensor(actions[batch_indices], dtype=torch.float32, device=self.device)
            batch_old_logs = torch.as_tensor(old_log_probs[batch_indices], dtype=torch.float32, device=self.device)
            batch_advantages = torch.as_tensor(sample_advantages[batch_indices], dtype=torch.float32, device=self.device)
            new_log_probs, entropy = self.lon_actor.evaluate_actions(batch_obs, batch_actions)
            new_log_probs = new_log_probs.reshape(-1)
            entropy = entropy.reshape(-1)
            if not bool(torch.isfinite(new_log_probs).all() and torch.isfinite(entropy).all()):
                continue
            if first and int(epoch) == 0:
                self._check_epoch0_ratio("lon", new_log_probs, batch_old_logs)
            first = False
            loss, approx_kl = self._dual_clip_loss(
                new_log_probs, batch_old_logs, batch_advantages, entropy.mean(), entropy_coef=ent_coef
            )
            self._last_approx_kl = max(self._last_approx_kl, approx_kl)
            if approx_kl > kl_limit:
                break
            bc = self._anchor_bc_continuous(batch_obs, batch_actions, bc_coef)
            if bc is not None:
                loss = loss + bc
            if applied_np is not None:
                try:
                    app_t = torch.as_tensor(applied_np[batch_indices], dtype=torch.float32, device=self.device)
                    im = self.lon_actor.imitation_loss(batch_obs, app_t)
                    if im is not None and bool(torch.isfinite(im)):
                        loss = loss + im_coef * im
                except Exception:
                    pass
            if not bool(torch.isfinite(loss)):
                continue
            self.lon_optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(self.lon_actor.parameters(), self.max_grad_norm)
            self.lon_optimizer.step()
            losses.append(float(loss.detach().item()))
        return float(np.mean(losses)) if losses else 0.0

    def _update_lat_actor(self, rollouts, epoch=0):
        self._last_approx_kl = 0.0
        self._last_clipfrac = 0.0
        if not self._train_flags()["lat"] or self.lat_actor is None or self.lat_optimizer is None:
            return 0.0
        observations = self._pick_rollout(rollouts, "lat_obs")
        if _seq_len(observations) == 0:
            return 0.0
        actions = np.asarray(self._pick_rollout(rollouts, "lat_actions"), dtype=np.int64).reshape(-1)
        old_log_probs = np.asarray(self._pick_rollout(rollouts, "lat_log_probs"), dtype=np.float32).reshape(-1)
        sample_advantages = np.asarray(self._pick_rollout(rollouts, "lat_ind_advantages"), dtype=np.float32).reshape(-1)
        n = _seq_len(observations)
        if not (len(actions) == len(old_log_probs) == len(sample_advantages) == n):
            return 0.0
        if not (np.isfinite(old_log_probs).all() and np.isfinite(sample_advantages).all()):
            return 0.0
        raw_betas = self._pick_rollout(rollouts, "lat_soft_betas")
        if _seq_len(raw_betas) == n:
            betas = np.clip(np.asarray(raw_betas, dtype=np.float64).reshape(-1), 0.0, 1.0)
        else:
            default_beta = float(self._last_lat_beta) if self.training_stage == "Lat" else 1.0
            betas = np.full(n, default_beta, dtype=np.float64)
        keep = self._zero_dof_keep(observations)
        if not keep:
            return 0.0
        if len(keep) < n:
            idx = np.asarray(keep, dtype=np.int64)
            observations = [observations[i] for i in idx]
            actions, old_log_probs = actions[idx], old_log_probs[idx]
            sample_advantages, betas = sample_advantages[idx], betas[idx]
            n = len(observations)

        bc_base = (
            float(getattr(self, "anchor_bc_coef_lat", 0.0) or 0.0)
            if self.training_stage in JOINT_STAGES and self._anchor_lat is not None
            else 0.0
        )
        bc_coef = self._anchor_coef("lat", bc_base)
        ent_coef = self._entropy_coef_for("lat")
        kl_limit = self._kl_limit("lat")
        losses = []
        first = True
        for batch_indices in self._minibatches(n):
            batch_obs = self._batch_observations([observations[i] for i in batch_indices], head="lat")
            logits = self._lat_logits(batch_obs, betas[batch_indices])
            if not bool(torch.isfinite(logits).all()):
                continue
            dist = Categorical(logits=logits)
            batch_actions = torch.as_tensor(actions[batch_indices], dtype=torch.long, device=self.device)
            batch_old_logs = torch.as_tensor(old_log_probs[batch_indices], dtype=torch.float32, device=self.device)
            batch_advantages = torch.as_tensor(sample_advantages[batch_indices], dtype=torch.float32, device=self.device)
            new_log_probs = dist.log_prob(batch_actions)
            entropy = dist.entropy()
            if not bool(torch.isfinite(new_log_probs).all() and torch.isfinite(entropy).all()):
                continue
            if first and int(epoch) == 0:
                self._check_epoch0_ratio("lat", new_log_probs, batch_old_logs)
            first = False
            loss, approx_kl = self._dual_clip_loss(
                new_log_probs, batch_old_logs, batch_advantages, entropy.mean(), entropy_coef=ent_coef
            )
            self._last_approx_kl = max(self._last_approx_kl, approx_kl)
            if approx_kl > kl_limit:
                break
            bc, kl_val = self._anchor_bc_discrete(logits, self._anchor_lat, batch_obs, bc_coef, tempered=False)
            if bc is not None:
                loss = loss + bc
                self._anchor_kl_obs["lat"].append(kl_val)
            if not bool(torch.isfinite(loss)):
                continue
            self.lat_optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(self.lat_actor.parameters(), self.max_grad_norm)
            self.lat_optimizer.step()
            losses.append(float(loss.detach().item()))
        return float(np.mean(losses)) if losses else 0.0

    def _update_signal_actor(self, rollouts, epoch=0):
        self._last_approx_kl = 0.0
        self._last_clipfrac = 0.0
        beta_t = float(
            getattr(self, "teacher_beta", None)
            if getattr(self, "teacher_beta", None) is not None
            else getattr(self, "signal_teacher_beta", 0.0)
            or 0.0
        )
        if not np.isfinite(beta_t) or beta_t < 0.0:
            beta_t = 0.0
        conf_thr = float(getattr(self, "teacher_conf_threshold", TEACHER_CONFIDENCE_THRESHOLD) or TEACHER_CONFIDENCE_THRESHOLD)
        empty_stats = self._empty_teacher_stats(beta_t)
        if not self._train_flags()["signal"] or self.signal_actor is None or self.signal_optimizer is None:
            self._last_teacher_stats = empty_stats
            return 0.0
        observations = self._pick_rollout(rollouts, "signal_obs")
        if _seq_len(observations) == 0:
            self._last_teacher_stats = empty_stats
            return 0.0
        actions = np.asarray(self._pick_rollout(rollouts, "signal_actions"), dtype=np.int64).reshape(-1)
        old_log_probs = np.asarray(self._pick_rollout(rollouts, "signal_log_probs"), dtype=np.float32).reshape(-1)
        sample_advantages = np.asarray(self._pick_rollout(rollouts, "signal_ind_advantages"), dtype=np.float32).reshape(-1)
        joint_mode = self.training_stage in JOINT_STAGES
        if joint_mode:
            adv_scale = float(getattr(self, "joint_signal_adv_scale", DEFAULT_JOINT_SIGNAL_ADV_SCALE) or 1.0)
            if np.isfinite(adv_scale) and adv_scale != 1.0:
                sample_advantages = sample_advantages * adv_scale
        raw_t_actions = self._pick_rollout(rollouts, "signal_teacher_actions")
        raw_t_confs = self._pick_rollout(rollouts, "signal_teacher_confs")
        raw_t_sevs = self._pick_rollout(rollouts, "signal_teacher_severities")
        n = _seq_len(observations)
        if _seq_len(raw_t_actions) == n and _seq_len(raw_t_confs) == n:
            teacher_actions = np.asarray(raw_t_actions, dtype=np.int64).reshape(-1)
            teacher_confs = np.asarray(raw_t_confs, dtype=np.float32).reshape(-1)
        else:
            teacher_actions = np.full(n, -1, dtype=np.int64)
            teacher_confs = np.zeros(n, dtype=np.float32)
        if _seq_len(raw_t_sevs) == n:
            teacher_sevs = np.asarray(raw_t_sevs, dtype=np.float32).reshape(-1)
            teacher_sevs = np.clip(np.where(np.isfinite(teacher_sevs), teacher_sevs, 0.0), 0.0, 1.0)
        else:
            teacher_sevs = np.where((teacher_actions >= 0) & (teacher_confs >= conf_thr), 1.0, 0.0).astype(np.float32)
        if not (len(actions) == len(old_log_probs) == len(sample_advantages) == n):
            self._last_teacher_stats = empty_stats
            return 0.0
        if not (np.isfinite(old_log_probs).all() and np.isfinite(sample_advantages).all()):
            self._last_teacher_stats = empty_stats
            return 0.0

        keep_idx = self._zero_dof_keep(observations)
        if not keep_idx:
            self._last_teacher_stats = empty_stats
            return 0.0
        if len(keep_idx) < n:
            idx = np.asarray(keep_idx, dtype=np.int64)
            observations = [observations[i] for i in idx]
            actions, old_log_probs = actions[idx], old_log_probs[idx]
            sample_advantages = sample_advantages[idx]
            teacher_actions, teacher_confs, teacher_sevs = teacher_actions[idx], teacher_confs[idx], teacher_sevs[idx]
            n = len(observations)

        valid_mask_np = (teacher_actions >= 0) & (teacher_confs >= conf_thr)
        valid_total = int(np.sum(valid_mask_np))
        agree_total = int(np.sum(valid_mask_np & (actions == teacher_actions)))
        sev_mean = float(np.mean(teacher_sevs[valid_mask_np])) if valid_total > 0 else 0.0
        argmax_agree = 0.0
        if valid_total > 0:
            with torch.no_grad():
                vidx = np.where(valid_mask_np)[0]
                bo = self._batch_observations([observations[i] for i in vidx], head="signal")
                am = torch.argmax(self._effective_signal_logits(self.signal_actor(bo), bo.get("action_mask")), dim=-1)
                argmax_agree = float((am.cpu().numpy() == teacher_actions[vidx]).mean())

        losses, teacher_losses, entropies, grad_norms = [], [], [], []
        bc_base = (
            float(getattr(self, "anchor_bc_coef_signal", 0.0) or 0.0)
            if joint_mode and self._anchor_signal is not None
            else 0.0
        )
        bc_coef = self._anchor_coef("signal", bc_base)
        ent_scale = (
            float(getattr(self, "joint_signal_entropy_scale", DEFAULT_JOINT_SIGNAL_ENTROPY_SCALE) or 1.0)
            if joint_mode
            else 1.0
        )
        ent_coef = self._entropy_coef_for("signal") * (max(0.0, ent_scale) if np.isfinite(ent_scale) else 1.0)
        kl_limit = self._kl_limit("signal")
        first = True
        for batch_indices in self._minibatches(n):
            batch_obs = self._batch_observations([observations[i] for i in batch_indices], head="signal")
            raw_logits = self.signal_actor(batch_obs)
            if not bool(torch.isfinite(raw_logits).all()):
                continue
            logits = self._effective_signal_logits(raw_logits, batch_obs.get("action_mask"))
            dist = Categorical(logits=logits)
            batch_actions = torch.as_tensor(actions[batch_indices], dtype=torch.long, device=self.device)
            batch_old_logs = torch.as_tensor(old_log_probs[batch_indices], dtype=torch.float32, device=self.device)
            batch_advantages = torch.as_tensor(sample_advantages[batch_indices], dtype=torch.float32, device=self.device)
            new_log_probs = dist.log_prob(batch_actions)
            entropy = dist.entropy()
            if not bool(torch.isfinite(new_log_probs).all() and torch.isfinite(entropy).all()):
                continue
            if first and int(epoch) == 0:
                self._check_epoch0_ratio("signal", new_log_probs, batch_old_logs)
            first = False
            ppo_loss, approx_kl = self._dual_clip_loss(
                new_log_probs, batch_old_logs, batch_advantages, entropy.mean(), entropy_coef=ent_coef
            )
            self._last_approx_kl = max(self._last_approx_kl, approx_kl)
            if approx_kl > kl_limit:
                break
            if not bool(torch.isfinite(ppo_loss)):
                continue
            loss = ppo_loss
            bc, kl_val = self._anchor_bc_discrete(logits, self._anchor_signal, batch_obs, bc_coef, tempered=True)
            if bc is not None:
                loss = loss + bc
                self._anchor_kl_obs["signal"].append(kl_val)
            if beta_t > 0.0:
                b_t_act = torch.as_tensor(teacher_actions[batch_indices], dtype=torch.long, device=self.device)
                b_t_conf = torch.as_tensor(teacher_confs[batch_indices], dtype=torch.float32, device=self.device)
                b_t_sev = torch.as_tensor(teacher_sevs[batch_indices], dtype=torch.float32, device=self.device)
                valid_mask = (b_t_act >= 0) & (b_t_conf >= conf_thr) & (b_t_sev > 0.0)
                if bool(valid_mask.any()):
                    t_log_probs = dist.log_prob(torch.clamp(b_t_act, min=0))[valid_mask]
                    w = b_t_sev[valid_mask]
                    teacher_loss = -(w * t_log_probs).sum() / torch.clamp(w.sum(), min=1e-8)
                    if bool(torch.isfinite(teacher_loss)):
                        loss = loss + beta_t * teacher_loss
                        teacher_losses.append(float(teacher_loss.detach().item()))
            if not bool(torch.isfinite(loss)):
                continue
            self.signal_optimizer.zero_grad(set_to_none=True)
            loss.backward()
            grad_norm = torch.nn.utils.clip_grad_norm_(self.signal_actor.parameters(), self.max_grad_norm)
            try:
                grad_norms.append(float(grad_norm.detach().item()) if torch.is_tensor(grad_norm) else float(grad_norm))
            except (TypeError, ValueError, OverflowError):
                pass
            self.signal_optimizer.step()
            losses.append(float(loss.detach().item()))
            entropies.append(float(entropy.mean().detach().item()))

        agree_rate = float(agree_total) / float(valid_total) if valid_total > 0 else 0.0
        ent = float(np.mean(entropies)) if entropies else 0.0
        gnorm = float(np.mean(grad_norms)) if grad_norms else 0.0
        t_loss = float(np.mean(teacher_losses)) if teacher_losses else 0.0
        self._last_teacher_stats = {
            "valid_samples": int(valid_total),
            "teacher_valid_samples": float(valid_total),
            "teacher_loss": t_loss,
            "teacher_beta": float(beta_t),
            "teacher_severity_mean": float(sev_mean),
            "agreement_rate": float(agree_rate),
            "teacher_agreement_rate": float(agree_rate),
            "teacher_argmax_agreement": float(argmax_agree),
            "entropy": ent,
            "signal_entropy": ent,
            "grad_norm": gnorm,
            "signal_grad_norm": gnorm,
        }
        return float(np.mean(losses)) if losses else 0.0

    # ------------------------------------------------------------------ critic
    def _update_critic(self, global_graphs, returns, signal_returns=None, graph_data_list=None):
        self._last_sig_critic_loss = 0.0
        if self.critic is None or self.critic_optimizer is None:
            return 0.0
        if not any(p.requires_grad for p in self.critic.parameters()):
            return 0.0
        returns = np.asarray(returns, dtype=np.float32).reshape(-1)
        n = _seq_len(global_graphs)
        if n == 0 or len(returns) != n or not np.isfinite(returns).all():
            return 0.0
        if graph_data_list is None or len(graph_data_list) != n:
            graph_data_list = [self._graph_to_data(g) for g in global_graphs]
        std = self._ret_rms_std()
        normed = (returns - float(self._ret_rms_mean)) / (std + 1e-8)

        use_dual = False
        sig_normed = None
        if signal_returns is not None and hasattr(self.critic, "forward_dual"):
            sig_arr = np.asarray(signal_returns, dtype=np.float32).reshape(-1)
            if len(sig_arr) == n and np.isfinite(sig_arr).all():
                sig_normed = (sig_arr - float(self._sig_ret_rms_mean)) / (self._sig_ret_rms_std() + 1e-8)
                use_dual = True
        team_frozen = (
            str(getattr(self, "training_stage", "")) == "S"
            and bool(getattr(self, "freeze_team_critic_in_stage_s", True))
        ) or (
            hasattr(self.critic, "net") and not any(p.requires_grad for p in self.critic.net.parameters())
        )
        sig_w = float(getattr(self, "signal_critic_loss_weight", 0.5))

        losses, sig_losses = [], []
        for batch_indices in self._minibatches(n):
            batched = self._batch_graphs(None, data_list=[graph_data_list[i] for i in batch_indices])
            targets = torch.clamp(
                torch.as_tensor(normed[batch_indices], dtype=torch.float32, device=self.device), -10.0, 10.0
            )
            if use_dual and sig_normed is not None:
                pred_team_raw, pred_sig_raw = self.critic.forward_dual(batched)
                predicted = pred_team_raw.reshape(-1)
                pred_sig = pred_sig_raw.reshape(-1)
                if (
                    predicted.numel() != len(batch_indices)
                    or pred_sig.numel() != len(batch_indices)
                    or not bool(torch.isfinite(predicted).all())
                    or not bool(torch.isfinite(pred_sig).all())
                ):
                    continue
                sig_tgt = torch.clamp(
                    torch.as_tensor(sig_normed[batch_indices], dtype=torch.float32, device=self.device), -10.0, 10.0
                )
                loss_sig = F.smooth_l1_loss(pred_sig, sig_tgt, beta=1.0)
                if team_frozen:
                    loss = loss_sig
                else:
                    loss = F.smooth_l1_loss(predicted, targets, beta=1.0) + sig_w * loss_sig
                if not bool(torch.isfinite(loss)):
                    continue
                sig_losses.append(float(loss_sig.detach().item()))
            else:
                predicted = self.critic(batched).reshape(-1)
                if predicted.numel() != len(batch_indices) or not bool(torch.isfinite(predicted).all()):
                    continue
                loss = F.smooth_l1_loss(predicted, targets, beta=1.0)
                if not bool(torch.isfinite(loss)):
                    continue
            self.critic_optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(self.critic.parameters(), self.max_grad_norm)
            self.critic_optimizer.step()
            losses.append(float(loss.detach().item()))
        self._last_sig_critic_loss = float(np.mean(sig_losses)) if sig_losses else 0.0
        return float(np.mean(losses)) if losses else 0.0

    # ------------------------------------------------------------------ update
    def _filter_zero_dof_rollouts(self, rollouts) -> None:
        """F5: v5 used `if not raw` on rollout fields -> ValueError for ndarrays."""
        for obs_key, keys in (
            ("lat_obs", ("lat_obs", "lat_actions", "lat_log_probs", "lat_ind_advantages", "lat_soft_betas")),
            ("signal_obs", SIGNAL_SAMPLE_KEYS),
        ):
            obs_list = self._pick_rollout(rollouts, obs_key)
            n_obs = _seq_len(obs_list)
            if n_obs == 0:
                continue
            keep = self._zero_dof_keep(obs_list)
            if len(keep) == n_obs:
                continue
            if not keep:
                for k in keys:
                    if k in rollouts:
                        rollouts[k] = []
                continue
            idx = np.asarray(keep, dtype=np.int64)
            for k in keys:
                raw = self._pick_rollout(rollouts, k)
                if _seq_len(raw) != n_obs:
                    continue
                if k.endswith("_obs"):
                    rollouts[k] = [raw[i] for i in idx]
                else:
                    arr = np.asarray(raw)
                    if arr.ndim == 0:
                        continue
                    rollouts[k] = arr[idx]

    def _adapt_anchor_mult(self) -> dict:
        """F10: dual ascent on the anchor coefficient toward anchor_kl_target."""
        out = {}
        lo, hi = self.anchor_mult_bounds
        tgt = float(getattr(self, "anchor_kl_target", DEFAULT_ANCHOR_KL_TARGET))
        for head in ("signal", "lat"):
            obs = [v for v in self._anchor_kl_obs.get(head, []) if v is not None and np.isfinite(v)]
            self._anchor_kl_obs[head] = []
            if not obs:
                continue
            kl = float(np.mean(obs))
            out[head] = kl
            if not bool(getattr(self, "anchor_kl_adaptive", True)) or tgt <= 0.0:
                continue
            m = float(self._anchor_mult.get(head, 1.0))
            if kl > 1.5 * tgt:
                m *= 1.5
            elif kl < tgt / 1.5:
                m /= 1.5
            self._anchor_mult[head] = float(min(hi, max(lo, m)))
        return out

    def update(self, rollouts):
        global_graphs = self._pick_rollout(rollouts, "global_obs")
        beta_now = float(getattr(self, "teacher_beta", getattr(self, "signal_teacher_beta", 0.0)) or 0.0)
        empty = {
            "lon_actor": 0.0, "lat_actor": 0.0, "signal_actor": 0.0, "critic": 0.0,
            "signal_critic": 0.0, "cav_actor": 0.0, "teacher_valid_samples": 0.0,
            "teacher_loss": 0.0, "teacher_beta": beta_now, "teacher_severity_mean": 0.0,
            "teacher_agreement_rate": 0.0, "teacher_argmax_agreement": 0.0,
            "signal_entropy": 0.0, "signal_grad_norm": 0.0,
        }
        n_glob = _seq_len(global_graphs)
        if n_glob == 0:
            return empty
        for h in ("signal", "lat"):
            self._anchor_kl_obs[h] = []

        returns = np.asarray(self._pick_rollout(rollouts, "team_returns", "returns"), dtype=np.float32).reshape(-1)
        raw_sig_returns = self._pick_rollout(rollouts, "signal_returns")
        sig_returns = (
            np.asarray(raw_sig_returns, dtype=np.float32).reshape(-1)
            if _seq_len(raw_sig_returns) == n_glob
            else None
        )
        if not (
            str(getattr(self, "training_stage", "")) == "S"
            and bool(getattr(self, "freeze_team_critic_in_stage_s", True))
        ):
            self._update_ret_rms(returns)
        if sig_returns is not None:
            self._update_sig_ret_rms(sig_returns)

        self._filter_zero_dof_rollouts(rollouts)

        _smb = int(getattr(self, "signal_min_batch", 0) or 0)
        if _smb > 0 and bool(self._train_flags().get("signal", False)):
            _buf = getattr(self, "_signal_buffer", None)
            if _buf is None or int(_buf.min_batch) != _smb:
                _buf = SignalSampleBuffer(_smb)
                self._signal_buffer = _buf
            signature = (round(self.current_signal_temperature(), 4), bool(self.joint_abort))
            _buf.add(rollouts, str(getattr(self, "training_stage", "")), pick=self._pick_rollout, signature=signature)
            if _buf.ready():
                rollouts.update(_buf.release())
                self._signal_deferred = False
            else:
                for _k in SIGNAL_SAMPLE_KEYS:
                    rollouts[_k] = []
                self._signal_deferred = True
        else:
            self._signal_buffer = None
            self._signal_deferred = False

        for key in ("ind_advantages", "lon_ind_advantages", "lat_ind_advantages", "signal_ind_advantages"):
            raw_adv = self._pick_rollout(rollouts, key)
            adv = np.asarray(raw_adv, dtype=np.float32).reshape(-1)
            if adv.size > 1 and np.isfinite(adv).all():
                rollouts[key] = (adv - adv.mean()) / (adv.std(ddof=0) + 1e-8)
            elif adv.size:
                rollouts[key] = adv

        graph_data_list = [self._graph_to_data(g) for g in global_graphs]
        hist = {"lon_actor": [], "lat_actor": [], "signal_actor": [], "critic": [], "signal_critic": []}
        kl_stop = {"lon_actor": False, "lat_actor": False, "signal_actor": False}
        kl_seen = {"lon_actor": 0.0, "lat_actor": 0.0, "signal_actor": 0.0}
        clipfrac = {"lon_actor": [], "lat_actor": [], "signal_actor": []}
        n_sig = _seq_len(self._pick_rollout(rollouts, "signal_obs"))
        signal_epoch_cap = self._signal_epoch_cap(
            n_sig, self.ppo_epochs, force_one=bool(getattr(self, "_force_signal_one_epoch", False))
        )
        teacher_acc = {
            "teacher_valid_samples": [], "teacher_loss": [], "teacher_beta": [],
            "teacher_severity_mean": [], "teacher_agreement_rate": [],
            "teacher_argmax_agreement": [], "signal_entropy": [], "signal_grad_norm": [],
        }
        for epoch in range(self.ppo_epochs):
            for name, fn, lim_head in (
                ("lon_actor", self._update_lon_actor, "lon"),
                ("lat_actor", self._update_lat_actor, "lat"),
            ):
                if kl_stop[name]:
                    continue
                hist[name].append(fn(rollouts, epoch=epoch))
                kl_seen[name] = max(kl_seen[name], float(self._last_approx_kl))
                clipfrac[name].append(float(self._last_clipfrac))
                if float(self._last_approx_kl) > self._kl_limit(lim_head):
                    kl_stop[name] = True
            if epoch < signal_epoch_cap and not kl_stop["signal_actor"]:
                hist["signal_actor"].append(self._update_signal_actor(rollouts, epoch=epoch))
                kl_seen["signal_actor"] = max(kl_seen["signal_actor"], float(self._last_approx_kl))
                clipfrac["signal_actor"].append(float(self._last_clipfrac))
                stats = getattr(self, "_last_teacher_stats", {}) or {}
                for key in teacher_acc:
                    teacher_acc[key].append(float(stats.get(key, 0.0)))
                if float(self._last_approx_kl) > self._kl_limit("signal"):
                    kl_stop["signal_actor"] = True
            hist["critic"].append(
                self._update_critic(global_graphs, returns, signal_returns=sig_returns, graph_data_list=graph_data_list)
            )
            hist["signal_critic"].append(float(getattr(self, "_last_sig_critic_loss", 0.0)))

        flags = self._train_flags()
        signal_ran = bool(flags.get("signal", False)) and n_sig > 0
        if signal_ran and self.training_stage in JOINT_STAGES:
            self._joint_sig_updates += 1  # F7: temperature advances per signal update
        anchor_kl = self._adapt_anchor_mult()

        # F6: normalisers move only after the samples were consumed.
        if self.obs_norm:
            if flags.get("lon", False):
                self._update_obs_rms("lon", self._pick_rollout(rollouts, "lon_obs", "cav_obs"))
            if flags.get("lat", False):
                self._update_obs_rms("lat", self._pick_rollout(rollouts, "lat_obs"))
            if signal_ran:
                self._update_obs_rms("signal", self._pick_rollout(rollouts, "signal_obs"))
            self._update_graph_rms(global_graphs)

        av_stats = self._update_agent_value(rollouts)

        out = {k: float(np.mean(v)) if v else 0.0 for k, v in hist.items()}
        out.update({f"diag/{k}": float(v) for k, v in av_stats.items()})
        out["agent_value"] = float(av_stats.get("agent_value_loss", 0.0))
        for key, vals in teacher_acc.items():
            if key == "teacher_valid_samples":
                out[key] = float(vals[0]) if vals else 0.0
            else:
                out[key] = float(np.mean(vals)) if vals else 0.0
        env_st = self.cav_env_stage(self.training_stage)
        out["cav_actor"] = out["lat_actor"] if env_st == "Lat" else out["lon_actor"]
        # v6 diagnostics (TensorBoard friendly)
        for name in ("lon_actor", "lat_actor", "signal_actor"):
            out[f"diag/{name}_approx_kl"] = float(kl_seen[name])
            out[f"diag/{name}_clipfrac"] = float(np.mean(clipfrac[name])) if clipfrac[name] else 0.0
            out[f"diag/{name}_kl_stopped"] = float(kl_stop[name])
        for h in _HEADS:
            out[f"diag/{h}_epoch0_logratio_dev"] = float(self._epoch0_ratio_dev.get(h, 0.0))
        out["diag/signal_temperature"] = float(self.current_signal_temperature())
        out["diag/signal_deferred"] = float(bool(self._signal_deferred))
        out["diag/signal_samples"] = float(n_sig)
        for h in ("signal", "lat"):
            out[f"diag/anchor_kl_{h}"] = float(anchor_kl.get(h, 0.0))
            out[f"diag/anchor_mult_{h}"] = float(self._anchor_mult.get(h, 1.0))
        out["diag/ret_rms_mean"] = float(self._ret_rms_mean)
        out["diag/ret_rms_std"] = float(self._ret_rms_std())
        out["diag/sig_ret_rms_std"] = float(self._sig_ret_rms_std())
        return out

    # ------------------------------------------------------- v7 agent value
    def attach_agent_value_net(self, net, lr=None) -> None:
        """Register the per-agent value net (agents/agent_value.AgentValueNet)."""
        self.agent_value_net = net
        if net is None:
            self.agent_value_optimizer = None
            return
        if lr is not None:
            self.agent_value_lr = float(lr)
        net.to(self.device)
        self.agent_value_optimizer = optim.Adam(net.parameters(), lr=float(self.agent_value_lr))

    def agent_values(self, inputs, chunk_size: int = 4096) -> np.ndarray:
        """Raw-scale V for a batch of value inputs [N, D]. Empty -> shape (0,)."""
        arr = np.asarray(inputs, dtype=np.float32)
        if self.agent_value_net is None or arr.size == 0:
            return np.zeros(int(arr.shape[0]) if arr.ndim > 0 else 0, dtype=np.float32)
        if arr.ndim == 1:
            arr = arr.reshape(1, -1)
        outs = []
        self.agent_value_net.eval()
        with torch.no_grad():
            for s in range(0, arr.shape[0], max(1, int(chunk_size))):
                x = torch.as_tensor(arr[s:s + chunk_size], dtype=torch.float32, device=self.device)
                outs.append(self.agent_value_net(x).reshape(-1).float().cpu().numpy())
        self.agent_value_net.train()
        y = np.concatenate(outs) if outs else np.zeros(0, dtype=np.float32)
        raw = self.agent_value_norm.denormalize(y)
        return np.where(np.isfinite(raw), raw, 0.0).astype(np.float32)

    def _update_agent_value(self, rollouts) -> dict:
        """Regress V(o_i (+) c) on option-level GAE returns (normalised + PopArt)."""
        stats = {"agent_value_loss": 0.0, "agent_value_ev": 0.0, "agent_value_n": 0.0}
        net, opt = self.agent_value_net, self.agent_value_optimizer
        x_raw = self._pick_rollout(rollouts, "v7_value_inputs")
        y_raw = self._pick_rollout(rollouts, "v7_value_returns")
        n = _seq_len(x_raw)
        if net is None or opt is None or n == 0 or _seq_len(y_raw) != n:
            self._last_agent_value_stats = stats
            return stats
        try:
            X = np.stack([np.asarray(v, dtype=np.float32).reshape(-1) for v in x_raw])
        except ValueError:
            self._last_agent_value_stats = stats
            return stats
        Y = np.asarray(y_raw, dtype=np.float64).reshape(-1)
        ok = np.isfinite(Y) & np.isfinite(X).all(axis=1)
        X, Y = X[ok], Y[ok]
        n = int(Y.shape[0])
        if n == 0:
            self._last_agent_value_stats = stats
            return stats
        old_m, old_s = self.agent_value_norm.stats()
        self.agent_value_norm.update(Y)
        new_m, new_s = self.agent_value_norm.stats()
        self._popart_preserve(getattr(net, "last_linear", None), old_m, old_s, new_m, new_s)
        target = np.clip(self.agent_value_norm.normalize(Y), -10.0, 10.0).astype(np.float32)
        Xt = torch.as_tensor(X, dtype=torch.float32, device=self.device)
        Tt = torch.as_tensor(target, dtype=torch.float32, device=self.device)
        epochs = int(self.agent_value_epochs or self.ppo_epochs)
        mb = max(32, int(self.agent_value_minibatch))
        losses = []
        for _ in range(max(1, epochs)):
            perm = np.random.permutation(n)
            for chunk in np.array_split(perm, max(1, int(math.ceil(n / float(mb))))):
                if chunk.size == 0:
                    continue
                idx = torch.as_tensor(chunk, dtype=torch.long, device=self.device)
                pred = net(Xt.index_select(0, idx)).reshape(-1)
                loss = F.smooth_l1_loss(pred, Tt.index_select(0, idx), beta=1.0)
                if not bool(torch.isfinite(loss)):
                    continue
                opt.zero_grad(set_to_none=True)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(net.parameters(), float(self.agent_value_max_grad_norm))
                opt.step()
                losses.append(float(loss.detach().item()))
        with torch.no_grad():
            pred_raw = self.agent_value_norm.denormalize(net(Xt).reshape(-1).float().cpu().numpy())
        var_y = float(np.var(Y))
        ev = 1.0 - float(np.var(Y - pred_raw)) / var_y if var_y > 1e-12 else 0.0
        stats = {"agent_value_loss": float(np.mean(losses)) if losses else 0.0,
                 "agent_value_ev": float(ev), "agent_value_n": float(n)}
        self._last_agent_value_stats = stats
        return stats

    # ------------------------------------------------------------- persistence
    def export_state(self) -> dict:
        """Non-module training state added by v7 (train_RL already saves the
        team/signal return RMS; this adds the agent-value norm, observation
        normalisers, temperature-anneal progress and anchor multipliers)."""
        return {
            "version": 6,
            "training_stage": self.training_stage,
            "ret_rms": [float(self._ret_rms_mean), float(self._ret_rms_var), float(self._ret_rms_count)],
            "sig_ret_rms": [float(self._sig_ret_rms_mean), float(self._sig_ret_rms_var), float(self._sig_ret_rms_count)],
            "obs_norm": bool(self.obs_norm),
            "obs_clip": float(self.obs_clip),
            "obs_rms": {h: rms.state_dict() for h, rms in self._obs_rms.items()},
            "joint_sig_updates": int(self._joint_sig_updates),
            "anchor_mult": dict(self._anchor_mult),
            "joint_abort": bool(self.joint_abort),
            "agent_value_norm": self.agent_value_norm.state_dict(),
        }

    def import_state(self, state: dict) -> None:
        if not state:
            return
        rr = state.get("ret_rms")
        if rr and len(rr) == 3:
            self._ret_rms_mean, self._ret_rms_var, self._ret_rms_count = (float(x) for x in rr)
        sr = state.get("sig_ret_rms")
        if sr and len(sr) == 3:
            self._sig_ret_rms_mean, self._sig_ret_rms_var, self._sig_ret_rms_count = (float(x) for x in sr)
        if "obs_norm" in state:
            self.obs_norm = bool(state["obs_norm"])
        if "obs_clip" in state:
            self.obs_clip = float(state["obs_clip"])
        for h, sd in (state.get("obs_rms") or {}).items():
            if h not in self._obs_rms:
                self._obs_rms[h] = RunningMeanStd(clip=self.obs_clip, name=h)
            self._obs_rms[h].load_state_dict(sd)
        self._joint_sig_updates = int(state.get("joint_sig_updates", 0))
        am = state.get("anchor_mult")
        if isinstance(am, dict):
            self._anchor_mult.update({k: float(v) for k, v in am.items()})
        self.joint_abort = bool(state.get("joint_abort", self.joint_abort))
        if isinstance(state.get("agent_value_norm"), dict):
            self.agent_value_norm.load_state_dict(state["agent_value_norm"])
