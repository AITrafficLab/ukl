"""Optional running observation normalisation. Pure numpy, unit-tested.

Not needed for the shipped env: marl_env / cav_state_builder already scale
every actor and graph feature to O(1) (clipped to <= 2.5), so ``obs_norm``
stays False by default. Kept for new feature sets with raw physical units.

PPO-exactness rules if enabled: statistics are updated only after a PPO
update consumed the samples; each actor head has its own normaliser, updated
only while that head trains; Welford merging so the transform converges.
"""
from __future__ import annotations

from typing import Dict, Optional

import numpy as np


class RunningMeanStd:
    def __init__(self, clip: float = 10.0, min_std: float = 1e-2, eps: float = 1e-4,
                 name: str = "", max_rows_per_update: int = 200_000):
        self.clip = float(clip)
        self.min_std = float(min_std)
        self.name = str(name)
        self.max_rows = int(max_rows_per_update)
        self.mean: Optional[np.ndarray] = None
        self.var: Optional[np.ndarray] = None
        self.count: float = float(eps)
        self.frozen = False
        self.disabled = False

    @property
    def dim(self) -> Optional[int]:
        return None if self.mean is None else int(self.mean.shape[0])

    @property
    def initialised(self) -> bool:
        return self.mean is not None and self.count > 1.0

    def update(self, x) -> int:
        """Merge a batch (..., dim). Non-finite rows are ignored. Returns rows used."""
        if self.frozen or self.disabled:
            return 0
        arr = np.asarray(x, dtype=np.float64)
        if arr.size == 0:
            return 0
        if arr.ndim == 1:
            arr = arr.reshape(1, -1)
        arr = arr.reshape(-1, arr.shape[-1])
        arr = arr[np.isfinite(arr).all(axis=1)]
        if arr.shape[0] == 0:
            return 0
        if self.max_rows > 0 and arr.shape[0] > self.max_rows:
            idx = np.random.default_rng(arr.shape[0]).choice(arr.shape[0], self.max_rows, replace=False)
            arr = arr[idx]
        if self.mean is None:
            self.mean = np.zeros(arr.shape[1], dtype=np.float64)
            self.var = np.ones(arr.shape[1], dtype=np.float64)
        if arr.shape[1] != self.mean.shape[0]:
            print(
                f"[RunningMeanStd:{self.name}] feature dim changed "
                f"{self.mean.shape[0]} -> {arr.shape[1]}; normaliser disabled",
                flush=True,
            )
            self.disabled = True
            return 0
        b_mean = arr.mean(axis=0)
        b_var = arr.var(axis=0)
        b_n = float(arr.shape[0])
        delta = b_mean - self.mean
        tot = self.count + b_n
        new_mean = self.mean + delta * (b_n / tot)
        m2 = self.var * self.count + b_var * b_n + delta ** 2 * self.count * b_n / tot
        self.mean = new_mean
        self.var = np.maximum(m2 / tot, 0.0)
        self.count = tot
        return int(b_n)

    def normalize(self, x) -> np.ndarray:
        arr = np.asarray(x, dtype=np.float32)
        if self.disabled or self.mean is None or arr.shape[-1] != self.mean.shape[0]:
            return np.clip(arr, -self.clip, self.clip).astype(np.float32, copy=False)
        std = np.maximum(np.sqrt(self.var), self.min_std)
        out = (arr - self.mean.astype(np.float32)) / std.astype(np.float32)
        return np.clip(out, -self.clip, self.clip).astype(np.float32, copy=False)

    def state_dict(self) -> Dict[str, object]:
        return {
            "mean": None if self.mean is None else self.mean.tolist(),
            "var": None if self.var is None else self.var.tolist(),
            "count": float(self.count),
            "clip": self.clip,
            "min_std": self.min_std,
            "frozen": bool(self.frozen),
            "disabled": bool(self.disabled),
        }

    def load_state_dict(self, state: Dict[str, object]) -> None:
        if not state:
            return
        self.mean = None if state.get("mean") is None else np.asarray(state["mean"], dtype=np.float64)
        self.var = None if state.get("var") is None else np.asarray(state["var"], dtype=np.float64)
        self.count = float(state.get("count", 1e-4))
        self.clip = float(state.get("clip", self.clip))
        self.min_std = float(state.get("min_std", self.min_std))
        self.frozen = bool(state.get("frozen", False))
        self.disabled = bool(state.get("disabled", False))
