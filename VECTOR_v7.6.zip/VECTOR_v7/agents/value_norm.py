"""Debiased EMA value normalisation (MAPPO ValueNorm, Yu et al. 2022). Pure numpy.

The agent value net predicts normalised returns; ``denormalize`` maps back to
the raw return scale used by GAE. Statistics move only inside
``MAPPOAgent.update`` (after values for the flush were computed), and the
caller applies PopArt output preservation on the net's last layer.
"""
from __future__ import annotations

from typing import Dict

import numpy as np


class ValueNorm:
    def __init__(self, beta: float = 0.995, eps: float = 1e-5, min_std: float = 1e-2):
        self.beta = float(beta)
        self.eps = float(eps)
        self.min_std = float(min_std)
        self.running_mean = 0.0
        self.running_mean_sq = 0.0
        self.debias = 0.0

    @property
    def ready(self) -> bool:
        return self.debias > self.eps

    def stats(self):
        if not self.ready:
            return 0.0, 1.0
        mean = self.running_mean / self.debias
        mean_sq = self.running_mean_sq / self.debias
        var = max(mean_sq - mean * mean, self.min_std ** 2)
        return float(mean), float(np.sqrt(var))

    def update(self, x) -> None:
        arr = np.asarray(x, dtype=np.float64).reshape(-1)
        arr = arr[np.isfinite(arr)]
        if arr.size == 0:
            return
        w = self.beta
        self.running_mean = w * self.running_mean + (1.0 - w) * float(arr.mean())
        self.running_mean_sq = w * self.running_mean_sq + (1.0 - w) * float((arr ** 2).mean())
        self.debias = w * self.debias + (1.0 - w)

    def normalize(self, x):
        m, s = self.stats()
        return (np.asarray(x, dtype=np.float64) - m) / s

    def denormalize(self, y):
        m, s = self.stats()
        return np.asarray(y, dtype=np.float64) * s + m

    def state_dict(self) -> Dict[str, float]:
        return {"beta": self.beta, "running_mean": self.running_mean,
                "running_mean_sq": self.running_mean_sq, "debias": self.debias}

    def load_state_dict(self, d: Dict[str, float]) -> None:
        if not d:
            return
        self.beta = float(d.get("beta", self.beta))
        self.running_mean = float(d.get("running_mean", 0.0))
        self.running_mean_sq = float(d.get("running_mean_sq", 0.0))
        self.debias = float(d.get("debias", 0.0))
