"""Signal-actor sample accumulation across flushes (VECTOR v5 batch 1.3, v6 guard).

v4 updated the signal actor on every flush (~1024 sim steps), i.e. on only
~20-35 decisions, with advantage normalisation over that handful of samples.
This buffer holds the samples until ``min_batch`` decisions are available.

On-policy guarantee: the buffered samples are only valid while the *sampling
distribution* is unchanged. v5 keyed the buffer on the training stage only.
v6 keys it on ``(stage, signature)`` where the signature captures everything
else that changes the executed signal distribution (joint-stage temperature,
joint_abort). Any change discards the buffer instead of silently mixing
samples from different behaviour policies.
Pure python/numpy so it is unit-tested without torch.
"""
from __future__ import annotations

from typing import Callable, Dict, Hashable, List, Optional

import numpy as np

SIGNAL_SAMPLE_KEYS = (
    "signal_obs",
    "signal_actions",
    "signal_log_probs",
    "signal_ind_advantages",
    "signal_teacher_actions",
    "signal_teacher_confs",
    "signal_teacher_severities",
    "signal_step_indices",
)
_DEFAULTS = {
    "signal_teacher_actions": -1,
    "signal_teacher_confs": 0.0,
    "signal_teacher_severities": 0.0,
    "signal_step_indices": -1,
}
_DTYPES = {
    "signal_actions": np.int64,
    "signal_log_probs": np.float32,
    "signal_ind_advantages": np.float32,
    "signal_teacher_actions": np.int64,
    "signal_teacher_confs": np.float32,
    "signal_teacher_severities": np.float32,
    "signal_step_indices": np.int64,
}


def _as_list(x) -> List:
    if x is None:
        return []
    if isinstance(x, np.ndarray):
        return list(x.reshape(-1)) if x.ndim > 0 else [x.item()]
    return list(x)


class SignalSampleBuffer:
    def __init__(self, min_batch: int = 128):
        self.min_batch = max(0, int(min_batch))
        self.stage: Optional[str] = None
        self.signature: Optional[Hashable] = None
        self.discarded = 0  # samples thrown away due to behaviour-policy change
        self._data: Dict[str, List] = {k: [] for k in SIGNAL_SAMPLE_KEYS}

    def __len__(self) -> int:
        return len(self._data["signal_obs"])

    def clear(self) -> None:
        self._data = {k: [] for k in SIGNAL_SAMPLE_KEYS}

    def add(self, rollouts, stage: str, pick: Optional[Callable] = None,
            signature: Optional[Hashable] = None) -> int:
        """Append this flush's signal samples (already single-legal filtered)."""
        if stage != self.stage or signature != self.signature:
            self.discarded += len(self)
            self.clear()
            self.stage = stage
            self.signature = signature
        get = pick or (lambda r, k: r.get(k, []))
        obs = _as_list(get(rollouts, "signal_obs"))
        n = len(obs)
        if n == 0:
            return 0
        cols = {"signal_obs": obs}
        for k in SIGNAL_SAMPLE_KEYS[1:]:
            vals = _as_list(get(rollouts, k))
            if len(vals) != n:
                if k in _DEFAULTS:
                    vals = [_DEFAULTS[k]] * n
                else:
                    raise ValueError(f"signal buffer: misaligned '{k}' ({len(vals)} != {n})")
            cols[k] = vals
        for k in SIGNAL_SAMPLE_KEYS:
            self._data[k].extend(cols[k])
        return n

    def ready(self) -> bool:
        return self.min_batch <= 0 or len(self) >= self.min_batch

    def release(self) -> Dict[str, object]:
        out: Dict[str, object] = {"signal_obs": list(self._data["signal_obs"])}
        for k, dt in _DTYPES.items():
            out[k] = np.asarray(self._data[k], dtype=dt)
        self.clear()
        return out
