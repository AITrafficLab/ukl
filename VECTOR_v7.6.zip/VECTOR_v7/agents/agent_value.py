"""Per-agent value network V(o_i (+) c) for CAV credit assignment (VECTOR v7).

Input = agent-specific global state (MAPPO "AS" state): the CAV's own
normalised observation concatenated with the shared signal observation
(phase, timers, per-phase queue/count/wait[, pressure]). A plain MLP is
enough here: inputs are already scaled to O(1) by the env builders, it is
evaluated in one batch per flush, and it avoids the v6-P1 individual head,
which shared the GNN critic optimizer, regressed one step per flush on the
first 64 samples only and paired every sample with graphs[0].
"""
from __future__ import annotations

import math

import torch
import torch.nn as nn


class AgentValueNet(nn.Module):
    def __init__(self, in_dim: int, hidden_dim: int = 128):
        super().__init__()
        self.in_dim = int(in_dim)
        self.net = nn.Sequential(
            nn.Linear(self.in_dim, hidden_dim), nn.Tanh(),
            nn.Linear(hidden_dim, hidden_dim), nn.Tanh(),
            nn.Linear(hidden_dim, 1),
        )
        for m in (self.net[0], self.net[2]):
            nn.init.orthogonal_(m.weight, gain=math.sqrt(2.0))
            nn.init.zeros_(m.bias)
        nn.init.orthogonal_(self.net[4].weight, gain=1.0)
        nn.init.zeros_(self.net[4].bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = torch.nan_to_num(x, nan=0.0, posinf=5.0, neginf=-5.0).clamp(-10.0, 10.0)
        return self.net(x).squeeze(-1)

    @property
    def last_linear(self) -> nn.Linear:
        return self.net[4]
