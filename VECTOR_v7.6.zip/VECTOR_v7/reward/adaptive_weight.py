"""Hierarchical reward + Stage-S-style VLM residual on Lon/Lat (fixed W).

Lon residual (Package B+):
  - Formal W_long stays frozen at the soft-start / checkpoint prior.
  - Negative CoRe residual only under Safety_Critical + true near-miss
    (``r_safe < 0`` exposure gate).
  - P2-A: Congestion_Dominated may add a bounded positive evacuate bonus to
    efficient / moving CAVs that are not near-miss.

Lat residual (Package B+):
  - Formal W_lat stays frozen at the soft-start / checkpoint prior.
  - Negative CoRe residual when formal Lat reward is poor (``r_lat < 0.2``).
  - P2-A: Formation_Opportunity (primary) / Queue_Imbalance (secondary) may
    add a bounded positive bonus to already-good formation or rebalance LCs.
"""
from __future__ import annotations

import os
import threading
from typing import Any, Dict, Mapping, Optional

import numpy as np

from environment.peer_index import shared_peers


def _env_float_const(name: str, default: float) -> float:
    raw = os.environ.get(name)
    if raw is None or str(raw).strip() == "":
        return float(default)
    try:
        val = float(str(raw).strip())
    except (TypeError, ValueError, OverflowError):
        return float(default)
    return float(val) if np.isfinite(val) else float(default)


# Lon/Lat CoRe residual: calibrated scale (default 0.05; override via env).
VLM_CAV_RESIDUAL_SCALE = _env_float_const("VLM_CAV_RESIDUAL_SCALE", 0.05)
VLM_CAV_RESIDUAL_CONF_MIN = 0.60


def _lon_exposure_gate(comps: Mapping[str, Any], vinfo: Mapping[str, Any]) -> float:
    """True near-miss exposure only (``r_safe < 0`` → TTC < 1.5s or gap < 1m).

    Mid-band compact following (``0 <= r_safe < 0.5``, ~1.5–2.0s TTC) must NOT
    expose: that band is normal platoon density and was over-penalized before.
    Idle / creep with infinite TTC returns ``r_safe=0.0`` and must NOT expose.
    ``vinfo`` is kept for call-site compatibility.
    """
    del vinfo
    try:
        safe_val = float(comps.get("safe", 1.0))
    except (TypeError, ValueError, OverflowError):
        safe_val = 1.0
    if not np.isfinite(safe_val):
        safe_val = 1.0
    return 1.0 if safe_val < 0.0 else 0.0


def _lon_evacuate_gate(comps: Mapping[str, Any], vinfo: Mapping[str, Any]) -> float:
    """Congestion positive-residual gate: reward active, efficient discharge.

    Applied only when exposure gate is 0. Positive bonus must target *good*
    behaviour (eff > 0 and moving); gating on slow/low-eff would invert the
    incentive and subsidize creep.
    """
    try:
        eff = float(comps.get("eff", 0.0))
    except (TypeError, ValueError, OverflowError):
        eff = 0.0
    if not np.isfinite(eff):
        eff = 0.0
    try:
        spd = float(vinfo.get("speed", 0.0) or 0.0)
    except (TypeError, ValueError, OverflowError):
        spd = 0.0
    if not np.isfinite(spd):
        spd = 0.0
    if eff > 0.0 and spd >= 1.0:
        return 1.0
    return 0.0


def _lat_formation_gate(comps: Mapping[str, Any]) -> float:
    """Formation positive-residual gate: safe + constructive form term.

    Keep or LC both allowed; must not reward unsafe gaps (``safe_lc < 0``).
    """
    try:
        safe_lc = float(comps.get("safe_lc", 0.0))
    except (TypeError, ValueError, OverflowError):
        safe_lc = 0.0
    if not np.isfinite(safe_lc):
        safe_lc = 0.0
    try:
        form = float(comps.get("form", 0.0))
    except (TypeError, ValueError, OverflowError):
        form = 0.0
    if not np.isfinite(form):
        form = 0.0
    if safe_lc >= 0.0 and form > 0.0:
        return 1.0
    return 0.0


def _lat_balance_lc_gate(comps: Mapping[str, Any], action: Any) -> float:
    """Queue-imbalance positive gate: actual safe LC into a better lane.

    Keep / unsafe / non-improving LC must not receive the bonus.
    """
    try:
        act = int(action)
    except (TypeError, ValueError, OverflowError):
        act = 0
    if act == 0:
        return 0.0
    try:
        safe_lc = float(comps.get("safe_lc", 0.0))
        eff_lc = float(comps.get("eff_lc", 0.0))
        lane = float(comps.get("lane", 0.0))
    except (TypeError, ValueError, OverflowError):
        return 0.0
    if not (np.isfinite(safe_lc) and np.isfinite(eff_lc) and np.isfinite(lane)):
        return 0.0
    if safe_lc > 0.0 and eff_lc > 0.0 and lane > 0.0:
        return 1.0
    return 0.0


def _normalize_traffic_mode(mode: Any) -> str:
    return str(mode or "").strip().lower().replace(" ", "_").replace("-", "_")


# Package B: residual is safety-sparse. Routine congestion / platoon modes do
# not carry a large default risk; only Safety_Critical keeps full weight.
_MODE_RESIDUAL_RISK = {
    "safety_critical": 1.0,
    "safety-critical": 1.0,
    "congestion_dominated": 0.0,
    "queue_imbalance": 0.35,
    "platoon_opportunity": 0.0,
    "formation_opportunity": 0.0,
    "free_flow": 0.0,
}


def _invalid_cav_semantic(reason: str = "invalid") -> Dict[str, float]:
    return {
        "valid": 0.0,
        "confidence": 0.0,
        "residual_risk": 0.0,
        "reason": str(reason or "invalid"),
    }


def _mode_to_residual_risk(mode: Any) -> float:
    key = str(mode or "").strip().lower().replace(" ", "_")
    if key in _MODE_RESIDUAL_RISK:
        return float(_MODE_RESIDUAL_RISK[key])
    return 0.0


def _vlm_cav_residual_from_sem(sem: Optional[Mapping[str, Any]]) -> float:
    """Bounded CoRe residual in [-scale, 0] from Lon/Lat VLM semantics."""
    if not isinstance(sem, Mapping):
        return 0.0
    try:
        valid = float(sem.get("valid", 1.0) or 0.0)
    except (TypeError, ValueError, OverflowError):
        valid = 0.0
    if valid < 0.5:
        return 0.0
    try:
        conf = float(sem.get("confidence", 0.0) or 0.0)
    except (TypeError, ValueError, OverflowError):
        conf = 0.0
    conf = float(np.clip(conf, 0.0, 1.0))
    if conf < float(VLM_CAV_RESIDUAL_CONF_MIN):
        return 0.0
    risk = None
    for key in ("residual_risk", "risk", "hazard", "spillback_risk"):
        if key not in sem:
            continue
        try:
            risk = float(sem.get(key) or 0.0)
        except (TypeError, ValueError, OverflowError):
            risk = None
        if risk is not None and np.isfinite(risk):
            break
    if risk is None:
        risk = _mode_to_residual_risk(sem.get("traffic_mode"))
    risk = float(np.clip(risk, 0.0, 1.0))
    return float(
        np.clip(-float(VLM_CAV_RESIDUAL_SCALE) * conf * risk, -float(VLM_CAV_RESIDUAL_SCALE), 0.0)
    )


def _vlm_lon_congestion_bonus_from_sem(sem: Optional[Mapping[str, Any]]) -> float:
    """P2-A: bounded positive residual in [0, scale] for Congestion_Dominated.

    Formal W_long stays frozen; this is the only efficiency-side VLM nudge.
    """
    if not isinstance(sem, Mapping):
        return 0.0
    try:
        valid = float(sem.get("valid", 1.0) or 0.0)
    except (TypeError, ValueError, OverflowError):
        valid = 0.0
    if valid < 0.5:
        return 0.0
    try:
        conf = float(sem.get("confidence", 0.0) or 0.0)
    except (TypeError, ValueError, OverflowError):
        conf = 0.0
    conf = float(np.clip(conf, 0.0, 1.0))
    if conf < float(VLM_CAV_RESIDUAL_CONF_MIN):
        return 0.0
    mode = _normalize_traffic_mode(sem.get("traffic_mode"))
    if mode != "congestion_dominated":
        return 0.0
    return float(
        np.clip(float(VLM_CAV_RESIDUAL_SCALE) * conf, 0.0, float(VLM_CAV_RESIDUAL_SCALE))
    )


def _vlm_lat_positive_bonus_from_sem(sem: Optional[Mapping[str, Any]]) -> float:
    """P2-A Lat: positive residual for Formation (primary) / Queue_Imbalance (aux).

    Formal W_lat stays frozen; gates in ``_compose_lat_residual`` decide who gets it.
    """
    if not isinstance(sem, Mapping):
        return 0.0
    try:
        valid = float(sem.get("valid", 1.0) or 0.0)
    except (TypeError, ValueError, OverflowError):
        valid = 0.0
    if valid < 0.5:
        return 0.0
    try:
        conf = float(sem.get("confidence", 0.0) or 0.0)
    except (TypeError, ValueError, OverflowError):
        conf = 0.0
    conf = float(np.clip(conf, 0.0, 1.0))
    if conf < float(VLM_CAV_RESIDUAL_CONF_MIN):
        return 0.0
    mode = _normalize_traffic_mode(sem.get("traffic_mode"))
    if mode not in ("formation_opportunity", "queue_imbalance"):
        return 0.0
    return float(
        np.clip(float(VLM_CAV_RESIDUAL_SCALE) * conf, 0.0, float(VLM_CAV_RESIDUAL_SCALE))
    )


def _semantic_from_vlm_dict(weight_dict: Mapping[str, Any]) -> Dict[str, Any]:
    """Build residual semantic dict from residual JSON or legacy weight JSON."""
    mode = str(weight_dict.get("traffic_mode", "") or "").strip()
    analysis = str(weight_dict.get("semantic_analysis") or "")
    try:
        # v4: missing confidence => residual OFF (v3 defaulted to 0.85)
        conf = float(weight_dict.get("confidence", 0.0) or 0.0)
    except (TypeError, ValueError, OverflowError):
        conf = 0.0
    conf = float(np.clip(conf, 0.0, 1.0))
    risk = None
    for key in ("residual_risk", "risk", "hazard"):
        if key not in weight_dict:
            continue
        try:
            risk = float(weight_dict.get(key) or 0.0)
        except (TypeError, ValueError, OverflowError):
            risk = None
        if risk is not None and np.isfinite(risk):
            break
    if risk is None:
        risk = _mode_to_residual_risk(mode)
    risk = float(np.clip(risk if risk is not None else 0.0, 0.0, 1.0))
    try:
        valid = float(weight_dict.get("valid", 0.0) or 0.0)
    except (TypeError, ValueError, OverflowError):
        valid = 0.0
    return {
        "valid": 1.0 if valid >= 0.5 else 0.0,
        "confidence": conf,
        "residual_risk": risk,
        "traffic_mode": mode,
        "semantic_analysis": analysis,
    }

from baselines.episode_timing import VLM_WARMUP_BY_STAGE, VLM_WARMUP_EPISODES

# Lon/Lat residual VLM: aligned with Stage-S — no default stage-tail freeze.
# Soft-start still gates the first N stage episodes; after that VLM stays on
# through the end of Lon/Lat (like signal-vision in Stage-S).
# Opt-in ablation only: VLM_WEIGHT_FREEZE_TAIL_FRAC>0 (e.g. 0.30).
VLM_WEIGHT_FREEZE_TAIL_FRAC = _env_float_const("VLM_WEIGHT_FREEZE_TAIL_FRAC", 0.0)
# Episode-level blend toward the canonical anchor (not the drifted W).
# Lon uses a slower keep to cut small-net queue sawtooth after soft-start.
# Override: VLM_LON_EMA_KEEP_EPISODE.
VLM_LON_EMA_KEEP_EPISODE = _env_float_const("VLM_LON_EMA_KEEP_EPISODE", 0.92)
VLM_LAT_EMA_KEEP_EPISODE = _env_float_const("VLM_LAT_EMA_KEEP_EPISODE", 0.85)
VLM_EMA_KEEP_STEP = _env_float_const("VLM_EMA_KEEP_STEP", 0.75)
from environment.cav_state_builder import (
    _lane_index,
    _nearest_gap_on_lane,
    build_lane_features,
    driver_lane_offset,
    nearest_target_lane_partner,
)
from reward.base_reward import BaseReward
from reward.lateral_reward import (
    CONTROL_ESCAPE_PENALTY,
    DEFAULT_LAT_WEIGHTS,
    LAT_NET_EXT_EMA_ALPHA,
    LateralReward,
)
from reward.longitudinal_reward import DEFAULT_LONG_WEIGHTS, LongitudinalReward
from reward.signal_reward import (
    DEFAULT_CYCLE_S,
    DEFAULT_SIG_WEIGHTS,
    compute_signal_reward,
)
from VLM.scene_encoder import VLMSceneEncoder


def _env_flag(name, default=True):
    raw = os.environ.get(name)
    if raw is None:
        return bool(default)
    return str(raw).strip().lower() in ("1", "true", "yes", "on")


def joint_vlm_enabled() -> bool:
    """Opt-in: keep adapting W_long/W_lat during JointLonSig / JointAll."""
    return _env_flag("VLM_ENABLE_JOINT", default=False)


def heuristic_weights_enabled() -> bool:
    """Local rule-based W proposer (no cloud VLM); for joint ablations / offline."""
    return _env_flag("VLM_HEURISTIC_WEIGHTS", default=False)


def _finite_float(value, default=0.0):
    """Convert to a finite float; malformed/NaN/Inf inputs use a safe default."""
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError):
        return float(default)
    return result if np.isfinite(result) else float(default)


def _normalized_weights(values, size, fallback):
    """Return a finite non-negative simplex vector of exactly ``size`` entries."""
    size = max(1, int(size))
    try:
        fb = np.asarray(fallback, dtype=np.float32).reshape(-1)
    except (TypeError, ValueError, OverflowError):
        fb = np.empty(0, dtype=np.float32)
    if fb.size < size:
        fb = np.pad(fb, (0, size - fb.size))
    fb = np.nan_to_num(fb[:size], nan=0.0, posinf=0.0, neginf=0.0)
    fb = np.clip(fb, 0.0, None)
    fb_sum = float(fb.sum())
    if not np.isfinite(fb_sum) or fb_sum <= 1e-8:
        fb = np.full(size, 1.0 / size, dtype=np.float32)
    else:
        fb = (fb / fb_sum).astype(np.float32)

    try:
        arr = np.asarray(values, dtype=np.float32).reshape(-1)
    except (TypeError, ValueError, OverflowError):
        return fb.copy()
    if arr.size < size:
        arr = np.pad(arr, (0, size - arr.size))
    arr = np.nan_to_num(arr[:size], nan=0.0, posinf=0.0, neginf=0.0)
    arr = np.clip(arr, 0.0, None)
    total = float(arr.sum())
    if not np.isfinite(total) or total <= 1e-8:
        return fb.copy()
    return (arr / total).astype(np.float32)


class AdaptiveReward:
    """Hierarchical reward: waiting-increment R_sig + weighted R_lat/R_long.

    The separate signal-vision path supplies semantic observations in Stage-S.
    This class only lets VLM adapt W_long in Stage-Lon and W_lat in Stage-Lat.
    """

    def __init__(
        self,
        update_interval=50,
        vlm_api_key=None,
        vlm_model="qwen3-vl-flash",
        bev_layout="cross",
        use_vlm=True,
        fixed_weights=None,
        fixed_lat_weights=None,
        fixed_sig_weights=None,
        vlm_api_base=None,
        fail_stop_on_vlm_error=None,
        desired_speed=16.67,
        vlm_weight_stages=None,
    ):
        self.use_vlm = bool(use_vlm)
        if fail_stop_on_vlm_error is None:
            fail_stop_on_vlm_error = _env_flag("VLM_FAIL_STOP", True)
        self.fail_stop_on_vlm_error = bool(fail_stop_on_vlm_error) and self.use_vlm
        # Stages where reward-weight VLM may adapt W_long / W_lat.
        # Default: Lon+Lat when use_vlm; empty when disabled. Stage-S never
        # uses this path (signal vision is separate).
        self.set_vlm_weight_stages(vlm_weight_stages)
        self.vlm = VLMSceneEncoder(
            api_key=vlm_api_key,
            model=vlm_model,
            layout=bev_layout,
            api_base=vlm_api_base,
        )
        # Propagate fail-stop so teacher fetch re-raises into SignalVisionScheduler.
        self.vlm.fail_stop_on_vlm_error = bool(self.fail_stop_on_vlm_error)
        # Fallback only when the scenario key is unknown. Live cadence is
        # stage-name bound in _sync_vlm_intervals (S → Lon → Lat).
        self._scenario_update_interval = None
        self._base_update_interval = max(1, int(update_interval))
        self.crash_attribution_enabled = True
        self.crash_terminal_penalty = -1.0
        self.update_interval = self._base_update_interval
        self.min_update_interval = self.update_interval
        self.max_update_interval = 2 * self.update_interval

        # Longitudinal weights: 4-D (safe, efficiency, comfort, platoon).
        # Keep compatibility with the legacy 3-weight [safe, efficiency, comfort]
        # format, while preventing malformed/NaN checkpoint values from poisoning
        # the reward function.
        if fixed_weights is None:
            self.initial_weights = _normalized_weights(
                DEFAULT_LONG_WEIGHTS, 4, DEFAULT_LONG_WEIGHTS
            )
        else:
            try:
                w = np.asarray(fixed_weights, dtype=np.float32).reshape(-1)
            except (TypeError, ValueError, OverflowError):
                w = np.empty(0, dtype=np.float32)
            if w.size == 3:
                w = np.concatenate(
                    [w, np.asarray([float(DEFAULT_LONG_WEIGHTS[3])], dtype=np.float32)]
                )
            if w.size < 4:
                w = DEFAULT_LONG_WEIGHTS.copy()
            self.initial_weights = _normalized_weights(w[:4], 4, DEFAULT_LONG_WEIGHTS)

        self.initial_lat_weights = _normalized_weights(
            DEFAULT_LAT_WEIGHTS if fixed_lat_weights is None else fixed_lat_weights,
            5,
            DEFAULT_LAT_WEIGHTS,
        )
        self.initial_sig_weights = _normalized_weights(
            DEFAULT_SIG_WEIGHTS if fixed_sig_weights is None else fixed_sig_weights,
            4,
            DEFAULT_SIG_WEIGHTS,
        )

        self.lateral = LateralReward(self.initial_lat_weights)
        self.longitudinal = LongitudinalReward(self.initial_weights, desired_speed=desired_speed)

        self._lock = threading.RLock()
        self._generation = 0
        self.vlm_thread_running = False
        self._vlm_fatal_error = None
        self._training_stage = "S"
        self._stage_episode = 0  # episode index within current stage
        self._stage_len = 0  # episodes in current stage (0 = unknown / no tail freeze)
        self._vlm_tail_freeze_logged = False
        self._vlm_warmup_by_stage = dict(VLM_WARMUP_BY_STAGE)
        self.vlm_warmup_episodes = int(
            self._vlm_warmup_by_stage.get("S", VLM_WARMUP_EPISODES)
        )
        self._arm_vlm_after_reset = False
        self.macro_weights = self.initial_weights.copy()  # W_long
        self.macro_lat_weights = self.initial_lat_weights.copy()  # W_lat
        self.macro_sig_weights = self.initial_sig_weights.copy()  # W_sig
        self._sig_frozen = False  # True after Stage-S ends (Lon/Lat)
        self._long_frozen = False  # True after Stage-Lon ends (Lat)
        self._prev_signal_action = {}  # tls_id → last green index
        self._signal_switch_latched = {}
        self._last_vlm_raw = {}  # last parsed VLM dict (pre-EMA / residual)
        self._last_vlm_mode = None
        self._last_vlm_analysis = ""
        # Lon/Lat CoRe residuals (Stage-S aligned): formal W stays fixed;
        # VLM only publishes a bounded semantic residual.
        self._vlm_lon_semantic: Dict[str, Any] = _invalid_cav_semantic("init")
        self._vlm_lat_semantic: Dict[str, Any] = _invalid_cav_semantic("init")
        # Episode-end carryover so end_episode_vlm_update() is not wiped by reset().
        self._carryover_lon_semantic: Optional[Dict[str, Any]] = None
        self._carryover_lat_semantic: Optional[Dict[str, Any]] = None
        # Rolling network-queue ref for Lat LC externality (EMA of queue_length).
        self._lat_net_queue_ema = None
        # Episode-level aggregation: accumulate intra-episode VLM raws, apply
        # ONE residual publish at episode end (weights stay frozen).
        self._episode_vlm_raws: list = []
        self._vlm_owner_gen = None  # generation that currently owns the worker slot
        # Sliding-window stats since last VLM trigger: worst-case min TTC,
        # peak DLC imbalance, window means. Fed to VLM so a 0.5s event is
        # never hidden by the instantaneous snapshot at trigger time.
        self._window_min_ttc = float("inf")
        self._window_max_dlc = 0.0
        self._window_speeds: list = []
        self._window_platoon: list = []
        self._window_queues: list = []
        self._window_danger = 0
        self._prev_window_speed = None
        self._long_congested = False
        # BEV keyframe: hot path stores lightweight state only (0 pixels).
        # Unique prepare_scene_image runs inside _async_vlm_request.
        self._kf_best_ttc = 99.0
        self._kf_best_dlc = 0.0
        self._kf_best_n = 0
        self._keyframe_state_snapshot = None  # shallow pure-data dict
        self._kf_score = None  # (ttc, -dlc); lower ttc / higher dlc wins
        self.signal_incoming_edges = set()
        self.signal_outgoing_edges = set()
        self._scenario_key = ""
        self.max_road_capacity = 160.0
        self.control_zone_length = 200.0
        self.signal_cycle_s = float(DEFAULT_CYCLE_S)
        self.DESIRED_SPEED = float(desired_speed)
        self.default_green_duration = 10.0
        self.team_leader_weight = 0.5
        self.team_signal_weight = 0.5
        # Compatibility shims (removed coop channel)
        self._w_safe = float(self.macro_weights[0])
        self._w_eff = float(self.macro_weights[1])
        self._w_comfort = float(self.macro_weights[2])
        self._w_coop = 0.0
        self._sync_vlm_intervals()
        self.reset()

    # --- property shims used by marl_env / tests ---
    @property
    def w_safe(self):
        return float(self.macro_weights[0])

    @property
    def w_eff(self):
        return float(self.macro_weights[1])

    @property
    def w_comfort(self):
        return float(self.macro_weights[2])

    @property
    def w_platoon(self):
        return float(self.macro_weights[3]) if len(self.macro_weights) > 3 else 0.0

    @property
    def w_coop(self):
        return 0.0

    def set_signal_edges(self, incoming=None, outgoing=None):
        self.signal_incoming_edges = set(incoming or ())
        self.signal_outgoing_edges = set(outgoing or ())

    def set_coop_enabled(self, enabled, w_coop=None):
        """Legacy no-op: coop channel removed; use platoon weight instead."""
        del enabled, w_coop

    def configure_coop(self, **kwargs):
        """Legacy no-op."""
        del kwargs

    def reset_coop_state(self):
        pass

    def reset(self):
        with self._lock:
            self._generation += 1
            # Only reset the ACTIVE stage's weight simplex during soft-start or
            # with VLM disabled. Never reset a channel already frozen by the
            # curriculum: especially W_long during Stage-Lat.
            if not self.vlm_updates_allowed():
                if self._training_stage == "S" and not self._sig_frozen:
                    self.macro_sig_weights = self.initial_sig_weights.copy()
                elif self._training_stage == "Lon" and not self._long_frozen:
                    self.macro_weights = self.initial_weights.copy()
                    self.longitudinal.set_weights(self.macro_weights)
                elif self._training_stage == "Lat":
                    self.macro_lat_weights = self.initial_lat_weights.copy()
                    self.lateral.set_weights(self.macro_lat_weights)
            # Bump generation so in-flight workers discard results. Do NOT clear
            # vlm_thread_running here — a stale finally would race a new worker.
            self._episode_vlm_raws = []
            # Fresh episode: new sliding window + new key-frame race.
            self._window_min_ttc = float("inf")
            self._window_max_dlc = 0.0
            self._window_speeds = []
            self._window_platoon = []
            self._window_queues = []
            self._window_danger = 0
            self._kf_best_ttc = 99.0
            self._kf_best_dlc = 0.0
            self._kf_best_n = 0
            self._keyframe_state_snapshot = None
            self._kf_score = None
            # Warm-start from episode-end aggregated VLM residual if same-stage VLM is active;
            # otherwise clear cleanly to prevent cross-stage contamination.
            same_lon_stage = getattr(self, "_carryover_lon_stage", None) == self._training_stage
            same_lat_stage = getattr(self, "_carryover_lat_stage", None) == self._training_stage
            if self.use_vlm and same_lon_stage and isinstance(self._carryover_lon_semantic, dict):
                self._vlm_lon_semantic = dict(self._carryover_lon_semantic)
            else:
                self._vlm_lon_semantic = _invalid_cav_semantic("reset")
            if self.use_vlm and same_lat_stage and isinstance(self._carryover_lat_semantic, dict):
                self._vlm_lat_semantic = dict(self._carryover_lat_semantic)
            else:
                self._vlm_lat_semantic = _invalid_cav_semantic("reset")
            self._carryover_lon_semantic = None
            self._carryover_lat_semantic = None
            self._carryover_lon_stage = None
            self._carryover_lat_stage = None
        self.step_counter = 0
        self.steps_since_last_update = 0
        self.last_semantic_state = None
        self._prev_signal_action = {}
        self._signal_switch_latched = {}
        if self._arm_vlm_after_reset and self.vlm_updates_allowed():
            self.steps_since_last_update = self.max_update_interval
            self._arm_vlm_after_reset = False

    # Legacy Stage-S interval metadata (75 / 112.5 / 150 sim seconds) retained
    # for compatibility only. Stage-S reward-weight VLM calls are disabled:
    # the separate signal-vision scheduler owns visual-semantic refreshes.
    # Stage-Lon/Lat reward-weight VLM intervals are 30s / 45s respectively
    # (relaxed from 20s / 30s; tuned for the full control horizon).
    SCENARIO_VLM_INTERVAL_S = {
        "3leg_3phases": 30.0,
        "3leg_2phases": 30.0,  # back-compat alias
        "4leg_4phases": 45.0,
        "4leg_3phases": 45.0,
        "5leg_5phases": 60.0,
        "5leg_4phases": 60.0,
        "xuancheng_4phases": 60.0,
        "xuancheng_5phases": 60.0,
    }
    STAGE_S_INTERVAL_SCALE = 2.5
    # Bound by stage name, not curriculum index. Order is S → Lon → Lat.
    LON_VLM_INTERVAL_S = 30.0
    LAT_VLM_INTERVAL_S = 45.0

    def set_scenario(self, scenario_key: Optional[str] = None):
        """Store scenario key and Stage-S VLM interval (formal is topology-unified)."""
        key = str(scenario_key or "").strip()
        secs = self.SCENARIO_VLM_INTERVAL_S.get(key)
        with self._lock:
            self._scenario_key = key
            self._scenario_update_interval = float(secs) if secs else None
        self._sync_vlm_intervals()
        return self._scenario_update_interval

    def _steps_for_seconds(self, seconds: float) -> int:
        step = 0.2
        try:
            step = float(getattr(self, "_sim_step_length", 0.2) or 0.2)
        except (TypeError, ValueError):
            step = 0.2
        return max(1, int(round(float(seconds) / max(step, 1e-6))))

    def _sync_vlm_intervals(self):
        """Sync reward-weight VLM intervals by stage name, never by index.

        Stage-S retains legacy interval metadata only; vlm_channel() returns
        None there, so this class does not launch Stage-S weight requests.
        The separate signal-vision scheduler owns visual-semantic refreshes.
        Stage-Lon and Stage-Lat reward-weight updates remain 30s and 45s.
        """
        stage = str(getattr(self, "_training_stage", "S") or "S")
        scen_secs = getattr(self, "_scenario_update_interval", None)
        # Joint tails suspend reward-weight VLM (actors only); keep Lon/Lat intervals
        # as harmless placeholders.
        if stage in ("Lon", "JointLonSig"):
            interval = self._steps_for_seconds(self.LON_VLM_INTERVAL_S)
        elif stage in ("Lat", "JointAll"):
            interval = self._steps_for_seconds(self.LAT_VLM_INTERVAL_S)
        elif stage == "S" and scen_secs:
            interval = self._steps_for_seconds(
                float(scen_secs) * self.STAGE_S_INTERVAL_SCALE
            )
        elif stage == "S":
            interval = max(
                1, int(round(self._base_update_interval * self.STAGE_S_INTERVAL_SCALE))
            )
        else:
            interval = max(1, int(self._base_update_interval))
        self.update_interval = interval
        self.min_update_interval = interval
        self.max_update_interval = interval

    def set_vlm_warmup_by_stage(self, mapping: Optional[Mapping[str, Any]] = None):
        """Override per-stage soft-start lengths (e.g. quick profile)."""
        if mapping:
            for k, v in mapping.items():
                st = self._normalize_stage(k)
                self._vlm_warmup_by_stage[st] = max(0, int(v))
        self.set_vlm_warmup_for_stage(self._training_stage)

    def set_vlm_warmup_for_stage(self, stage: Optional[str] = None):
        st = self._normalize_stage(stage or self._training_stage)
        table = getattr(self, "_vlm_warmup_by_stage", None) or VLM_WARMUP_BY_STAGE
        if st in table:
            self.vlm_warmup_episodes = int(table[st])
        elif joint_vlm_enabled() and st in ("JointLonSig", "JointAll"):
            # Soft-start already ran in Lon/Lat; joint ablation adapts immediately.
            self.vlm_warmup_episodes = 0
        else:
            self.vlm_warmup_episodes = int(table.get(st, VLM_WARMUP_EPISODES))

    @staticmethod
    def _normalize_stage(stage):
        from agents.mappo import MAPPOAgent

        return MAPPOAgent._normalize_stage(stage)

    def set_vlm_weight_stages(self, stages=None):
        """Restrict reward-weight VLM to the given stages (Lon / Lat)."""
        if stages is None:
            self._vlm_weight_stages = (
                frozenset(("Lon", "Lat")) if self.use_vlm else frozenset()
            )
            return
        if isinstance(stages, str):
            raw = [stages]
        else:
            raw = list(stages)
        normalized = []
        for s in raw:
            st = self._normalize_stage(s)
            if st in ("Lon", "Lat"):
                normalized.append(st)
        self._vlm_weight_stages = frozenset(normalized)

    def vlm_channel(self):
        """Return the reward-weight channel eligible for VLM adaptation.

        Stage-S uses the separate signal-vision semantic pathway; this class
        must not issue VLM calls to tune signal reward weights. Stage-Lon adapts
        W_long, and Stage-Lat adapts W_lat. W_sig fields remain only for legacy
        checkpoint/log compatibility because the signal reward is unweighted.

        Joint tails default to frozen weights (channel None). Set
        ``VLM_ENABLE_JOINT=1`` to keep adapting W_long in JointLonSig and
        W_lat in JointAll (ablation / research).
        """
        if self._training_stage == "S":
            return None
        if self._training_stage == "JointLonSig":
            return "lon" if joint_vlm_enabled() else None
        if self._training_stage == "JointAll":
            return "lat" if joint_vlm_enabled() else None
        if self._training_stage == "Lat":
            return "lat"
        if self._training_stage == "Lon":
            if _env_flag("V7_INFLUENCE_REWARD", default=False):
                # v7: the influence-segment reward replaces the Lon reward in
                # marl_env, so the Lon VLM residual would be overwritten; skip
                # the calls instead of paying for them.
                return None
            return "lon"
        return None

    def _vlm_tail_freeze_start(self) -> Optional[int]:
        """First stage-local ep (inclusive) where Lon/Lat W updates freeze."""
        if self._training_stage not in ("Lon", "Lat"):
            return None
        length = max(0, int(getattr(self, "_stage_len", 0) or 0))
        if length <= 0:
            return None
        frac = float(VLM_WEIGHT_FREEZE_TAIL_FRAC)
        frac = min(0.50, max(0.0, frac))
        if frac <= 0.0:
            return None
        start = int(length - max(1, int(round(length * frac))))
        # Keep at least one post-warmup adaptive episode when the stage is long
        # enough; otherwise freeze immediately after warmup.
        warm = max(0, int(self.vlm_warmup_episodes))
        return max(warm, start)

    def vlm_updates_allowed(self):
        """True after per-stage soft-start warmup when VLM is enabled."""
        if not self.use_vlm:
            return False
        # Prefer explicit stage allow-list; COVLM_VLM_ONLY_STAGE further restricts.
        stages = getattr(self, "_vlm_weight_stages", None)
        if stages is None:
            stages = frozenset(("Lon", "Lat"))
        st = str(self._training_stage or "S")
        if st in ("JointLonSig", "JointAll"):
            if not joint_vlm_enabled():
                return False
            # Joint reuses Lon/Lat weight stages when those channels are enabled.
            need = "Lon" if st == "JointLonSig" else "Lat"
            if need not in stages and st not in stages:
                return False
        elif st not in stages:
            return False
        allowed_stage = os.environ.get('COVLM_VLM_ONLY_STAGE', '').strip()
        if allowed_stage:
            allowed_norm = self._normalize_stage(allowed_stage)
            if self._training_stage != allowed_norm:
                return False
        if self.vlm_channel() is None:
            return False
        if int(self._stage_episode) < int(self.vlm_warmup_episodes):
            return False
        freeze_from = self._vlm_tail_freeze_start()
        if freeze_from is not None and int(self._stage_episode) >= int(freeze_from):
            return False
        return True

    def set_stage_episode(self, episode_in_stage: int, stage_len: Optional[int] = None):
        """Update episode index within the current stage (0-based)."""
        prev_allowed = self.vlm_updates_allowed()
        self._stage_episode = max(0, int(episode_in_stage))
        if stage_len is not None:
            self._stage_len = max(0, int(stage_len))
        now_allowed = self.vlm_updates_allowed()
        if now_allowed and not prev_allowed and self.use_vlm:
            ch = self.vlm_channel()
            self._arm_vlm_after_reset = True
            self.steps_since_last_update = self.max_update_interval
            self.last_semantic_state = None
            self._vlm_tail_freeze_logged = False
            print(
                f"[VLM] Stage-{self._training_stage}: soft-start done "
                f"(ep_in_stage={self._stage_episode}); online EMA on W_{ch} activated",
                flush=True,
            )
        elif prev_allowed and not now_allowed and self.use_vlm:
            freeze_from = self._vlm_tail_freeze_start()
            if (
                freeze_from is not None
                and int(self._stage_episode) >= int(freeze_from)
                and not bool(getattr(self, "_vlm_tail_freeze_logged", False))
            ):
                ch = self.vlm_channel() or (
                    "long" if self._training_stage == "Lon" else "lat"
                )
                self._vlm_tail_freeze_logged = True
                print(
                    f"[VLM] Stage-{self._training_stage}: W_{ch} FROZEN for tail "
                    f"(ep_in_stage={self._stage_episode}/{self._stage_len}; "
                    f"freeze_from={freeze_from})",
                    flush=True,
                )

    def set_training_stage(self, stage, stage_episode: int = 0, stage_len: Optional[int] = None):
        stage = self._normalize_stage(stage)
        prev = getattr(self, "_training_stage", None)
        prev_allowed = self.vlm_updates_allowed() if prev == stage else False
        self._training_stage = stage
        self._stage_episode = max(0, int(stage_episode))
        if stage_len is not None:
            self._stage_len = max(0, int(stage_len))
        elif prev != stage:
            # Unknown length until train_RL passes stage_len; disable freeze gate.
            self._stage_len = 0
            self._vlm_tail_freeze_logged = False
        self.set_vlm_warmup_for_stage(stage)
        self._sync_vlm_intervals()
        # Always keep all reward terms on (no mid-training formula change).
        self.lateral.set_form_enabled(True)
        self.longitudinal.set_platoon_enabled(True)
        # Same-stage episode advance (real training path): arm VLM after soft-start.
        if prev == stage:
            now_allowed = self.vlm_updates_allowed()
            if now_allowed and not prev_allowed and self.use_vlm:
                ch = self.vlm_channel()
                self._arm_vlm_after_reset = True
                self.steps_since_last_update = self.max_update_interval
                self.last_semantic_state = None
                self._vlm_tail_freeze_logged = False
                print(
                    f"[VLM] Stage-{self._training_stage}: soft-start done "
                    f"(ep_in_stage={self._stage_episode}); online EMA on W_{ch} activated",
                    flush=True,
                )
            elif prev_allowed and not now_allowed and self.use_vlm:
                freeze_from = self._vlm_tail_freeze_start()
                if (
                    freeze_from is not None
                    and int(self._stage_episode) >= int(freeze_from)
                    and not bool(getattr(self, "_vlm_tail_freeze_logged", False))
                ):
                    ch = self.vlm_channel() or (
                        "long" if self._training_stage == "Lon" else "lat"
                    )
                    self._vlm_tail_freeze_logged = True
                    print(
                        f"[VLM] Stage-{self._training_stage}: W_{ch} FROZEN for tail "
                        f"(ep_in_stage={self._stage_episode}/{self._stage_len}; "
                        f"freeze_from={freeze_from})",
                        flush=True,
                    )
        if prev != stage:
            # Freeze by destination stage name, including a resume that
            # enters Lon/Lat while this object still thinks it is in S.
            if stage in ("Lon", "Lat", "JointLonSig", "JointAll"):
                self._sig_frozen = True
                print(
                    f"[VLM] Stage-{stage}: W_sig FROZEN at "
                    f"{self.macro_sig_weights.tolist()} (VLM-SIG off)",
                    flush=True,
                )
            if stage in ("Lat", "JointAll"):
                self._long_frozen = True
                print(
                    f"[VLM] Stage-{stage}: W_long FROZEN at "
                    f"{self.macro_weights.tolist()} (VLM-LON off)",
                    flush=True,
                )
            elif stage in ("Lon", "JointLonSig"):
                # Default: freeze W_long in JointLonSig. Ablation VLM_ENABLE_JOINT
                # keeps adapting W_long through the joint tail.
                self._long_frozen = stage == "JointLonSig" and not joint_vlm_enabled()
            if stage == "S":
                self._sig_frozen = False
                self._long_frozen = False
            with self._lock:
                self._generation += 1
                # Never carry raw VLM proposals across a stage boundary: a late
                # Stage-S response must not be reinterpreted as Lon/Lat residual.
                self._episode_vlm_raws = []
                self._carryover_lon_semantic = None
                self._carryover_lat_semantic = None
                self._vlm_lon_semantic = _invalid_cav_semantic("stage_boundary")
                self._vlm_lat_semantic = _invalid_cav_semantic("stage_boundary")
                # Stage-entry baselines: never wipe frozen W_sig/W_long.
                # Joint tails keep current weights (no soft-start reset).
                if stage == "S":
                    self.macro_weights = self.initial_weights.copy()
                    self.macro_lat_weights = self.initial_lat_weights.copy()
                    self.longitudinal.set_weights(self.macro_weights)
                    self.lateral.set_weights(self.macro_lat_weights)
                    if not self._sig_frozen:
                        self.macro_sig_weights = self.initial_sig_weights.copy()
                elif stage == "Lon":
                    # Longitudinal soft-start: reset W_long only; keep W_lat.
                    self.macro_weights = self.initial_weights.copy()
                    self.longitudinal.set_weights(self.macro_weights)
                elif stage == "Lat":
                    # Lateral soft-start: reset W_lat only; W_long stays FROZEN.
                    self.macro_lat_weights = self.initial_lat_weights.copy()
                    self.lateral.set_weights(self.macro_lat_weights)
                self.vlm_thread_running = False
            self.steps_since_last_update = 0
            self.last_semantic_state = None
            self._arm_vlm_after_reset = False
            self._prev_signal_action = {}
            self._signal_switch_latched = {}
            if self.use_vlm and stage == "S":
                print(
                    "[VLM] Stage-S: reward-weight VLM calls disabled; "
                    "signal visual semantics belong to the separate signal-vision "
                    "scheduler. Legacy W_sig is retained only for checkpoint/log compatibility.",
                    flush=True,
                )
            elif self.use_vlm and stage in ("Lat", "Lon"):
                ch = self.vlm_channel()
                print(
                    f"[VLM] Stage-{stage}: fixed W_{ch} + residual soft-start "
                    f"({self.vlm_warmup_episodes} eps); "
                    f"W_lat={self.macro_lat_weights.tolist()} "
                    f"W_long={self.macro_weights.tolist()}",
                    flush=True,
                )
            elif self.use_vlm and stage in ("JointLonSig", "JointAll"):
                if joint_vlm_enabled():
                    ch = self.vlm_channel()
                    self._arm_vlm_after_reset = True
                    self.steps_since_last_update = self.max_update_interval
                    print(
                        f"[VLM] Stage-{stage}: reward-weight VLM ENABLED "
                        f"(VLM_ENABLE_JOINT=1) on W_{ch}; "
                        f"W_long frozen={self._long_frozen}",
                        flush=True,
                    )
                else:
                    print(
                        f"[VLM] Stage-{stage}: reward-weight VLM suspended "
                        f"(actor joint fine-tune only); "
                        f"W_sig frozen, W_long frozen={self._long_frozen}",
                        flush=True,
                    )
            elif self.use_vlm:
                print(
                    f"[VLM] Stage-{stage}: online updates suspended",
                    flush=True,
                )

    def _apply_vlm_long_weights(self, weight_dict: Mapping[str, Any],
                                  episode_level: bool = False):
        """Publish Lon residual semantics; W_long stays frozen at the formal prior."""
        del episode_level
        lon_ok = self._training_stage == "Lon" or (
            joint_vlm_enabled() and self._training_stage == "JointLonSig"
        )
        if self._long_frozen or not lon_ok:
            return
        sem = _semantic_from_vlm_dict(weight_dict)
        mode = _normalize_traffic_mode(sem.get("traffic_mode"))
        # Package B+: only Safety_Critical carries negative residual risk.
        # Congestion uses a separate positive evacuate bonus (P2-A), not risk.
        if mode not in ("safety_critical",):
            sem["residual_risk"] = 0.0
        with self._lock:
            # Keep formal Lon weights pinned to the soft-start / checkpoint prior.
            self.macro_weights = np.asarray(
                self.initial_weights, dtype=np.float32
            ).copy()
            self.longitudinal.set_weights(self.macro_weights)
            self.macro_weights = np.asarray(
                self.longitudinal.weights, dtype=np.float32
            ).copy()
            self._vlm_lon_semantic = dict(sem)
            self._last_vlm_raw = {
                "residual_risk": float(sem.get("residual_risk", 0.0) or 0.0),
                "confidence": float(sem.get("confidence", 0.0) or 0.0),
                "valid": float(sem.get("valid", 0.0) or 0.0),
            }
            self._last_vlm_mode = sem.get("traffic_mode")
            self._last_vlm_analysis = str(sem.get("semantic_analysis") or "")
            delta_neg = _vlm_cav_residual_from_sem(sem)
            delta_pos = _vlm_lon_congestion_bonus_from_sem(sem)
            print(
                f"[VLM] Lon residual published "
                f"risk={float(sem.get('residual_risk', 0.0)):.3f} "
                f"conf={float(sem.get('confidence', 0.0)):.2f} "
                f"δ_neg={delta_neg:.4f} δ_pos={delta_pos:.4f} "
                f"W_long FROZEN={self.macro_weights.tolist()} "
                f"mode={self._last_vlm_mode!r} analysis={self._last_vlm_analysis!r}",
                flush=True,
            )

    # Mode-prior anchors for W_lat (order: lane, safe, eff, form, comfort).
    # Safety-first: safe_lc stays elevated; eff_lc never dominates.
    LAT_MODE_PRIORS = {
        # eff_lc (index 2) stays at the 0.20 default except Safety_Critical.
        # Formation takes share from lane/comfort, not from eff_lc.
        "safety_critical": (0.12, 0.30, 0.18, 0.23, 0.17),
        "formation_opportunity": (0.10, 0.22, 0.20, 0.30, 0.18),
        "queue_imbalance": (0.22, 0.24, 0.24, 0.16, 0.14),
        "free_flow": (0.12, 0.24, 0.20, 0.24, 0.20),
    }
    # Canonical defaults. EMA deviation is measured from these, never from
    # the already-adapted vector, so one biased mode cannot walk the simplex.
    LON_MODE_PRIORS = {
        "safety_critical": (0.32, 0.28, 0.18, 0.22),
        "congestion_dominated": (0.18, 0.50, 0.14, 0.18),
        "platoon_opportunity": (0.20, 0.38, 0.18, 0.24),
        "free_flow": (0.18, 0.42, 0.20, 0.20),
    }

    def _update_lat_net_queue_ref(self, state: Mapping[str, Any]):
        """EMA of network queue for Lat LC externality. Returns (q_now, q_ref)."""
        stats = state.get("stats") if isinstance(state, Mapping) else None
        q_now = 0.0
        if isinstance(stats, Mapping):
            for key in ("queue_length", "avg_queue_length", "Average_Queue_Length"):
                if key in stats:
                    try:
                        q_now = float(stats.get(key) or 0.0)
                    except (TypeError, ValueError, OverflowError):
                        q_now = 0.0
                    break
        if not np.isfinite(q_now):
            q_now = 0.0
        q_now = max(0.0, float(q_now))
        alpha = float(LAT_NET_EXT_EMA_ALPHA)
        alpha = min(1.0, max(1e-4, alpha))
        ema = getattr(self, "_lat_net_queue_ema", None)
        if ema is None or not np.isfinite(float(ema)):
            self._lat_net_queue_ema = float(q_now)
        else:
            self._lat_net_queue_ema = (
                (1.0 - alpha) * float(ema) + alpha * float(q_now)
            )
        return float(q_now), float(self._lat_net_queue_ema)

    @staticmethod
    def _enrich_lat_meta(
        vinfo: Mapping[str, Any],
        action: int,
        meta: dict,
        state: Mapping[str, Any],
        peers: Optional[dict] = None,
    ) -> dict:
        """Fill target-lane queue / bumper gap for the signed LC action.

        ``peers`` may be a prebuilt per-step snapshot (same content as built
        from ``state``); passing it avoids rebuilding one dict-per-vehicle
        for every lateral agent on the hot path.
        """
        act = int(action)
        # Driver-relative: LHT/RHT via vinfo['lefthand'].
        offset = int(driver_lane_offset(act, vinfo))
        if peers is None:
            peers = shared_peers(state)  # v5.2: one merged snapshot per state, not per agent
        ego = dict(vinfo)
        try:
            l_cur, l_tgt, l_min, _ = build_lane_features(ego, peers, offset)
            meta["current_lane_queue"] = float(l_cur)
            meta["target_lane_queue"] = float(l_tgt)
            meta["min_lane_queue"] = float(l_min)
        except Exception:
            pass
        try:
            tgt = int(_lane_index(str(vinfo.get("lane") or ""))) + int(offset)
        except (TypeError, ValueError):
            tgt = int(offset)
        if offset != 0:
            try:
                gap_l, closing_l = _nearest_gap_on_lane(ego, peers, tgt, ahead=True)
                gap_f, closing_f = _nearest_gap_on_lane(ego, peers, tgt, ahead=False)
                gaps = [g for g in (gap_l, gap_f) if g is not None]
                meta["target_lane_gap"] = float(min(gaps)) if gaps else 100.0
                meta["target_front_gap"] = 100.0 if gap_l is None else float(gap_l)
                meta["target_rear_gap"] = 100.0 if gap_f is None else float(gap_f)
                rc = 0.0 if closing_f is None else float(closing_f)
                meta["target_rear_closing"] = rc
                meta["target_rear_ttc"] = (
                    float(gap_f) / rc
                    if (gap_f is not None and rc > 0.1)
                    else 99.0
                )
                del closing_l
            except Exception:
                meta.setdefault("target_lane_gap", 100.0)
                meta.setdefault("target_rear_ttc", 99.0)
                meta.setdefault("target_rear_closing", 0.0)
        else:
            meta.setdefault("target_lane_gap", 100.0)
            meta.setdefault("target_rear_ttc", 99.0)
            meta.setdefault("target_rear_closing", 0.0)
        try:
            form_gap, form_cav = nearest_target_lane_partner(
                ego,
                peers,
                tgt,
                approach_edges=vinfo.get("approach_edges"),
            )
            meta["target_form_gap"] = float(form_gap)
            meta["target_form_is_cav"] = form_cav
        except Exception:
            meta.setdefault("target_form_gap", 100.0)
            meta.setdefault("target_form_is_cav", None)
        return meta

    def _apply_vlm_lat_weights(self, weight_dict: Mapping[str, Any],
                                 episode_level: bool = False):
        """Publish Lat residual semantics; W_lat stays frozen at the formal prior."""
        del episode_level
        lat_ok = self._training_stage == "Lat" or (
            joint_vlm_enabled() and self._training_stage == "JointAll"
        )
        if not lat_ok:
            return
        sem = _semantic_from_vlm_dict(weight_dict)
        mode = _normalize_traffic_mode(sem.get("traffic_mode"))
        # Package B+: Formation uses positive bonus (like Lon congestion), not risk.
        # Queue_Imbalance keeps a capped negative risk for poor formal Lat samples.
        if mode in ("free_flow", "formation_opportunity"):
            sem["residual_risk"] = 0.0
        elif mode in ("queue_imbalance",):
            sem["residual_risk"] = min(
                float(sem.get("residual_risk", 0.0) or 0.0), 0.35
            )
        elif mode not in ("safety_critical", "safety-critical"):
            sem["residual_risk"] = min(
                float(sem.get("residual_risk", 0.0) or 0.0), 0.15
            )
        with self._lock:
            self.macro_lat_weights = np.asarray(
                self.initial_lat_weights, dtype=np.float32
            ).copy()
            self.lateral.set_weights(self.macro_lat_weights)
            self.macro_lat_weights = np.asarray(
                self.lateral.weights, dtype=np.float32
            ).copy()
            self._vlm_lat_semantic = dict(sem)
            self._last_vlm_raw = {
                "residual_risk": float(sem.get("residual_risk", 0.0) or 0.0),
                "confidence": float(sem.get("confidence", 0.0) or 0.0),
                "valid": float(sem.get("valid", 0.0) or 0.0),
            }
            self._last_vlm_mode = sem.get("traffic_mode")
            self._last_vlm_analysis = str(sem.get("semantic_analysis") or "")
            delta_neg = _vlm_cav_residual_from_sem(sem)
            delta_pos = _vlm_lat_positive_bonus_from_sem(sem)
            print(
                f"[VLM] Lat residual published "
                f"risk={float(sem.get('residual_risk', 0.0)):.3f} "
                f"conf={float(sem.get('confidence', 0.0)):.2f} "
                f"δ_neg={delta_neg:.4f} δ_pos={delta_pos:.4f} "
                f"W_lat FROZEN={self.macro_lat_weights.tolist()} "
                f"mode={self._last_vlm_mode!r} analysis={self._last_vlm_analysis!r}",
                flush=True,
            )

    def _vlm_lon_residual(self) -> float:
        """Negative safety residual only (≤ 0)."""
        with self._lock:
            sem = dict(getattr(self, "_vlm_lon_semantic", None) or {})
        return _vlm_cav_residual_from_sem(sem)

    def _vlm_lon_congestion_bonus(self) -> float:
        """Positive evacuate residual for Congestion_Dominated (≥ 0)."""
        with self._lock:
            sem = dict(getattr(self, "_vlm_lon_semantic", None) or {})
        return _vlm_lon_congestion_bonus_from_sem(sem)

    def _vlm_lat_residual(self) -> float:
        with self._lock:
            sem = dict(getattr(self, "_vlm_lat_semantic", None) or {})
        return _vlm_cav_residual_from_sem(sem)

    def _vlm_lat_positive_bonus(self) -> float:
        """Positive Lat residual for Formation / Queue_Imbalance (≥ 0)."""
        with self._lock:
            sem = dict(getattr(self, "_vlm_lat_semantic", None) or {})
        return _vlm_lat_positive_bonus_from_sem(sem)

    def _compose_lon_residual(
        self, comps: Mapping[str, Any], vinfo: Mapping[str, Any]
    ) -> tuple[float, float]:
        """Combine exposure-gated safety penalty and evacuate bonus.

        Returns ``(r_lon_res, exposed)``. Near-miss → negative only; otherwise
        congestion mode may add a positive evacuate nudge on efficient movers.
        """
        if not self.use_vlm:
            return 0.0, 0.0
        exposed = float(_lon_exposure_gate(comps, vinfo))
        if exposed >= 0.5:
            return float(self._vlm_lon_residual()) * exposed, exposed
        bonus = float(self._vlm_lon_congestion_bonus())
        if abs(bonus) <= 1e-12:
            return 0.0, exposed
        evacuate = float(_lon_evacuate_gate(comps, vinfo))
        return bonus * evacuate, exposed

    def _compose_lat_residual(
        self,
        comps: Mapping[str, Any],
        *,
        formal: float,
        action: Any = 0,
    ) -> tuple[float, float]:
        """Combine Lat poor-formal penalty and Formation / imbalance bonuses.

        Returns ``(r_lat_res, exposed)``. ``formal < 0.2`` → negative only;
        otherwise Formation (form+safe) or Queue_Imbalance (safe improving LC).
        """
        if not self.use_vlm:
            return 0.0, 0.0
        try:
            formal_f = float(formal)
        except (TypeError, ValueError, OverflowError):
            formal_f = 0.0
        if not np.isfinite(formal_f):
            formal_f = 0.0
        exposed = 1.0 if formal_f < 0.2 else 0.0
        if exposed >= 0.5:
            return float(self._vlm_lat_residual()) * exposed, exposed
        bonus = float(self._vlm_lat_positive_bonus())
        if abs(bonus) <= 1e-12:
            return 0.0, exposed
        with self._lock:
            mode = _normalize_traffic_mode(
                (getattr(self, "_vlm_lat_semantic", None) or {}).get("traffic_mode")
            )
        if mode == "formation_opportunity":
            gate = float(_lat_formation_gate(comps))
        elif mode == "queue_imbalance":
            gate = float(_lat_balance_lc_gate(comps, action))
        else:
            gate = 0.0
        return bonus * gate, exposed

    # Mode-prior anchors (aligned with SYSTEM_PROMPT_SIG): structural spread
    # across the four modes; delay floor 0.16; progression capped at 0.32.
    SIG_MODE_PRIORS = {
        "phase_starvation": (0.36, 0.34, 0.20, 0.10),
        "queue_imbalance": (0.53, 0.19, 0.18, 0.10),
        "string_approaching": (0.38, 0.19, 0.31, 0.12),
        "free_flow": (0.38, 0.19, 0.27, 0.16),
    }
    # Per-component clamps (same ranges as prompt / scene_encoder).
    SIG_WEIGHT_CLAMPS = (
        (0.35, 0.56),  # queue
        (0.16, 0.36),  # delay
        (0.14, 0.32),  # progression
        (0.07, 0.16),  # switch
    )

    @classmethod
    def _clamp_sig_weights(cls, w: np.ndarray) -> np.ndarray:
        """Project onto sum=1 while respecting per-component [lo, hi].

        A naive clamp-then-renormalize can push ``delay_weight`` below its
        floor (e.g. all components at their upper bounds). Iterate: pin
        floors/caps, then redistribute the residual only among components
        that still have room so prompt floors remain hard constraints.
        """
        clamps = cls.SIG_WEIGHT_CLAMPS
        n = len(clamps)
        try:
            raw = np.asarray(w, dtype=np.float32).reshape(-1)
        except (TypeError, ValueError, OverflowError):
            raw = np.empty(0, dtype=np.float32)
        raw = np.nan_to_num(raw, nan=0.0, posinf=0.0, neginf=0.0)
        out = np.zeros(n, dtype=np.float32)
        lo = np.zeros(n, dtype=np.float32)
        hi = np.zeros(n, dtype=np.float32)
        for i, (a, b) in enumerate(clamps):
            lo[i] = float(a)
            hi[i] = float(b)
            out[i] = float(raw[i]) if i < len(raw) else float(0.5 * (a + b))
        # Feasible box simplex: sum(lo) <= 1 <= sum(hi) for current SIG clamps.
        out = np.clip(out, lo, hi)
        for _ in range(12):
            s = float(out.sum())
            deficit = 1.0 - s
            if abs(deficit) <= 1e-6:
                break
            if deficit > 0.0:
                room = hi - out
            else:
                room = out - lo
            mask = room > 1e-8
            if not bool(np.any(mask)):
                break
            share = room / float(room[mask].sum())
            out = np.where(mask, out + deficit * share, out)
            out = np.clip(out, lo, hi)
        s = float(out.sum())
        if abs(s - 1.0) > 1e-4 and s > 1e-8:
            # Last resort (should be rare): scale then re-pin floors.
            out = out / s
            out = np.maximum(out, lo)
            s2 = float(out.sum())
            if s2 > 1.0:
                excess = s2 - 1.0
                room = out - lo
                mask = room > 1e-8
                if bool(np.any(mask)):
                    out = np.where(
                        mask,
                        out - excess * (room / float(room[mask].sum())),
                        out,
                    )
            out = np.clip(out, lo, hi)
        return out.astype(np.float32)

    def apply_macro_weights(
        self,
        W_sig=None,
        W_lat=None,
        W_long=None,
    ):
        """Restore finite, correctly-sized EMA weights from a checkpoint."""
        with self._lock:
            if W_sig is not None:
                self.macro_sig_weights = self._clamp_sig_weights(W_sig).astype(np.float32)
            if W_lat is not None:
                self.macro_lat_weights = _normalized_weights(
                    W_lat, 5, self.initial_lat_weights
                )
                self.lateral.set_weights(self.macro_lat_weights)
                self.macro_lat_weights = np.asarray(
                    self.lateral.weights, dtype=np.float32
                ).copy()
            if W_long is not None:
                self.macro_weights = _normalized_weights(
                    W_long, 4, self.initial_weights
                )
                self.longitudinal.set_weights(self.macro_weights)
                self.macro_weights = np.asarray(
                    self.longitudinal.weights, dtype=np.float32
                ).copy()

    def _apply_vlm_sig_weights(self, weight_dict: Mapping[str, Any],
                                 episode_level: bool = False):
        """No-op shim: Stage-S uses SignalVisionScheduler/Teacher, not W_sig."""
        del weight_dict, episode_level
        return

    def _apply_vlm_weights(self, weight_dict: Mapping[str, Any], channel: Optional[str] = None,
                             episode_level: bool = False):
        """Apply EMA using the channel captured at request time (avoids S→Lon TOCTOU)."""
        ch = str(channel or weight_dict.get("weight_mode") or self.vlm_channel() or "").lower()
        if ch in ("sig", "signal", "s", "tls"):
            self._apply_vlm_sig_weights(weight_dict, episode_level=episode_level)
        elif ch in ("lat", "lateral", "lat"):
            self._apply_vlm_lat_weights(weight_dict, episode_level=episode_level)
        elif ch in ("lon", "long", "longitudinal", "lon"):
            self._apply_vlm_long_weights(weight_dict, episode_level=episode_level)

    def get_vlm_weight_snapshot(self) -> Dict[str, Any]:
        """Current fixed weights + Lon/Lat residual semantics (TB / diagnostics)."""
        with self._lock:
            return {
                "stage": str(self._training_stage),
                "channel": self.vlm_channel(),
                "W_long": [float(x) for x in self.macro_weights],
                "W_lat": [float(x) for x in self.macro_lat_weights],
                "W_sig": [float(x) for x in self.macro_sig_weights],
                "sig_frozen": bool(self._sig_frozen),
                "lon_frozen": bool(self._long_frozen),
                "last_raw": dict(self._last_vlm_raw or {}),
                "traffic_mode": self._last_vlm_mode,
                "semantic_analysis": self._last_vlm_analysis,
                "lon_residual": float(_vlm_cav_residual_from_sem(self._vlm_lon_semantic)),
                "lon_pos_bonus": float(_vlm_lon_congestion_bonus_from_sem(self._vlm_lon_semantic)),
                "lat_residual": float(_vlm_cav_residual_from_sem(self._vlm_lat_semantic)),
                "lat_pos_bonus": float(_vlm_lat_positive_bonus_from_sem(self._vlm_lat_semantic)),
                "lon_semantic": dict(self._vlm_lon_semantic or {}),
                "lat_semantic": dict(self._vlm_lat_semantic or {}),
            }

    @staticmethod
    def _snapshot_for_vlm(state: Optional[Mapping]) -> Dict[str, Any]:
        """Shallow pure-data copy for BEV render + VLM prompt (no env objects).

        Copies only dict trees the renderer/prompt need: cavs/hdvs (per-vehicle
        scalar fields), stats, signals, and optional junction metadata.
        """
        if not isinstance(state, Mapping):
            return {}
        out: Dict[str, Any] = {}
        for group in ("cavs", "hdvs"):
            src = state.get(group) or {}
            if not isinstance(src, Mapping):
                out[group] = {}
                continue
            out[group] = {
                str(vid): (dict(vinfo) if isinstance(vinfo, Mapping) else vinfo)
                for vid, vinfo in src.items()
            }
        stats = state.get("stats") or {}
        out["stats"] = dict(stats) if isinstance(stats, Mapping) else {}
        signals = state.get("signals") or {}
        if isinstance(signals, Mapping):
            out["signals"] = {
                str(k): (dict(v) if isinstance(v, Mapping) else v)
                for k, v in signals.items()
            }
        else:
            out["signals"] = {}
        for key in ("junction_name", "junction_center", "time"):
            if key in state:
                out[key] = state[key]
        return out

    def _merge_window_stats_into(self, snap: Dict[str, Any]) -> None:
        """Fold sliding-window extremes into snap['stats'] (in place)."""
        try:
            wstats = dict(snap.get("stats") or {})
            if self._window_min_ttc != float("inf"):
                wstats["min_ttc"] = min(
                    _finite_float(wstats.get("min_ttc", 99.0), 99.0),
                    _finite_float(self._window_min_ttc, 99.0),
                )
            if self._window_max_dlc > 0.0:
                wstats["thru_dlc_queue_diff"] = max(
                    _finite_float(wstats.get("thru_dlc_queue_diff", 0.0), 0.0),
                    _finite_float(self._window_max_dlc, 0.0),
                )
            if self._window_speeds:
                wstats["average_speed"] = float(
                    sum(self._window_speeds) / len(self._window_speeds)
                )
            if self._window_platoon:
                wstats["platoon_rate"] = float(
                    sum(self._window_platoon) / len(self._window_platoon)
                )
            wstats["danger_event_number"] = max(
                0, int(_finite_float(wstats.get("danger_event_number", 0), 0.0))
            ) + max(0, int(self._window_danger))
            snap["stats"] = wstats
        except Exception:
            pass

    def _heuristic_reward_weights(
        self, state: Mapping[str, Any], channel: str
    ) -> Dict[str, Any]:
        """Rule-based stand-in for cloud VLM weight JSON (prompt Rule 1–4)."""
        stats = state.get("stats") if isinstance(state.get("stats"), Mapping) else {}
        rs = stats.get("vlm_reward_summary") if isinstance(stats, Mapping) else {}
        if not isinstance(rs, Mapping):
            rs = {}

        def _f(key, default=0.0, src=None):
            bag = src if src is not None else stats
            return _finite_float(
                (bag or {}).get(key, default) if isinstance(bag, Mapping) else default,
                float(default),
            )

        min_ttc = _f("min_ttc", 99.0)
        if min_ttc >= 98.0:
            min_ttc = _f("min_ttc", 99.0, rs)
        frac_unsafe = _f("frac_unsafe_ttc", 0.0, rs)
        danger = max(
            0,
            int(_f("danger_event_number", 0.0)),
        )
        queue_total = _f("queue_total", 0.0, rs)
        if queue_total <= 0.0:
            queue_keys = [
                k for k in stats if str(k).startswith("queue_") and k != "queue_length"
            ]
            queue_total = float(
                sum(max(0.0, _f(k, 0.0)) for k in queue_keys)
            ) if queue_keys else _f("queue_length", 0.0)
        avg_speed = _f("average_speed", 0.0)
        platoon_rate = _f("platoon_rate", _f("platoon_rate", 0.0, rs))
        dlc = _f("thru_dlc_queue_diff", _f("thru_dlc_queue_diff", 0.0, rs))
        n_dlc = max(0, int(_f("n_dlc", _f("n_dlc", 0.0, rs))))

        ch = str(channel or "lon").strip().lower()
        if ch == "lat":
            if min_ttc < 1.2 and (frac_unsafe > 0.15 or danger >= 3):
                mode = "Safety_Critical"
                prior = self.LAT_MODE_PRIORS["safety_critical"]
            elif dlc >= 2.0:
                mode = "Queue_Imbalance"
                prior = self.LAT_MODE_PRIORS["queue_imbalance"]
            elif dlc < 2.0 and n_dlc >= 2:
                mode = "Formation_Opportunity"
                prior = self.LAT_MODE_PRIORS["formation_opportunity"]
            else:
                mode = "Free_Flow"
                prior = self.LAT_MODE_PRIORS["free_flow"]
            keys = (
                "lane_weight",
                "safe_lc_weight",
                "eff_lc_weight",
                "formation_weight",
                "comfort_lc_weight",
            )
            out = {k: float(v) for k, v in zip(keys, prior)}
            out["traffic_mode"] = mode
            out["semantic_analysis"] = "heuristic_lat"
            out["weight_mode"] = "lat"
            out["residual_risk"] = _mode_to_residual_risk(mode)
            out["confidence"] = 0.85
            out["valid"] = 1.0
            return out

        # Longitudinal rules (aligned with SYSTEM_PROMPT_LON thresholds).
        if min_ttc < 1.5 or danger >= 2 or frac_unsafe > 0.10:
            mode = "Safety_Critical"
            prior = self.LON_MODE_PRIORS["safety_critical"]
        elif queue_total >= 32.0 or avg_speed < 5.0:
            mode = "Congestion_Dominated"
            prior = self.LON_MODE_PRIORS["congestion_dominated"]
        elif (
            queue_total < 32.0
            and avg_speed >= 6.8
            and platoon_rate >= 0.20
            and min_ttc >= 1.5
        ):
            mode = "Platoon_Opportunity"
            prior = self.LON_MODE_PRIORS["platoon_opportunity"]
        else:
            mode = "Free_Flow"
            prior = self.LON_MODE_PRIORS["free_flow"]
        keys = (
            "safety_weight",
            "efficiency_weight",
            "comfort_weight",
            "platoon_weight",
        )
        out = {k: float(v) for k, v in zip(keys, prior)}
        out["traffic_mode"] = mode
        out["semantic_analysis"] = "heuristic_lon"
        out["weight_mode"] = "lon"
        out["residual_risk"] = _mode_to_residual_risk(mode)
        out["confidence"] = 0.85
        out["valid"] = 1.0
        return out

    def trigger_vlm_update(self, state, ep=0, step=0):
        if not self.vlm_updates_allowed():
            return False
        channel = self.vlm_channel()
        # Build prompt snap before claiming the worker slot so we can fold
        # window extremes under the same lock that clears them.
        state_snapshot = self._snapshot_for_vlm(state)
        with self._lock:
            if self.vlm_thread_running:
                return False
            if not self.vlm_updates_allowed():
                return False
            self.vlm_thread_running = True
            generation = self._generation
            self._vlm_owner_gen = generation
            self._refresh_traffic_gate()
            self._merge_window_stats_into(state_snapshot)
            render_state = self._keyframe_state_snapshot
            self._keyframe_state_snapshot = None
            self._kf_score = None
            self._window_min_ttc = float("inf")
            self._window_max_dlc = 0.0
            self._window_speeds = []
            self._window_platoon = []
            self._window_queues = []
            self._window_danger = 0
            self._kf_best_ttc = 99.0
            self._kf_best_dlc = 0.0
            self._kf_best_n = 0
        if render_state is None:
            render_state = state_snapshot
        worker = threading.Thread(
            target=self._async_vlm_request,
            args=(state_snapshot, ep, step, generation, channel, render_state),
            daemon=True,
        )
        try:
            worker.start()
        except Exception as exc:
            with self._lock:
                if self._vlm_owner_gen == generation:
                    self.vlm_thread_running = False
                    self._vlm_owner_gen = None
            if self.fail_stop_on_vlm_error:
                self._vlm_fatal_error = exc
            else:
                print(f"[VLM Thread Start Error] {exc}", flush=True)
            return False
        return True

    def _async_vlm_request(
        self, state, ep, step, generation, channel, render_state=None
    ):
        """Background: sole BEV prepare_scene_image + VLM API. Never calls TraCI."""
        try:
            if heuristic_weights_enabled():
                # Offline / ablation: skip BEV + cloud; use prompt-aligned rules.
                new_w = self._heuristic_reward_weights(state, channel)
                print(
                    f"[VLM Heuristic] ep={ep} step={step} ch={channel} "
                    f"mode={new_w.get('traffic_mode')}",
                    flush=True,
                )
            else:
                # Main-thread contract: 0 BEV work. This is the only render site.
                prepared = self.vlm.prepare_scene_image(
                    render_state if render_state is not None else state,
                    ep=ep,
                    step=step,
                    prefer_key_frame=False,
                )
                new_w = self.vlm.fetch_reward_weights_sync(
                    state,
                    ep=ep,
                    step=step,
                    prepared_image=prepared,
                    weight_mode=channel,
                )
            if not isinstance(new_w, Mapping):
                raise TypeError(
                    f"VLM reward-weight response must be a mapping, got {type(new_w).__name__}"
                )
            new_w = dict(new_w)
            # Accept residual schema (preferred) or legacy weight JSON.
            residual_keys = (
                "residual_risk", "risk", "hazard", "confidence", "valid",
            )
            weight_keys = {
                "sig": (
                    "queue_weight", "queue", "delay_weight", "delay",
                    "progression_weight", "progression", "switch_weight", "switch",
                ),
                "lon": (
                    "safety_weight", "safety", "efficiency_weight", "efficiency",
                    "comfort_weight", "comfort", "platoon_weight", "platoon",
                ),
                "lat": (
                    "lane_weight", "lane", "safe_lc_weight", "safe_lc",
                    "eff_lc_weight", "eff_lc", "formation_weight", "form",
                    "comfort_lc_weight", "comfort_lc",
                ),
            }.get(str(channel).lower(), ())
            has_usable = bool(str(new_w.get("traffic_mode") or "").strip())
            if not has_usable:
                for key in residual_keys + weight_keys:
                    if key not in new_w:
                        continue
                    try:
                        has_usable = bool(np.isfinite(float(new_w[key])))
                    except (TypeError, ValueError, OverflowError):
                        has_usable = False
                    if has_usable:
                        break
            if not has_usable:
                raise ValueError(
                    f"VLM response for channel {channel!r} lacks residual/weight fields"
                )
            # The request-time channel is authoritative; never trust a response
            # field to route a proposal into another reward simplex.
            new_w["weight_mode"] = channel
            # Publish residual immediately for the active window AND accumulate
            # for episode-end summary under one lock with generation check.
            with self._lock:
                if generation != self._generation:
                    return
                # Apply with the *captured* channel so a mid-flight
                # Stage-S→Lon switch cannot EMA-corrupt W_lat with sig JSON.
                stale = self.vlm_channel() != channel
                if stale:
                    return
                self._episode_vlm_raws.append(dict(new_w))
                self._apply_vlm_weights(new_w, channel=channel, episode_level=False)
        except Exception as exc:
            print(f"[VLM Thread Error] {exc}", flush=True)
            if self.fail_stop_on_vlm_error:
                self._vlm_fatal_error = exc
        finally:
            with self._lock:
                # Clear busy only if this worker still owns the slot (survives
                # reset() generation bumps without leaving the flag stuck True).
                if getattr(self, "_vlm_owner_gen", None) == generation:
                    self.vlm_thread_running = False
                    self._vlm_owner_gen = None

    def end_episode_vlm_update(self) -> bool:
        """Apply ONE slow EMA from this episode's accumulated VLM raws.

        Returns True if an update was applied. Called once per episode end.
        """
        with self._lock:
            raws = list(getattr(self, "_episode_vlm_raws", None) or [])
            self._episode_vlm_raws = []
        if not raws:
            return False
        channel = self.vlm_channel()
        if channel is None:
            return False
        # A defensive channel filter protects against stale/cross-stage results
        # even if a caller manually invokes this method during a transition.
        raws = [
            r for r in raws
            if str(r.get("weight_mode") or channel).strip().lower() == channel
        ]
        if not raws:
            return False
        # Mean-aggregate raw weight dicts of this episode.
        keys: list = []
        for r in raws:
            for k in r.keys():
                if k not in keys:
                    keys.append(k)
        agg: dict = {}
        for k in keys:
            if k in ("traffic_mode", "semantic_analysis", "weight_mode"):
                continue
            vals = []
            for r in raws:
                try:
                    value = float(r.get(k))
                except (TypeError, ValueError, OverflowError):
                    continue
                if np.isfinite(value):
                    vals.append(value)
            if vals:
                agg[k] = float(sum(vals) / len(vals))
        # Majority vote on mode; keep latest analysis text.
        modes = [str(r.get("traffic_mode") or "") for r in raws if r.get("traffic_mode")]
        # Deterministic tie-break: retain the earliest mode among tied votes.
        agg["traffic_mode"] = (
            max(modes, key=lambda mode: (modes.count(mode), -modes.index(mode)))
            if modes else None
        )
        agg["semantic_analysis"] = str((raws[-1].get("semantic_analysis") or ""))
        agg["weight_mode"] = channel
        self._apply_vlm_weights(agg, channel=channel, episode_level=True)
        with self._lock:
            if channel in ("lon", "long", "longitudinal"):
                carried = dict(self._vlm_lon_semantic or {})
                carried["confidence"] = round(float(carried.get("confidence", 0.0)) * 0.90, 4)
                self._carryover_lon_semantic = carried
                self._carryover_lon_stage = self._training_stage
            elif channel in ("lat", "lateral"):
                carried = dict(self._vlm_lat_semantic or {})
                carried["confidence"] = round(float(carried.get("confidence", 0.0)) * 0.90, 4)
                self._carryover_lat_semantic = carried
                self._carryover_lat_stage = self._training_stage
        return True

    def _refresh_traffic_gate(self) -> None:
        """Snapshot the window that is about to be cleared for a VLM call.

        Must run before the window lists are reset. The gate is what
        ``_apply_vlm_long_weights`` reads at episode end, because by then
        the lists that produced the proposal no longer exist.
        """
        queues = list(getattr(self, "_window_queues", None) or [])
        speeds = list(getattr(self, "_window_speeds", None) or [])
        if not queues and not speeds:
            return
        mean_q = float(sum(queues) / len(queues)) if queues else 0.0
        mean_v = float(sum(speeds) / len(speeds)) if speeds else 99.0
        prev_v = getattr(self, "_prev_window_speed", None)
        slowing = (
            prev_v is not None
            and mean_v + 0.3 < float(prev_v)
            and mean_q >= 32.0
        )
        self._prev_window_speed = mean_v
        self._long_congested = bool(mean_q >= 32.0 or mean_v < 5.0 or slowing)

    def _long_congestion_active(self) -> bool:
        """True while the latest completed VLM window is still queued or slowing."""
        return bool(getattr(self, "_long_congested", False))

    @staticmethod
    def _queue_total(stats):
        stats = stats or {}
        total = 0.0
        for key, val in stats.items():
            k = str(key)
            if k.startswith("queue_") and k != "queue_length":
                total += _finite_float(val, 0.0)
        return total

    def check_semantic_drift(self, current_state):
        if self.last_semantic_state is None:
            return True
        curr_stats = (current_state or {}).get("stats") or {}
        last_stats = (self.last_semantic_state or {}).get("stats") or {}
        # Kept for callers/tests. The scheduler sets min == max, so this
        # does not fire a VLM call before the stage interval elapses.
        stage = str(getattr(self, "_training_stage", "S") or "S")
        if stage in ("Lat", "Lon"):
            try:
                ttc = _finite_float(curr_stats.get("min_ttc", 99.0), 99.0)
            except (TypeError, ValueError):
                ttc = 99.0
            if ttc < 1.3:
                return True
            try:
                dlc = _finite_float(curr_stats.get("thru_dlc_queue_diff", 0.0), 0.0)
            except (TypeError, ValueError):
                dlc = 0.0
            try:
                last_dlc = _finite_float(last_stats.get("thru_dlc_queue_diff", 0.0), 0.0)
            except (TypeError, ValueError):
                last_dlc = 0.0
            if dlc >= 2.0 > last_dlc:
                return True
        curr_q = self._queue_total(curr_stats)
        last_q = self._queue_total(last_stats)
        curr_v = _finite_float(curr_stats.get("average_speed", 0.0), 0.0)
        last_v = _finite_float(last_stats.get("average_speed", 0.0), 0.0)
        drift = 0.6 * abs(curr_q - last_q) / 50.0 + 0.4 * abs(curr_v - last_v) / 16.67
        return drift > 0.15

    def _note_key_frame_state(self, state, ttc: float, dlc: float, n_dlc: int = 0) -> None:
        """Hot path: store worst-event ``_keyframe_state_snapshot`` only (no BEV).

        Absolute rule: never call ``bev_renderer`` / ``prepare_scene_image`` here.
        Stage-Lat (lateral): prioritize max thru_dlc_queue_diff / n_dlc, NOT min TTC,
        so red-light braking frames do not hijack the lateral VLM.
        Stage-Lon/S: keep min-TTC priority for longitudinal safety.
        """
        if not self.use_vlm or not self.vlm_updates_allowed():
            return
        ttc_f = _finite_float(ttc, 99.0)
        dlc_f = _finite_float(dlc, 0.0)
        try:
            n_f = max(0, int(n_dlc or 0))
        except (TypeError, ValueError, OverflowError):
            n_f = 0
        stage = str(getattr(self, "_training_stage", "S") or "S")
        with self._lock:
            if stage == "Lat":
                # Higher DLC wins; tie-break by MORE DLC vehicles, then LOWER ttc
                # only as a last resort. Score tuple compared with <: smaller wins,
                # so negate dlc/n_dlc.
                score = (-dlc_f, -float(n_f), ttc_f)
            else:
                score = (ttc_f, -dlc_f)
            prev = self._kf_score
            if prev is not None and score >= prev:
                return
            self._kf_score = score
            self._keyframe_state_snapshot = self._snapshot_for_vlm(state)

    def _signal_switch_once(self, tls_id, cur_a, prev_a, state, previous_state):
        """Count one switch: the green decision, or the first yellow step if that was missed.

        Yellow, all-red, and the first step of the new green are lock steps and
        must not each add another switch penalty.
        """
        from environment.tls_phases import phase_kind

        sig = ((state or {}).get("signals") or {}).get(tls_id) or {}
        prev_sig = ((previous_state or {}).get("signals") or {}).get(tls_id) or {}
        cur_kind = phase_kind(str(sig.get("state") or ""))
        prev_kind = phase_kind(str(prev_sig.get("state") or "")) if prev_sig else ""
        latched = bool(self._signal_switch_latched.get(tls_id, False))
        try:
            green_index = int(sig.get("green_index"))
        except (TypeError, ValueError):
            green_index = None

        if cur_kind == "green" and prev_kind in ("yellow", "red"):
            self._signal_switch_latched[tls_id] = False
            return False
        if cur_kind != "green":
            # First step that leaves green (into yellow or all-red).
            if prev_kind == "green" and not latched:
                self._signal_switch_latched[tls_id] = True
                return True
            return False
        requests_other = (
            prev_a is not None
            and int(prev_a) != int(cur_a)
            and (green_index is None or int(cur_a) != int(green_index))
        )
        if prev_kind == "green" and requests_other and not latched:
            self._signal_switch_latched[tls_id] = True
            return True
        return False

    def compute_agent_rewards(
        self,
        state,
        previous_state=None,
        actions=None,
        ep=0,
        step=0,
        lambdas=None,
        lat_actions=None,
        lat_meta=None,
        dt=0.2,
        active_agent_ids=None,
    ):
        del lambdas
        self.step_counter += 1
        self.steps_since_last_update += 1

        # Per-step (0.2s, local, zero API cost) sliding-window tracking for
        # Lon/Lat: worst TTC, peak DLC imbalance, mean speed/platoon, danger.
        try:
            st = (state or {}).get("stats") or {}
            ttc = _finite_float(st.get("min_ttc", 99.0), 99.0)
            if ttc < float(getattr(self, "_window_min_ttc", float("inf"))):
                self._window_min_ttc = ttc
            dlc = _finite_float(st.get("thru_dlc_queue_diff", 0.0), 0.0)
            if dlc > _finite_float(getattr(self, "_window_max_dlc", 0.0), 0.0):
                self._window_max_dlc = dlc
            self._window_speeds.append(_finite_float(st.get("average_speed", 0.0), 0.0))
            self._window_platoon.append(_finite_float(st.get("platoon_rate", 0.0), 0.0))
            self._window_queues.append(self._queue_total(st))
            self._window_danger += max(
                0, int(_finite_float(st.get("danger_event_number", 0), 0.0))
            )
            # Bound memory: keep at most ~5 min of steps.
            if len(self._window_speeds) > 1500:
                self._window_speeds = self._window_speeds[-1500:]
                self._window_platoon = self._window_platoon[-1500:]
                self._window_queues = self._window_queues[-1500:]
            # Key-frame (Lon/Lat): store lightweight state only (no BEV on hot path).
            try:
                stage = str(getattr(self, "_training_stage", "S") or "S")
                if stage in ("Lat", "Lon"):
                    st = (state or {}).get("stats") or {}
                    ttc = _finite_float(st.get("min_ttc", 99.0), 99.0)
                    dlc = _finite_float(st.get("thru_dlc_queue_diff", 0.0), 0.0)
                    try:
                        n_dlc = int(st.get("n_dlc", 0) or 0)
                    except (TypeError, ValueError):
                        n_dlc = 0
                    new_worst = ttc < _finite_float(getattr(self, "_kf_best_ttc", 99.0), 99.0)
                    new_imb = dlc > _finite_float(getattr(self, "_kf_best_dlc", 0.0), 0.0)
                    if stage == "Lat":
                        # Lat interval window: max thru_dlc_queue_diff, then most n_dlc.
                        # A lower min_TTC alone must not replace the frame.
                        best_n = max(0, int(getattr(self, "_kf_best_n", 0) or 0))
                        best_dlc = _finite_float(getattr(self, "_kf_best_dlc", 0.0), 0.0)
                        take = new_imb or (n_dlc > best_n and dlc >= best_dlc)
                    elif stage == "Lon":
                        # Lon interval window: longitudinal min_TTC only.
                        take = new_worst and ttc < 5.0
                    else:
                        take = (new_worst and ttc < 5.0) or (new_imb and dlc >= 3.0)
                    if take:
                        self._kf_best_ttc = min(
                            ttc, _finite_float(getattr(self, "_kf_best_ttc", 99.0), 99.0)
                        )
                        self._kf_best_dlc = max(
                            dlc, _finite_float(getattr(self, "_kf_best_dlc", 0.0), 0.0)
                        )
                        self._kf_best_n = max(
                            n_dlc, int(getattr(self, "_kf_best_n", 0) or 0)
                        )
                        self._note_key_frame_state(state, ttc, dlc, n_dlc)
            except Exception:
                pass
        except Exception:
            pass

        if self.vlm_updates_allowed():
            due_to_interval = self.steps_since_last_update >= self.max_update_interval
            due_to_drift = False
            if not due_to_interval and self.steps_since_last_update >= self.min_update_interval:
                due_to_drift = self.check_semantic_drift(state)
            if due_to_interval or due_to_drift:
                try:
                    launched = self.trigger_vlm_update(state, ep, step)
                except Exception as exc:
                    if self.fail_stop_on_vlm_error:
                        self._vlm_fatal_error = exc
                        launched = False
                    else:
                        print(f"[VLM Event-Trigger] Could not prepare VLM request: {exc}")
                        launched = False
                # Only reset cooldown when a worker actually launched; otherwise
                # a busy thread would starve retries by clearing the timer.
                if launched:
                    self.last_semantic_state = self._snapshot_for_vlm(state)
                    self.steps_since_last_update = 0
                    why = "semantic shift" if due_to_drift and not due_to_interval else "interval"
                    print(
                        f"[VLM Event-Trigger] step={step} ({why}): launched online VLM call",
                        flush=True,
                    )

        actions = actions or {}
        lat_actions = lat_actions or {}
        lat_meta = lat_meta or {}
        previous_cavs = (previous_state or {}).get("cavs", {}) if previous_state else {}
        # One shared peers snapshot for this step: _enrich_lat_meta would
        # otherwise rebuild one dict-per-vehicle for every lateral agent.
        peers_snapshot: Optional[dict] = None
        prev_peers_snapshot: Optional[dict] = None
        if lat_actions or any(
            a.startswith("cav_lat_") for a in actions
        ):
            peers_snapshot = {}
            for group in ("cavs", "hdvs"):
                for oid, o in (state.get(group) or {}).items():
                    peers_snapshot[oid] = dict(o)
                    peers_snapshot[oid]["_id"] = oid
            prev_peers_snapshot = {}
            for group in ("cavs", "hdvs"):
                for oid, o in ((previous_state or {}).get(group) or {}).items():
                    prev_peers_snapshot[oid] = dict(o)
                    prev_peers_snapshot[oid]["_id"] = oid
            if not prev_peers_snapshot:
                prev_peers_snapshot = peers_snapshot

        # Update Lat network-queue EMA once per reward step (LC externality ref).
        _net_q, _net_q_ref = self._update_lat_net_queue_ref(state)

        agent_rewards: Dict[str, float] = {}
        lon_formal_by_agent: Dict[str, float] = {}
        terminal_incident_agents: set[str] = set()
        crash_attr_on = bool(getattr(self, "crash_attribution_enabled", True))
        crash_pen = float(getattr(self, "crash_terminal_penalty", -1.0))
        collider_vids = set(str(x) for x in ((state or {}).get("collider_ids") or ()))
        teleport_vids = set(str(x) for x in ((state or {}).get("teleport_ids") or ()))
        culprit_vids = (collider_vids | teleport_vids) if crash_attr_on else set()
        lat_list, lon_list, sig_list = [], [], []
        global_reward_dict = {
            "eff": 0.0,
            "safe": 0.0,
            "comfort": 0.0,
            "platoon": 0.0,
            "lat": 0.0,
            "long": 0.0,
            "lon_formal": 0.0,
            "lon_residual": 0.0,
            "lon_residual_nonzero_frac": 0.0,
            "lon_exposed_frac": 0.0,
            "lon_formal_by_agent": lon_formal_by_agent,
            "terminal_incident_agents": [],
        }
        lon_comps_acc = []
        lat_comps_acc = []

        for agent_id, action in actions.items():
            if agent_id.startswith("cav_lon_"):
                vid = agent_id[len("cav_lon_") :]
                vinfo = state.get("cavs", {}).get(vid)
                if not vinfo:
                    if vid in culprit_vids:
                        agent_rewards[agent_id] = float(crash_pen)
                        lon_formal_by_agent[agent_id] = float(crash_pen)
                        terminal_incident_agents.add(agent_id)
                        lon_list.append(float(crash_pen))
                    else:
                        agent_rewards[agent_id] = 0.0
                    continue
                if vid in culprit_vids:
                    vinfo_eff = dict(vinfo)
                    if float(vinfo_eff.get("leader_gap", 100.0) or 100.0) > 5.0:
                        vinfo_eff["leader_gap"] = -0.20
                    vinfo_eff["ttc"] = 0.05
                else:
                    vinfo_eff = vinfo
                prev_a = float(previous_cavs.get(vid, {}).get("acceleration", vinfo_eff.get("acceleration", 0.0)))
                r_lon, comps = self.longitudinal.compute(vinfo_eff, state, prev_accel=prev_a, dt=float(dt))
                if vid in culprit_vids:
                    r_lon = float(min(float(r_lon), crash_pen))
                    terminal_incident_agents.add(agent_id)
                # Formal Lon + exposure-gated VLM residual (safety neg / cong pos).
                r_lon_formal = float(r_lon)
                r_lon_res, _lon_exposed = self._compose_lon_residual(comps, vinfo)
                r_lon = float(np.clip(r_lon_formal + r_lon_res, -1.0, 1.0))
                comps = dict(comps)
                comps["formal"] = r_lon_formal
                comps["residual"] = r_lon_res
                comps["exposed"] = float(_lon_exposed)
                # Lon agent gets longitudinal reward; lat agent scored separately
                agent_rewards[agent_id] = float(r_lon)
                lon_formal_by_agent[agent_id] = float(r_lon_formal)
                lon_list.append(float(r_lon))
                lon_comps_acc.append(comps)
            elif agent_id.startswith("cav_lat_"):
                vid = agent_id[len("cav_lat_") :]
                vinfo = state.get("cavs", {}).get(vid)
                if not vinfo:
                    if vid in culprit_vids:
                        agent_rewards[agent_id] = float(crash_pen)
                        terminal_incident_agents.add(agent_id)
                        lat_list.append(float(crash_pen))
                    else:
                        agent_rewards[agent_id] = 0.0
                    continue
                # DoF gate: non-DLC samples carry zero reward (escape applied later).
                # Default False matches obs / GAE / merge_and_update contract.
                try:
                    _eligible = bool((lat_meta.get(vid) or {}).get("dlc_eligible", False))
                except Exception:
                    _eligible = False
                # Prefer executed signed action from env (LOCKED_0DOF may force keep).
                # Never remap signed keep(0)→left(-1): Discrete 0/1/2 conversion
                # only when this vid is absent from lat_actions (policy index path).
                if vid in lat_actions:
                    la = int(lat_actions[vid])
                else:
                    la = (
                        int(action)
                        if not isinstance(action, (list, np.ndarray))
                        else int(np.asarray(action).reshape(-1)[0])
                    )
                    # Discrete policy index 0,1,2 → -1,0,1 (marl_env contract).
                    if la in (0, 1, 2):
                        la = [-1, 0, 1][la]
                meta = dict(lat_meta.get(vid, {}) or {})
                # Enrich from pre-LC state so successful LC into empty lane scores +.
                prev_vinfo = dict(previous_cavs.get(vid) or vinfo)
                prev_peers = prev_peers_snapshot or peers_snapshot
                meta = self._enrich_lat_meta(
                    prev_vinfo, int(la), meta, previous_state or state, peers=prev_peers
                )
                prev_lane = previous_cavs.get(vid, {}).get("lane")
                from environment.p1_control import annotate_lane_change
                meta = annotate_lane_change(self, meta, vid, vinfo, prev_lane, state)
                r_lat, lat_comps = self.lateral.compute(
                    vinfo,
                    int(la),
                    meta=meta,
                    prev_lane=prev_lane,
                    network_queue=_net_q,
                    network_queue_ref=_net_q_ref,
                )
                if not _eligible and str(getattr(self, "_training_stage", "Lat") or "Lat") in (
                    "Lat",
                    "JointAll",
                ):
                    r_lat = 0.0
                    agent_rewards[agent_id] = 0.0
                    continue
                r_lat_formal = float(r_lat)
                r_lat_res, _lat_exposed = self._compose_lat_residual(
                    lat_comps or {}, formal=r_lat_formal, action=int(la)
                )
                r_lat = float(np.clip(r_lat_formal + r_lat_res, -1.0, 1.0))
                if vid in culprit_vids:
                    r_lat = float(min(float(r_lat), crash_pen))
                    terminal_incident_agents.add(agent_id)
                agent_rewards[agent_id] = float(r_lat)
                lat_list.append(float(r_lat))
                lat_comps_acc.append({"formal": r_lat_formal, "residual": r_lat_res, "exposed": float(_lat_exposed)})
            elif agent_id.startswith("cav_"):
                # Legacy single CAV id → longitudinal only
                vid = agent_id[4:]
                vinfo = state.get("cavs", {}).get(vid)
                if not vinfo:
                    agent_rewards[agent_id] = 0.0
                    continue
                prev_a = float(previous_cavs.get(vid, {}).get("acceleration", 0.0))
                r_lon, comps = self.longitudinal.compute(vinfo, state, prev_accel=prev_a, dt=float(dt))
                r_lon_formal = float(r_lon)
                r_lon_res, _lon_exposed = self._compose_lon_residual(comps, vinfo)
                r_lon = float(np.clip(r_lon_formal + r_lon_res, -1.0, 1.0))
                comps = dict(comps)
                comps["formal"] = r_lon_formal
                comps["residual"] = r_lon_res
                comps["exposed"] = float(_lon_exposed)
                agent_rewards[agent_id] = float(r_lon)
                lon_formal_by_agent[agent_id] = float(r_lon_formal)
                lon_list.append(float(r_lon))
                lon_comps_acc.append(comps)
            elif agent_id.startswith("signal_"):
                tls_id = agent_id[len("signal_") :]
                try:
                    cur_a = int(action) if not isinstance(action, (list, np.ndarray)) else int(
                        np.asarray(action).reshape(-1)[0]
                    )
                except (TypeError, ValueError):
                    cur_a = 0
                prev_a = self._prev_signal_action.get(tls_id)
                self._prev_signal_action[tls_id] = int(cur_a)
                switched = self._signal_switch_once(
                    tls_id, int(cur_a), prev_a, state, previous_state
                )
                r_sig, sig_comps = compute_signal_reward(
                    state,
                    weights=self.macro_sig_weights,
                    incoming_edges=self.signal_incoming_edges,
                    outgoing_edges=self.signal_outgoing_edges,
                    capacity=self.max_road_capacity,
                    cycle_s=float(getattr(self, "signal_cycle_s", DEFAULT_CYCLE_S)),
                    switched=switched,
                    dt=float(dt),
                    scenario_key=str(getattr(self, "_scenario_key", "") or ""),
                )
                agent_rewards[agent_id] = float(r_sig)
                sig_list.append(float(r_sig))
                global_reward_dict["sig_queue"] = float(sig_comps.get("queue", 0.0))
                global_reward_dict["sig_delay"] = float(sig_comps.get("delay", 0.0))
                global_reward_dict["sig_progression"] = float(
                    sig_comps.get("progression", 0.0)
                )
                global_reward_dict["sig_switch"] = float(sig_comps.get("switch", 0.0))
                global_reward_dict["sig_waiting_increment"] = float(
                    sig_comps.get("waiting_increment", sig_comps.get("total", 0.0))
                )
                global_reward_dict["sig_speed_term"] = float(
                    sig_comps.get("speed_term", 0.0)
                )
                global_reward_dict["sig_waiting_seconds"] = float(
                    sig_comps.get("waiting_seconds", 0.0)
                )
                global_reward_dict["sig_vehicle_time_exposure"] = float(
                    sig_comps.get("vehicle_time_exposure", 0.0)
                )
                global_reward_dict["sig_waiting_vehicles"] = float(
                    sig_comps.get("n_wait", 0.0)
                )
                global_reward_dict["sig_incoming_vehicles"] = float(
                    sig_comps.get("n_veh", 0.0)
                )
                global_reward_dict["sig_pressure_diagnostic"] = float(
                    sig_comps.get("pressure", 0.0)
                )
                global_reward_dict["sig_ql_norm"] = float(
                    sig_comps.get("r_ql_norm", 0.0)
                )
                global_reward_dict["sig_wt_norm"] = float(
                    sig_comps.get("r_wt_norm", 0.0)
                )
                global_reward_dict["sig_raw_ql_m"] = float(
                    sig_comps.get("raw_r_ql_m", 0.0)
                )
                global_reward_dict["sig_raw_wt_s"] = float(
                    sig_comps.get("raw_r_wt_s", 0.0)
                )
                # TB split: formal (unified ql/wt) vs VLM residual.
                global_reward_dict["sig_formal"] = float(
                    sig_comps.get(
                        "formal",
                        sig_comps.get("waiting_increment", sig_comps.get("total", 0.0)),
                    )
                )
                global_reward_dict["sig_residual"] = float(
                    sig_comps.get("residual", 0.0)
                )

        # Also score lat_actions that weren't in actions dict.
        # lat_actions from env are already signed (-1/0/+1) — never remap 0→-1.
        for vid, la in lat_actions.items():
            aid = f"cav_lat_{vid}"
            if aid in agent_rewards:
                continue
            vinfo = state.get("cavs", {}).get(vid)
            if not vinfo:
                continue
            la_i = int(la)
            prev_vinfo = dict(previous_cavs.get(vid) or vinfo)
            prev_peers = prev_peers_snapshot or peers_snapshot
            meta = self._enrich_lat_meta(
                prev_vinfo,
                la_i,
                dict(lat_meta.get(vid, {}) or {}),
                previous_state or state,
                peers=prev_peers,
            )
            prev_lane = previous_cavs.get(vid, {}).get("lane")
            from environment.p1_control import annotate_lane_change
            meta = annotate_lane_change(self, meta, vid, vinfo, prev_lane, state)
            r_lat, lat_comps = self.lateral.compute(
                vinfo,
                la_i,
                meta=meta,
                prev_lane=prev_lane,
                network_queue=_net_q,
                network_queue_ref=_net_q_ref,
            )
            r_lat_formal = float(r_lat)
            r_lat_res, _lat_exposed = self._compose_lat_residual(
                lat_comps or {}, formal=r_lat_formal, action=la_i
            )
            r_lat = float(np.clip(r_lat_formal + r_lat_res, -1.0, 1.0))
            agent_rewards[aid] = float(r_lat)
            lat_list.append(float(r_lat))
            lat_comps_acc.append({"formal": r_lat_formal, "residual": r_lat_res, "exposed": float(_lat_exposed)})

        if lon_comps_acc:
            global_reward_dict["safe"] = float(np.mean([c["safe"] for c in lon_comps_acc]))
            global_reward_dict["eff"] = float(np.mean([c["eff"] for c in lon_comps_acc]))
            global_reward_dict["comfort"] = float(np.mean([c["comfort"] for c in lon_comps_acc]))
            global_reward_dict["platoon"] = float(np.mean([c["platoon"] for c in lon_comps_acc]))
            global_reward_dict["lon_formal"] = float(
                np.mean([c.get("formal", 0.0) for c in lon_comps_acc])
            )
            global_reward_dict["lon_residual"] = float(
                np.mean([c.get("residual", 0.0) for c in lon_comps_acc])
            )
            global_reward_dict["lon_exposed_frac"] = float(
                np.mean([c.get("exposed", 0.0) for c in lon_comps_acc])
            )
            global_reward_dict["lon_residual_nonzero_frac"] = float(
                np.mean(
                    [
                        1.0 if abs(float(c.get("residual", 0.0) or 0.0)) > 1e-12 else 0.0
                        for c in lon_comps_acc
                    ]
                )
            )
        global_reward_dict["lat"] = float(np.mean(lat_list)) if lat_list else 0.0
        global_reward_dict["long"] = float(np.mean(lon_list)) if lon_list else 0.0
        if lat_comps_acc:
            global_reward_dict["lat_formal"] = float(
                np.mean([c.get("formal", 0.0) for c in lat_comps_acc])
            )
            global_reward_dict["lat_residual"] = float(
                np.mean([c.get("residual", 0.0) for c in lat_comps_acc])
            )
            global_reward_dict["lat_exposed_frac"] = float(
                np.mean([c.get("exposed", 0.0) for c in lat_comps_acc])
            )
        else:
            global_reward_dict["lat_formal"] = 0.0
            global_reward_dict["lat_residual"] = 0.0
            global_reward_dict["lat_exposed_frac"] = 0.0

        # Control-zone routing escape: one-shot explicit penalty (see SUMO_interface).
        # Credit it whenever the lateral agent was alive before the transition,
        # including action-hold ticks. The learner still filters non-decision
        # samples, while the penalty can propagate to earlier lane choices.
        escape_n = 0
        pen = float(CONTROL_ESCAPE_PENALTY)
        stage = str(getattr(self, "_training_stage", "S") or "S")
        active_ids = set(active_agent_ids or ())
        for vid, vinfo in (state.get("cavs") or {}).items():
            if not vinfo.get("triggered_escape"):
                continue
            escape_n += 1
            if stage not in ("Lat", "JointAll"):
                continue
            lat_aid = f"cav_lat_{vid}"
            if (
                lat_aid in agent_rewards
                or lat_aid in active_ids
                or vid in lat_actions
                or lat_aid in actions
            ):
                agent_rewards[lat_aid] = float(agent_rewards.get(lat_aid, 0.0)) - pen
        global_reward_dict["escape_penalty_count"] = float(escape_n)

        # Team reward: mean(lat+long over actively controlled vehicles) + signal.
        # Followers / non-DLC CAVs with forced 0.0 must not dilute the mean.
        cav_combined = []
        vids = set()
        for aid in agent_rewards:
            if aid.startswith("cav_lon_"):
                vids.add(aid[len("cav_lon_") :])
            elif aid.startswith("cav_lat_"):
                vid_cand = aid[len("cav_lat_") :]
                if bool((lat_meta.get(vid_cand) or {}).get("dlc_eligible", False)):
                    vids.add(vid_cand)
            elif aid.startswith("cav_"):
                vids.add(aid[4:])
        for vid in vids:
            rl = agent_rewards.get(f"cav_lon_{vid}", agent_rewards.get(f"cav_{vid}", 0.0))
            ra = agent_rewards.get(f"cav_lat_{vid}", 0.0)
            cav_combined.append(float(rl) + float(ra))

        mean_cav = float(np.mean(cav_combined)) if cav_combined else 0.0
        mean_sig = float(np.mean(sig_list)) if sig_list else 0.0
        if cav_combined and sig_list:
            global_reward_scalar = (
                self.team_leader_weight * mean_cav + self.team_signal_weight * mean_sig
            )
        elif cav_combined:
            global_reward_scalar = mean_cav
        elif sig_list:
            global_reward_scalar = mean_sig
        else:
            global_reward_scalar = 0.0

        global_reward_dict["terminal_incident_agents"] = sorted(terminal_incident_agents)
        return float(global_reward_scalar), global_reward_dict, agent_rewards

    def _base_reward_helper(self):
        helper = getattr(self, "_br_helper", None)
        if helper is None:
            helper = BaseReward()
            self._br_helper = helper
        helper.control_zone_length = float(self.control_zone_length)
        helper.DESIRED_SPEED = float(self.DESIRED_SPEED)
        helper.signal_incoming_edges = set(self.signal_incoming_edges or ())
        helper.signal_outgoing_edges = set(self.signal_outgoing_edges or ())
        helper.max_road_capacity = float(getattr(self, "max_road_capacity", 160.0) or 160.0)
        return helper

    def compute_meta_reward(self, state, previous_state):
        """Episode-level meta term; uses live AdaptiveReward zone/capacity."""
        return float(self._base_reward_helper().compute_meta_reward(state, previous_state))

    def summarize_for_vlm(self, state):
        # Lightweight summary for prompts
        return self._base_reward_helper().summarize_for_vlm(state)
