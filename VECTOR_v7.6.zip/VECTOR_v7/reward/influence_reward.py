"""Influence-segment reward for longitudinal CAV control (VECTOR v7).

Problem with the v5.2-v6 longitudinal reward
--------------------------------------------
``LongitudinalReward`` v2 is dominated by the ego delay rate
``-(1 - v_ego / v_free)``. At 30 % penetration most of the system delay sits
in HDVs, and the system benefit of a CAV eco-approach (arriving at the green
start at speed, smoothing the queue it leads) accrues to the vehicles BEHIND
it, while the CAV itself pays a small delay. Under an ego reward the best
response is "drive like IDM", i.e. residual -> 0, which is exactly the G2 rule
stack. The policy cannot beat G2 because its reward says G2 is optimal.

v7 reward (mixed-autonomy practice, cf. Flow / Lagrangian control where AVs
optimise a system-level speed objective):

    S_i = [ego, f1, f2, ...]  following the SUMO follower chain on the lane,
          stopping at the next CAV (it owns its own segment), at
          ``max_followers`` vehicles, or beyond ``max_dist_m`` behind ego.
    r_inf(i) = - (1 / (1 + max_followers)) * sum_{j in S_i} (1 - v_j / v_free_j)

The time integral of sum_j (1 - v_j/v_free_j) is the segment's delay, so the
reward is the CAV's share of system delay with fixed normalisation (a longer
segment means more vehicles depend on this CAV; the value function absorbs
the scale). Pure python, unit-tested in tests/test_influence_reward.py.
"""
from __future__ import annotations

from typing import Any, Dict, List, Mapping, Optional, Tuple

DEFAULT_MAX_FOLLOWERS = 6
DEFAULT_MAX_DIST_M = 90.0
DEFAULT_V_FREE = 16.67


def _f(x: Any, default: float) -> float:
    try:
        v = float(x)
    except (TypeError, ValueError, OverflowError):
        return float(default)
    return v if v == v and v not in (float("inf"), float("-inf")) else float(default)


def _v_free(vinfo: Mapping[str, Any], default: float) -> float:
    for key in ("lane_max_speed", "lane_speed_limit", "speed_limit", "max_speed"):
        if key in vinfo and vinfo.get(key) is not None:
            c = _f(vinfo.get(key), -1.0)
            if c > 0.5:
                return min(c, max(default, c))
    return max(default, 1e-3)


def delay_rate(vinfo: Mapping[str, Any], v_free_default: float = DEFAULT_V_FREE) -> float:
    v = max(_f(vinfo.get("speed", 0.0), 0.0), 0.0)
    vf = _v_free(vinfo, v_free_default)
    return float(min(1.0, max(0.0, 1.0 - v / vf)))


def influence_segment(
    state: Mapping[str, Any],
    ego_vid: str,
    *,
    max_followers: int = DEFAULT_MAX_FOLLOWERS,
    max_dist_m: float = DEFAULT_MAX_DIST_M,
) -> List[str]:
    """[ego, followers...] owned by this CAV (see module docstring)."""
    cavs = state.get("cavs") or {}
    hdvs = state.get("hdvs") or {}
    ego = cavs.get(ego_vid)
    if ego is None:
        return []
    seg = [str(ego_vid)]
    seen = {str(ego_vid)}
    cur = ego
    gap_sum = 0.0
    for _ in range(max(0, int(max_followers))):
        fid = cur.get("follower_id")
        if fid is None:
            break
        fid = str(fid)
        if fid in seen or fid in cavs:
            break  # loop guard / next CAV owns the rest
        nxt = hdvs.get(fid)
        if nxt is None:
            break
        gap_sum += max(_f(cur.get("follower_gap", 0.0), 0.0), 0.0) + max(_f(nxt.get("length", 5.0), 5.0), 0.0)
        if gap_sum > float(max_dist_m):
            break
        seg.append(fid)
        seen.add(fid)
        cur = nxt
    return seg


def influence_delay_reward(
    state: Mapping[str, Any],
    ego_vid: str,
    *,
    max_followers: int = DEFAULT_MAX_FOLLOWERS,
    max_dist_m: float = DEFAULT_MAX_DIST_M,
    v_free_default: float = DEFAULT_V_FREE,
) -> Tuple[float, Dict[str, float]]:
    """r_inf in [-1, 0] plus diagnostics."""
    seg = influence_segment(state, ego_vid, max_followers=max_followers, max_dist_m=max_dist_m)
    if not seg:
        return 0.0, {"n_seg": 0.0, "ego_delay": 0.0, "follower_delay": 0.0}
    cavs = state.get("cavs") or {}
    hdvs = state.get("hdvs") or {}
    ego_d = delay_rate(cavs[seg[0]], v_free_default)
    fol = [delay_rate(hdvs[v], v_free_default) for v in seg[1:]]
    total = ego_d + sum(fol)
    r = -total / float(1 + max(0, int(max_followers)))
    return float(max(-1.0, min(0.0, r))), {
        "n_seg": float(len(seg)),
        "ego_delay": float(ego_d),
        "follower_delay": float(sum(fol)),
    }


def v7_longitudinal_reward(
    state: Mapping[str, Any],
    ego_vid: str,
    *,
    w_inf: float = 0.75,
    w_safe: float = 0.15,
    w_comfort: float = 0.10,
    safe_term: Optional[float] = None,
    comfort_term: Optional[float] = None,
    **seg_kwargs: Any,
) -> Tuple[float, Dict[str, float]]:
    """w_inf * r_inf + w_safe * r_safe_v2 + w_comfort * r_comfort, in [-1, 0].

    ``safe_term`` / ``comfort_term`` come from reward.longitudinal_reward
    (r_safe_v2, r_comfort); pass None to compute them here when available.
    """
    r_inf, comps = influence_delay_reward(state, ego_vid, **seg_kwargs)
    ego = (state.get("cavs") or {}).get(ego_vid) or {}
    if safe_term is None or comfort_term is None:
        try:
            from reward.longitudinal_reward import r_comfort, r_safe_v2

            if safe_term is None:
                safe_term = float(r_safe_v2(ego))
            if comfort_term is None:
                comfort_term = float(r_comfort(_f(ego.get("acceleration", 0.0), 0.0),
                                               _f(ego.get("jerk", 0.0), 0.0)))
        except Exception:
            safe_term = 0.0 if safe_term is None else safe_term
            comfort_term = 0.0 if comfort_term is None else comfort_term
    safe_term = min(0.0, max(-1.0, float(safe_term)))
    comfort_term = min(0.0, max(-1.0, float(comfort_term)))
    total = w_inf * r_inf + w_safe * safe_term + w_comfort * comfort_term
    comps.update({"r_inf": float(r_inf), "r_safe": safe_term, "r_comfort": comfort_term})
    return float(max(-1.0, min(0.0, total))), comps
