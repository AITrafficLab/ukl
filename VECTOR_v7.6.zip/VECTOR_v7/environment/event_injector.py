"""Visual-only traffic events for the VECTOR v7.1 VLM study.

Why
---
In the shipped scenarios the VLM sees a rendering of the same SUMO state the
numeric policy already has, so it cannot add information. Real cameras can,
however, tell WHY a lane is stopped (broken-down car, work zone) while loop
detectors / CAV V2X only see "halted vehicles". This module injects such
events so that (i) the numeric channel keeps exactly what detectors measure
(the lane behind the obstacle fills with halted vehicles, the lane does not
discharge), (ii) the cause is visible only in the BEV render, and (iii) a
blocked lane fools Max-Pressure: its pressure is high but it cannot discharge.

Mechanics (robust under time-to-teleport = 300 s)
-------------------------------------------------
* v7.2 primary mode "convert": an HDV already on the target lane (the one
  closest to the stop line that can still brake comfortably) is held by a
  regular SUMO stop (``setStop``) for the event duration. Under saturation the
  29-36 m near-junction lanes of the 4-leg net never offer an insertion gap
  (v7.1 smoke: started=0/failed=1 every episode), whereas a head-of-lane
  vehicle always exists, and a stalled head vehicle is exactly the case that
  fools Max-Pressure (high pressure, zero discharge). The converted vehicle
  stays observable (detectors see a halted car) but is excluded from travel
  KPIs through the ``on_convert`` callback.
* Fallback mode "insert" (light traffic, empty lane): a dedicated vehicle
  ``evt_<k>`` is inserted at standstill and held by ``setStop``.
* Vehicles at a stop are never jam-teleported; ``setSpeed(0)`` ones would be.
* Only lanes with a neighbour that reaches every downstream edge of the lane
  are eligible, so queued vehicles can always escape by changing lanes; event
  durations stay below the teleport threshold for the queue behind.
* The obstacle is never subscribed by SUMO_interface: it is absent from the
  cavs/hdvs dicts, rewards and travel KPIs, but physically blocks the lane.
* Event schedules are seeded by the SUMO episode seed, so training seeds
  (run_seed * 10000 + episode) and validation/test seeds (900001.., 990001..)
  give disjoint event realisations.

Pure-python scheduling + a thin TraCI adapter; unit-tested with a fake TraCI
in tests/test_v71_events.py.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Set, Tuple

import numpy as np

EVENT_PREFIX = "evt_"

KIND_PARAMS = {
    # length of the blocked segment (m), duration range (s), vType id, colour
    "breakdown": {"length": 4.8, "dur": (120.0, 240.0), "vtype": "EVT_BREAKDOWN", "color": (90, 90, 95, 255)},
    "roadwork": {"length": 14.0, "dur": (180.0, 280.0), "vtype": "EVT_ROADWORK", "color": (255, 140, 0, 255)},
}
DEFAULT_KINDS = ("breakdown", "roadwork")


def is_event_vehicle(vid: Any) -> bool:
    return str(vid).startswith(EVENT_PREFIX)


@dataclass
class EventSpec:
    eid: int
    kind: str
    approach: str
    edge: str
    onset_s: float
    duration_s: float
    length_m: float
    status: str = "scheduled"        # scheduled | inserting | active | done | failed
    lane_id: str = ""
    lane_index: int = -1
    stop_pos: float = -1.0           # front position on the lane (m from lane start)
    dist_to_stopline: float = -1.0
    insert_t: float = -1.0
    pose: Tuple[float, float, float] = (0.0, 0.0, 0.0)   # x, y, angle (SUMO deg)
    attempts: int = 0
    mode: str = ""                   # convert | insert
    host_vid: str = ""               # converted vehicle id (mode == convert)
    fail_reason: str = ""
    last_try_t: float = -1e9
    rejections: int = 0

    @property
    def vid(self) -> str:
        return self.host_vid if self.host_vid else f"{EVENT_PREFIX}{self.eid}"

    @property
    def end_s(self) -> float:
        return float(self.onset_s) + float(self.duration_s)


def make_schedule(
    seed: int,
    control_start_s: float,
    control_end_s: float,
    approaches: Mapping[str, str],
    *,
    rate: float = 2.0,
    kinds: Sequence[str] = DEFAULT_KINDS,
    max_events: int = 4,
    lead_in_s: float = 60.0,
    count: int = 0,
) -> List[EventSpec]:
    """Seeded event plan for one episode. No two events overlap on an approach.

    ``count > 0`` fixes the number of events (short checks, controlled
    studies); otherwise it is Poisson(rate) capped at ``max_events``.
    """
    rng = np.random.default_rng(int(seed) & 0xFFFFFFFF)
    apps = sorted((str(k), str(v)) for k, v in (approaches or {}).items() if v)
    kinds = [k for k in kinds if k in KIND_PARAMS] or list(DEFAULT_KINDS)
    if not apps or control_end_s - control_start_s < lead_in_s + 150.0:
        return []
    n_draw = int(rng.poisson(max(0.0, float(rate))))  # always drawn: keeps the RNG stream stable
    n = int(min(max_events, int(count) if int(count) > 0 else n_draw))
    events: List[EventSpec] = []
    busy: Dict[str, List[Tuple[float, float]]] = {}
    for k in range(n * 4):
        if len(events) >= n:
            break
        kind = kinds[int(rng.integers(len(kinds)))]
        p = KIND_PARAMS[kind]
        dur = float(rng.uniform(*p["dur"]))
        lo = float(control_start_s) + float(lead_in_s)
        hi = float(control_end_s) - dur - 30.0
        if hi <= lo:
            continue
        onset = float(rng.uniform(lo, hi))
        app, edge = apps[int(rng.integers(len(apps)))]
        if any(not (onset + dur + 20.0 <= a or b + 20.0 <= onset) for a, b in busy.get(app, [])):
            continue
        busy.setdefault(app, []).append((onset, onset + dur))
        events.append(EventSpec(eid=len(events), kind=kind, approach=app, edge=edge,
                                onset_s=onset, duration_s=dur, length_m=float(p["length"])))
    events.sort(key=lambda e: e.onset_s)
    for i, e in enumerate(events):
        e.eid = i
    return events


def eligible_lanes(lane_targets: Mapping[int, Set[str]]) -> List[int]:
    """Lane indices whose downstream edges are all reachable from a neighbour lane."""
    out = []
    for idx, targets in sorted(lane_targets.items()):
        if not targets:
            continue
        for nb in (idx - 1, idx + 1):
            if nb in lane_targets and set(targets) <= set(lane_targets[nb]):
                out.append(idx)
                break
    return out


def choose_stop_pos(
    lane_len: float,
    vehicles: Sequence[Tuple[float, float, float]],
    obst_len: float,
    rng: np.random.Generator,
    *,
    d_min: float = 4.0,
    d_max: float = 60.0,
    decel: float = 3.0,
) -> Optional[float]:
    """Front position (m from lane start) for a standstill obstacle, or None.

    ``vehicles``: (front_pos, length, speed) on the lane. The obstacle body
    [pos - obst_len, pos] must fit with 2 m ahead clearance and the follower's
    braking distance v^2/(2 decel) + 5 m behind it.
    """
    L = float(lane_len)
    lo = max(L - float(d_max), float(obst_len) + 1.0)
    hi = L - float(d_min)
    if hi <= lo:
        return None
    cands = np.linspace(lo, hi, 25)
    rng.shuffle(cands)
    veh = sorted((float(p), float(l), float(v)) for p, l, v in vehicles)
    for pos in cands:
        back = pos - float(obst_len)
        ok = True
        for p, l, v in veh:
            v_back = p - l
            if v_back >= back - 0.5:          # vehicle ahead of (or overlapping) the obstacle back
                if v_back < pos + 2.0:        # must start 2 m ahead of the obstacle front
                    ok = False
                    break
            else:                              # follower: its front must stay behind with braking room
                need = v * v / (2.0 * decel) + 5.0
                if p > back - need:
                    ok = False
                    break
        if ok:
            return float(pos)
    return None


def choose_convert_candidate(
    lane_len: float,
    vehicles: Sequence[Tuple[str, float, float, float, bool]],
    *,
    d_min: float = 0.3,
    d_max: float = 60.0,
    decel: float = 3.0,
) -> Optional[Tuple[str, float]]:
    """Head-most HDV that can stop comfortably inside the event window.

    ``vehicles``: (vid, front_pos, speed, length, is_cav). Returns
    (vid, stop_end_pos) or None. The stop must end at least ``d_min`` before
    the stop line and the vehicle must reach it with deceleration <= decel.
    """
    L = float(lane_len)
    best = None
    for vid, pos, spd, _length, is_cav in vehicles:
        if is_cav or is_event_vehicle(vid):
            continue
        dist = L - float(pos)
        if dist < float(d_min) - 1e-6 or dist > float(d_max):
            continue
        need = max(0.0, float(spd)) ** 2 / (2.0 * float(decel))
        end_pos = float(pos) + need + 0.1
        if end_pos > L - float(d_min) + 1e-6:
            continue
        if best is None or float(pos) > best[1]:
            best = (str(vid), float(pos), end_pos)
    return None if best is None else (best[0], best[2])


class TraciEventAdapter:
    """Thin TraCI wrapper (the only part that talks to SUMO)."""

    def __init__(self, traci_module):
        self.t = traci_module
        self._routes: Set[str] = set()
        self._types_ready = False

    def ensure_types(self) -> None:
        if self._types_ready:
            return
        have = set(self.t.vehicletype.getIDList())
        for kind, p in KIND_PARAMS.items():
            if p["vtype"] in have:
                continue
            self.t.vehicletype.copy("DEFAULT_VEHTYPE", p["vtype"])
            self.t.vehicletype.setLength(p["vtype"], float(p["length"]))
            self.t.vehicletype.setMinGap(p["vtype"], 0.5)
            self.t.vehicletype.setColor(p["vtype"], p["color"])
        self._types_ready = True

    def lane_targets(self, edge: str) -> Dict[int, Set[str]]:
        n = int(self.t.edge.getLaneNumber(edge))
        out: Dict[int, Set[str]] = {}
        for i in range(n):
            tgts = set()
            for link in self.t.lane.getLinks(f"{edge}_{i}") or ():
                to_lane = str(link[0])
                tgts.add(to_lane.rsplit("_", 1)[0])
            out[i] = tgts
        return out

    def lane_length(self, lane_id: str) -> float:
        return float(self.t.lane.getLength(lane_id))

    def lane_vehicles(self, lane_id: str) -> List[Tuple[float, float, float]]:
        rows = []
        for vid in self.t.lane.getLastStepVehicleIDs(lane_id) or ():
            try:
                rows.append((float(self.t.vehicle.getLanePosition(vid)),
                             float(self.t.vehicle.getLength(vid)),
                             float(self.t.vehicle.getSpeed(vid))))
            except Exception:
                continue
        return rows

    def lane_candidates(self, lane_id: str) -> List[Tuple[str, float, float, float, bool]]:
        rows = []
        for vid in self.t.lane.getLastStepVehicleIDs(lane_id) or ():
            try:
                tid = str(self.t.vehicle.getTypeID(vid))
                rows.append((str(vid), float(self.t.vehicle.getLanePosition(vid)),
                             float(self.t.vehicle.getSpeed(vid)), float(self.t.vehicle.getLength(vid)),
                             "cav" in tid.lower()))
            except Exception:
                continue
        return rows

    def convert(self, ev: EventSpec, vid: str, end_pos: float, lane_index: int) -> None:
        # v7.3: lane index is passed explicitly. v7.2 read ev.lane_index, which is
        # only written AFTER a successful conversion (still -1 here), so every
        # setStop failed with "No lane with index '-1'".
        if int(lane_index) < 0:
            raise ValueError(f"invalid lane index {lane_index}")
        self.t.vehicle.setStop(vid, ev.edge, pos=float(end_pos), laneIndex=int(lane_index),
                               duration=float(ev.duration_s),
                               startPos=max(0.0, float(end_pos) - 6.0))

    def resume(self, vid: str) -> None:
        try:
            if self.t.vehicle.isStopped(vid):
                self.t.vehicle.resume(vid)
        except Exception:
            pass

    def insert(self, ev: EventSpec) -> None:
        rid = f"{EVENT_PREFIX}route_{ev.edge}"
        if rid not in self._routes:
            if rid not in set(self.t.route.getIDList()):
                self.t.route.add(rid, [ev.edge])
            self._routes.add(rid)
        vtype = KIND_PARAMS[ev.kind]["vtype"]
        self.t.vehicle.add(ev.vid, rid, typeID=vtype, depart="now",
                           departLane=str(ev.lane_index), departPos=f"{ev.stop_pos:.2f}",
                           departSpeed="0")
        self.t.vehicle.setStop(ev.vid, ev.edge, pos=float(ev.stop_pos) + 0.5,
                               laneIndex=int(ev.lane_index), duration=float(ev.duration_s) + 30.0,
                               startPos=max(0.0, float(ev.stop_pos) - float(ev.length_m) - 1.0))

    def present(self, vid: str) -> bool:
        return vid in set(self.t.vehicle.getIDList())

    def freeze(self, vid: str) -> None:
        self.t.vehicle.setLaneChangeMode(vid, 0)

    def pose(self, vid: str) -> Tuple[float, float, float]:
        x, y = self.t.vehicle.getPosition(vid)
        return float(x), float(y), float(self.t.vehicle.getAngle(vid))

    def remove(self, vid: str) -> None:
        self.t.vehicle.remove(vid)


class EventInjector:
    def __init__(self, adapter, events: List[EventSpec], *, seed: int = 0,
                 insert_timeout_s: float = 20.0, d_min: float = 4.0, d_max: float = 60.0,
                 allow_convert: bool = True, allow_insert: bool = True,
                 on_convert=None, log=print, retry_s: float = 1.0):
        self.ad = adapter
        self.events = list(events)
        self.rng = np.random.default_rng((int(seed) * 7919 + 17) & 0xFFFFFFFF)
        self.insert_timeout_s = float(insert_timeout_s)
        self.d_min, self.d_max = float(d_min), float(d_max)
        self.allow_convert, self.allow_insert = bool(allow_convert), bool(allow_insert)
        self.on_convert = on_convert
        self.log = log or (lambda *a, **k: None)
        self.retry_s = max(0.0, float(retry_s))
        self.stats = {"scheduled": float(len(events)), "started": 0.0, "failed": 0.0, "active_s": 0.0,
                      "converted": 0.0, "inserted": 0.0}
        self._targets_cache: Dict[str, Dict[int, Set[str]]] = {}
        self._last_t: Optional[float] = None

    # ---------------------------------------------------------------- runtime
    def tick(self, now: float) -> None:
        now = float(now)
        dt = 0.0 if self._last_t is None else max(0.0, now - self._last_t)
        self._last_t = now
        if any(e.status == "active" for e in self.events):
            self.stats["active_s"] += dt
        for ev in self.events:
            try:
                self._tick_event(ev, now)
            except Exception as exc:  # never let an event break the episode
                self.log(f"[Events] {ev.kind}@{ev.approach} #{ev.eid} {ev.status} error: {exc}", flush=True)
                if ev.status in ("scheduled", "inserting"):
                    self._fail(ev, "error")

    def _fail(self, ev: EventSpec, reason: str) -> None:
        ev.status = "failed"
        ev.fail_reason = str(reason)
        self.stats["failed"] += 1
        key = f"fail_{reason}"
        self.stats[key] = self.stats.get(key, 0.0) + 1.0
        self.log(f"[Events] FAILED {ev.kind}@{ev.approach} #{ev.eid} reason={reason} "
                 f"attempts={ev.attempts} convert_rejections={ev.rejections}", flush=True)

    def _activate(self, ev: EventSpec, now: float) -> None:
        ev.status = "active"
        self.stats["started"] += 1
        try:
            ev.pose = self.ad.pose(ev.vid)
        except Exception:
            pass
        self.log(f"[Events] ACTIVE {ev.kind}@{ev.approach} #{ev.eid} mode={ev.mode} vid={ev.vid} "
                 f"lane={ev.lane_id} d_stopline={ev.dist_to_stopline:.1f}m until=+{ev.end_s - now:.0f}s "
                 f"attempts={ev.attempts} convert_rejections={ev.rejections}", flush=True)

    def _tick_event(self, ev: EventSpec, now: float) -> None:
        if ev.status == "scheduled" and now >= ev.onset_s:
            if now >= ev.end_s:
                self._fail(ev, ev.fail_reason or "expired_no_candidate")
                return
            if now - ev.last_try_t < self.retry_s - 1e-9:
                return  # v7.3: one start attempt per retry_s (v7.2 retried every 0.2 s step)
            ev.last_try_t = now
            self._try_start(ev, now)
        elif ev.status == "inserting":
            if self.ad.present(ev.vid):
                self.ad.freeze(ev.vid)
                self._activate(ev, now)
            elif now - ev.insert_t > self.insert_timeout_s:
                try:
                    self.ad.remove(ev.vid)
                except Exception:
                    pass
                self._fail(ev, "insert_timeout")
        elif ev.status == "active":
            if now >= ev.end_s:
                try:
                    if ev.mode == "convert":
                        self.ad.resume(ev.vid)
                    else:
                        self.ad.remove(ev.vid)
                except Exception:
                    pass
                ev.status = "done"
                self.log(f"[Events] DONE {ev.kind}@{ev.approach} #{ev.eid} vid={ev.vid}", flush=True)
            else:
                try:
                    ev.pose = self.ad.pose(ev.vid)
                except Exception:
                    pass

    def _try_start(self, ev: EventSpec, now: float) -> None:
        ev.attempts += 1
        if ev.edge not in self._targets_cache:
            self._targets_cache[ev.edge] = self.ad.lane_targets(ev.edge)
        lanes = eligible_lanes(self._targets_cache[ev.edge])
        if not lanes:
            self._fail(ev, "no_eligible_lane")
            return
        order = list(lanes)
        self.rng.shuffle(order)
        if self.allow_convert:
            for idx in order:
                lane = f"{ev.edge}_{idx}"
                L = self.ad.lane_length(lane)
                cand = choose_convert_candidate(L, self.ad.lane_candidates(lane),
                                                d_max=self.d_max)
                if cand is None:
                    continue
                vid, end_pos = cand
                try:
                    self.ad.convert(ev, vid, end_pos, int(idx))
                except Exception as exc:  # e.g. "too close to break": try the next lane
                    ev.fail_reason = "convert_rejected"
                    ev.rejections += 1
                    if ev.rejections <= 3:
                        self.log(f"[Events] convert rejected {vid}@{lane}: {exc}"
                                 + (" (further rejections counted silently)" if ev.rejections == 3 else ""),
                                 flush=True)
                    continue
                ev.mode, ev.host_vid = "convert", vid
                ev.lane_index, ev.lane_id, ev.stop_pos = int(idx), lane, float(end_pos)
                ev.dist_to_stopline = float(L - end_pos)
                ev.insert_t = float(now)
                self.stats["converted"] += 1
                if callable(self.on_convert):
                    try:
                        self.on_convert(vid)
                    except Exception:
                        pass
                self._activate(ev, now)
                return
        if not self.allow_insert:
            ev.fail_reason = "no_candidate"
            return
        self.ad.ensure_types()
        for idx in order:
            lane = f"{ev.edge}_{idx}"
            L = self.ad.lane_length(lane)
            pos = choose_stop_pos(L, self.ad.lane_vehicles(lane), ev.length_m, self.rng,
                                  d_min=self.d_min, d_max=self.d_max)
            if pos is None:
                continue
            ev.lane_index, ev.lane_id, ev.stop_pos = int(idx), lane, float(pos)
            ev.dist_to_stopline = float(L - pos)
            ev.insert_t = float(now)
            ev.mode = "insert"
            self.ad.insert(ev)
            self.stats["inserted"] += 1
            ev.status = "inserting"
            return
        # neither a convertible head vehicle nor a free gap: retry next tick
        ev.fail_reason = "no_candidate"

    # ---------------------------------------------------------------- queries
    def active(self) -> List[EventSpec]:
        return [e for e in self.events if e.status == "active"]

    def blocked_lanes(self) -> Set[str]:
        return {e.lane_id for e in self.active() if e.lane_id}

    def lane_blocked_ahead(self, lane_id: str, lane_pos: float, horizon_m: float = 250.0,
                           vid: Optional[str] = None) -> bool:
        for e in self.active():
            if vid is not None and str(vid) == e.vid:
                continue  # the event vehicle itself must stay put
            if e.lane_id == lane_id and e.stop_pos > float(lane_pos) + 0.1 \
                    and e.stop_pos - float(lane_pos) <= float(horizon_m):
                return True
        return False

    def host_vids(self) -> Set[str]:
        return {e.vid for e in self.events if e.mode == "convert" and e.host_vid}

    def visual_list(self) -> List[Dict[str, Any]]:
        """Render-only description (never fed to the numeric observation)."""
        out = []
        for e in self.active():
            x, y, ang = e.pose
            vis_len = e.length_m if e.mode != "convert" else (7.0 if e.kind == "roadwork" else 4.8)
            out.append({"kind": e.kind, "x": x, "y": y, "angle": ang, "vid": e.vid,
                        "length_m": vis_len, "lane": e.lane_id, "approach": e.approach})
        return out

    def truth_approaches(self) -> Dict[str, int]:
        out: Dict[str, int] = {}
        for e in self.active():
            out[e.approach] = out.get(e.approach, 0) + 1
        return out


# ----------------------------------------------------------------------------
# Capacity factors per decision green (shared by obs, MP teacher, rule MP).
# ----------------------------------------------------------------------------
def phase_capacity_factors(
    phase_lanes: Mapping[int, Sequence[str]],
    n_green: int,
    lane_block_prob: Mapping[str, float],
) -> List[float]:
    """factor_p = 1 - mean_{l in lanes(p)} P(lane l blocked)."""
    out = []
    for g in range(int(n_green)):
        lanes = list(dict.fromkeys(phase_lanes.get(g, []) or []))
        if not lanes:
            out.append(1.0)
            continue
        loss = sum(float(min(1.0, max(0.0, lane_block_prob.get(l, 0.0)))) for l in lanes) / len(lanes)
        out.append(float(max(0.0, 1.0 - loss)))
    return out


def lane_probs_from_lanes(blocked: Iterable[str]) -> Dict[str, float]:
    return {str(l): 1.0 for l in blocked}


def lane_probs_from_approach_counts(
    counts: Mapping[str, float],
    approach_lanes: Mapping[str, Sequence[str]],
) -> Dict[str, float]:
    """VLM output is approach-level: spread k blocked lanes uniformly over the approach."""
    out: Dict[str, float] = {}
    for app, k in (counts or {}).items():
        lanes = list(approach_lanes.get(str(app), []) or [])
        if not lanes:
            continue
        p = float(min(1.0, max(0.0, float(k) / len(lanes))))
        for l in lanes:
            out[l] = max(out.get(l, 0.0), p)
    return out


class LaneStallDetector:
    """Detector-level numeric baseline: a lane that does not discharge while green.

    Inputs per sample and lane: is_green, halting count, vehicle-id set (what a
    stop-line + presence detector pair can provide). A lane is flagged after
    ``stall_s`` seconds of its own green with halted vehicles and zero
    departures; the flag clears when a departure is observed during green.
    """

    def __init__(self, stall_s: float = 8.0):
        self.stall_s = float(stall_s)
        self._green_since: Dict[str, float] = {}
        self._prev_ids: Dict[str, frozenset] = {}
        self._stalled: Dict[str, float] = {}

    def update(self, now: float, lanes: Mapping[str, Tuple[bool, int, frozenset]]) -> Set[str]:
        now = float(now)
        for lane, (green, halting, ids) in lanes.items():
            prev = self._prev_ids.get(lane)
            departed = bool(prev is not None and len(prev - ids) > 0)
            self._prev_ids[lane] = ids
            if not green:
                self._green_since.pop(lane, None)
                continue
            if departed or int(halting) <= 0:
                self._green_since[lane] = now
                self._stalled.pop(lane, None)
                continue
            start = self._green_since.setdefault(lane, now)
            if now - start >= self.stall_s:
                self._stalled.setdefault(lane, now)
        return set(self._stalled)

    def stalled(self) -> Set[str]:
        return set(self._stalled)


class PerceptionScore:
    """Approach-level precision / recall / detection latency vs ground truth."""

    def __init__(self):
        self.tp = self.fp = self.fn = self.tn = 0.0
        self._first_seen: Dict[int, float] = {}
        self._onsets: Dict[int, Tuple[str, float]] = {}

    def update(self, now: float, truth_events: Sequence[EventSpec], predicted: Set[str],
               all_approaches: Optional[Iterable[str]] = None) -> None:
        truth = {e.approach for e in truth_events}
        self.tp += len(truth & predicted)
        self.fp += len(predicted - truth)
        self.fn += len(truth - predicted)
        if all_approaches is not None:
            self.tn += len(set(all_approaches) - truth - predicted)
        for e in truth_events:
            t0 = float(e.insert_t) if float(e.insert_t) > 0.0 else float(e.onset_s)
            self._onsets.setdefault(e.eid, (e.approach, t0))
            if e.approach in predicted and e.eid not in self._first_seen:
                self._first_seen[e.eid] = float(now)

    def summary(self) -> Dict[str, float]:
        p = self.tp / (self.tp + self.fp) if (self.tp + self.fp) > 0 else 0.0
        r = self.tp / (self.tp + self.fn) if (self.tp + self.fn) > 0 else 0.0
        lats = [self._first_seen[k] - self._onsets[k][1] for k in self._first_seen if k in self._onsets]
        n_ev = len(self._onsets)
        return {
            "v7_evt_perc_precision": float(p),
            "v7_evt_perc_recall": float(r),
            "v7_evt_detect_latency_s": float(np.mean(lats)) if lats else 0.0,
            "v7_evt_detected_frac": float(len(lats) / n_ev) if n_ev else 0.0,
            # hallucination rate: predicted blockages on approaches without an event
            "v7_evt_perc_fp_rate": float(self.fp / (self.fp + self.tn)) if (self.fp + self.tn) > 0 else 0.0,
        }
