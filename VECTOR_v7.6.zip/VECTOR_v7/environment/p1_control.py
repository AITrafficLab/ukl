"""v6-P1 learning-mechanism helpers (pure; no SUMO, no torch).

P0 showed the residual policy does not beat the repaired rule stack. P1
replaces that residual with a target speed, an individual return, a committed
signal envelope, and a delayed lane-change outcome. ``--profile v524`` and
``--profile v6p0`` do not call these functions.
"""
from __future__ import annotations

import os

import numpy as np


def _on(name: str) -> bool:
    return str(os.environ.get(name, "0")).strip().lower() in ("1", "true", "yes", "on")


def _target_speed_map_v7() -> bool:
    return str(os.environ.get("LON_TARGET_SPEED_MAP", "p1")).strip().lower() == "v7"


def target_speed_from_action_v7(raw, v_max, action_low=-2.2, f_min=0.2):
    """VECTOR v7 speed-advisory map with a NEUTRAL zero action.

    v6-P1 mapped [low, high] linearly onto [0, v_max], so the actor's neutral
    initialisation (raw = 0, see LongitudinalActor._initialize_policy) became
    v* = 2.2/3.2 * v_max = 0.69 v_max (11.5 m/s at 60 km/h): every CAV started
    P1 capped ~31 % below the limit, which alone degrades TIS before learning.

    v7: fraction f = 1 + raw / |low| * (1 - f_min);  v* = f * v_max.
      raw = 0      -> v* = v_max (no cap: SUMO IDM drives, zero shock)
      raw = low    -> v* = f_min * v_max (strong eco-approach slow-down)
      raw > 0      -> v* > v_max (no-op under speed actuation)
    """
    lo = abs(float(action_low)) if abs(float(action_low)) > 1e-6 else 2.2
    fmin = float(np.clip(float(f_min), 0.0, 1.0))
    frac = 1.0 + float(raw) / lo * (1.0 - fmin)
    frac = float(np.clip(frac, fmin, 1.5))
    return float(frac * max(float(v_max), 0.0))


def target_speed_from_action(raw, v_max, action_low=-2.2, action_high=1.0, v_min=0.0):
    """Map the actor's bounded scalar onto a speed in ``[v_min, v_max]``.

    ``LON_TARGET_SPEED_MAP=v7`` switches to the neutral-at-zero map above.
    """
    if _target_speed_map_v7():
        return target_speed_from_action_v7(raw, v_max, action_low=action_low)
    lo = float(action_low)
    hi = float(action_high)
    span = hi - lo
    if span <= 1e-6:
        frac = 0.0
    else:
        frac = (float(raw) - lo) / span
    frac = float(np.clip(frac, 0.0, 1.0))
    vmax = max(float(v_max), 0.0)
    vmin = float(np.clip(float(v_min), 0.0, vmax))
    return float(vmin + frac * (vmax - vmin))


def accel_for_target_speed(
    raw,
    speed,
    v_max,
    action_low=-2.2,
    action_high=1.0,
    a_max=2.6,
    a_min=-4.5,
    tau=1.0,
):
    """Acceleration that tracks the decoded target speed over ``tau`` seconds.

    The existing CACC/ACC blend and RSS shield still run after this command.
    """
    v_star = target_speed_from_action(raw, v_max, action_low, action_high)
    tau = max(float(tau), 1e-3)
    accel = (float(v_star) - float(speed)) / tau
    return float(np.clip(accel, float(a_min), float(a_max)))


def commitment_action_mask(n, cur_g, elapsed, gmin, gmax, next_g, is_green):
    """Extend or end inside ``[gmin, gmax]``. Planned duration T is not a force.

    Before ``gmin`` only the current green is legal. At ``gmax`` only the
    committed next green is legal. In between the agent may keep or switch.
    """
    n = max(int(n), 1)
    cur = int(np.clip(int(cur_g), 0, n - 1))
    nxt = int(np.clip(int(next_g), 0, n - 1))
    mask = np.zeros(n, dtype=np.float32)
    if (not is_green) or float(elapsed) < float(gmin) - 1e-3:
        mask[cur] = 1.0
        return mask
    if float(elapsed) >= float(gmax) - 1e-3:
        mask[nxt] = 1.0
        if nxt == cur and n > 1:
            mask[(cur + 1) % n] = 1.0
            mask[cur] = 0.0
        return mask
    mask[cur] = 1.0
    if nxt != cur:
        mask[nxt] = 1.0
    return mask


def individual_deltas(entries):
    """Own reward only: no same-approach bonus and no cross-approach baseline."""
    return {str(aid): float(own) for aid, _app, own, _peer in (entries or ())}


class LaneChangeLedger:
    """Credit a lane change from the distance gained over the next ``delay_s``.

    ``p1_tt_delta`` is measured time minus the time the pre-change speed would
    have needed to cover the same distance (negative means the change was faster).
    ``p1_mobil`` is the normalized closing speed imposed on the new follower.
    """

    def __init__(self, delay_s=15.0):
        self.delay_s = float(np.clip(float(delay_s), 10.0, 20.0))
        self._open = {}

    def observe(self, vid, t, lane, dist, speed, rear_closing=0.0):
        vid = str(vid)
        t = float(t)
        lane = str(lane or "")
        dist = max(float(dist or 0.0), 0.0)
        speed = max(float(speed or 0.0), 0.0)
        rec = self._open.get(vid)
        out = {}
        if rec is None:
            self._open[vid] = {"lane": lane, "dist": dist, "speed": speed, "t": t}
            return out
        changed = bool(lane and rec.get("lane") and lane != rec.get("lane") and "t0" not in rec)
        if changed:
            rec["t0"] = t
            rec["dist0"] = float(rec.get("dist", dist))
            rec["v0"] = max(float(rec.get("speed", speed)), 0.5)
            rec["mobil"] = float(np.clip(-max(0.0, float(rear_closing)) / 5.0, -1.0, 0.0))
        rec["lane"] = lane or rec.get("lane", "")
        rec["dist"] = dist
        rec["speed"] = speed
        rec["t"] = t
        if "t0" in rec and t - float(rec["t0"]) >= self.delay_s - 1e-6:
            gain = max(0.0, float(rec["dist0"]) - dist)
            elapsed = max(t - float(rec["t0"]), 1e-3)
            tt_cf = gain / max(float(rec["v0"]), 0.5)
            out["p1_tt_delta"] = float(elapsed - tt_cf)
            out["p1_mobil"] = float(rec.get("mobil", 0.0))
            for key in ("t0", "dist0", "v0", "mobil"):
                rec.pop(key, None)
        self._open[vid] = rec
        return out


def annotate_lane_change(owner, meta, vid, vinfo, prev_lane, state):
    """Attach a matured lane-change outcome when ``P1_LAT_DELAYED`` is on."""
    if not _on("P1_LAT_DELAYED"):
        return meta
    meta = dict(meta or {})
    ledger = getattr(owner, "_p1_lc_ledger", None)
    if ledger is None:
        ledger = LaneChangeLedger()
        setattr(owner, "_p1_lc_ledger", ledger)
    stats = (state or {}).get("stats") or {}
    try:
        sim_t = float(stats.get("time", 0.0) or 0.0)
    except (TypeError, ValueError):
        sim_t = 0.0
    vinfo = vinfo or {}
    del prev_lane
    extra = ledger.observe(
        vid,
        sim_t,
        vinfo.get("lane"),
        vinfo.get("dist_to_stopline", 0.0),
        vinfo.get("speed", 0.0),
        meta.get("target_rear_closing", 0.0),
    )
    meta.update(extra)
    return meta


def decision_step(step_num, hold_steps) -> bool:
    hold = max(int(hold_steps), 1)
    return int(step_num) % hold == 0
