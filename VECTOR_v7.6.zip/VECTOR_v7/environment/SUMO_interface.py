import math
import os
import sys
import numpy as np

# SUMO tools (traci/sumolib/libsumo) must be on sys.path before import when not pip-installed.
if 'SUMO_HOME' in os.environ:
    tools = os.path.join(os.environ['SUMO_HOME'], 'tools')
    if tools not in sys.path:
        sys.path.insert(0, tools)
else:
    sys.exit("Please declare environment variable 'SUMO_HOME'")

# Headless training defaults to libsumo (in-process, no TCP). Disable with
# USE_LIBSUMO=0 or --gui (train_RL sets USE_LIBSUMO=0 before importing us).
# LIBSUMO_AS_TRACI must be set BEFORE any ``import traci`` in this process.
_WANT_LIBSUMO = str(os.environ.get("USE_LIBSUMO", "1")).strip().lower() not in (
    "0",
    "false",
    "no",
    "off",
)
_USING_LIBSUMO = False
if _WANT_LIBSUMO:
    try:
        import libsumo

        # Eclipse SUMO ``tools/`` often shadows site-packages ``traci`` on
        # PYTHONPATH; force the process-wide name to libsumo so every
        # ``import traci`` (including tls_phases) shares one in-process sim.
        os.environ["LIBSUMO_AS_TRACI"] = "1"
        sys.modules["traci"] = libsumo
        if "traci.constants" not in sys.modules:
            # libsumo exposes constants at libsumo.constants
            sys.modules["traci.constants"] = libsumo.constants
        _USING_LIBSUMO = True
        print("[SUMO] TraCI backend: libsumo (in-process)", flush=True)
    except Exception as exc:
        # ImportError on missing package; OSError/ImportError on DLL ABI mismatch
        # (e.g. sumo-data wheel newer than libsumo/_libsumo.pyd).
        _USING_LIBSUMO = False
        print(
            f"[SUMO] libsumo unavailable ({type(exc).__name__}: {exc}); "
            "falling back to socket TraCI",
            flush=True,
        )

import traci
import traci.constants as tc  # 引入批量订阅常量
from sumolib.miscutils import getFreeSocketPort


def should_keep_sticky_leader(vid, vinfo, leader_vids, near_stopline_m=25.0):
    """True if a former/current leader should keep sticky RL ownership.

    Keep sticky only for: current DBSCAN leaders, vehicles in the junction, or
    vehicles within ``near_stopline_m`` of the stop line. Mid-corridor former
    solo leaders must drop so followers return to IDM/CACC.
    """
    if vinfo is None:
        return False
    if not (
        vinfo.get("in_control_zone", False)
        or vinfo.get("in_platoon_zone", False)
        or vinfo.get("is_in_junction", False)
    ):
        return False
    try:
        dist_d = float(vinfo.get("dist_to_stopline", 999.0) or 999.0)
    except (TypeError, ValueError, OverflowError):
        dist_d = 999.0
    near = float(near_stopline_m)
    return bool(
        bool(vinfo.get("is_in_junction", False))
        or vid in leader_vids
        or (0.0 <= dist_d <= near)
    )


def using_libsumo() -> bool:
    """True when this process bound ``traci`` to libsumo."""
    return bool(_USING_LIBSUMO)

from environment.cav_state_builder import (
    driver_lane_offset,
    lat_dof_mode,
    lc_cooldown_seconds,
)
from environment.platoon_dbscan import PlatoonTracker
from environment import gap_policy as _gap_policy
from environment.zone_lc import desired_lc_mode
from environment.zone_manager import zone_flags
from reward.signal_reward import STARVE_WAIT_S
from reward.longitudinal_reward import DANGER_TTC
from environment.tls_phases import (
    MAX_SIGNAL_ACTIONS,
    green_phase_indices as program_green_indices,
    phase_kinds as classify_program_phases,
)

class SUMOEnvironment:
    # Stopline: 0..200 keep-lane (all); 200..700 lon/LC band; >700 free.
    CONTROL_ZONE_DISTANCE = 200.0
    PLATOON_FORMATION_LENGTH = 500.0
    PLATOON_ZONE_DISTANCE = 700.0
    MAX_SPEED = 16.67  # 60 km/h; overridden by scenario.SPEED_LIMIT_MS when present
    # Cross-junction defaults (4 green phases, G/Y alternating).
    MIN_GREEN_DURATION = 10.0
    MIN_GREEN_BY_PHASE = (10.0, 10.0, 10.0, 10.0, 10.0)
    MAX_GREEN_DURATION = 40.0
    GREEN_DECISION_INTERVAL = 5.0
    YELLOW_DURATION = 3.0
    ALL_RED_DURATION = 2.0
    # Cross: equal max for each of 4 greens unless overridden.
    MAX_GREEN_BY_PHASE = (40.0, 40.0, 40.0, 40.0, 40.0)
    JUNCTION_CLEARANCE_ACCEL = 0.8
    # Petrol density for converting SUMO fuel mass (mg) → litres (SUMO ≥1.14 default).
    FUEL_DENSITY_MG_PER_L = 740000.0
    # Green duration T = clip(g1 + k * Lq, g1, Gmax); Lq = sum of phase-lane queues.
    GREEN_DURATION_K = 0.35
    # Deprecated: no longer applied (kept so old configure/tests do not AttributeError).
    GREEN_DURATION_CAP_EXTRA = 30.0
    # Task-book starve = vehicle wait ≥105s. Idle-phase clock is optional
    # (useful for empty-looking protected-right pockets); default off / scenario on.
    STARVE_IDLE_CLOCK_ENABLED = os.environ.get(
        "STARVE_IDLE_CLOCK", ""
    ).strip().lower() in ("1", "true", "yes", "on")
    STARVE_IDLE_S = 75.0
    # Cycle fairness: each demand-bearing green served ≥1× per cycle (all junctions).
    CYCLE_FAIRNESS_ENABLED = True
    # Optional 4leg split: after a thru is served, prefer pending protected rights
    # over remaining thrus (empty = disabled; 3/5leg leave unset).
    CYCLE_THRU_GREENS = ()
    CYCLE_PROTECTED_GREENS = ()
    # Stage-Lon soft-start: residual a = a_IDM + β·Δa_π (or legacy convex mix).
    LON_IDM_MIX_BETA = 1.0
    LON_RESIDUAL_IDM = os.environ.get(
        "LON_RESIDUAL_IDM", "1"
    ).strip().lower() not in ("0", "false", "no", "off")
    LON_RESIDUAL_BOUND = 2.2
    LON_RESIDUAL_LOW = -2.2
    LON_RESIDUAL_HIGH = 1.0
    # 130m smooth glide-to-stop (-1.25 m/s^2) + GLOSA green-wave soft envelope.
    RED_GLIDE_ENVELOPE_ENABLED = os.environ.get(
        "LON_RED_GLIDE_ENVELOPE", "1"
    ).strip().lower() not in ("0", "false", "no", "off")
    # v5.2.2: continuous glide envelope only for head-of-queue / clear approach.
    # Slow followers stay on IDM/CACC gaps to preserve queue storage capacity.
    RED_GLIDE_HEAD_ONLY = os.environ.get(
        "LON_RED_GLIDE_HEAD_ONLY", "1"
    ).strip().lower() not in ("0", "false", "no", "off")
    RED_GLIDE_FOLLOWER_LEADER_MIN_M = 30.0
    # Queued/slow CAV followers are handed back to SUMO IDM entirely.
    IDM_FOLLOWER_ENABLED = os.environ.get(
        "LON_IDM_FOLLOWER", "1"
    ).strip().lower() not in ("0", "false", "no", "off")
    IDM_FOLLOWER_MAX_SPEED_MS = 1.5
    IDM_FOLLOWER_MAX_GAP_M = 30.0
    RED_GLIDE_DECEL = 1.25
    RED_GLIDE_HORIZON_M = 130.0
    RED_STOP_BUFFER_M = 0.25
    GLOSA_MIN_DIST_M = 16.0
    GLOSA_MAX_DIST_M = 220.0
    GLOSA_MAX_TTG_S = 28.0
    GLOSA_ARRIVAL_BUFFER_S = 1.2
    GLOSA_MIN_SPEED_MS = 3.5
    DBSCAN_EPS = 0.8
    DBSCAN_MIN_SAMPLES = 2
    DBSCAN_HYSTERESIS = 5
    TOP3_PHASE_MASK = True
    # When False (Stage-S), no CAV gets RL accel — all use IDM.
    CAV_RL_ENABLED = True
    # Stage-Lat / JointAll: CAV LC owned by lat_actor in the 200..700 m band.
    LATERAL_RL_OWNS_LC = False
    # Universal 0..200 m keep-lane for all vehicle types (also applied in zone_lc).
    CONTROL_ZONE_KEEP_LANE = True
    # Control all corridor CAVs by default so followers can maintain compact
    # 1.0..3.5 m queues and platoons; override via --leaders-only or env var.
    CAV_CONTROL_LEADERS_ONLY = os.environ.get(
        "CAV_CONTROL_LEADERS_ONLY", "0"
    ).strip().lower() in ("1", "true", "yes", "on")
    # TraCI error sentinel (-2^30). Treat near-sentinel junk the same way.
    _TRACI_INVALID = float(tc.INVALID_DOUBLE_VALUE)
    _TRACI_INVALID_FLOOR = -1.0e9

    # Cheap vars: subscribed for every vehicle every step.
    # VAR_NEXT_TLS enables network-agnostic control-zone detection (cross + Dublin).
    # Fuel/CO2 are optional (see enable_emissions); off by default for training speed.
    _BASE_SUB_VARS_CORE = [
        tc.VAR_ROAD_ID, tc.VAR_LANE_ID, tc.VAR_LANEPOSITION,
        tc.VAR_SPEED, tc.VAR_ACCELERATION, tc.VAR_POSITION, tc.VAR_ANGLE,
        tc.VAR_LENGTH,
        tc.VAR_TYPE, tc.VAR_ACCUMULATED_WAITING_TIME,
        tc.VAR_NEXT_TLS,
    ]
    _EMISSION_SUB_VARS = [
        tc.VAR_FUELCONSUMPTION,
        tc.VAR_CO2EMISSION,
    ]
    _ZONE_EXTRA_SUB_VARS = [
        tc.VAR_NEXT_LINKS,
        tc.VAR_SPEED_WITHOUT_TRACI,
    ]
    # Optional: SUMO ≥1.x exposes VAR_FOLLOWER (0x78). Probe at subscribe time;
    # get_state falls back to getFollower when the var is absent or empty.
    _VAR_FOLLOWER = getattr(tc, "VAR_FOLLOWER", None)
    # Backward-compatible aliases (include emissions; instance lists may omit them).
    _BASE_SUB_VARS = _BASE_SUB_VARS_CORE + _EMISSION_SUB_VARS
    _ZONE_SUB_VARS = _BASE_SUB_VARS + _ZONE_EXTRA_SUB_VARS

    def _synth_remaining(self, synth, now):
        """Seconds left in a synthesized yellow (+ all-red) transition."""
        try:
            el = max(0.0, float(now) - float(synth.get("started_at", now)))
        except (TypeError, ValueError):
            el = 0.0
        y = float(getattr(self, "YELLOW_DURATION", 3.0))
        ar = float(getattr(self, "ALL_RED_DURATION", 2.0))
        if str(synth.get("mode") or "") == "yellow":
            return max(0.0, y - el) + ar
        return max(0.0, ar - el)

    def _time_to_green(self, tls_id, link_index, current_link_state, signal_info=None):
        if not tls_id or link_index < 0:
            return -1.0
        if str(current_link_state).lower() == 'g':
            return 0.0

        signal_info = signal_info or self._signals.get(tls_id, {})
        wait_time = float(signal_info.get('remaining_time', 0.0))
        current_phase = (
            int(signal_info['phase'])
            if 'phase' in signal_info else traci.trafficlight.getPhase(tls_id)
        )
        phases = self.signal_programs.get(tls_id)
        if phases is None:
            phases = self._logic_phases_from_traci(tls_id)
            self.signal_programs[tls_id] = phases
        try:
            synth_next = int(signal_info.get('synth_next', -1)) if signal_info else -1
        except (TypeError, ValueError):
            synth_next = -1
        if synth_next >= 0 and phases and bool(getattr(self, "SPAT_SYNTH_FIX", True)):
            # v5.2.4: transition in progress -> next green is known. Walk the
            # static program from it (v5.2.3 walked from the old green).
            n_ph = len(phases)
            for offset in range(0, n_ph):
                phase = phases[(synth_next + offset) % n_ph]
                if link_index < len(phase.state) and phase.state[link_index].lower() == 'g':
                    return wait_time
                wait_time += float(phase.duration)
            return -1.0
        for offset in range(1, len(phases) + 1):
            phase = phases[(current_phase + offset) % len(phases)]
            if link_index < len(phase.state) and phase.state[link_index].lower() == 'g':
                return wait_time
            wait_time += float(phase.duration)
        return -1.0

    @classmethod
    def _traci_valid_double(cls, value, *, non_negative=False):
        """Return float if TraCI value is usable; else None (sentinel / junk)."""
        try:
            v = float(value)
        except (TypeError, ValueError):
            return None
        if not np.isfinite(v) or v <= cls._TRACI_INVALID_FLOOR or v == cls._TRACI_INVALID:
            return None
        if non_negative and v < 0.0:
            return 0.0
        return v

    @staticmethod
    def resolve_demand_route_file(sumocfg_file, demand_profile="full"):
        """Return absolute path to ``*_quick.rou.xml`` / ``*_full.rou.xml`` if present.

        ``demand_profile``: ``\"quick\"`` | ``\"full\"`` (default). Falls back to
        None so SUMO uses the route-files entry in the sumocfg (normally full).
        """
        profile = str(demand_profile or "full").strip().lower()
        if profile in ("q", "smoke"):
            profile = "quick"
        if profile not in ("quick", "full"):
            profile = "full"
        cfg = os.path.abspath(sumocfg_file)
        cfg_dir = os.path.dirname(cfg)
        stem = os.path.splitext(os.path.basename(cfg))[0]
        cand = os.path.join(cfg_dir, f"{stem}_{profile}.rou.xml")
        if os.path.isfile(cand):
            return cand
        return None

    def __init__(
        self,
        sumocfg_file,
        use_gui=False,
        step_length=0.2,
        terminate_on_gridlock=False,
        sumo_port=None,
        demand_profile="full",
        enable_emissions=None,
    ):
        self.sumocfg_file = sumocfg_file
        self.use_gui = use_gui
        self.step_length = step_length
        if bool(use_gui) and bool(_USING_LIBSUMO):
            raise RuntimeError(
                "sumo-gui requires TraCI sockets; restart with USE_LIBSUMO=0 "
                "(train_RL --gui sets this automatically before import)."
            )
        # Default on via SUMO_ENABLE_EMISSIONS (set 0/false/off to skip HBEFA cost).
        if enable_emissions is None:
            enable_emissions = str(
                os.environ.get("SUMO_ENABLE_EMISSIONS", "1")
            ).strip().lower() not in ("0", "false", "no", "off")
        self.enable_emissions = bool(enable_emissions)
        self._base_sub_vars = list(self._BASE_SUB_VARS_CORE)
        if self.enable_emissions:
            self._base_sub_vars.extend(self._EMISSION_SUB_VARS)
        self._zone_sub_vars = list(self._base_sub_vars) + list(self._ZONE_EXTRA_SUB_VARS)
        self.demand_profile = str(demand_profile or "full").strip().lower()
        if self.demand_profile in ("q", "smoke"):
            self.demand_profile = "quick"
        if self.demand_profile not in ("quick", "full"):
            self.demand_profile = "full"
        self.route_file = self.resolve_demand_route_file(
            sumocfg_file, self.demand_profile
        )
        # Fixed-timing fill before RL; overridable via configure_control / CLI.
        self.warmup_seconds = 300.0
        # v4: OD must stay intact in training AND evaluation (train == eval).
        # v3 retargeted stuck CAVs in training and ALWAYS rewrote stuck HDVs.
        self.allow_deadlock_retarget = False
        self.allow_hdv_retarget = False
        self._od_rewrites = 0
        # v4: HDVs keep SUMO strategic LC inside the control zone.
        self.CONTROL_ZONE_KEEP_LANE_HDV = False
        # v4 measurement: queue = halted vehicles only ('legacy' = v3, which also
        # counted DBSCAN clusters of MOVING platoons as queue length).
        self.QUEUE_MODE = "halted"
        self.QUEUE_HALT_SPEED_MS = 0.5
        self.INCLUDE_PERMISSIVE_LANES = True
        self._permissive_only_lanes = {}
        # v4: arrival-aware green budget (principled replacement of the DBSCAN side effect).
        self.GREEN_ARRIVAL_AWARE = True
        self.GREEN_ARRIVAL_K = 2.0
        self.GREEN_ARRIVAL_WINDOW_S = 10.0
        self._last_green_arr = {}
        # v4: SUMO runtime options re-applied at every reset().
        self.max_depart_delay = -1.0
        self.collision_check_junctions = True
        self.demand_randomizer = None
        self._active_route_file = None
        self._scheduled_depart = {}
        self._warmup_arrived = set()
        self._lane_index_cache = (None, None, None)
        self.SIGNAL_MASK_CONTRACT = str(os.environ.get("SIGNAL_MASK_CONTRACT", "1")).strip().lower() not in ("0", "false", "no", "off")
        self._last_signal_mask = {}
        self.sumo_diag_dir = None
        # v5.2: GLOSA speed floor is runtime-configurable (--glosa-min-speed).
        try:
            _gms = os.environ.get("LON_GLOSA_MIN_SPEED", "")
            if _gms not in ("", None):
                self.GLOSA_MIN_SPEED_MS = max(0.5, float(_gms))
        except (TypeError, ValueError):
            pass
        self.ABLATE_ZERO_LON_RESIDUAL = str(
            os.environ.get("VECTOR_ABLATE_ZERO_LON_RESIDUAL", "0")
        ).strip().lower() in ("1", "true", "yes", "on")
        # v5.2.1 ablation A0: CAVs that would get Lon RL fall back to SUMO's native
        # IDM (no residual, CACC, envelopes or shield) -- the Stage-S behaviour.
        self.ABLATE_CAV_NATIVE_IDM = str(
            os.environ.get("VECTOR_ABLATE_CAV_NATIVE_IDM", "0")
        ).strip().lower() in ("1", "true", "yes", "on")
        # v5.2.4 control-stack bisection switches (defaults = v5.2.3 behaviour).
        self._load_v524_switches()
        self._speed_capped = {}
        self._jstall_reset()
        self._lon_noop_vids_step = []
        # Default off: do not end episodes early on queue-gridlock heuristic.
        # Episodes end on max_steps / traffic_exhausted (or explicit True).
        self.terminate_on_gridlock = bool(terminate_on_gridlock)
        # Explicit TraCI port per env (avoids concurrent SUMO port collisions).
        if sumo_port is None:
            sumo_port = getFreeSocketPort()
        if sumo_port is None:
            raise RuntimeError("Failed to allocate a free TraCI port for SUMO")
        self.sumo_port = int(sumo_port)
        self._traci_label = f"sumo_{self.sumo_port}"
        self.controlled_cavs = set()
        self.phase_started_at = {}
        self.last_signal_phase = {}
        self.signal_programs = {}
        self._collision_episodes = 0

        # Static / slow-changing caches
        self.vehicle_types = {}
        self.lane_lengths_cache = {}
        self._edge_lane_lengths = {}
        self.vehicle_lane_mode_cache = {}
        self.vehicle_route_fixed = set()
        self.vehicle_routes = {}
        # vid → (current_edge, next_edge|None); invalidated on route change / reset.
        self._route_next_by_vid = {}
        self.vtype_dynamics_cache = {}
        self.tls_ids = []
        self._signals = {}
        self._sim_time = 0.0
        self._last_collisions = 0
        self._last_teleports = 0
        self._zone_subscribed = set()
        # vid → static length (m); constant for a vehicle's lifetime.
        self._vehicle_length_cache = {}
        # None=unprobed, True=zone sub returns follower, False=use getFollower RPC.
        self._follower_sub_ok = None
        # Fine-grained zone info from last get_state; reused by the following step()
        # (same sim time — no simulationStep in between) to avoid duplicate TraCI gets.
        self._zone_detail = {}
        # vid → sim-time when the vehicle first entered the control zone (for reward cv).
        self._zone_enter_time = {}
        # One-shot control-zone routing escape (illegal lane → force/escape LC).
        self._escape_penalty_issued = set()  # already penalized this control-zone visit
        self._step_escape_triggered = set()  # vids that triggered escape this step()
        # Episode traffic KPIs (cleared after warmup / on reset)
        self._depart_times = {}
        self._prev_speeds = {}
        self._last_accum_wait = {}
        self._episode_travel_times = []
        self._episode_waiting_times = []
        self._episode_stops = 0
        self._ep_fuel_mg = 0.0
        self._ep_co2_mg = 0.0
        self._ep_dist_m = 0.0
        # Unique vehicles observed while integrating emissions (post-warmup episode).
        self._ep_vehicle_ids = set()
        # Per-vehicle emission integrals for mean intensity (L/100km, g/km).
        self._ep_veh_fuel_mg = {}
        self._ep_veh_co2_mg = {}
        self._ep_veh_dist_m = {}
        # Optional per-scenario approach map + green bounds (scenario.py).
        self._approach_cardinal = {}
        self._approach_chains = {}
        self._edge_lane_dests = {}  # edge → {lane_idx → {to_edge}} for routing masks
        self._edge_n_lanes = {}  # edge → lane count (static, from net.xml)
        self._lane_to_edges_ser = {}  # edge → {lane_idx → [to_edge, ...]} cached lists
        # True after net.xml topology parse; get_state must not TraCI for n_lanes /
        # lane_to_edges / lane lengths once this is set.
        self._static_topology_ready = False
        # Populated from net XML in _calculate_max_road_capacity (3/4-leg LHT, 5-leg RHT).
        self.lefthand = False
        self.incoming_edges = []
        self.outgoing_edges = []
        # Gridlock heuristic: scale by approaches; require sustained exceedance.
        # (Legacy fixed waiting>60 killed 5leg after short warmup with AQL≈80.)
        self._gridlock_waiting_threshold = 120
        # Gridlock detector in wall-seconds (independent of step_length).
        self._gridlock_hold_steps = max(1, int(round(10.0 / float(self.step_length))))  # ~10 s
        self._gridlock_grace_steps = max(1, int(round(20.0 / float(self.step_length))))  # ~20 s after handover
        self._gridlock_streak = 0
        self._control_steps = 0
        # Last is_done() cause: "" | "traffic_exhausted" | "gridlock"
        self._done_reason = ""
        self._run_seed = 0
        norm = os.path.normpath(sumocfg_file).lower()
        # Dublin-style layout also for 3-leg / 4-leg target junctions.
        self._dublin_mode = ("dublin" in norm) or ("-leg" in norm) or ("leg(" in norm)

        self.sub_results = {}
        self.platoon_tracker = PlatoonTracker(
            eps=float(self.DBSCAN_EPS),
            min_samples=int(self.DBSCAN_MIN_SAMPLES),
            hysteresis_steps=int(self.DBSCAN_HYSTERESIS),
        )
        self._platoon_info = {}
        self._leader_vids = set()
        self._sticky_leader_vids = set()  # keep RL through junction clearance
        # vid → sim-time when discretionary LC keep-lock expires.
        self._lc_cooldown_until = {}
        self._phase_incoming_lanes = {}  # tls_id -> {green_idx: [lane_ids]}
        self._green_last_served = {}  # tls_id -> {green_idx: sim time last active}
        self._cycle_served = {}  # tls_id -> set of green indices served this cycle
        self._last_green_T = {}  # tls_id -> last computed T
        self._last_green_lv = {}  # tls_id -> queue length used for T
        self._last_green_index = {}  # tls_id -> green index associated with cached T

        # Load scenario.py early so BEV can bind junction center / approach edges
        # before TraCI starts (reset() will reload safely).
        self._load_scenario_config()
        self.max_road_capacity = self._calculate_max_road_capacity()

        sumo_binary = "sumo-gui" if self.use_gui else "sumo"
        self.sumo_cmd = [
            sumo_binary,
            "-c", self.sumocfg_file,
            "--step-length", str(self.step_length),
            "--no-step-log", "true",
            "--no-warnings", "true",
            "--time-to-teleport", "300",
            # v4: --max-depart-delay / --collision.check-junctions / --route-files
            # are injected per reset() by _runtime_sumo_options().
            # Avoid default 100s sliding window forgetting waits on long exits.
            "--waiting-time-memory", "10000",
            # 1.0 = full HBEFA every step (slow). 0 = skip emission devices in training.
            "--device.emissions.probability",
            "1.0" if self.enable_emissions else "0",
            "--start", "true",
            "--quit-on-end", "true"
        ]
        # Override sumocfg route-files: quick vs full demand (see *_quick/_full.rou.xml).
        if self.route_file:
            self.sumo_cmd.extend(["--route-files", self.route_file])
            print(
                f"[SUMO] demand_profile={self.demand_profile} "
                f"route_file={os.path.basename(self.route_file)}"
            )
        print(
            f"[SUMO] emissions={'on' if self.enable_emissions else 'off (training)'}",
            flush=True,
        )

    def _subscribe_vehicle(self, vid, in_zone=False):
        """Register (or upgrade/downgrade) vehicle subscription."""
        # Do NOT append VAR_FOLLOWER to vehicle.subscribe: SUMO requires a
        # distance parameter (like subscribeLeader). Use getFollower in
        # _parse_follower instead; subscribeLeader remains for leaders.
        vars_ = list(self._zone_sub_vars if in_zone else self._base_sub_vars)
        traci.vehicle.subscribe(vid, vars_)
        if in_zone:
            try:
                traci.vehicle.subscribeLeader(vid, dist=100.0)
            except Exception:
                pass
            self._zone_subscribed.add(vid)
        else:
            self._zone_subscribed.discard(vid)
        # Regular subscribe cannot carry follower dist → always RPC fallback.
        self._follower_sub_ok = False

    def _sync_zone_subscriptions(self):
        """Upgrade/downgrade subscriptions based on current control-zone membership."""
        alive = set(self.sub_results.keys())
        for vid in list(self._zone_subscribed - alive):
            self._zone_subscribed.discard(vid)
        # Drop length / next-edge caches for departed vehicles.
        if self._vehicle_length_cache:
            for vid in list(self._vehicle_length_cache.keys()):
                if vid not in alive:
                    self._vehicle_length_cache.pop(vid, None)
        route_next = getattr(self, "_route_next_by_vid", None)
        if route_next:
            for vid in list(route_next.keys()):
                if vid not in alive:
                    route_next.pop(vid, None)

        # Subscribe the full platoon corridor (not only 200 m control), so
        # formation-band vehicles get leader vars without per-step TraCI fallback.
        for vid, v_data in self.sub_results.items():
            in_zone = self._in_platoon_zone(v_data)
            was_zone = vid in self._zone_subscribed
            if in_zone and not was_zone:
                self._subscribe_vehicle(vid, in_zone=True)
            elif (not in_zone) and was_zone:
                self._subscribe_vehicle(vid, in_zone=False)

    @staticmethod
    def _unpack_controlled_link(conn):
        """Compat: traci (from, to, via) tuple or libsumo TraCILink object."""
        if conn is None:
            return "", ""
        if hasattr(conn, "fromLane"):
            return (
                str(getattr(conn, "fromLane", "") or ""),
                str(getattr(conn, "toLane", "") or ""),
            )
        try:
            return str(conn[0] or ""), str(conn[1] or "")
        except (TypeError, IndexError, KeyError):
            return "", ""

    @staticmethod
    def _unpack_next_tls_entry(entry):
        """Compat: traci 4-tuple or libsumo TraCINextTLSData."""
        if entry is None:
            return None, -1, -1.0, "n"
        if hasattr(entry, "dist") or hasattr(entry, "id") or hasattr(entry, "tlsID"):
            tls_id = getattr(entry, "id", None)
            if tls_id is None:
                tls_id = getattr(entry, "tlsID", None)
            tl_index = getattr(entry, "tlIndex", None)
            if tl_index is None:
                tl_index = getattr(entry, "tlsIndex", -1)
            return (
                (str(tls_id) if tls_id is not None else None),
                int(tl_index if tl_index is not None else -1),
                float(getattr(entry, "dist", -1.0)),
                str(getattr(entry, "state", "n")),
            )
        return str(entry[0]), int(entry[1]), float(entry[2]), str(entry[3])

    @staticmethod
    def _unpack_next_links_flags(first):
        """Compat: traci connection tuple indices 3/4 or libsumo .isOpen/.hasFoe."""
        if first is None:
            return True, False
        if hasattr(first, "isOpen") or hasattr(first, "hasFoe"):
            return bool(getattr(first, "isOpen", True)), bool(getattr(first, "hasFoe", False))
        try:
            return bool(first[3]), bool(first[4])
        except (TypeError, IndexError, KeyError):
            return True, False

    @staticmethod
    def _unpack_leader_follower(pair):
        """Compat: (id, gap) tuple or SWIG object with id/gap fields."""
        if not pair:
            return None, None
        if hasattr(pair, "id") or hasattr(pair, "vehicleID"):
            vid = getattr(pair, "id", None)
            if vid is None:
                vid = getattr(pair, "vehicleID", None)
            gap = getattr(pair, "dist", None)
            if gap is None:
                gap = getattr(pair, "gap", None)
            if gap is None:
                gap = getattr(pair, "length", 100.0)
            return (str(vid) if vid else None), float(gap)
        try:
            return pair[0], float(pair[1])
        except (TypeError, ValueError, IndexError):
            return None, None

    def _dist_to_stopline_from_vdata(self, v_data):
        """Stop-line distance (m). Must match get_state packing (TLS, else chain sum)."""
        edge_id = v_data[tc.VAR_ROAD_ID]
        if edge_id.startswith(':'):
            return 0.0
        next_tls = v_data.get(tc.VAR_NEXT_TLS) or ()
        if next_tls:
            try:
                _, _, dist_tls, _ = self._unpack_next_tls_entry(next_tls[0])
                return float(dist_tls)
            except (TypeError, ValueError, IndexError, AttributeError):
                pass
        if edge_id.endswith('A0') or edge_id in getattr(self, '_approach_cardinal', {}):
            lane_id = v_data[tc.VAR_LANE_ID]
            rem = self._lane_length(lane_id) - float(v_data[tc.VAR_LANEPOSITION])
            card = self._approach_cardinal.get(edge_id)
            chains = getattr(self, '_approach_chains', None) or {}
            chain = chains.get(card) if card else None
            if chain and edge_id in chain:
                idx = chain.index(edge_id)
                for nearer in chain[:idx]:
                    lens = self._lane_lengths_for_edge(nearer) or []
                    rem += max(lens) if lens else 0.0
            return float(rem)
        return -1.0

    def _in_control_zone(self, v_data):
        edge_id = v_data[tc.VAR_ROAD_ID]
        if edge_id.startswith(':'):
            return True
        dist = self._dist_to_stopline_from_vdata(v_data)
        return dist >= 0.0 and dist <= float(self.CONTROL_ZONE_DISTANCE)

    def _in_platoon_zone(self, v_data):
        edge_id = v_data[tc.VAR_ROAD_ID]
        if edge_id.startswith(':'):
            return True
        dist = self._dist_to_stopline_from_vdata(v_data)
        outer = float(getattr(self, 'PLATOON_ZONE_DISTANCE', self.CONTROL_ZONE_DISTANCE))
        return dist >= 0.0 and dist <= outer

    def _load_scenario_config(self):
        """Load scenario.py (or dublin_scenario.py) beside the sumocfg for green bounds."""
        self.scenario_tls_id = getattr(self, "scenario_tls_id", None)
        self.scenario_junction_id = getattr(self, "scenario_junction_id", None)
        self.scenario_junction_center = getattr(self, "scenario_junction_center", None)
        self.scenario_approach_edges = getattr(self, "scenario_approach_edges", None)
        self.tls_program_id = getattr(self, "tls_program_id", None)
        try:
            from importlib.machinery import SourceFileLoader
            cfg_dir = os.path.dirname(os.path.abspath(self.sumocfg_file))
            scen_path = None
            for name in ("scenario.py", "dublin_scenario.py"):
                cand = os.path.join(cfg_dir, name)
                if os.path.isfile(cand):
                    scen_path = cand
                    break
            if scen_path is None:
                return
            mod = SourceFileLoader(
                f"sumo_scenario_{abs(hash(scen_path)) % (10**8)}", scen_path
            ).load_module()
            if bool(getattr(mod, "USE_DUBLIN_LAYOUT", False)):
                self._dublin_mode = True
            tls_id = getattr(mod, "TLS_ID", None)
            if tls_id:
                self.scenario_tls_id = str(tls_id)
            prog = getattr(mod, "TLS_PROGRAM_ID", None)
            if prog:
                self.tls_program_id = str(prog)
            jid = getattr(mod, "JUNCTION_ID", None)
            if jid:
                self.scenario_junction_id = str(jid)
            jcenter = getattr(mod, "JUNCTION_CENTER", None)
            if jcenter is not None and len(jcenter) >= 2:
                self.scenario_junction_center = (float(jcenter[0]), float(jcenter[1]))
            approach_edges = getattr(mod, "APPROACH_EDGES", None)
            if isinstance(approach_edges, dict) and approach_edges:
                # cardinal -> primary edge id (first listed = nearest junction)
                self.scenario_approach_edges = {
                    str(card): (str(edges[0]) if isinstance(edges, (list, tuple)) and edges else str(edges))
                    for card, edges in approach_edges.items()
                }
                # Full approach chains (near-junction → upstream) for multi-edge corridors.
                self._approach_chains = {
                    str(card): tuple(
                        str(e) for e in (edges if isinstance(edges, (list, tuple)) else (edges,))
                    )
                    for card, edges in approach_edges.items()
                }
            self.CONTROL_ZONE_DISTANCE = float(
                getattr(mod, "CONTROL_ZONE_DISTANCE", self.CONTROL_ZONE_DISTANCE)
            )
            if hasattr(mod, "PLATOON_FORMATION_LENGTH"):
                self.PLATOON_FORMATION_LENGTH = float(mod.PLATOON_FORMATION_LENGTH)
            if hasattr(mod, "PLATOON_ZONE_DISTANCE"):
                self.PLATOON_ZONE_DISTANCE = float(mod.PLATOON_ZONE_DISTANCE)
            else:
                self.PLATOON_ZONE_DISTANCE = float(
                    self.CONTROL_ZONE_DISTANCE
                ) + float(getattr(self, "PLATOON_FORMATION_LENGTH", 500.0))
            if hasattr(mod, "SPEED_LIMIT_MS"):
                self.MAX_SPEED = float(mod.SPEED_LIMIT_MS)
            self.MIN_GREEN_DURATION = float(
                getattr(mod, "MIN_GREEN_DURATION", self.MIN_GREEN_DURATION)
            )
            min_by = getattr(mod, "MIN_GREEN_BY_PHASE", None)
            if min_by is not None:
                self.MIN_GREEN_BY_PHASE = tuple(float(x) for x in min_by)
            else:
                self.MIN_GREEN_BY_PHASE = tuple(
                    self.MIN_GREEN_DURATION for _ in range(MAX_SIGNAL_ACTIONS)
                )
            self.MAX_GREEN_DURATION = float(
                getattr(mod, "MAX_GREEN_DURATION", self.MAX_GREEN_DURATION)
            )
            self.GREEN_DECISION_INTERVAL = float(
                getattr(mod, "GREEN_DECISION_INTERVAL", self.GREEN_DECISION_INTERVAL)
            )
            self.YELLOW_DURATION = float(
                getattr(mod, "YELLOW_DURATION", self.YELLOW_DURATION)
            )
            self.ALL_RED_DURATION = float(
                getattr(mod, "ALL_RED_DURATION", self.ALL_RED_DURATION)
            )
            max_by = getattr(mod, "MAX_GREEN_BY_PHASE", None)
            if max_by is not None:
                self.MAX_GREEN_BY_PHASE = tuple(float(x) for x in max_by)
            if hasattr(mod, "STARVE_IDLE_CLOCK"):
                self.STARVE_IDLE_CLOCK_ENABLED = bool(mod.STARVE_IDLE_CLOCK)
            if hasattr(mod, "STARVE_IDLE_S"):
                self.STARVE_IDLE_S = float(mod.STARVE_IDLE_S)
            if hasattr(mod, "CYCLE_FAIRNESS_ENABLED"):
                self.CYCLE_FAIRNESS_ENABLED = bool(mod.CYCLE_FAIRNESS_ENABLED)
            thru_g = getattr(mod, "CYCLE_THRU_GREENS", None)
            if thru_g is not None:
                self.CYCLE_THRU_GREENS = tuple(int(x) for x in thru_g)
            prot_g = getattr(mod, "CYCLE_PROTECTED_GREENS", None)
            if prot_g is not None:
                self.CYCLE_PROTECTED_GREENS = tuple(int(x) for x in prot_g)
            mapping = {}
            for card, edges in (getattr(mod, "APPROACH_EDGES", {}) or {}).items():
                # Scenario values may be a single edge string or a list/tuple.
                # Iterating a string directly would incorrectly map its characters.
                edge_items = edges if isinstance(edges, (list, tuple, set)) else (edges,)
                for edge in edge_items:
                    edge_id = str(edge or "").strip()
                    if edge_id:
                        mapping[edge_id] = str(card)
            if mapping:
                self._approach_cardinal = mapping
            approach_dirs = getattr(mod, "APPROACH_EDGES", None) or {}
            if approach_dirs:
                n_dirs = max(1, len(approach_dirs))
            elif mapping:
                n_dirs = max(1, len(set(mapping.values())))
            else:
                n_dirs = 4
            # ~25 queued veh / approach direction; floor 120 so 5leg warmup (~80) survives.
            self._gridlock_waiting_threshold = max(120, int(25 * n_dirs))
            print(
                f"[SUMO] scenario={os.path.basename(scen_path)} "
                f"tls={self.scenario_tls_id or '-'} "
                f"min_green={self.MIN_GREEN_DURATION}s "
                f"max_by_phase={self.MAX_GREEN_BY_PHASE} "
                f"decision={self.GREEN_DECISION_INTERVAL}s "
                f"gridlock_thr={self._gridlock_waiting_threshold}"
            )
        except Exception as exc:
            print(f"[SUMOEnvironment] scenario load skipped: {exc}")

    def _resolve_controlled_tls_ids(self):
        """Prefer scenario.py TLS_ID so secondary corridor lights are not RL-controlled."""
        all_tls = list(traci.trafficlight.getIDList())
        preferred = getattr(self, "scenario_tls_id", None)
        if preferred and preferred in all_tls:
            if len(all_tls) > 1:
                skipped = [t for t in all_tls if t != preferred]
                print(
                    f"[SUMO] controlling TLS {preferred} "
                    f"(ignoring secondary: {skipped})"
                )
            return [preferred]
        if preferred and preferred not in all_tls:
            print(
                f"[SUMO] ERROR: scenario TLS_ID={preferred} not in net; "
                f"available={all_tls}. Refusing to control secondary lights."
            )
            raise RuntimeError(
                f"scenario TLS_ID={preferred} not found in TraCI TLS list {all_tls}"
            )
        return all_tls

    def _load_dublin_approach_map(self):
        """Backward-compatible alias."""
        self._load_scenario_config()

    def _get_tls_phases(self, tls_id):
        phases = self.signal_programs.get(tls_id)
        if phases is None:
            phases = self._logic_phases_from_traci(tls_id)
            self.signal_programs[tls_id] = phases
        return phases

    def _logic_phases_from_traci(self, tls_id):
        from environment.tls_phases import traci_program_phases

        want = getattr(self, "tls_program_id", None)
        if want:
            logics = traci.trafficlight.getAllProgramLogics(tls_id) or []
            for lg in logics:
                if str(getattr(lg, "programID", "")) == str(want):
                    return lg.phases
        return traci_program_phases(tls_id)

    def _activate_tls_program(self):
        """Switch to additional-file program (e.g. programID=rl) before warmup."""
        prog = getattr(self, "tls_program_id", None)
        if not prog:
            return
        tls_ids = []
        preferred = getattr(self, "scenario_tls_id", None)
        if preferred:
            tls_ids = [preferred]
        else:
            try:
                tls_ids = list(traci.trafficlight.getIDList() or [])
            except Exception:
                tls_ids = []
        for tls_id in tls_ids:
            try:
                traci.trafficlight.setProgram(tls_id, prog)
                print(f"[SUMO] tls={tls_id} program={prog}")
            except Exception as exc:
                print(f"[Warn] setProgram({tls_id}, {prog}) failed: {exc}")

    def _phase_kind(self, tls_id, phase_idx):
        """Classify a program phase: 'green' | 'yellow' | 'red'."""
        phases = self._get_tls_phases(tls_id)
        if phase_idx < 0 or phase_idx >= len(phases):
            return 'red'
        cache_key = f"{tls_id}_kinds"
        kinds = self.signal_programs.get(cache_key)
        if kinds is None:
            kinds = classify_program_phases([p.state or '' for p in phases])
            self.signal_programs[cache_key] = kinds
        return kinds[phase_idx]

    def _green_phase_indices(self, tls_id):
        phases = self._get_tls_phases(tls_id)
        return program_green_indices([p.state or '' for p in phases]) or [0]
    def _min_green_for(self, tls_id, green_index):
        limits = getattr(self, "MIN_GREEN_BY_PHASE", None)
        if limits and 0 <= int(green_index) < len(limits):
            return float(limits[int(green_index)])
        return float(self.MIN_GREEN_DURATION)

    def _compute_green_duration(self, tls_id, green_idx, lv=None):
        """Compute a finite, scenario-bounded green budget T.

        T = clip(g1 + k * Lq_crit + k_arr * N_arr, g1, Gmax)
          Lq_crit: max single-lane HALTED queue (m) on the phase's approaches
          N_arr  : (v4) critical-lane count of moving vehicles reaching the stop
                   line within GREEN_ARRIVAL_WINDOW_S, so approaching platoons get
                   green time from their ARRIVAL TIME (v3 inflated Lq with DBSCAN
                   cluster extents regardless of arrival time).
        """
        g1 = float(self._min_green_for(tls_id, green_idx))
        if not np.isfinite(g1) or g1 <= 0.0:
            g1 = max(float(getattr(self, "step_length", 0.2)), 1.0)
        gmax = float(self._max_green_for(tls_id, green_idx))
        if not np.isfinite(gmax) or gmax < g1:
            gmax = g1
        lv_given = lv is not None
        if lv is None:
            lv = self._queue_length_for_green(tls_id, green_idx)
        try:
            lv = float(lv)
        except (TypeError, ValueError, OverflowError):
            lv = 0.0
        if not np.isfinite(lv):
            lv = 0.0
        lv = max(0.0, lv)
        k = float(self.GREEN_DURATION_K)
        if not np.isfinite(k) or k < 0.0:
            k = 0.0
        arr = 0.0
        if (
            (not lv_given)
            and bool(getattr(self, "GREEN_ARRIVAL_AWARE", True))
            and str(getattr(self, "QUEUE_MODE", "halted")).strip().lower() != "legacy"
        ):
            try:
                arr = float(self._arrivals_for_green(tls_id, green_idx))
            except Exception:
                arr = 0.0
        try:
            k_arr = max(0.0, float(getattr(self, "GREEN_ARRIVAL_K", 2.0)))
        except (TypeError, ValueError):
            k_arr = 0.0
        t_raw = g1 + k * lv + k_arr * arr
        T = float(np.clip(t_raw, g1, gmax))
        self._last_green_T[tls_id] = T
        self._last_green_lv[tls_id] = lv
        if not hasattr(self, "_last_green_arr") or self._last_green_arr is None:
            self._last_green_arr = {}
        self._last_green_arr[tls_id] = arr
        self._last_green_index[tls_id] = int(green_idx)
        return T

    def _ensure_phase_lane_map(self, tls_id):
        if tls_id in self._phase_incoming_lanes:
            return
        greens = self._green_phase_indices(tls_id)
        mapping = {i: [] for i in range(len(greens))}
        permissive = []
        try:
            links = traci.trafficlight.getControlledLinks(tls_id)
            phases = self._get_tls_phases(tls_id)
            for g_idx, phase_idx in enumerate(greens):
                state = phases[phase_idx].state or ''
                lanes = []
                for link_i, ch in enumerate(state):
                    # Only capital protected 'G' defines a phase's decision lanes.
                    if ch != 'G':
                        continue
                    if link_i >= len(links):
                        continue
                    for triple in links[link_i]:
                        if not triple:
                            continue
                        in_lane, _ = self._unpack_controlled_link(triple)
                        if in_lane and in_lane not in lanes:
                            lanes.append(in_lane)
                mapping[g_idx] = lanes
            # v4: lanes reached only through permissive 'g' links in ANY program
            # phase (e.g. 5-leg lane-0 turn lanes) were invisible to v3's reward,
            # observation and starvation masks. Track them for the reward lane set.
            g_lanes = set(l for ls in mapping.values() for l in ls)
            for ph in phases:
                st = getattr(ph, "state", "") or ''
                for link_i, ch in enumerate(st):
                    if ch != 'g' or link_i >= len(links):
                        continue
                    for triple in links[link_i]:
                        if not triple:
                            continue
                        in_lane, _ = self._unpack_controlled_link(triple)
                        if in_lane and in_lane not in g_lanes and in_lane not in permissive:
                            permissive.append(in_lane)
        except Exception as exc:
            print(
                f"[SUMO] _ensure_phase_lane_map failed for {tls_id}: {exc}",
                flush=True,
            )
        self._phase_incoming_lanes[tls_id] = mapping
        if not hasattr(self, "_permissive_only_lanes") or self._permissive_only_lanes is None:
            self._permissive_only_lanes = {}
        self._permissive_only_lanes[tls_id] = permissive
        if permissive:
            print(
                f"[SUMO] tls={tls_id}: {len(permissive)} permissive-only approach lane(s) "
                f"added to the reward lane set: {permissive}",
                flush=True,
            )
        # Empty map would silently zero phase-queue formal terms - surface it.
        if not any(mapping.values()):
            print(
                f"[SUMO] WARNING: phase incoming lanes empty for {tls_id} "
                f"(controlled-links parse may have failed)",
                flush=True,
            )

    def _lane_vehicle_index(self):
        """v4 perf: per-step map lane -> [(speed, dist_to_stopline, accumulated_wait)].

        v3 rescanned every vehicle in the network inside each queue / wait /
        near-count helper (dozens of full scans per step). The index is rebuilt
        once per ``sub_results`` object.
        """
        subs = getattr(self, "sub_results", None) or {}
        cache = getattr(self, "_lane_index_cache", None) or (None, None, None)
        if cache[0] is subs and cache[1] == len(subs) and cache[2] is not None:
            return cache[2]
        index = {}
        for v_data in subs.values():
            try:
                lane_id = str(v_data.get(tc.VAR_LANE_ID, "") or "")
            except Exception:
                continue
            if not lane_id:
                continue
            try:
                speed = float(v_data.get(tc.VAR_SPEED, 0.0) or 0.0)
            except (TypeError, ValueError):
                speed = 0.0
            try:
                dist = float(self._dist_to_stopline_from_vdata(v_data))
            except Exception:
                dist = -1.0
            w = self._traci_valid_double(
                v_data.get(tc.VAR_ACCUMULATED_WAITING_TIME, 0.0), non_negative=True
            )
            index.setdefault(lane_id, []).append((speed, dist, w))
        self._lane_index_cache = (subs, len(subs), index)
        return index

    def _phase_chain_lanes(self, tls_id, green_idx):
        """(base stop-line lanes, de-duplicated chain lanes) served by a green."""
        self._ensure_phase_lane_map(tls_id)
        base_lanes = self._phase_incoming_lanes.get(tls_id, {}).get(int(green_idx), []) or []
        lanes, seen = [], set()
        for bl in base_lanes:
            for cl in self._expand_lane_chain(bl):
                if cl not in seen:
                    seen.add(cl)
                    lanes.append(cl)
        return base_lanes, lanes

    def _arrivals_for_green(self, tls_id, green_idx, window_s=None):
        """Critical-lane count of MOVING vehicles that reach the stop line within window_s."""
        window = float(
            getattr(self, "GREEN_ARRIVAL_WINDOW_S", 10.0) if window_s is None else window_s
        )
        halt_v = float(getattr(self, "QUEUE_HALT_SPEED_MS", 0.5) or 0.5)
        base_lanes, _ = self._phase_chain_lanes(tls_id, green_idx)
        idx = self._lane_vehicle_index()
        best = 0
        for bl in base_lanes:
            n = 0
            for cl in self._expand_lane_chain(bl):
                for speed, dist, _w in idx.get(cl, ()):
                    if speed >= halt_v and dist >= 0.0 and dist <= speed * window:
                        n += 1
            best = max(best, n)
        return int(best)

    def _runtime_sumo_options(self, seed):
        """v4: per-reset SUMO options (insertion policy, junction collisions, demand)."""
        opts = []
        try:
            mdd = float(getattr(self, "max_depart_delay", -1.0))
        except (TypeError, ValueError):
            mdd = -1.0
        # Negative => never discard un-inserted vehicles (large finite value avoids
        # CLI parsing of a negative number). v3 used 30 s and silently dropped them.
        opts += ["--max-depart-delay", "100000" if mdd < 0 else str(mdd)]
        opts += [
            "--collision.check-junctions",
            "true" if bool(getattr(self, "collision_check_junctions", True)) else "false",
        ]
        base = self._base_route_file()
        route = None
        rnd = getattr(self, "demand_randomizer", None)
        if rnd is not None and bool(getattr(rnd, "enabled", False)) and base:
            try:
                route = rnd.generate(base, int(seed))
            except Exception as exc:
                print(f"[SUMO] demand randomization skipped: {exc}", flush=True)
                route = None
        if route:
            opts += ["--route-files", route]
            meta = getattr(rnd, "last_meta", {}) or {}
            print(
                f"[SUMO] demand randomized seed={seed} "
                f"scale={float(meta.get('scale', 1.0)):.3f} vehicles={int(meta.get('n_out', 0))}",
                flush=True,
            )
        self._active_route_file = route or base
        diag = getattr(self, "sumo_diag_dir", None)
        if diag:
            try:
                os.makedirs(diag, exist_ok=True)
                opts += [
                    "--collision-output", os.path.join(diag, f"collisions_{int(seed)}.xml"),
                    "--error-log", os.path.join(diag, f"sumo_warnings_{int(seed)}.log"),
                    "--no-warnings", "false",
                    "--statistic-output", os.path.join(diag, f"statistics_{int(seed)}.xml"),
                ]
            except OSError as exc:
                print(f"[SUMO] diag dir unavailable ({exc}); diagnostics off", flush=True)
        try:
            from environment.demand_randomizer import read_trip_departs

            self._scheduled_depart = read_trip_departs(self._active_route_file)
        except Exception:
            self._scheduled_depart = {}
        return opts

    def _base_route_file(self):
        """Route file SUMO loads by default (quick/full override, else sumocfg)."""
        if getattr(self, "route_file", None):
            return self.route_file
        try:
            import xml.etree.ElementTree as _ET

            node = _ET.parse(self.sumocfg_file).getroot().find(".//route-files")
            if node is None:
                return None
            first = str(node.get("value") or "").split(",")[0].strip()
            if not first:
                return None
            path = first if os.path.isabs(first) else os.path.join(
                os.path.dirname(os.path.abspath(self.sumocfg_file)), first
            )
            return path if os.path.isfile(path) else None
        except Exception:
            return None

    def _tis_init(self, now):
        """Time-in-system: scheduled depart (clipped to hand-over) -> arrival.

        Counts vehicles still waiting for insertion or still on the network at
        their elapsed time, so discarded/blocked insertions can no longer make a
        congested controller look better (v3 ATT counted completed trips only).
        """
        handover = float(now)
        warm = getattr(self, "_warmup_arrived", None) or set()
        items = []
        for vid, dep in (getattr(self, "_scheduled_depart", None) or {}).items():
            if vid in warm:
                continue
            items.append((max(float(dep), handover), str(vid)))
        items.sort()
        self._tis_items = items
        self._tis_ptr = 0
        self._tis_s = {}
        self._tis_unf_n = 0
        self._tis_unf_sum = 0.0
        self._tis_done_n = 0
        self._tis_done_sum = 0.0
        self._tis_release(handover)

    def _tis_release(self, now):
        items = getattr(self, "_tis_items", None)
        if not items:
            return
        p = int(getattr(self, "_tis_ptr", 0))
        n = len(items)
        now = float(now)
        while p < n and items[p][0] <= now:
            s, vid = items[p]
            if vid not in self._tis_s:
                self._tis_s[vid] = s
                self._tis_unf_n += 1
                self._tis_unf_sum += s
            p += 1
        self._tis_ptr = p

    def _tis_on_arrival(self, vid, now):
        s = (getattr(self, "_tis_s", None) or {}).pop(str(vid), None)
        if s is None:
            return
        self._tis_unf_n -= 1
        self._tis_unf_sum -= s
        self._tis_done_n += 1
        self._tis_done_sum += max(0.0, float(now) - float(s))

    def _tis_value(self, now):
        n = int(getattr(self, "_tis_done_n", 0)) + int(getattr(self, "_tis_unf_n", 0))
        if n <= 0:
            return 0.0
        unf = float(self._tis_unf_n) * float(now) - float(self._tis_unf_sum)
        return float((float(self._tis_done_sum) + max(0.0, unf)) / float(n))

    def _insertion_backlog(self):
        try:
            return int(len(traci.simulation.getPendingVehicles() or ()))
        except Exception:
            return 0

    def _expand_lane_chain(self, lane_id: str) -> list:
        """Expand a near-junction TLS lane across upstream edges in _approach_chains."""
        lid = str(lane_id or "")
        if not lid or "_" not in lid:
            return [lid] if lid else []
        edge_id, idx_str = lid.rsplit("_", 1)
        try:
            lane_idx = int(idx_str)
        except ValueError:
            return [lid]
        card = (getattr(self, "_approach_cardinal", None) or {}).get(edge_id)
        chains = getattr(self, "_approach_chains", None) or {}
        chain = chains.get(card) if card else None
        if not chain or edge_id not in chain:
            return [lid]
        out = [lid]
        pos = list(chain).index(edge_id)
        # Include upstream edges along the same approach corridor.
        # Only same-index lanes: widened tip pockets (lane_idx >= n_up) must not
        # clamp onto upstream n_up-1 or the feeder queue is double-counted into
        # every pocket when averaging per-lane queues for the signal formal.
        for up_edge in chain[pos + 1 :]:
            up_edge = str(up_edge or "")
            if not up_edge:
                continue
            n_up = int(self._n_lanes_for(up_edge) or 1)
            if n_up <= 0:
                continue
            if lane_idx < 0 or lane_idx >= n_up:
                continue
            cand_lid = f"{up_edge}_{lane_idx}"
            if cand_lid not in out:
                out.append(cand_lid)
        return out

    def _corridor_length_for_lane(self, lane_id: str) -> float:
        """Total physical approach length (m) along the chain for spill_proxy."""
        chain_lanes = self._expand_lane_chain(lane_id)
        total_len = 0.0
        for clid in chain_lanes:
            try:
                l_val = float(self._lane_length(clid) or 0.0)
                if np.isfinite(l_val) and l_val > 0.0:
                    total_len += l_val
            except Exception:
                pass
        return max(total_len, 300.0)

    def _queue_length_for_green(self, tls_id, green_idx):
        """Critical single-lane queue: max over controlled approach lanes of phase."""
        self._ensure_phase_lane_map(tls_id)
        base_lanes = self._phase_incoming_lanes.get(tls_id, {}).get(int(green_idx), []) or []
        if not base_lanes:
            return 0.0
        return float(max(self._queue_length_for_lane(bl) for bl in base_lanes))

    def _queue_length_for_lane(self, lane_id: str) -> float:
        """Per-lane queue length (m) across the lane and its upstream approach chain.

        v4 default 'halted': halted vehicles (v < QUEUE_HALT_SPEED_MS) x 7.5 m.
        'legacy' (v3): max(DBSCAN cluster extents, halted x 7.5). DBSCAN clusters
        include MOVING platoons, so v3 penalized CAV platoons as if they queued.
        """
        lid = str(lane_id or "")
        if not lid:
            return 0.0
        chain_lanes = self._expand_lane_chain(lid)
        idx = self._lane_vehicle_index()
        halt_v = float(getattr(self, "QUEUE_HALT_SPEED_MS", 0.5) or 0.5)
        count = 0
        for cl in chain_lanes:
            for speed, _dist, _w in idx.get(cl, ()):
                if speed < halt_v:
                    count += 1
        halted_m = float(count) * 7.5
        if str(getattr(self, "QUEUE_MODE", "halted")).strip().lower() == "legacy":
            lv = 0.0
            if getattr(self, "platoon_tracker", None) is not None:
                try:
                    lv = float(self.platoon_tracker.queue_length_for_lanes(chain_lanes))
                except Exception:
                    lv = 0.0
            return float(max(lv, halted_m))
        return halted_m

    def _approach_lane_queue_lengths_m(self, tls_id) -> dict:
        """Fixed-topology per-lane queues (m) over the union of green-phase in-lanes.

        v4: also lanes served only by permissive 'g' links (INCLUDE_PERMISSIVE_LANES).
        """
        self._ensure_phase_lane_map(tls_id)
        lane_map = self._phase_incoming_lanes.get(tls_id, {}) or {}
        extra = []
        if bool(getattr(self, "INCLUDE_PERMISSIVE_LANES", True)):
            extra = list((getattr(self, "_permissive_only_lanes", None) or {}).get(tls_id, []) or [])
        lanes, seen = [], set()
        for lids in list(lane_map.values()) + [extra]:
            for lid in lids or []:
                s = str(lid or "")
                if not s or s in seen:
                    continue
                seen.add(s)
                lanes.append(s)
        return {lid: float(self._queue_length_for_lane(lid)) for lid in lanes}

    def _avg_wait_for_green(self, tls_id, green_idx) -> float:
        """Mean ACCUMULATED_WAITING_TIME (s) near stopline on lanes served by green.

        Anti-dilution: only vehicles within 250 m of the stop line or slower than
        5 m/s contribute (matches reward.signal_reward WAIT_INCLUDE_*).
        """
        _base, lanes = self._phase_chain_lanes(tls_id, green_idx)
        if not lanes:
            return 0.0
        idx = self._lane_vehicle_index()
        waits = []
        for cl in lanes:
            for speed, dist, w in idx.get(cl, ()):
                if not ((0.0 <= float(dist) <= 250.0) or speed < 5.0):
                    continue
                if w is not None:
                    waits.append(float(w))
        if not waits:
            return 0.0
        return float(np.mean(waits))

    def _phase_avg_waits_s(self, tls_id) -> list:
        """Per-green-phase mean waits (s); length = n_green."""
        self._ensure_phase_lane_map(tls_id)
        greens = self._green_phase_indices(tls_id)
        return [float(self._avg_wait_for_green(tls_id, i)) for i in range(len(greens))]

    def _max_wait_for_green(self, tls_id, green_idx):
        """Peak ACCUMULATED_WAITING_TIME (s) near stopline for green (anti-dilution)."""
        _base, lanes = self._phase_chain_lanes(tls_id, green_idx)
        if not lanes:
            return 0.0
        idx = self._lane_vehicle_index()
        max_w = 0.0
        for cl in lanes:
            for speed, dist, w in idx.get(cl, ()):
                if not ((0.0 <= float(dist) <= 250.0) or speed < 5.0):
                    continue
                if w is not None and float(w) > max_w:
                    max_w = float(w)
        return max_w

    def _phase_out_edges(self, tls_id, green_idx):
        """Downstream edges released by capital-G links of this green."""
        # Cache must not share the method name: getattr would return the bound method.
        cache = getattr(self, "_phase_out_edges_cache", None)
        if not isinstance(cache, dict):
            self._phase_out_edges_cache = {}
            cache = self._phase_out_edges_cache
        key = (str(tls_id), int(green_idx))
        if key in cache:
            return cache[key]
        outs = set()
        try:
            greens = self._green_phase_indices(tls_id)
            if int(green_idx) < 0 or int(green_idx) >= len(greens):
                cache[key] = outs
                return outs
            phase_idx = greens[int(green_idx)]
            phases = self._get_tls_phases(tls_id)
            state = phases[phase_idx].state or ""
            links = traci.trafficlight.getControlledLinks(tls_id)
            for link_i, ch in enumerate(state):
                if ch != "G" or link_i >= len(links):
                    continue
                for triple in links[link_i]:
                    _in_lane, out_lane = self._unpack_controlled_link(triple)
                    if out_lane:
                        outs.add(str(out_lane).rsplit("_", 1)[0])
        except Exception:
            pass
        cache[key] = outs
        return outs

    def _near_count_for_green(self, tls_id, green_idx, horizon_m=150.0):
        """Vehicles within ``horizon_m`` of the stop line on this green's lanes."""
        _base, lanes = self._phase_chain_lanes(tls_id, green_idx)
        if not lanes:
            return 0
        idx = self._lane_vehicle_index()
        n = 0
        for cl in lanes:
            for _speed, dist, _w in idx.get(cl, ()):
                if 0.0 <= float(dist) <= float(horizon_m):
                    n += 1
        return int(n)

    def _current_tls_program(self, tls_id):
        """Program id active before setRedYellowGreenState switches to 'online'."""
        try:
            prog = str(traci.trafficlight.getProgram(tls_id) or "")
        except Exception:
            prog = ""
        if prog and prog != "online":
            return prog
        configured = str(getattr(self, "tls_program_id", None) or "")
        if configured and configured != "online":
            return configured
        return "0"

    def _restore_tls_program(self, tls_id, saved=None):
        """Leave TraCI program 'online' and return to the program that was running."""
        candidates = []
        for prog in (saved, getattr(self, "tls_program_id", None), "0"):
            prog = str(prog or "")
            if prog and prog != "online" and prog not in candidates:
                candidates.append(prog)
        try:
            logics = traci.trafficlight.getAllProgramLogics(tls_id) or []
        except Exception:
            logics = []
        for lg in logics:
            prog = str(getattr(lg, "programID", "") or "")
            if prog and prog != "online" and prog not in candidates:
                candidates.append(prog)
        last_exc = None
        for prog in candidates:
            try:
                traci.trafficlight.setProgram(tls_id, prog)
                return prog
            except Exception as exc:
                last_exc = exc
        print(
            f"[SUMO] setProgram({tls_id}) after synth failed; tried {candidates}: {last_exc}",
            flush=True,
        )
        raise RuntimeError(
            f"cannot restore tls {tls_id} from program 'online'"
        ) from last_exc

    def _green_has_demand(self, tls_id, green_idx):
        """Near-stopline / stopped vehicles whose next edge matches phase outs."""
        if not hasattr(self, "_phase_incoming_lanes"):
            self._phase_incoming_lanes = {}
        if not hasattr(self, "sub_results"):
            self.sub_results = {}
        try:
            self._ensure_phase_lane_map(tls_id)
        except Exception:
            pass
        base_lanes = (
            (getattr(self, "_phase_incoming_lanes", {}) or {})
            .get(tls_id, {})
            .get(int(green_idx), [])
            or []
        )
        lane_set = set()
        for bl in base_lanes:
            lane_set.update(self._expand_lane_chain(bl))
        if not lane_set:
            try:
                return float(self._queue_length_for_green(tls_id, green_idx)) >= 22.5
            except Exception:
                return True
        out_edges = self._phase_out_edges(tls_id, green_idx)
        for vid, v_data in (self.sub_results or {}).items():
            lane_id = str(v_data.get(tc.VAR_LANE_ID, "") or "")
            if lane_id not in lane_set:
                continue
            speed = float(v_data.get(tc.VAR_SPEED, 0.0) or 0.0)
            dist = self._dist_to_stopline_from_vdata(v_data)
            near = (0.0 <= dist <= 120.0) or speed < 0.5
            if not near:
                continue
            if out_edges:
                try:
                    edge = str(v_data.get(tc.VAR_ROAD_ID, "") or "")
                    nxt = self._route_next_edge(vid, edge)
                    if nxt and nxt not in out_edges:
                        continue
                except Exception:
                    pass
            return True
        try:
            return float(self._queue_length_for_green(tls_id, green_idx)) >= 22.5
        except Exception:
            return True

    def _cycle_pending_demand(self, tls_id, n_green, exclude=None):
        """Unserved greens with soft fairness demand (queue≥22.5m or Wmax≥45s)."""
        if not bool(getattr(self, "CYCLE_FAIRNESS_ENABLED", True)):
            return []
        served = getattr(self, "_cycle_served", {}).get(tls_id) or set()
        excl = set() if exclude is None else {int(exclude)}
        pending = []
        for i in range(int(n_green)):
            if i in served or i in excl:
                continue
            try:
                lq = float(self._queue_length_for_green(tls_id, i))
            except Exception:
                lq = 0.0
            try:
                wmax = float(self._max_wait_for_green(tls_id, i))
            except Exception:
                wmax = 0.0
            if lq >= 22.5 or wmax >= 45.0:
                pending.append(i)
        return pending

    def _maybe_complete_cycle(self, tls_id, n_green):
        """Reset cycle when every unserved green has no demand (or all served)."""
        if not bool(getattr(self, "CYCLE_FAIRNESS_ENABLED", True)):
            return
        served = getattr(self, "_cycle_served", {}).setdefault(tls_id, set())
        unserved = [i for i in range(int(n_green)) if i not in served]
        if not unserved:
            self._cycle_served[tls_id] = set()
            return
        if all(not self._green_has_demand(tls_id, i) for i in unserved):
            self._cycle_served[tls_id] = set()

    def _apply_cycle_fairness_mask(self, mask, tls_id, n, cur_g, *, must_switch):
        """Restrict mask to demand-pending phases; prefer sum(mask)>=2.

        When multiple unserved demand phases exist, open all of them (and Keep
        only if still draining and not must_switch). Single-lock only when one
        pending phase remains (hard fairness / empty alternatives).

        4leg (CYCLE_THRU/PROTECTED set): once any thru has been served this
        cycle, pending protected rights close remaining thrus so the actor
        cannot G0↔G2 while G1/G3 still have demand.
        """
        pending = self._cycle_pending_demand(tls_id, n, exclude=None)
        if not pending:
            return mask
        served = getattr(self, "_cycle_served", {}).get(tls_id) or set()
        # Still draining an unserved current green: do not force away early.
        if (
            not must_switch
            and int(cur_g) not in served
            and self._green_has_demand(tls_id, cur_g)
        ):
            return mask
        thru = {int(x) for x in (getattr(self, "CYCLE_THRU_GREENS", ()) or ())}
        prot = {int(x) for x in (getattr(self, "CYCLE_PROTECTED_GREENS", ()) or ())}
        if thru and prot and any(i in served for i in thru):
            prot_pending = [i for i in pending if i in prot]
            if prot_pending:
                pending = prot_pending
        out = np.zeros(int(n), dtype=np.float32)
        for i in pending:
            if must_switch and i == int(cur_g):
                continue
            out[i] = 1.0
        if not must_switch and self._green_has_demand(tls_id, cur_g):
            out[int(cur_g)] = 1.0
        if not out.any():
            # Only pending was current under must_switch — open other pending.
            for i in pending:
                out[i] = 1.0
        if out.any():
            return out
        return mask

    def _congestion_top3_indices(self, tls_id, n_green):
        """Top-3 by Lq_crit + 1.5 * W_max (protects slow left / U-turn phases)."""
        scores = []
        for i in range(n_green):
            try:
                lq = float(self._queue_length_for_green(tls_id, i))
            except Exception:
                lq = 0.0
            try:
                wmax = float(self._max_wait_for_green(tls_id, i))
            except Exception:
                wmax = 0.0
            scores.append((lq + 1.5 * wmax, i))
        scores.sort(reverse=True)
        top = [idx for _, idx in scores[: min(3, n_green)]]
        return set(top) if top else set(range(n_green))

    def _compose_transition_state(self, cur_state: str, next_state: str, mode: str) -> str:
        """Build yellow or all-red string for arbitrary green→green jump.

        mode='yellow': links that lose green become 'y'; overlapping greens keep.
        mode='allred': losing links become 'r'; overlapping greens keep.
        """
        cur_s = str(cur_state or "")
        nxt_s = str(next_state or "")
        n = max(len(cur_s), len(nxt_s))
        out = []
        for i in range(n):
            c = cur_s[i] if i < len(cur_s) else "r"
            nch = nxt_s[i] if i < len(nxt_s) else "r"
            cur_g = c in ("G", "g")
            next_g = nch in ("G", "g")
            if cur_g and next_g:
                out.append(c if c in ("G", "g") else nch)
            elif cur_g and not next_g:
                out.append("y" if mode == "yellow" else "r")
            else:
                out.append("r")
        return "".join(out)

    def _begin_phase_transition(self, tls_id, current_phase, next_phase, now):
        """Arbitrary jump: synthesized yellow → all-red → target green."""
        phases = self._get_tls_phases(tls_id)
        cur_state = phases[int(current_phase)].state if 0 <= int(current_phase) < len(phases) else ""
        nxt_state = phases[int(next_phase)].state if 0 <= int(next_phase) < len(phases) else ""
        y_state = self._compose_transition_state(cur_state, nxt_state, "yellow")
        ar_state = self._compose_transition_state(cur_state, nxt_state, "allred")
        saved_program = self._current_tls_program(tls_id)
        try:
            traci.trafficlight.setRedYellowGreenState(tls_id, y_state)
        except Exception:
            # Fallback: adjacent yellow in program if present.
            try:
                traci.trafficlight.setPhase(tls_id, int(current_phase) + 1)
            except Exception:
                pass
        self.signal_programs[f"{tls_id}_synth"] = {
            "mode": "yellow",
            "yellow_state": y_state,
            "allred_state": ar_state,
            "next_green": int(next_phase),
            "from_phase": int(current_phase),
            "program_id": saved_program,
            "started_at": float(now),
        }
        self.last_signal_phase[tls_id] = int(current_phase)
        self.phase_started_at[tls_id] = float(now)
        self.signal_programs[f"{tls_id}_next"] = int(next_phase)
        self.signal_programs[f"{tls_id}_last_decision"] = 0.0

    def _advance_synth_transition(self, tls_id, now):
        """Tick synthetic yellow/all-red; return True if handled this step."""
        synth = self.signal_programs.get(f"{tls_id}_synth")
        if not synth:
            return False
        elapsed = float(now) - float(synth.get("started_at", now))
        mode = str(synth.get("mode") or "")
        if mode == "yellow":
            if elapsed < float(self.YELLOW_DURATION) - 1e-3:
                try:
                    traci.trafficlight.setRedYellowGreenState(
                        tls_id, str(synth.get("yellow_state") or "")
                    )
                except Exception:
                    pass
                return True
            # Enter all-red clearance.
            synth["mode"] = "allred"
            synth["started_at"] = float(now)
            try:
                traci.trafficlight.setRedYellowGreenState(
                    tls_id, str(synth.get("allred_state") or "")
                )
            except Exception:
                pass
            self.phase_started_at[tls_id] = float(now)
            return True
        if mode == "allred":
            if elapsed < float(self.ALL_RED_DURATION) - 1e-3:
                try:
                    traci.trafficlight.setRedYellowGreenState(
                        tls_id, str(synth.get("allred_state") or "")
                    )
                except Exception:
                    pass
                return True
            next_green = int(synth.get("next_green", 0))
            next_g_idx = self._green_index_of_phase(tls_id, next_green)
            T = self._compute_green_duration(tls_id, next_g_idx)
            # setRedYellowGreenState leaves program "online" (phase 0 only).
            # Restore the program captured before that call. cross uses "0";
            # 3/4/5-leg use "rl". Defaulting to "rl" crashes nets that lack it.
            self._restore_tls_program(tls_id, synth.get("program_id"))
            traci.trafficlight.setPhase(tls_id, next_green)
            traci.trafficlight.setPhaseDuration(tls_id, float(T))
            self.last_signal_phase[tls_id] = next_green
            self.phase_started_at[tls_id] = float(now)
            self.signal_programs[f"{tls_id}_last_decision"] = 0.0
            self.signal_programs.pop(f"{tls_id}_synth", None)
            return True
        self.signal_programs.pop(f"{tls_id}_synth", None)
        return False

    def _starving_green_phase(self, tls_id, cur_g, thr=90.0):
        """Green index with the worst vehicle wait, or None (hard cut at 90s).

        Idle-clock starve is disabled; only real vehicle wait triggers.
        """
        greens_n = max(1, len(self._green_phase_indices(tls_id)))
        best_i = None
        best_w = float(thr) - 1e-9
        for i in range(greens_n):
            if i == int(cur_g):
                continue
            if not self._green_has_demand(tls_id, i):
                continue
            lane_w = float(self._max_wait_for_green(tls_id, i))
            if lane_w >= float(thr) - 1e-9 and lane_w > best_w:
                best_w = lane_w
                best_i = i
        return best_i

    def _starve_may_force(self, tls_id, cur_g, elapsed, target_g, gmin, thr=None):
        """True only when starve is allowed to override the current green.

        Enabled at planned-T expiry, or when the current approach has drained
        (queue proxy < 15 m) after min green. Disabled while the current green
        itself still has wait ≥ thr and has not reached target_g — so a busy
        arterial is not cut at gmin every cycle.
        """
        if thr is None:
            thr = float(STARVE_WAIT_S)
        thr = float(thr)
        elapsed = float(elapsed)
        target_g = float(target_g)
        gmin = float(gmin)
        cur_wait = float(self._max_wait_for_green(tls_id, cur_g))
        if cur_wait >= thr - 1e-9 and elapsed < target_g - 1e-3:
            return False
        at_t = elapsed >= target_g - 1e-3
        queue_cur = float(self._queue_length_for_green(tls_id, cur_g))
        drained = (queue_cur < 15.0) and (elapsed >= gmin - 1e-3)
        return bool(at_t or drained)

    def _fallback_switch_index(self, tls_id, cur_g, n):
        """Prefer cycle-pending demand phases, else largest approach queue."""
        pending = self._cycle_pending_demand(tls_id, n, exclude=cur_g)
        if pending:
            best_i = None
            best_q = -1.0
            for i in pending:
                q = float(self._queue_length_for_green(tls_id, i))
                if q > best_q:
                    best_q = q
                    best_i = i
            if best_i is not None:
                return int(best_i)
        best_i = None
        best_q = -1.0
        for i in range(int(n)):
            if i == int(cur_g):
                continue
            if not self._green_has_demand(tls_id, i):
                continue
            q = float(self._queue_length_for_green(tls_id, i))
            if q > best_q:
                best_q = q
                best_i = i
        if best_i is None:
            return (int(cur_g) + 1) % max(1, int(n))
        return int(best_i)

    def _top3_mask_active(self, n_green):
        """Top-3 truncation only on junctions with more than 4 greens (e.g. 5-leg)."""
        return bool(self.TOP3_PHASE_MASK) and int(n_green) > 4

    def _starve_override_mask(self, tls_id, n, cur_g):
        """If a non-current green has wait >= STARVE_WAIT_S, force switch there.

        Prevents protected-turn approach vehicles from sitting until the 300 s
        SUMO teleport (Safety_Incidents). Demand-conditioned: never open empty.
        Idle clock uses STARVE_IDLE_S when enabled.
        """
        thr = float(STARVE_WAIT_S)
        idle_thr = float(getattr(self, "STARVE_IDLE_S", 75.0) or 75.0)
        waits = []
        for i in range(int(n)):
            if i == int(cur_g):
                continue
            if not self._green_has_demand(tls_id, i):
                continue
            waits.append((self._max_wait_for_green(tls_id, i), i))
        starved = [i for w, i in waits if w >= thr - 1e-9]
        if bool(getattr(self, "STARVE_IDLE_CLOCK_ENABLED", False)):
            now = float(getattr(self, "_sim_time", 0.0) or 0.0)
            last_map = (getattr(self, "_green_last_served", None) or {}).get(tls_id) or {}
            for i in range(int(n)):
                if i == int(cur_g) or i in starved:
                    continue
                if not self._green_has_demand(tls_id, i):
                    continue
                last = last_map.get(i)
                if last is None:
                    continue
                if now - float(last) >= idle_thr - 1e-9:
                    starved.append(i)
        if not starved:
            return None
        out = np.zeros(int(n), dtype=np.float32)
        for i in starved:
            out[i] = 1.0
        # Prefer sum(mask)>=2 when multiple starved; single-lock only if one.
        if not out.any() and waits:
            waits.sort(key=lambda t: t[0], reverse=True)
            out[int(waits[0][1])] = 1.0
        return out

    def configure_control(
        self,
        cav_rl_enabled=None,
        lateral_rl_enabled=None,
        control_keep_lane=None,
        top3_phase_mask=None,
        green_duration_k=None,
        dbscan_eps=None,
        cav_rl_leaders_only=None,
        warmup_seconds=None,
        lon_idm_mix_beta=None,
        cycle_fairness=None,
        lon_residual_idm=None,
        red_glide_envelope=None,
        green_glide_decouple=None,
        in_memory_follower_lookup=None,
        cacc_soft_platoon=None,
        cacc_full_gap_m=None,
        cacc_free_gap_m=None,
        cacc_rl_authority_floor=None,
        cacc_leader_accel_gain=None,
        queue_mode=None,
        include_permissive_lanes=None,
        green_arrival_aware=None,
        green_arrival_k=None,
        green_arrival_window_s=None,
        max_depart_delay=None,
        collision_check_junctions=None,
        allow_od_rewrite=None,
        allow_hdv_retarget=None,
        control_keep_lane_hdv=None,
        demand_randomize=None,
        demand_jitter_s=None,
        demand_scale_low=None,
        demand_scale_high=None,
        eval_mode=None,
        ablate_zero_lon_residual=None,
        sumo_diag_dir=None,
    ):
        """Runtime knobs for staged training / eval (v4 knobs documented in config.yaml)."""
        if cav_rl_enabled is not None:
            self.CAV_RL_ENABLED = bool(cav_rl_enabled)
        if lateral_rl_enabled is not None:
            self.LATERAL_RL_OWNS_LC = bool(lateral_rl_enabled)
        if control_keep_lane is not None:
            self.CONTROL_ZONE_KEEP_LANE = bool(control_keep_lane)
        if top3_phase_mask is not None:
            self.TOP3_PHASE_MASK = bool(top3_phase_mask)
        if green_duration_k is not None:
            self.GREEN_DURATION_K = float(green_duration_k)
        if dbscan_eps is not None:
            self.DBSCAN_EPS = float(dbscan_eps)
            self.platoon_tracker.eps = float(dbscan_eps)
        if cav_rl_leaders_only is not None:
            self.CAV_CONTROL_LEADERS_ONLY = bool(cav_rl_leaders_only)
        if warmup_seconds is not None:
            self.warmup_seconds = max(0.0, float(warmup_seconds))
        if lon_idm_mix_beta is not None:
            self.LON_IDM_MIX_BETA = float(np.clip(float(lon_idm_mix_beta), 0.0, 1.0))
        if cycle_fairness is not None:
            self.CYCLE_FAIRNESS_ENABLED = bool(cycle_fairness)
        if lon_residual_idm is not None:
            self.LON_RESIDUAL_IDM = bool(lon_residual_idm)
        if red_glide_envelope is not None:
            self.RED_GLIDE_ENVELOPE_ENABLED = bool(red_glide_envelope)
        if green_glide_decouple is not None:
            self.GREEN_GLIDE_DECOUPLE_ENABLED = bool(green_glide_decouple)
        if in_memory_follower_lookup is not None:
            self.IN_MEMORY_FOLLOWER_LOOKUP = bool(in_memory_follower_lookup)
        if cacc_soft_platoon is not None:
            self.CACC_SOFT_PLATOON_ENABLED = bool(cacc_soft_platoon)
        if cacc_full_gap_m is not None:
            self.CACC_FULL_GAP_M = float(cacc_full_gap_m)
        if cacc_free_gap_m is not None:
            self.CACC_FREE_GAP_M = float(cacc_free_gap_m)
        if cacc_rl_authority_floor is not None:
            self.CACC_RL_AUTHORITY_FLOOR = float(np.clip(float(cacc_rl_authority_floor), 0.0, 1.0))
        if cacc_leader_accel_gain is not None:
            self.CACC_LEADER_ACCEL_GAIN = float(cacc_leader_accel_gain)
        # ---- v4 knobs ----
        if queue_mode is not None:
            qm = str(queue_mode).strip().lower()
            self.QUEUE_MODE = qm if qm in ("halted", "legacy") else "halted"
        if include_permissive_lanes is not None:
            self.INCLUDE_PERMISSIVE_LANES = bool(include_permissive_lanes)
        if green_arrival_aware is not None:
            self.GREEN_ARRIVAL_AWARE = bool(green_arrival_aware)
        if green_arrival_k is not None:
            self.GREEN_ARRIVAL_K = max(0.0, float(green_arrival_k))
        if green_arrival_window_s is not None:
            self.GREEN_ARRIVAL_WINDOW_S = max(0.0, float(green_arrival_window_s))
        if max_depart_delay is not None:
            self.max_depart_delay = float(max_depart_delay)
        if collision_check_junctions is not None:
            self.collision_check_junctions = bool(collision_check_junctions)
        if allow_od_rewrite is not None:
            self.allow_deadlock_retarget = bool(allow_od_rewrite)
            self.allow_hdv_retarget = bool(allow_od_rewrite)
        if allow_hdv_retarget is not None:
            self.allow_hdv_retarget = bool(allow_hdv_retarget)
        if control_keep_lane_hdv is not None:
            self.CONTROL_ZONE_KEEP_LANE_HDV = bool(control_keep_lane_hdv)
        if any(x is not None for x in (demand_randomize, demand_jitter_s, demand_scale_low, demand_scale_high)):
            from environment.demand_randomizer import DemandRandomizer

            cur = getattr(self, "demand_randomizer", None)
            enabled = (
                bool(demand_randomize)
                if demand_randomize is not None
                else bool(getattr(cur, "enabled", False))
            )
            self.demand_randomizer = DemandRandomizer(
                enabled=enabled,
                jitter_s=float(demand_jitter_s if demand_jitter_s is not None else getattr(cur, "jitter_s", 60.0)),
                scale_low=float(demand_scale_low if demand_scale_low is not None else getattr(cur, "scale_low", 0.9)),
                scale_high=float(demand_scale_high if demand_scale_high is not None else getattr(cur, "scale_high", 1.1)),
                out_dir=getattr(cur, "out_dir", None),
            )
        if sumo_diag_dir is not None:
            self.sumo_diag_dir = str(sumo_diag_dir) or None
        if ablate_zero_lon_residual is not None:
            self.ABLATE_ZERO_LON_RESIDUAL = bool(ablate_zero_lon_residual)
        if eval_mode:
            # Evaluation protocol: no OD rewrites; fixed demand unless explicitly
            # randomized with held-out seeds (demand_randomize=True + eval seeds).
            self.allow_deadlock_retarget = False
            self.allow_hdv_retarget = False
            if getattr(self, "demand_randomizer", None) is not None and demand_randomize is None:
                self.demand_randomizer.enabled = False

    # ------------------------------------------------------------------
    # v5.2.4: control-stack bisection switches + junction-stall diagnostics
    # ------------------------------------------------------------------
    # Speed-advisory actuation: below this margin under a_IDM the stack is
    # treated as "wants to brake" and the vehicle max speed is capped.
    SPEED_ADV_TOL = 0.05
    SPEED_ADV_MIN_MS = 0.05
    JSTALL_V_MS = 0.1
    JSTALL_EVENT_S = 10.0
    _HANDBACK_REASONS = ("idm_follower", "native_idm", "near_stopline", "junction")

    @staticmethod
    def _env_on(name, default="0"):
        return str(os.environ.get(name, default)).strip().lower() in (
            "1", "true", "yes", "on"
        )

    def _load_v524_switches(self):
        """Read the v5.2.4 switches (env vars set by train_RL before workers start)."""
        self.LON_NO_FLOORS = self._env_on("LON_NO_FLOORS")
        try:
            self.LON_HANDBACK_NEAR_M = max(
                0.0, float(os.environ.get("LON_HANDBACK_NEAR_M", "0") or 0.0)
            )
        except (TypeError, ValueError):
            self.LON_HANDBACK_NEAR_M = 0.0
        self.LON_HANDBACK_JUNCTION = self._env_on("LON_HANDBACK_JUNCTION")
        act = str(os.environ.get("LON_ACTUATION", "accel") or "accel").strip().lower()
        self.LON_ACTUATION = "speed" if act == "speed" else "accel"
        mode = str(os.environ.get("LON_ACTION_MODE", "residual") or "residual").strip().lower()
        self.LON_ACTION_MODE = "target_speed" if mode == "target_speed" else "residual"
        # Bug fix (default on): SPaT during synthesized yellow / all-red.
        self.SPAT_SYNTH_FIX = self._env_on("SPAT_SYNTH_FIX", "1")

    def v524_summary(self) -> str:
        return (
            f"no_floors={int(bool(self.LON_NO_FLOORS))} "
            f"handback_near_m={float(self.LON_HANDBACK_NEAR_M):g} "
            f"handback_junction={int(bool(self.LON_HANDBACK_JUNCTION))} "
            f"actuation={self.LON_ACTUATION} "
            f"spat_synth_fix={int(bool(self.SPAT_SYNTH_FIX))}"
        )

    def _lon_handback_reason(self, is_in_junction, dist_to_stopline) -> str:
        """Non-empty reason when a CAV must be handed back to SUMO's own model.

        ``LON_HANDBACK_NEAR_M > 0`` covers [0, near) m before the stop line AND
        the junction box; ``LON_HANDBACK_JUNCTION`` covers the box only.
        """
        if is_in_junction and (
            bool(self.LON_HANDBACK_JUNCTION) or float(self.LON_HANDBACK_NEAR_M) > 0.0
        ):
            return "junction"
        near = float(self.LON_HANDBACK_NEAR_M)
        if near > 0.0 and dist_to_stopline is not None:
            try:
                d = float(dist_to_stopline)
            except (TypeError, ValueError):
                return ""
            if np.isfinite(d) and 0.0 <= d < near:
                return "near_stopline"
        return ""

    def _release_cav_to_sumo(self, vid):
        """Hand a CAV back to SUMO (speed control off, original max speed restored)."""
        try:
            traci.vehicle.setSpeedMode(vid, 31)
            traci.vehicle.setSpeed(vid, -1)
        except Exception:
            pass
        cap = (getattr(self, "_speed_capped", None) or {}).pop(vid, None)
        if cap is not None:
            try:
                traci.vehicle.setMaxSpeed(vid, float(cap[0]))
            except Exception:
                pass

    def _note_handback(self, vid, reason, applied_cav_actions, shield_clip_deltas):
        """Record a CAV whose sampled Lon action is NOT executed this step."""
        self._release_cav_to_sumo(vid)
        applied_cav_actions[vid] = 0.0
        shield_clip_deltas[vid] = 0.0
        self._lon_noop_vids_step.append(str(vid))
        js = self._jstall
        js["lon_noop"] += 1
        key = f"handback_{reason}"
        js[key] = js.get(key, 0) + 1

    def _actuate_cav(self, vid, accel, a_idm, current_speed):
        """Apply the stack output: SUMO acceleration (v5.2.3) or speed advisory.

        ``speed``: the vehicle keeps SUMO's own car-following / junction logic;
        the stack can only cap its max speed (never push it beyond IDM).
        """
        if self.LON_ACTUATION != "speed":
            traci.vehicle.setAcceleration(vid, accel, self.step_length)
            return
        capped = self._speed_capped
        if vid not in capped:
            try:
                vmax0 = float(traci.vehicle.getMaxSpeed(vid))
            except Exception:
                vmax0 = float(getattr(self, "MAX_SPEED", 16.67))
            if not np.isfinite(vmax0) or vmax0 <= 0.0:
                vmax0 = float(getattr(self, "MAX_SPEED", 16.67))
            capped[vid] = [vmax0, None]
            try:
                traci.vehicle.setSpeed(vid, -1)
            except Exception:
                pass
        vmax0, last = capped[vid]
        if float(accel) >= float(a_idm) - float(self.SPEED_ADV_TOL):
            cap = vmax0
        else:
            cap = min(
                vmax0,
                max(
                    float(self.SPEED_ADV_MIN_MS),
                    float(current_speed) + float(accel) * float(self.step_length),
                ),
            )
        if last is None or abs(float(cap) - float(last)) > 1e-3:
            traci.vehicle.setMaxSpeed(vid, float(cap))
            capped[vid][1] = float(cap)

    def _jstall_reset(self):
        self._auth_reset()
        self._jstall = {
            "sig_ctrl_cav_s": 0.0,
            "sig_free_cav_s": 0.0,
            "sig_hdv_s": 0.0,
            "unsig_s": 0.0,
            "ctrl_cav_events": 0,
            "free_cav_events": 0,
            "hdv_events": 0,
            "lon_exec": 0,
            "lon_noop": 0,
        }
        self._jstall_since = {}
        self._jstall_counted = set()

    @staticmethod
    def _junction_of_internal_lane(lane_id):
        """':J_3_0' -> 'J' (internal lane -> junction id); '' for normal lanes."""
        s = str(lane_id or "")
        if not s.startswith(":"):
            return ""
        edge = s.rsplit("_", 1)[0]
        return edge[1:].rsplit("_", 1)[0]

    def _signalized_junction_ids(self):
        cached = getattr(self, "_sig_junction_ids", None)
        if cached is not None:
            return cached
        out = set()
        for tls_id in list(self.tls_ids or []):
            try:
                groups = traci.trafficlight.getControlledLinks(tls_id)
            except Exception:
                continue
            for group in groups or ():
                for link in group or ():
                    try:
                        via = link[2]
                    except (IndexError, TypeError):
                        continue
                    jid = self._junction_of_internal_lane(via)
                    if jid:
                        out.add(jid)
        if out:
            self._sig_junction_ids = out
        return out

    def _jstall_accumulate(self, controlled, now):
        """Observe-only: vehicle-seconds standing inside junction boxes."""
        dt = float(self.step_length)
        sig = self._signalized_junction_ids()
        js = self._jstall
        old_since = self._jstall_since
        new_since = {}
        for vid, d in (self.sub_results or {}).items():
            lane = str(d.get(tc.VAR_LANE_ID, "") or "")
            if not lane.startswith(":"):
                continue
            spd = self._traci_valid_double(d.get(tc.VAR_SPEED, None))
            if spd is None or float(spd) >= float(self.JSTALL_V_MS):
                continue
            jid = self._junction_of_internal_lane(lane)
            if jid not in sig:
                js["unsig_s"] += dt
                continue
            vtype = str(d.get(tc.VAR_TYPE, "") or "")
            if "CAV" in vtype:
                grp = "ctrl_cav" if vid in controlled else "free_cav"
            else:
                grp = "hdv"
            js[f"sig_{grp}_s"] += dt
            t0 = old_since.get(vid, float(now))
            new_since[vid] = t0
            if float(now) - t0 >= float(self.JSTALL_EVENT_S) and vid not in self._jstall_counted:
                self._jstall_counted.add(vid)
                js[f"{grp}_events"] += 1
        self._jstall_since = new_since

    # ------------------------------------------------------------------
    # v6-P0: longitudinal execution-authority audit (observe-only)
    # ------------------------------------------------------------------
    # Tests hypothesis D1 of the v6 diagnosis: the policy residual is executed
    # one-sidedly (positive part cut by the rule stack / SUMO safe speed), so
    # exploration noise produces a net slowdown versus IDM.
    AUTH_TOL = 0.05        # m/s^2: stack residual vs policy residual
    AUTH_SUMO_TOL = 0.10   # m/s^2: realised vs requested acceleration

    def _auth_reset(self):
        self._auth = {
            "n": 0, "pol_sum": 0.0, "stack_sum": 0.0,
            "stack_cut": 0, "stack_lift": 0,
            "pol_pos": 0, "pol_pos_exec": 0,
            "real_n": 0, "real_res_sum": 0.0, "req_res_sum": 0.0,
            "sumo_cut": 0, "sumo_lift": 0,
        }
        self._auth_pending = {}

    def _auth_record(self, vid, accel_policy, accel_stack, a_idm):
        """Called once per executed CAV: policy accel (IDM + beta*residual) vs stack output."""
        a = getattr(self, "_auth", None)
        if a is None:
            self._auth_reset()
            a = self._auth
        try:
            pol_res = float(accel_policy) - float(a_idm)
            stack_res = float(accel_stack) - float(a_idm)
        except (TypeError, ValueError):
            return
        if not (np.isfinite(pol_res) and np.isfinite(stack_res)):
            return
        tol = float(self.AUTH_TOL)
        a["n"] += 1
        a["pol_sum"] += pol_res
        a["stack_sum"] += stack_res
        if stack_res < pol_res - tol:
            a["stack_cut"] += 1
        elif stack_res > pol_res + tol:
            a["stack_lift"] += 1
        if pol_res > tol:
            a["pol_pos"] += 1
            if stack_res > tol:
                a["pol_pos_exec"] += 1
        self._auth_pending[str(vid)] = (float(accel_stack), float(a_idm))

    def _auth_realize(self):
        """After simulationStep: compare SUMO's realised acceleration with the request."""
        pend = getattr(self, "_auth_pending", None)
        if not pend:
            return
        a = self._auth
        tol = float(self.AUTH_SUMO_TOL)
        subs = self.sub_results or {}
        for vid, (req, a_idm) in pend.items():
            d = subs.get(vid)
            if d is None:
                continue
            real = self._traci_valid_double(d.get(tc.VAR_ACCELERATION, None))
            if real is None:
                continue
            real = float(real)
            a["real_n"] += 1
            a["real_res_sum"] += real - float(a_idm)
            a["req_res_sum"] += float(req) - float(a_idm)
            if real < float(req) - tol:
                a["sumo_cut"] += 1
            elif real > float(req) + tol:
                a["sumo_lift"] += 1
        self._auth_pending = {}

    def auth_stats(self) -> dict:
        a = getattr(self, "_auth", None) or {}
        n = int(a.get("n", 0))
        rn = int(a.get("real_n", 0))
        pp = int(a.get("pol_pos", 0))
        return {
            "auth_n": float(n),
            "auth_policy_res_mean": float(a.get("pol_sum", 0.0)) / max(1, n),
            "auth_stack_res_mean": float(a.get("stack_sum", 0.0)) / max(1, n),
            "auth_stack_cut_frac": float(a.get("stack_cut", 0)) / max(1, n),
            "auth_stack_lift_frac": float(a.get("stack_lift", 0)) / max(1, n),
            "auth_policy_pos_frac": float(pp) / max(1, n),
            "auth_pos_exec_ratio": float(a.get("pol_pos_exec", 0)) / max(1, pp),
            "auth_realized_res_mean": float(a.get("real_res_sum", 0.0)) / max(1, rn),
            "auth_requested_res_mean": float(a.get("req_res_sum", 0.0)) / max(1, rn),
            "auth_sumo_cut_frac": float(a.get("sumo_cut", 0)) / max(1, rn),
            "auth_sumo_lift_frac": float(a.get("sumo_lift", 0)) / max(1, rn),
        }

    # ------------------------------------------------------------------
    # v6-P0: rule signal controllers inside the SAME envelope as the RL agent
    # (min/max green, budget T, cycle fairness, starvation). SIGNAL_RULE=
    # maxpressure | longest_queue replaces the agent's choice among the phases
    # its own mask allows; the agent sample is then logged as overridden and
    # excluded from PPO. Used as a strong baseline and to freeze the signal side
    # while bisecting the CAV control stack.
    # ------------------------------------------------------------------
    def _signal_rule_name(self) -> str:
        raw = str(os.environ.get("SIGNAL_RULE", "") or "").strip().lower()
        return raw if raw in ("maxpressure", "longest_queue", "fixed") else ""

    def _phase_pressure(self, tls_id, green_idx, horizon_m=200.0) -> float:
        """Max-Pressure: vehicles on the green's incoming lanes within ``horizon_m``
        of the stop line minus vehicles on its downstream (capital-G) edges."""
        _base, lanes = self._phase_chain_lanes(tls_id, green_idx)
        idx = self._lane_vehicle_index()
        n_in = 0
        for cl in lanes:
            for _speed, dist, _w in idx.get(cl, ()):
                if 0.0 <= float(dist) <= float(horizon_m):
                    n_in += 1
        outs = self._phase_out_edges(tls_id, green_idx)
        n_out = 0
        if outs:
            for lane_id, rows in idx.items():
                if str(lane_id).rsplit("_", 1)[0] in outs:
                    n_out += len(rows)
        return float(n_in - n_out)

    def _rule_signal_choice(self, tls_id, current_phase, rule):
        cached = (getattr(self, "_last_signal_mask", None) or {}).get(tls_id)
        if cached is None or int(cached[0]) != int(current_phase):
            return None
        mask = np.asarray(cached[1], dtype=np.float32).reshape(-1)
        legal = [i for i in range(mask.shape[0]) if float(mask[i]) > 0.5]
        if len(legal) <= 1:
            return None
        cur_g = int(self._green_index_of_phase(tls_id, current_phase))
        best, best_score = None, None
        for g in legal:
            if rule == "maxpressure":
                score = self._phase_pressure(tls_id, g)
                if score > 0.0 and self._env_on("V7_MP_CAPACITY_AWARE"):
                    _cap = getattr(self, "_v7_cap_factor", None) or []
                    if 0 <= g < len(_cap):
                        score *= float(_cap[g])
            else:
                score = float(self._queue_length_for_green(tls_id, g))
            # Tie-break: keep the current green, then the lowest index.
            key = (score, 1 if g == cur_g else 0, -g)
            if best_score is None or key > best_score:
                best, best_score = g, key
        return best

    def jstall_stats(self) -> dict:
        js = getattr(self, "_jstall", None) or {}
        n_exec = int(js.get("lon_exec", 0))
        n_noop = int(js.get("lon_noop", 0))
        out = {
            "jstall_sig_ctrl_cav_s": float(js.get("sig_ctrl_cav_s", 0.0)),
            "jstall_sig_free_cav_s": float(js.get("sig_free_cav_s", 0.0)),
            "jstall_sig_hdv_s": float(js.get("sig_hdv_s", 0.0)),
            "jstall_unsig_s": float(js.get("unsig_s", 0.0)),
            "jstall_ctrl_cav_events": float(js.get("ctrl_cav_events", 0)),
            "jstall_free_cav_events": float(js.get("free_cav_events", 0)),
            "jstall_hdv_events": float(js.get("hdv_events", 0)),
            "lon_noop_frac": float(n_noop) / float(max(1, n_exec + n_noop)),
        }
        for r in self._HANDBACK_REASONS:
            out[f"lon_handback_{r}"] = float(js.get(f"handback_{r}", 0))
        return out

    def _cav_action_applies(
        self,
        vid,
        cav_actions,
        is_leader,
        in_control_zone,
        is_in_junction,
        in_platoon_zone=False,
        dist_to_stopline=None,
        cluster_id=None,
    ) -> bool:
        if not bool(self.CAV_RL_ENABLED):
            return False
        if not cav_actions or vid not in cav_actions:
            return False
        # Longitudinal RL in formation + control zones.
        if not (in_control_zone or is_in_junction or in_platoon_zone):
            return False
        leaders_only = bool(getattr(self, "CAV_CONTROL_LEADERS_ONLY", False))
        if leaders_only and not is_leader:
            return False
        # Match marl_env lon obs gate: corridor distance (and leader when leaders-only).
        # All-CAV mode (CAV_CONTROL_LEADERS_ONLY=False) still uses the distance gate;
        # DBSCAN leader labels are observational only and do not block Lon RL.
        try:
            from environment.cav_state_builder import lon_rl_eligible

            if dist_to_stopline is None or cluster_id is None:
                detail = (getattr(self, "_zone_detail", None) or {}).get(vid) or {}
                if dist_to_stopline is None:
                    dist_to_stopline = detail.get("dist_to_stopline", -1.0)
                if cluster_id is None and self.platoon_tracker is not None:
                    cluster_id = self.platoon_tracker.cluster_of.get(vid)
            if not lon_rl_eligible(
                {
                    "is_leader": bool(is_leader),
                    "is_in_junction": bool(is_in_junction),
                    "dist_to_stopline": dist_to_stopline,
                    "cluster_id": cluster_id,
                },
                require_leader=bool(leaders_only),
            ):
                return False
        except Exception:
            pass
        return True

    def _green_index_of_phase(self, tls_id, phase_idx):
        greens = self._green_phase_indices(tls_id)
        if not greens:
            return 0
        if phase_idx in greens:
            return greens.index(phase_idx)
        # Yellow / all-red: attribute to the preceding green.
        prev = [g for g in greens if g <= phase_idx]
        if prev:
            return greens.index(prev[-1])
        return 0

    def _max_green_for(self, tls_id, green_index):
        limits = getattr(self, "MAX_GREEN_BY_PHASE", ())
        if limits and 0 <= int(green_index) < len(limits):
            try:
                value = float(limits[int(green_index)])
                if np.isfinite(value) and value > 0.0:
                    return value
            except (TypeError, ValueError, OverflowError):
                pass
        fallback = float(getattr(self, "MAX_GREEN_DURATION", 40.0))
        return fallback if np.isfinite(fallback) and fallback > 0.0 else 40.0

    def _planned_green_for(self, tls_id, green_index):
        """Return the current phase's cached budget, initializing T on first use.

        The first controlled green after warmup used to fall back to Gmax because
        no T had yet been cached. Initializing lazily ensures 3/4/5-leg junctions
        all apply the same queue-dependent rule from the first decision onward.
        """
        min_g = float(self._min_green_for(tls_id, green_index))
        if not np.isfinite(min_g) or min_g <= 0.0:
            min_g = max(float(getattr(self, "step_length", 0.2)), 1.0)
        max_g = max(min_g, float(self._max_green_for(tls_id, green_index)))
        if self._env_on("V7_GMAX_BUDGET"):
            # v7 ablation: no heuristic planned-T forced switch; the controller
            # (RL or Max-Pressure) decides inside [Gmin, Gmax] at every decision.
            return float(max_g)
        T = getattr(self, "_last_green_T", {}).get(tls_id)
        cached_index = getattr(self, "_last_green_index", {}).get(tls_id)
        if T is None or (cached_index is not None and int(cached_index) != int(green_index)):
            return self._compute_green_duration(tls_id, green_index)
        try:
            T = float(T)
        except (TypeError, ValueError, OverflowError):
            return self._compute_green_duration(tls_id, green_index)
        if not np.isfinite(T):
            return self._compute_green_duration(tls_id, green_index)
        return float(np.clip(T, min_g, max_g))

    def _clamp_signal_action(self, tls_id, action_value, current_phase, elapsed):
        """Clamp agent phase choice into min/planned-T green rules; return green index.

        v5.1 mask contract: an action that was legal in the mask the agent
        actually observed (cached by _build_action_mask for the same phase) is
        executed as chosen. v4 re-derived the rules one step later, so
        starvation sets (mask allowed several phases, clamp forced one) and
        T-expiry crossings replaced 1-15 % of decisions in the smoke test.
        Min green is still enforced first. SIGNAL_MASK_CONTRACT=0 restores v4.
        """
        greens = self._green_phase_indices(tls_id)
        n = max(1, len(greens))
        cur_g = self._green_index_of_phase(tls_id, current_phase)
        action_value = int(np.clip(int(action_value), 0, n - 1))
        target_g = self._planned_green_for(tls_id, cur_g)
        kind = self._phase_kind(tls_id, current_phase)
        if kind != 'green':
            return action_value
        gmin = self._min_green_for(tls_id, cur_g)
        if elapsed < gmin - 1e-3:
            return cur_g
        if bool(getattr(self, "SIGNAL_MASK_CONTRACT", True)):
            cached = (getattr(self, "_last_signal_mask", None) or {}).get(tls_id)
            if cached is not None:
                c_phase, c_mask = cached
                if (
                    int(c_phase) == int(current_phase)
                    and len(c_mask) == n
                    and float(c_mask[action_value]) > 0.5
                ):
                    return action_value
        if self._starve_may_force(tls_id, cur_g, elapsed, target_g, gmin):
            starve_g = self._starving_green_phase(tls_id, cur_g)
            if starve_g is not None:
                return int(starve_g)
        if elapsed >= target_g - 1e-3:
            if action_value == cur_g:
                return self._fallback_switch_index(tls_id, cur_g, n)
            return action_value
        return action_value

    def _queue_cardinal(self, edge_id):
        if edge_id.startswith('top'):
            return 'N'
        if edge_id.startswith('bottom'):
            return 'S'
        if edge_id.startswith('right'):
            return 'E'
        if edge_id.startswith('left'):
            return 'W'
        return self._approach_cardinal.get(edge_id)

    def _lane_length(self, lane_id):
        """Lane length (m) from net.xml caches — no TraCI once topology is ready."""
        length = self.lane_lengths_cache.get(lane_id)
        if length is not None:
            return float(length)
        edge = self._edge_of_lane(lane_id)
        try:
            idx = int(str(lane_id).rsplit("_", 1)[-1])
        except (TypeError, ValueError):
            idx = -1
        lens = (getattr(self, "_edge_lane_lengths", None) or {}).get(edge)
        if lens and 0 <= idx < len(lens):
            length = float(lens[idx])
            self.lane_lengths_cache[lane_id] = length
            return length
        if getattr(self, "_static_topology_ready", False):
            return 0.0
        # Pre-topology / unit-test fallback only.
        try:
            length = float(traci.lane.getLength(lane_id))
            self.lane_lengths_cache[lane_id] = length
            return length
        except Exception:
            return 0.0

    def _vehicle_type(self, vid, v_data=None):
        vtype = self.vehicle_types.get(vid)
        if vtype is not None:
            return vtype
        if v_data is not None and tc.VAR_TYPE in v_data:
            vtype = v_data[tc.VAR_TYPE]
        else:
            vtype = traci.vehicle.getTypeID(vid)
        self.vehicle_types[vid] = vtype
        return vtype

    def _vtype_limits(self, vtype):
        cached = self.vtype_dynamics_cache.get(vtype)
        if cached is None:
            cached = (
                float(traci.vehicletype.getAccel(vtype)),
                float(traci.vehicletype.getDecel(vtype)),
            )
            self.vtype_dynamics_cache[vtype] = cached
        return cached

    def _vehicle_route(self, vid):
        route = self.vehicle_routes.get(vid)
        if route is None:
            route = traci.vehicle.getRoute(vid)
            self.vehicle_routes[vid] = route
            self._invalidate_route_next(vid)
        return route

    def _set_vehicle_route(self, vid, route):
        """Store route and drop next-edge cache for ``vid``."""
        self.vehicle_routes[vid] = route
        self._invalidate_route_next(vid)

    def _clear_vehicle_route(self, vid):
        self.vehicle_routes.pop(vid, None)
        self._invalidate_route_next(vid)

    def _refresh_signals(self):
        """One TraCI round per TLS per step — shared by get_state / signal control / time_to_green."""
        now = traci.simulation.getTime()
        self._sim_time = now
        if not self.tls_ids:
            self.tls_ids = self._resolve_controlled_tls_ids()
        signals = {}
        for tls_id in self.tls_ids:
            synth = self.signal_programs.get(f"{tls_id}_synth")
            if synth:
                # "online" program reports phase 0, which is a real green in rl.
                phase = int(synth.get("from_phase", self.last_signal_phase.get(tls_id, 0)))
                state = str(
                    synth.get("yellow_state") if synth.get("mode") == "yellow"
                    else synth.get("allred_state") or ""
                )
            else:
                phase = traci.trafficlight.getPhase(tls_id)
                state = traci.trafficlight.getRedYellowGreenState(tls_id)
            remaining = max(0.0, traci.trafficlight.getNextSwitch(tls_id) - now)
            synth_next = -1
            if synth and bool(getattr(self, "SPAT_SYNTH_FIX", True)):
                # v5.2.4: during a synthesized transition the "online" program's
                # next switch is meaningless; the remaining time is the rest of
                # yellow (+ all-red), and the next green is already decided.
                remaining = self._synth_remaining(synth, now)
                try:
                    synth_next = int(synth.get("next_green", -1))
                except (TypeError, ValueError):
                    synth_next = -1
            elapsed = max(0.0, now - self.phase_started_at.get(tls_id, now))
            green_index = int(self._green_index_of_phase(tls_id, phase))
            n_green = max(1, len(self._green_phase_indices(tls_id)))
            signals[tls_id] = {
                'phase': phase,
                'green_index': green_index,
                'n_green': n_green,
                'state': state,
                'synth': str(synth.get("mode")) if synth else "",
                'synth_next': int(synth_next),
                'remaining_time': remaining,
                'elapsed_time': elapsed,
            }
            if self._env_on("SIGNAL_COMMITMENT") and not synth:
                gmin = float(self._min_green_for(tls_id, green_index))
                try:
                    next_g = int(self._fallback_switch_index(tls_id, green_index, n_green))
                except Exception:
                    next_g = (green_index + 1) % n_green
                signals[tls_id]['committed_gmin_remaining'] = max(0.0, gmin - elapsed)
                signals[tls_id]['committed_next_green'] = int(next_g)
                signals[tls_id]['p1_planned_T'] = float(self._planned_green_for(tls_id, green_index))
        self._signals = signals
        return signals

    def _parse_next_tls(self, vid, v_data):
        next_tls = v_data.get(tc.VAR_NEXT_TLS)
        if next_tls:
            try:
                return self._unpack_next_tls_entry(next_tls[0])
            except Exception:
                pass
        # Fallback only if zone subscription has not produced data yet
        try:
            raw = traci.vehicle.getNextTLS(vid)
            if raw:
                return self._unpack_next_tls_entry(raw[0])
        except Exception:
            pass
        return None, -1, -1.0, 'n'

    def _parse_leader(self, vid, v_data, default_speed):
        leader = v_data.get(tc.VAR_LEADER)
        if leader is None:
            try:
                leader = traci.vehicle.getLeader(vid, 100.0)
            except Exception:
                leader = None
        if not leader:
            return None, 100.0, default_speed, None
        leader_id, leader_gap = self._unpack_leader_follower(leader)
        if leader_id is None or leader_gap is None:
            return None, 100.0, default_speed, None
        leader_speed = self.sub_results.get(leader_id, {}).get(tc.VAR_SPEED, default_speed)
        if str(leader_id).startswith("evt_"):
            leader_speed = 0.0  # v7.1 obstacle is unsubscribed; never assume it moves
        ttc = None
        closing = default_speed - leader_speed
        if closing > 0.0 and leader_gap > 0.0:
            ttc = leader_gap / closing
        return leader_id, float(leader_gap), leader_speed, ttc

    def _ensure_upstream_lane_map(self):
        """Build cached map: lane_id -> list[(upstream_lane_id, intermediate_len_m)]."""
        cached = getattr(self, "_upstream_lane_map_cache", None)
        if cached is not None:
            return cached
        up_map = {}

        def _add_pred(dst_lane: str, src_lane: str, between_m: float) -> None:
            if not dst_lane or not src_lane or dst_lane == src_lane:
                return
            lst = up_map.setdefault(dst_lane, [])
            for ex_lane, _ in lst:
                if ex_lane == src_lane:
                    return
            lst.append((src_lane, max(0.0, float(between_m))))

        net_path = None
        try:
            net_path = self.resolve_net_xml_path()
        except Exception:
            net_path = getattr(self, "net_xml_path", None)
        lane_len_xml = {}
        if net_path and os.path.isfile(str(net_path)):
            try:
                import xml.etree.ElementTree as _ET

                root = _ET.parse(str(net_path)).getroot()
                for edge_el in root.findall("edge"):
                    for lane_el in edge_el.findall("lane"):
                        lid = lane_el.attrib.get("id")
                        if lid:
                            lane_len_xml[lid] = float(lane_el.attrib.get("length", 0.0) or 0.0)
                for conn_el in root.findall("connection"):
                    fe = conn_el.attrib.get("from", "")
                    te = conn_el.attrib.get("to", "")
                    fl = conn_el.attrib.get("fromLane")
                    tl = conn_el.attrib.get("toLane")
                    via = conn_el.attrib.get("via", "")
                    if not fe or not te or fl is None or tl is None:
                        continue
                    if fe.startswith(":") or te.startswith(":"):
                        continue
                    src_lane = f"{fe}_{fl}"
                    dst_lane = f"{te}_{tl}"
                    via_len = float(lane_len_xml.get(via, 0.0)) if via else 0.0
                    if via:
                        _add_pred(dst_lane, via, 0.0)
                        _add_pred(via, src_lane, 0.0)
                    _add_pred(dst_lane, src_lane, via_len)
            except Exception:
                pass

        chains = getattr(self, "_approach_chains", None) or {}
        for _card, chain in chains.items():
            if not chain or len(chain) < 2:
                continue
            for idx in range(len(chain) - 1):
                near_edge = str(chain[idx])
                up_edge = str(chain[idx + 1])
                for k in range(6):
                    _add_pred(f"{near_edge}_{k}", f"{up_edge}_{k}", 0.0)

        self._upstream_lane_map_cache = up_map
        if lane_len_xml and not getattr(self, "_xml_lane_lengths", None):
            self._xml_lane_lengths = lane_len_xml
        return up_map

    def _safe_lane_len(self, lane_id: str) -> float:
        xml_lens = getattr(self, "_xml_lane_lengths", None) or {}
        if lane_id in xml_lens and xml_lens[lane_id] > 0.0:
            return float(xml_lens[lane_id])
        try:
            val = float(self._lane_length(lane_id))
            if val > 0.0:
                return val
        except Exception:
            pass
        return 0.0

    @staticmethod
    def _min_gap_for_vtype(vtype: str) -> float:
        return 1.0 if "CAV" in str(vtype or "") else 2.5

    def _build_in_memory_followers(self, sub_results=None, max_dist: float = 100.0):
        """Compute O(N) zero-RPC (follower_id, net_gap_m) map across same & chained edges."""
        subs = sub_results if sub_results is not None else (getattr(self, "sub_results", None) or {})
        if not subs:
            return {}
        best = {}

        def _consider(ego_id: str, fol_id: str, gap_val: float) -> None:
            if not ego_id or not fol_id or ego_id == fol_id:
                return
            if not np.isfinite(gap_val) or gap_val > max_dist or gap_val < -5.0:
                return
            prev = best.get(ego_id)
            if prev is None or gap_val < prev[1]:
                best[ego_id] = (str(fol_id), float(gap_val))

        lane_buckets = {}
        for uid, u_data in subs.items():
            if not isinstance(u_data, dict):
                continue
            raw_lead = u_data.get(tc.VAR_LEADER)
            if raw_lead:
                lid, lgap = self._unpack_leader_follower(raw_lead)
                if lid is not None and lgap is not None:
                    _consider(str(lid), str(uid), float(lgap))

            lane_id = str(u_data.get(tc.VAR_LANE_ID, "") or "")
            pos_raw = self._traci_valid_double(u_data.get(tc.VAR_LANEPOSITION, None))
            if not lane_id or pos_raw is None:
                continue
            vtype = str(u_data.get(tc.VAR_TYPE, "") or "")
            vlen = self._traci_valid_double(u_data.get(tc.VAR_LENGTH, None), non_negative=True)
            if vlen is None or vlen <= 0.0:
                vlen = float((getattr(self, "_vehicle_length_cache", None) or {}).get(uid, 5.0) or 5.0)
            mgap = self._min_gap_for_vtype(vtype)
            pos = float(pos_raw)
            lane_buckets.setdefault(lane_id, []).append((pos, str(uid), float(vlen), float(mgap)))

        for lid_k in lane_buckets:
            lane_buckets[lid_k].sort(key=lambda item: item[0])

        for lane_id, arr in lane_buckets.items():
            for idx in range(1, len(arr)):
                pos_fol, fol_id, _len_fol, mgap_fol = arr[idx - 1]
                pos_ego, ego_id, len_ego, _mgap_ego = arr[idx]
                net_gap = (pos_ego - len_ego) - pos_fol - mgap_fol
                _consider(ego_id, fol_id, net_gap)

        up_map = self._ensure_upstream_lane_map()
        if up_map:
            for lane_id, arr in lane_buckets.items():
                if not arr or lane_id not in up_map:
                    continue
                pos_ego, ego_id, len_ego, _mgap_ego = arr[0]
                if pos_ego - len_ego > max_dist:
                    continue
                for up_lane, between_m in up_map.get(lane_id, ()):
                    up_arr = lane_buckets.get(up_lane)
                    if not up_arr:
                        continue
                    up_len = self._safe_lane_len(up_lane)
                    if up_len <= 0.0:
                        continue
                    pos_fol, fol_id, _len_fol, mgap_fol = up_arr[-1]
                    rem_up = max(0.0, up_len - pos_fol)
                    net_gap = (pos_ego - len_ego) + float(between_m) + rem_up - mgap_fol
                    _consider(ego_id, fol_id, net_gap)

        return best

    def _parse_follower(self, vid, v_data):
        """Return (follower_id, gap_m) via zero-RPC in-memory cache or getFollower fallback."""
        del v_data
        if bool(getattr(self, "IN_MEMORY_FOLLOWER_LOOKUP", True)):
            cache = getattr(self, "_step_follower_map", None)
            if cache is not None:
                hit = cache.get(vid)
                if hit is not None:
                    return hit[0], float(hit[1])
                return None, 100.0
        try:
            follower = traci.vehicle.getFollower(vid, 100.0)
        except Exception:
            follower = None
        if not follower:
            return None, 100.0
        follower_id, follower_gap = self._unpack_leader_follower(follower)
        if follower_id is None or follower_gap is None:
            return None, 100.0
        return follower_id, float(follower_gap)

    def _cached_vehicle_length(self, vid, v_data):
        """Static length (m); cache per vid (no per-step TraCI getLength)."""
        cache = self._vehicle_length_cache
        cached = cache.get(vid)
        if cached is not None:
            return float(cached)
        length_raw = self._traci_valid_double(
            v_data.get(tc.VAR_LENGTH, None), non_negative=True
        )
        if length_raw is None:
            try:
                length_raw = float(traci.vehicle.getLength(vid))
            except Exception:
                length_raw = 5.0
        cache[vid] = float(length_raw)
        return float(length_raw)

    def _parse_next_links(self, vid, v_data):
        next_links = v_data.get(tc.VAR_NEXT_LINKS)
        if next_links is None:
            try:
                next_links = traci.vehicle.getNextLinks(vid)
            except Exception:
                next_links = ()
        if not next_links:
            return True, False
        return self._unpack_next_links_flags(next_links[0])

    def _parse_speed_without_traci(self, vid, v_data, fallback_speed):
        val = v_data.get(tc.VAR_SPEED_WITHOUT_TRACI)
        if val is not None:
            return float(val)
        try:
            return float(traci.vehicle.getSpeedWithoutTraCI(vid))
        except Exception:
            return float(fallback_speed)

    def _reset_episode_kpis(self):
        """Start KPI counters after warmup so metrics cover the controlled episode only."""
        now = traci.simulation.getTime()
        self._depart_times = {}
        self._prev_speeds = {}
        self._veh_was_moving = {}
        self._last_accum_wait = {}
        for vid, v_data in self.sub_results.items():
            try:
                dep = float(traci.vehicle.getDeparture(vid))
            except Exception:
                dep = now
            # Clip warm-up departures so ATT excludes the fixed-timing warm-up.
            self._depart_times[vid] = float(max(dep, now))
            spd = self._traci_valid_double(v_data.get(tc.VAR_SPEED, 0.0))
            spd_f = 0.0 if spd is None else float(spd)
            self._prev_speeds[vid] = spd_f
            self._veh_was_moving[vid] = bool(spd_f >= 0.5)
            # Control-period wait only: ignore SUMO warmup accumulatedWaitingTime.
            self._last_accum_wait[vid] = 0.0
        self._episode_travel_times = []
        self._episode_waiting_times = []
        self._episode_stops = 0
        self._ep_fuel_mg = 0.0
        self._ep_co2_mg = 0.0
        self._ep_dist_m = 0.0
        self._ep_vehicle_ids = set()
        self._ep_veh_fuel_mg = {}
        self._ep_veh_co2_mg = {}
        self._ep_veh_dist_m = {}
        self._gridlock_streak = 0
        self._control_steps = 0
        self._done_reason = ""
        self._kpi_handover_time = float(now)
        # v4: insertion-aware time-in-system KPI and OD-rewrite counter.
        self._od_rewrites = 0
        self._tis_init(float(now))
        self._jstall_reset()

    @staticmethod
    def _edge_of_lane(lane_id):
        """Edge id from SUMO lane id naming (``edge_laneIndex``). Never TraCI."""
        if not lane_id:
            return ""
        lid = str(lane_id)
        if "_" in lid:
            return lid.rsplit("_", 1)[0]
        return lid

    def _refresh_signal_topology(self):
        """Incoming/outgoing edges for signal pressure reward (Dublin OSM + cross)."""
        incoming = set()
        outgoing = set()
        tls_list = list(self.tls_ids or [])
        preferred = getattr(self, "scenario_tls_id", None)
        if preferred and preferred in tls_list:
            tls_list = [preferred]
        for tls_id in tls_list:
            try:
                links = traci.trafficlight.getControlledLinks(tls_id)
            except Exception:
                continue
            for group in links:
                for conn in group:
                    if not conn:
                        continue
                    in_lane, out_lane = self._unpack_controlled_link(conn)
                    if in_lane:
                        e = self._edge_of_lane(in_lane)
                        if e and not e.startswith(":"):
                            incoming.add(e)
                    if out_lane:
                        e = self._edge_of_lane(out_lane)
                        if e and not e.startswith(":"):
                            outgoing.add(e)
        # scenario APPROACH_EDGES are always incoming approaches
        for e in self._approach_cardinal:
            incoming.add(e)
        self.incoming_edges = sorted(incoming)
        self.outgoing_edges = sorted(outgoing)
        c = self._update_signal_pressure_capacity()
        print(
            f"[SUMO] signal pressure c={c:.1f} "
            f"(incoming_edges={len(self.incoming_edges)}, "
            f"L_zone={float(getattr(self, 'CONTROL_ZONE_DISTANCE', 300.0)):.0f}m)"
        )

    def _emission_kpis(self):
        """Episode emission KPIs from HBEFA rates integrated over the controlled episode.

        Returns dict with:
          - fleet_avg_fuel / fleet_avg_co2: distance-normalized fleet intensity (L/100km, g/km)
          - total_fuel_L / total_co2_g: episode sums over all observed vehicles
          - veh_avg_fuel_L / veh_avg_co2_g: mean of per-vehicle intensities (L/100km, g/km)
        """
        dist_km = float(self._ep_dist_m) / 1000.0
        fuel_L = float(self._ep_fuel_mg) / float(self.FUEL_DENSITY_MG_PER_L)
        co2_g = float(self._ep_co2_mg) / 1000.0
        if dist_km <= 1e-9:
            fleet_fuel, fleet_co2 = 0.0, 0.0
        else:
            fleet_fuel = (fuel_L / dist_km) * 100.0
            fleet_co2 = co2_g / dist_km

        veh_fuels = []
        veh_co2s = []
        for vid, v_fuel_mg in self._ep_veh_fuel_mg.items():
            v_dist_km = float(self._ep_veh_dist_m.get(vid, 0.0)) / 1000.0
            # v5.2.1: vehicles that mostly idled inside the window (< 50 m) give
            # L/100km values in the thousands and dominate the mean.
            if v_dist_km < float(getattr(self, "VEH_FUEL_MIN_DIST_KM", 0.05)):
                continue
            v_fuel_L = float(v_fuel_mg) / float(self.FUEL_DENSITY_MG_PER_L)
            v_co2_g = float(self._ep_veh_co2_mg.get(vid, 0.0)) / 1000.0
            veh_fuels.append((v_fuel_L / v_dist_km) * 100.0)
            veh_co2s.append(v_co2_g / v_dist_km)
        n_veh = int(len(self._ep_vehicle_ids))
        veh_fuel = float(np.mean(veh_fuels)) if veh_fuels else 0.0
        veh_co2 = float(np.mean(veh_co2s)) if veh_co2s else 0.0
        return {
            'fleet_avg_fuel': float(fleet_fuel),
            'fleet_avg_co2': float(fleet_co2),
            'total_fuel_L': float(fuel_L),
            'total_co2_g': float(co2_g),
            'veh_avg_fuel_L': float(veh_fuel),  # L/100km (mean of per-vehicle)
            'veh_avg_co2_g': float(veh_co2),    # g/km (mean of per-vehicle)
            'emission_vehicle_count': n_veh,
        }

    @staticmethod
    def all_sample_avg_waiting_time(completed_waits, unfinished_waits) -> float:
        """Mean wait over completed trips + still-on-net / unfinished vehicles.

        Uncensored AWT in s/veh: includes right-censored vehicles that never arrive.
        """
        n_done = len(completed_waits) if completed_waits is not None else 0
        n_open = len(unfinished_waits) if unfinished_waits is not None else 0
        n = int(n_done + n_open)
        if n <= 0:
            return 0.0
        total = float(sum(completed_waits or ())) + float(sum(unfinished_waits or ()))
        return float(total / float(n))

    def _uncensored_avg_travel_time(self, now: float) -> float:
        """ATT over completed trips + still-on-net vehicles (warm-up clipped)."""
        times = [float(x) for x in (getattr(self, "_episode_travel_times", None) or [])]
        deps = getattr(self, "_depart_times", None) or {}
        for vid, dep in deps.items():
            if vid not in (getattr(self, "sub_results", None) or {}):
                continue
            try:
                times.append(max(0.0, float(now) - float(dep)))
            except (TypeError, ValueError):
                continue
        if not times:
            return 0.0
        return float(np.mean(times))

    def _update_episode_kpis(self):
        """Track arrivals (ATT), true per-vehicle waiting, and stop events."""
        now = traci.simulation.getTime()
        dt = float(self.step_length)
        self._tis_release(float(now))
        if not hasattr(self, "_veh_was_moving"):
            self._veh_was_moving = {}
        # Self-accumulate control-period wait (v < 0.1); ignore SUMO 100s memory.
        _v7_excl = getattr(self, "_v7_evt_excluded", None) or ()
        for vid, v_data in self.sub_results.items():
            if vid in _v7_excl:
                continue
            speed = self._traci_valid_double(v_data.get(tc.VAR_SPEED, 0.0))
            if speed is None:
                continue
            if speed < 0.1:
                self._last_accum_wait[vid] = (
                    float(self._last_accum_wait.get(vid, 0.0)) + dt
                )
            else:
                self._last_accum_wait.setdefault(vid, 0.0)
            was_moving = self._veh_was_moving.get(vid, speed >= 0.5)
            if speed >= 0.5:
                self._veh_was_moving[vid] = True
            elif speed < 0.1 and was_moving:
                # Hysteresis: only count a stop after a real move (>= 0.5 m/s).
                self._episode_stops += 1
                self._veh_was_moving[vid] = False
            self._prev_speeds[vid] = speed

        try:
            for vid in traci.simulation.getDepartedIDList():
                if str(vid).startswith("evt_"):
                    continue
                self._depart_times.setdefault(vid, now)
                self._last_accum_wait.setdefault(vid, 0.0)
                self._veh_was_moving.setdefault(vid, True)
            for vid in traci.simulation.getArrivedIDList():
                if str(vid).startswith("evt_") or vid in (getattr(self, "_v7_evt_excluded", None) or ()):
                    continue
                dep = self._depart_times.pop(vid, None)
                self._tis_on_arrival(str(vid), float(now))
                w_i = float(self._last_accum_wait.pop(vid, 0.0))
                self._episode_waiting_times.append(w_i)
                if dep is not None:
                    self._episode_travel_times.append(float(now - dep))
                self._prev_speeds.pop(vid, None)
                self._veh_was_moving.pop(vid, None)
        except Exception:
            pass

    def resolve_net_xml_path(self):
        """Absolute path to the SUMO .net.xml referenced by this sumocfg."""
        cached = getattr(self, "net_xml_path", None)
        if cached and os.path.isfile(cached):
            return cached
        import xml.etree.ElementTree as ET
        try:
            tree = ET.parse(self.sumocfg_file)
            net_file_node = tree.find(".//net-file")
            if net_file_node is None:
                return None
            net_file_name = net_file_node.get("value")
            net_file_path = os.path.join(
                os.path.dirname(os.path.abspath(self.sumocfg_file)), net_file_name
            )
            if os.path.isfile(net_file_path):
                self.net_xml_path = os.path.abspath(net_file_path)
                return self.net_xml_path
        except Exception:
            pass
        return None

    def _calculate_max_road_capacity(self):
        """
        Parse .net.xml: fill lane length cache and return a legacy fallback c
        (max edge capacity). Signal pressure for MAPPO uses
        ``_update_signal_pressure_capacity`` instead (incoming + L_zone clip).
        vehicle space = 4.5 m length + 2.5 m gap = 7.0 m.
        """
        import xml.etree.ElementTree as ET
        try:
            net_file_path = self.resolve_net_xml_path()
            if not net_file_path:
                return 160.0

            net_tree = ET.parse(net_file_path)
            max_capacity = 0.0
            vehicle_space = 4.5 + 2.5  # 7.0m
            self._edge_lane_lengths = {}
            if not hasattr(self, "lane_speeds_cache") or self.lane_speeds_cache is None:
                self.lane_speeds_cache = {}
            # edge_id → {fromLane_idx → set(to_edge_id)} for lateral routing masks.
            self._edge_lane_dests = {}
            # edge_id → {fromLane_idx → set((to_edge_id, toLane_idx))} for multi-hop corridor projection.
            self._edge_lane_to_lanes = {}
            self._corridor_proj_cache = {}
            self._edge_n_lanes = {}
            self._lane_to_edges_ser = {}
            self._static_topology_ready = False
            # 3/4-leg Dublin nets are lefthand; 5-leg is righthand.
            # Set immediately so a later parse error cannot leave the RHT default
            # on an LHT net (would invert all driver-relative LC).
            root = net_tree.getroot()
            self.lefthand = str(root.attrib.get("lefthand", "false")).lower() in (
                "1", "true", "yes"
            )

            for edge in net_tree.findall('.//edge'):
                eid = edge.get('id')
                lanes = edge.findall('lane')
                if not lanes:
                    continue
                # Always cache lane lengths (incl. internal) so get_state never
                # needs traci.lane.getLength on the hot path.
                lane_lens = []
                for lane in lanes:
                    lid = lane.get('id')
                    L = float(lane.get('length', 0.0))
                    lane_lens.append(L)
                    if lid:
                        self.lane_lengths_cache[lid] = L
                        try:
                            self.lane_speeds_cache[lid] = float(
                                lane.get('speed', self.MAX_SPEED)
                            )
                        except (TypeError, ValueError):
                            self.lane_speeds_cache[lid] = float(self.MAX_SPEED)
                if edge.get('function'):
                    # Internal / walkingarea / etc.: lengths only.
                    if eid:
                        self._edge_lane_lengths[eid] = lane_lens
                    continue
                if eid:
                    self._edge_lane_lengths[eid] = lane_lens
                    self._edge_n_lanes[eid] = len(lane_lens)
                edge_capacity = sum(L / vehicle_space for L in lane_lens)
                if edge_capacity > max_capacity:
                    max_capacity = edge_capacity

            for conn in net_tree.findall('.//connection'):
                fr = conn.get('from') or ''
                to = conn.get('to') or ''
                if not fr or fr.startswith(':') or not to or to.startswith(':'):
                    continue
                try:
                    fl = int(conn.get('fromLane', 0))
                    tl = int(conn.get('toLane', 0))
                except (TypeError, ValueError):
                    continue
                bucket = self._edge_lane_dests.setdefault(fr, {})
                bucket.setdefault(fl, set()).add(to)
                l2l = self._edge_lane_to_lanes.setdefault(fr, {})
                l2l.setdefault(fl, set()).add((to, tl))

            # Eager serializable topology (avoids per-step sorted() rebuilds).
            self._lane_to_edges_ser = {
                eid: {int(k): sorted(str(x) for x in v) for k, v in raw.items()}
                for eid, raw in self._edge_lane_dests.items()
            }
            self._static_topology_ready = True

            return max_capacity if max_capacity > 0 else 160.0
        except Exception as e:
            print(f"[Warning] Failed to parse .net.xml for capacity: {e}, using default 160.0")
            self._static_topology_ready = False
            return 160.0

    def _invalidate_route_next(self, vid=None):
        """Drop next-edge cache for one vehicle or all (after route/reset changes)."""
        cache = getattr(self, "_route_next_by_vid", None)
        if cache is None:
            self._route_next_by_vid = {}
            return
        if vid is None:
            cache.clear()
        else:
            cache.pop(vid, None)

    def _route_next_edge(self, vid, current_edge):
        """Next edge after ``current_edge`` on the vehicle route (or None)."""
        if not current_edge or str(current_edge).startswith(':'):
            return None
        cur = str(current_edge)
        cache = getattr(self, "_route_next_by_vid", None)
        if cache is None:
            self._route_next_by_vid = {}
            cache = self._route_next_by_vid
        hit = cache.get(vid)
        if hit is not None and hit[0] == cur:
            return hit[1]
        try:
            route = self._vehicle_route(vid) or ()
        except Exception:
            cache[vid] = (cur, None)
            return None
        if not route:
            cache[vid] = (cur, None)
            return None
        try:
            idx = route.index(cur)
        except (ValueError, AttributeError, TypeError):
            try:
                route = list(route)
                idx = route.index(cur)
            except (ValueError, TypeError):
                cache[vid] = (cur, None)
                return None
        nxt = str(route[idx + 1]) if (idx + 1) < len(route) else None
        cache[vid] = (cur, nxt)
        return nxt

    def _n_lanes_for(self, edge_id):
        """Lane count from net.xml caches only (never TraCI on get_state path)."""
        if not edge_id or str(edge_id).startswith(':'):
            return 1
        cache = getattr(self, '_edge_n_lanes', None)
        if cache is None:
            self._edge_n_lanes = {}
            cache = self._edge_n_lanes
        hit = cache.get(edge_id)
        if hit is not None:
            return int(hit)
        lens = (getattr(self, '_edge_lane_lengths', None) or {}).get(edge_id)
        if lens:
            n = len(lens)
            cache[edge_id] = n
            return n
        dests = (getattr(self, '_edge_lane_dests', None) or {}).get(edge_id)
        if dests:
            try:
                n = max(int(k) for k in dests) + 1
            except (TypeError, ValueError):
                n = len(dests)
            cache[edge_id] = max(int(n), 1)
            return cache[edge_id]
        # Unknown edge after net.xml load: do not call TraCI (hot-path safe).
        cache[edge_id] = 1
        return 1

    def _lane_to_edges_for(self, edge_id):
        """Serializable {lane_idx: [to_edge, ...]} for one approach edge (cached)."""
        ser = getattr(self, '_lane_to_edges_ser', None)
        if ser is None:
            self._lane_to_edges_ser = {}
            ser = self._lane_to_edges_ser
        cached = ser.get(edge_id)
        if cached is not None:
            return cached
        raw = (getattr(self, '_edge_lane_dests', None) or {}).get(edge_id) or {}
        out = {int(k): sorted(str(x) for x in v) for k, v in raw.items()}
        ser[edge_id] = out
        return out

    def _corridor_route_target_and_lane_map(self, vid, current_edge):
        """Resolve post-approach exit edge and multi-hop projected lane_to_edges.

        On multi-segment approaches (e.g. 4-leg where 850 m upstream edges feed
        29-36 m stop-line edges inside the 200 m keep-lane control zone, or 3-leg
        East), 1-hop ``_route_next_edge`` sees all upstream lanes connecting onto
        the short stop-line edge, hiding that lane 2 becomes a right-turn-only
        pocket 29 m before the stop line. Projecting lane-to-lane links across all
        consecutive edges of the same approach chain eliminates dead-end traps.
        """
        if not current_edge or str(current_edge).startswith(':'):
            return None, {}
        cur = str(current_edge)
        nxt_1hop = self._route_next_edge(vid, cur)
        ser_1hop = self._lane_to_edges_for(cur)
        l2l_all = getattr(self, '_edge_lane_to_lanes', None) or {}
        if not nxt_1hop or not l2l_all:
            return nxt_1hop, ser_1hop

        app_map = getattr(self, '_approach_cardinal', None) or {}
        cur_card = app_map.get(cur)
        try:
            route = list(self._vehicle_route(vid) or ())
            idx = route.index(cur)
        except Exception:
            return nxt_1hop, ser_1hop

        # Walk consecutive edges belonging to the same approach corridor before the junction.
        chain = [cur]
        pos = idx + 1
        while pos < len(route):
            cand = str(route[pos] or '')
            if not cand or cand.startswith(':'):
                break
            cand_card = app_map.get(cand)
            same_corridor = bool(cur_card and cand_card and cand_card == cur_card)
            if not same_corridor and not cur_card:
                # Fallback when scenario APPROACH_EDGES is absent: chain into a short (<80m)
                # stop-line pocket edge if every lane of prev edge continues straight onto cand.
                cand_lens = (getattr(self, '_edge_lane_lengths', None) or {}).get(cand) or []
                max_len = max(cand_lens) if cand_lens else 999.0
                prev_dests = (getattr(self, '_edge_lane_dests', None) or {}).get(chain[-1]) or {}
                only_cand = bool(prev_dests) and all(set(v) == {cand} for v in prev_dests.values() if v)
                same_corridor = bool(max_len <= 80.0 and only_cand and (pos + 1) < len(route))
            if not same_corridor:
                break
            chain.append(cand)
            pos += 1

        if len(chain) <= 1 or pos >= len(route):
            return nxt_1hop, ser_1hop

        exit_edge = str(route[pos] or '').strip() or nxt_1hop
        cache = getattr(self, '_corridor_proj_cache', None)
        if cache is None:
            self._corridor_proj_cache = {}
            cache = self._corridor_proj_cache
        chain_key = tuple(chain)
        proj_map = cache.get(chain_key)
        if proj_map is None:
            n_cur = self._n_lanes_for(cur)
            proj_map = {}
            for start_lane in range(n_cur):
                frontier = {(cur, int(start_lane))}
                valid_chain = True
                for hop_i in range(len(chain) - 1):
                    src_e = chain[hop_i]
                    dst_e = chain[hop_i + 1]
                    next_frontier = set()
                    src_l2l = l2l_all.get(src_e) or {}
                    for (_e, l_idx) in frontier:
                        for (to_e, to_l) in (src_l2l.get(int(l_idx)) or ()):
                            if str(to_e) == dst_e:
                                next_frontier.add((dst_e, int(to_l)))
                    if not next_frontier:
                        valid_chain = False
                        break
                    frontier = next_frontier
                if not valid_chain:
                    proj_map[int(start_lane)] = []
                else:
                    last_e = chain[-1]
                    last_dests = (getattr(self, '_edge_lane_dests', None) or {}).get(last_e) or {}
                    out_edges = set()
                    for (_e, l_idx) in frontier:
                        for out_e in (last_dests.get(int(l_idx)) or ()):
                            out_edges.add(str(out_e))
                    proj_map[int(start_lane)] = sorted(out_edges)
            cache[chain_key] = proj_map

        # Fail-safe: only apply projection if at least one lane reaches exit_edge.
        if any(exit_edge in dests for dests in proj_map.values()):
            return exit_edge, proj_map
        return nxt_1hop, ser_1hop

    def _lane_reaches_route(self, edge_id, lane_idx, next_edge, lane_map_override=None):
        if not next_edge:
            return True
        edge_map = (
            lane_map_override
            if lane_map_override is not None
            else (getattr(self, '_edge_lane_dests', None) or {}).get(edge_id)
        )
        if not edge_map:
            return True
        dests = edge_map.get(int(lane_idx), edge_map.get(str(lane_idx)))
        if dests is None:
            return False
        return str(next_edge) in dests

    def _mark_control_escape(self, vid):
        """One-shot flag: first illegal-lane escape in this control-zone visit."""
        issued = getattr(self, "_escape_penalty_issued", None)
        if issued is None:
            self._escape_penalty_issued = set()
            issued = self._escape_penalty_issued
        if vid in issued:
            return False
        issued.add(vid)
        trig = getattr(self, "_step_escape_triggered", None)
        if trig is None:
            self._step_escape_triggered = set()
            trig = self._step_escape_triggered
        trig.add(vid)
        return True

    def _maybe_retarget_deadlock(self, vid, edge_id, cur_lane_idx) -> bool:
        """changeTarget rescue. v4: OFF by default (OD must stay intact; train == eval)."""
        if not bool(getattr(self, "allow_deadlock_retarget", False)):
            return False
        try:
            dests = self._lane_to_edges_for(edge_id).get(int(cur_lane_idx), [])
            if not dests:
                return False
            traci.vehicle.changeTarget(vid, str(dests[0]))
            self._set_vehicle_route(vid, traci.vehicle.getRoute(vid))
            self._mark_control_escape(vid)
            self._od_rewrites = int(getattr(self, "_od_rewrites", 0)) + 1
            return True
        except Exception:
            return False

    def _force_cav_onto_route_lane(self, vid, edge_id, lane_id):
        """Stepwise escape: move one adjacent lane per call toward nearest legal lane.

        Critical inside the 200 m control zone where RL lateral is normally frozen:
        without this, keep-only + no escape leaves the car stuck on green.
        A single adjacent-lane TraCI request per step lets the maneuver complete
        instead of resetting a multi-lane timer every step.

        If the CAV is already within 55 m of the stop line and blocked (< 1.5 m/s)
        on a route-illegal lane, retarget it to a reachable downstream edge (like
        HDV rescue) so it never deadlocks for 300 s (jam teleport).
        Returns True if a force lane-change was requested.
        """
        if not edge_id or str(edge_id).startswith(':'):
            return False
        next_e, proj_map = self._corridor_route_target_and_lane_map(vid, edge_id)
        if not next_e:
            return False
        try:
            cur = int(str(lane_id).rsplit('_', 1)[-1])
        except (TypeError, ValueError):
            return False
        if self._lane_reaches_route(edge_id, cur, next_e, lane_map_override=proj_map):
            return False

        # Last-55m CAV deadlock rescue (training only; Eval forbids OD rewrite).
        v_data = (getattr(self, "sub_results", None) or {}).get(vid) or {}
        if v_data:
            dist = self._dist_to_stopline_from_vdata(v_data)
            speed = float(v_data.get(tc.VAR_SPEED, 0.0) or 0.0)
            wait_s = float(self._traci_valid_double(v_data.get(tc.VAR_ACCUMULATED_WAITING_TIME, 0.0), non_negative=True) or 0.0)
            rescue_horizon = 150.0 if wait_s >= 120.0 else 55.0
            if 0.0 <= dist <= rescue_horizon and speed < 1.5:
                if self._maybe_retarget_deadlock(vid, edge_id, cur):
                    return False

        n = int(self._n_lanes_for(edge_id))
        if n <= 0:
            return False
        legal = [
            i for i in range(n)
            if self._lane_reaches_route(edge_id, i, next_e, lane_map_override=proj_map)
        ]
        if not legal:
            # Topology trap: retarget only when allowed (never in Eval).
            self._maybe_retarget_deadlock(vid, edge_id, cur)
            return False
        best = min(legal, key=lambda i: abs(i - cur))
        if best == cur:
            return False
        step_lane = int(cur + (1 if best > cur else -1))
        try:
            traci.vehicle.changeLane(vid, step_lane, 3.0)
            return True
        except Exception:
            return False

    def _rescue_hdv_illegal_lane(self, vid, edge_id, lane_id, v_data):
        """Last-50 m HDV rescue: retarget to a reachable downstream edge.

        HDVs keep strategic LC 1621, but within ~50 m of the stop line SUMO can
        no longer change lanes. Retargeting gives the vehicle a valid connection
        so it clears the stop line on green instead of blocking the approach.
        """
        if not edge_id or str(edge_id).startswith(':'):
            return False
        next_e = self._route_next_edge(vid, edge_id)
        if not next_e:
            return False
        try:
            cur = int(str(lane_id).rsplit('_', 1)[-1])
        except (TypeError, ValueError):
            return False
        if self._lane_reaches_route(edge_id, cur, next_e):
            return False
        try:
            speed = float(v_data.get(tc.VAR_SPEED, 0.0) or 0.0)
        except Exception:
            speed = 0.0
        dist = self._dist_to_stopline_from_vdata(v_data)
        wait_s = float(self._traci_valid_double(v_data.get(tc.VAR_ACCUMULATED_WAITING_TIME, 0.0), non_negative=True) or 0.0)
        rescue_horizon = 150.0 if wait_s >= 120.0 else 60.0
        if not (0.0 <= dist <= rescue_horizon and speed < 2.0):
            return False
        try:
            dests = self._lane_to_edges_for(edge_id).get(int(cur), [])
            if not dests:
                try:
                    traci.vehicle.rerouteEffort(vid)
                except Exception:
                    return False
                self._clear_vehicle_route(vid)
                return True
            traci.vehicle.changeTarget(vid, str(dests[0]))
            self._set_vehicle_route(vid, traci.vehicle.getRoute(vid))
            return True
        except Exception:
            return False

    def _step_hdv_rescue(self, vid, edge_id, lane_id, v_data, in_control_zone):
        # v4: HDV destination rewriting is OFF by default (v3: always on, incl. eval).
        if not in_control_zone or not bool(getattr(self, "allow_hdv_retarget", False)):
            return False
        ok = bool(self._rescue_hdv_illegal_lane(vid, edge_id, lane_id, v_data))
        if ok:
            self._od_rewrites = int(getattr(self, "_od_rewrites", 0)) + 1
        return ok

    def _lane_lengths_for_edge(self, edge_id):
        """Return lane lengths (m) for an edge from net.xml caches only."""
        cached = getattr(self, "_edge_lane_lengths", None) or {}
        if edge_id in cached and cached[edge_id]:
            return list(cached[edge_id])
        lengths = []
        for lid, L in self.lane_lengths_cache.items():
            if lid.rsplit("_", 1)[0] == edge_id:
                lengths.append(float(L))
        if lengths and edge_id:
            self._edge_lane_lengths = getattr(self, "_edge_lane_lengths", {})
            self._edge_lane_lengths[edge_id] = list(lengths)
            n_cache = getattr(self, "_edge_n_lanes", None)
            if n_cache is None:
                self._edge_n_lanes = {}
                n_cache = self._edge_n_lanes
            n_cache[edge_id] = len(lengths)
        return lengths

    def _update_signal_pressure_capacity(self):
        """
        MAPPO / no_vlm signal reward normalizer:
          c = sum_{e in E_in} sum_{lane in e} min(L_lane, L_zone) / 7
        Falls back to legacy max-edge capacity if no incoming edges yet.
        """
        vehicle_space = 4.5 + 2.5  # 7.0 m
        L_zone = float(getattr(self, "CONTROL_ZONE_DISTANCE", 300.0) or 300.0)
        incoming = list(getattr(self, "incoming_edges", None) or [])
        total = 0.0
        for eid in incoming:
            for L in self._lane_lengths_for_edge(eid):
                total += min(float(L), L_zone) / vehicle_space
        if total > 1e-6:
            self.max_road_capacity = float(total)
        else:
            # Keep init fallback (max-edge) until topology is known.
            self.max_road_capacity = float(
                getattr(self, "max_road_capacity", 160.0) or 160.0
            )
        return float(self.max_road_capacity)

    def _close_traci(self):
        """Close this env's TraCI/libsumo connection (label-aware for TraCI)."""
        if not _USING_LIBSUMO:
            label = getattr(self, "_traci_label", "default")
            try:
                traci.switch(label)
            except Exception:
                pass
        try:
            if traci.isLoaded():
                traci.close()
        except Exception:
            pass

    def reset(self, seed=None):
        self._close_traci()

        if seed is None:
            self._run_seed = int(getattr(self, "_run_seed", 0)) + 1
            seed = self._run_seed
        else:
            self._run_seed = int(seed)

        cmd = list(self.sumo_cmd) + ["--seed", str(int(seed))]
        _rt_opts = self._runtime_sumo_options(int(seed))
        for _j in range(0, len(_rt_opts) - 1, 2):  # runtime options override base ones
            while _rt_opts[_j] in cmd:
                _i = cmd.index(_rt_opts[_j])
                del cmd[_i:_i + 2]
        cmd += _rt_opts
        if _USING_LIBSUMO and not bool(self.use_gui):
            print(f"[SUMO] starting libsumo in-process (seed={seed})", flush=True)
            # Official libsumo API keeps the binary name; no port/label.
            traci.start(cmd)
        else:
            print(
                f"[SUMO] starting TraCI on port={self.sumo_port} "
                f"label={self._traci_label}",
                flush=True,
            )
            traci.start(cmd, port=int(self.sumo_port), label=self._traci_label)
        self.controlled_cavs.clear()
        self._speed_capped = {}
        self._sig_junction_ids = None
        self._lon_noop_vids_step = []
        self._jstall_reset()
        self.phase_started_at.clear()
        self.last_signal_phase.clear()
        self.signal_programs.clear()
        self.platoon_tracker.reset()
        self._platoon_info = {}
        self._leader_vids = set()
        self._sticky_leader_vids = set()
        self._lc_cooldown_until = {}
        self._phase_incoming_lanes.clear()
        self._last_green_T.clear()
        self._last_green_lv.clear()
        self._last_green_index.clear()
        self._collision_episodes = 0
        self.vehicle_types.clear()
        # Keep static topology from net.xml across resets (n_lanes / lane_to_edges /
        # lane lengths). Only drop dynamic per-vehicle caches.
        if not getattr(self, "_static_topology_ready", False):
            self.max_road_capacity = self._calculate_max_road_capacity()
        self.vehicle_lane_mode_cache.clear()
        self.vehicle_route_fixed.clear()
        self.vehicle_routes.clear()
        self._invalidate_route_next()
        self.vtype_dynamics_cache.clear()
        self.sub_results.clear()
        self._zone_subscribed.clear()
        self._zone_detail.clear()
        self._zone_enter_time.clear()
        self._vehicle_length_cache.clear()
        self._follower_sub_ok = None
        self._escape_penalty_issued = set()
        self._step_escape_triggered = set()
        self._escape_hold = set()
        self._signals.clear()
        self._last_collisions = 0
        self._last_teleports = 0
        self.tls_ids = []
        self.incoming_edges = []
        self.outgoing_edges = []
        # Always try scenario.py / dublin_scenario.py next to sumocfg.
        self._load_scenario_config()
        self._activate_tls_program()
        if self._dublin_mode:
            print(
                f"[SUMO] Dublin-style mode: control_zone={self.CONTROL_ZONE_DISTANCE}m, "
                f"platoon_zone={float(getattr(self, 'PLATOON_ZONE_DISTANCE', self.CONTROL_ZONE_DISTANCE)):.0f}m, "
                f"approach_edges={len(self._approach_cardinal)}, "
                f"min_green={self.MIN_GREEN_DURATION}s, "
                f"max_green_by_phase={self.MAX_GREEN_BY_PHASE}"
            )

        # Warmup: fixed-timing / default SUMO only. KPIs reset after this so
        # rewards, RL updates, and eval metrics cover the controlled horizon only.
        # CLI: --warmup-seconds / --quick (see baselines.episode_timing).
        warmup_seconds = max(0.0, float(getattr(self, "warmup_seconds", 300.0) or 0.0))
        warmup_steps = int(round(warmup_seconds / max(float(self.step_length), 1e-6)))
        print(
            f"[SUMO] warmup {warmup_seconds:.0f}s ({warmup_steps} steps @ "
            f"{self.step_length}s); not counted in rewards/metrics (seed={seed})..."
        )
        self._warmup_arrived = set()
        for i in range(warmup_steps):
            traci.simulationStep()
            for vid in traci.simulation.getDepartedIDList():
                self._subscribe_vehicle(vid, in_zone=False)
            try:
                self._warmup_arrived.update(
                    str(v) for v in traci.simulation.getArrivedIDList()
                )
            except Exception:
                pass
            done = i + 1
            if done % 500 == 0 or done == warmup_steps:
                print(f"   ... warmup {done}/{warmup_steps}")

        print("[SUMO] warmup done; handing control to agent.")
        now_handover = float(traci.simulation.getTime())
        self._green_last_served = {}
        self._cycle_served = {}
        for tls_id in self._resolve_controlled_tls_ids():
            n_g = len(self._green_phase_indices(tls_id))
            self._green_last_served[tls_id] = {i: now_handover for i in range(n_g)}
            self._cycle_served[tls_id] = set()

        self.sub_results = traci.vehicle.getAllSubscriptionResults()
        self._sync_zone_subscriptions()
        # Re-fetch after upgrade so zone vars are present for the first get_state
        if self._zone_subscribed:
            self.sub_results = traci.vehicle.getAllSubscriptionResults()

        self.tls_ids = self._resolve_controlled_tls_ids()
        self._refresh_signal_topology()
        now = traci.simulation.getTime()
        for tls_id in self.tls_ids:
            phase = traci.trafficlight.getPhase(tls_id)
            remaining = max(0.0, traci.trafficlight.getNextSwitch(tls_id) - now)
            duration = traci.trafficlight.getPhaseDuration(tls_id)
            self.last_signal_phase[tls_id] = phase
            self.phase_started_at[tls_id] = now - max(0.0, duration - remaining)
            self.signal_programs[tls_id] = self._logic_phases_from_traci(tls_id)

        self._reset_episode_kpis()
        try:
            self._v7_events_reset(seed)
        except Exception as exc:
            print(f"[Events] reset disabled: {exc}", flush=True)
            self._v7_evt = None
        return self.get_state()

    # ------------------------------------------------------------------
    # VECTOR v7.1: visual-only events + perception sources
    # (environment/event_injector.py, VLM/event_perception.py)
    # ------------------------------------------------------------------
    V7_EVENT_KPI_KEYS = (
        "v7_evt_scheduled", "v7_evt_started", "v7_evt_failed", "v7_evt_active_frac",
        "v7_evt_halted_in", "v7_evt_halted_out",
        "v7_evt_perc_precision", "v7_evt_perc_recall",
        "v7_evt_detect_latency_s", "v7_evt_detected_frac", "v7_evt_perc_fp_rate",
        "v7_evt_converted", "v7_evt_inserted",
    )

    def _v7_perception_mode(self) -> str:
        m = str(os.environ.get("V7_EVENT_PERCEPTION", "off") or "off").strip().lower()
        return m if m in ("off", "oracle", "numeric", "vlm") else "off"

    def _v7_events_reset(self, seed):
        self._v7_evt = None
        self._v7_vlm_counts = {}
        self._v7_cap_factor = []
        self._v7_evt_detector = None
        self._v7_evt_score = None
        self._v7_evt_acc = {"in_n": 0.0, "in_sum": 0.0, "out_n": 0.0, "out_sum": 0.0}
        self._v7_evt_last_sample = -1e9
        self._v7_tls_lane_links = {}
        self._v7_evt_excluded = set()
        self._v7_evt_t0 = float(traci.simulation.getTime())
        events_on = self._env_on("V7_EVENTS")
        if not events_on and self._v7_perception_mode() == "off":
            return
        from environment import event_injector as _ei

        self._v7_evt_detector = _ei.LaneStallDetector()
        self._v7_evt_score = _ei.PerceptionScore()
        if not events_on:
            return
        apps = {}
        for k, v in (getattr(self, "scenario_approach_edges", None) or {}).items():
            e = v[0] if isinstance(v, (list, tuple)) and v else v
            if e:
                apps[str(k)] = str(e)
        try:
            horizon = float(os.environ.get("V7_EVENT_HORIZON_S", "900") or 900.0)
            rate = float(os.environ.get("V7_EVENT_RATE", "2.0") or 2.0)
        except (TypeError, ValueError):
            horizon, rate = 900.0, 2.0
        kinds = tuple(
            x.strip() for x in str(os.environ.get("V7_EVENT_KINDS", "breakdown,roadwork")).split(",")
            if x.strip()
        )
        try:
            count = int(float(os.environ.get("V7_EVENT_COUNT", "0") or 0))
        except (TypeError, ValueError):
            count = 0
        events = _ei.make_schedule(
            int(seed) + 7000003, self._v7_evt_t0, self._v7_evt_t0 + horizon, apps,
            rate=rate, kinds=kinds, count=count,
        )
        self._v7_evt = _ei.EventInjector(
            _ei.TraciEventAdapter(traci), events, seed=int(seed),
            allow_insert=not self._env_on("V7_EVENT_CONVERT_ONLY"),
            on_convert=self._v7_exclude_vehicle,
        )
        print(
            f"[Events] seed={seed} scheduled={len(events)} "
            + ", ".join(
                f"{e.kind}@{e.approach}:+{e.onset_s - self._v7_evt_t0:.0f}s/{e.duration_s:.0f}s"
                for e in events
            ),
            flush=True,
        )

    def _v7_exclude_vehicle(self, vid) -> None:
        """A converted (broken-down) HDV stays observable but leaves travel KPIs:
        its trip is disrupted by the event, not by the controller."""
        vid = str(vid)
        excl = getattr(self, "_v7_evt_excluded", None)
        if excl is None:
            excl = self._v7_evt_excluded = set()
        excl.add(vid)
        s = (getattr(self, "_tis_s", None) or {}).pop(vid, None)
        if s is not None:
            self._tis_unf_n -= 1
            self._tis_unf_sum -= s

    def set_v7_vlm_blockage(self, counts) -> None:
        """VLM perception result (approach -> blocked lane count), set by marl_env."""
        self._v7_vlm_counts = dict(counts or {})

    def _v7_lane_links(self, tls_id):
        cache = getattr(self, "_v7_tls_lane_links", None)
        if cache is None:
            cache = self._v7_tls_lane_links = {}
        if tls_id not in cache:
            m = {}
            for idx, group in enumerate(traci.trafficlight.getControlledLinks(tls_id) or []):
                for link in group or []:
                    if link:
                        m.setdefault(str(link[0]), []).append(int(idx))
            cache[tls_id] = m
        return cache[tls_id]

    def _v7_events_state(self, state, tls_id_0, n_g0):
        """Publish capacity factors (active perception source), render-only
        event objects and event/perception KPIs into ``state``."""
        det = getattr(self, "_v7_evt_detector", None)
        evt = getattr(self, "_v7_evt", None)
        if det is None and evt is None:
            return
        from environment import event_injector as _ei

        now = float(traci.simulation.getTime())
        lane_map = (getattr(self, "_phase_incoming_lanes", {}) or {}).get(tls_id_0, {}) or {}
        all_lanes = sorted({str(l) for g in range(int(n_g0)) for l in (lane_map.get(g) or [])})
        sampled = now - float(getattr(self, "_v7_evt_last_sample", -1e9)) >= 1.0 - 1e-6
        if det is not None and sampled and all_lanes:
            sig = traci.trafficlight.getRedYellowGreenState(tls_id_0)
            links = self._v7_lane_links(tls_id_0)
            obs = {}
            for l in all_lanes:
                idxs = links.get(l, [])
                green = any(0 <= i < len(sig) and sig[i] in "Gg" for i in idxs)
                obs[l] = (
                    bool(green),
                    int(traci.lane.getLastStepHaltingNumber(l)),
                    frozenset(traci.lane.getLastStepVehicleIDs(l) or ()),
                )
            det.update(now, obs)
        stalled = det.stalled() if det is not None else set()
        apps_lanes = {}
        for card, v in (getattr(self, "scenario_approach_edges", None) or {}).items():
            e = v[0] if isinstance(v, (list, tuple)) and v else v
            apps_lanes[str(card)] = [l for l in all_lanes if l.rsplit("_", 1)[0] == str(e)]
        lane_app = {l: c for c, ls in apps_lanes.items() for l in ls}
        mode = self._v7_perception_mode()
        if mode == "oracle" and evt is not None:
            probs = _ei.lane_probs_from_lanes(evt.blocked_lanes())
            pred = set(evt.truth_approaches())
        elif mode == "numeric":
            probs = _ei.lane_probs_from_lanes(stalled)
            pred = {lane_app[l] for l in stalled if l in lane_app}
        elif mode == "vlm":
            counts = dict(getattr(self, "_v7_vlm_counts", {}) or {})
            probs = _ei.lane_probs_from_approach_counts(counts, apps_lanes)
            pred = {a for a, k in counts.items() if float(k) > 0}
        else:
            probs, pred = {}, set()
        cap = _ei.phase_capacity_factors(lane_map, int(n_g0), probs)
        self._v7_cap_factor = cap
        st = state['stats']
        st['phase_capacity_factor'] = list(cap)
        st['v7_numeric_stall_any'] = 1.0 if stalled else 0.0
        # v7.5: edge-trigger input for the VLM scheduler + ground truth used ONLY
        # to score VLM answers (stripped from the snapshot the VLM sees).
        st['v7_numeric_stall_apps'] = sorted({lane_app[l] for l in stalled if l in lane_app})
        st['v7_evt_truth_apps'] = sorted(evt.truth_approaches()) if evt is not None else []
        if evt is None and self._v7_evt_score is not None and mode != "off":
            # no-event runs: every predicted blockage is a false positive
            if sampled:
                self._v7_evt_score.update(now, [], pred, all_approaches=list(apps_lanes.keys()))
            st.update(self._v7_evt_score.summary())
        if evt is not None:
            state['events_visual'] = evt.visual_list()
            active = evt.active()
            if sampled:
                if self._v7_evt_score is not None:
                    self._v7_evt_score.update(now, active, pred, all_approaches=list(apps_lanes.keys()))
                halted = 0
                for v_data in (self.sub_results or {}).values():
                    spd = self._traci_valid_double(v_data.get(tc.VAR_SPEED, 0.0))
                    if spd is not None and spd < 0.1:
                        halted += 1
                acc = self._v7_evt_acc
                key = "in" if active else "out"
                acc[key + "_n"] += 1.0
                acc[key + "_sum"] += float(halted)
            acc = self._v7_evt_acc
            elapsed = max(now - float(getattr(self, "_v7_evt_t0", now)), 1e-6)
            st['v7_evt_scheduled'] = float(evt.stats["scheduled"])
            st['v7_evt_started'] = float(evt.stats["started"])
            st['v7_evt_failed'] = float(evt.stats["failed"])
            st['v7_evt_converted'] = float(evt.stats.get("converted", 0.0))
            st['v7_evt_inserted'] = float(evt.stats.get("inserted", 0.0))
            st['v7_evt_active_frac'] = float(evt.stats["active_s"]) / elapsed
            st['v7_evt_halted_in'] = acc["in_sum"] / acc["in_n"] if acc["in_n"] else 0.0
            st['v7_evt_halted_out'] = acc["out_sum"] / acc["out_n"] if acc["out_n"] else 0.0
            if self._v7_evt_score is not None:
                st.update(self._v7_evt_score.summary())
        if sampled:
            self._v7_evt_last_sample = now

    def step(self, cav_actions=None, signal_actions=None, cav_lat_actions=None):
        """Apply CAV longitudinal (accel), optional lateral {-1,0,1}, and TLS actions."""
        current_controlled_cavs = set()
        applied_cav_actions = {}
        applied_abs_accels = {}
        shield_clip_deltas = {}
        safety_interventions = 0
        cav_lat_actions = cav_lat_actions or {}
        self._step_escape_triggered = set()
        # v5.2.4: CAVs whose sampled Lon action is not executed this step.
        self._lon_noop_vids_step = []

        all_vehicles = list(self.sub_results.keys())
        if self._speed_capped:
            _alive = set(all_vehicles)
            for _gone in [v for v in self._speed_capped if v not in _alive]:
                self._speed_capped.pop(_gone, None)
        for vid in all_vehicles:
            v_data = self.sub_results[vid]
            edge_id = v_data[tc.VAR_ROAD_ID]
            is_in_junction = edge_id.startswith(':')
            in_control_zone = self._in_control_zone(v_data)
            in_platoon_zone = self._in_platoon_zone(v_data)
            vtype = self._vehicle_type(vid, v_data)
            is_cav = 'CAV' in vtype

            # Pre-compute routing legality once per vehicle per step so the
            # LC-mode decision and the escape logic cannot disagree.
            _edge_now = edge_id if not is_in_junction else ""
            _lane_now = str(v_data.get(tc.VAR_LANE_ID, '') or '')
            try:
                _cur_lane_idx = int(_lane_now.rsplit('_', 1)[-1])
            except (TypeError, ValueError):
                _cur_lane_idx = 0
            if _edge_now:
                _next_edge, _proj_lane_map = self._corridor_route_target_and_lane_map(vid, _edge_now)
            else:
                _next_edge, _proj_lane_map = None, None
            _on_illegal = bool(
                _edge_now
                and _next_edge
                and not self._lane_reaches_route(
                    _edge_now, _cur_lane_idx, _next_edge, lane_map_override=_proj_lane_map
                )
            )
            _dof_now = "RULE_MLC" if _on_illegal else "" 
            _escape_hold = getattr(self, "_escape_hold", None)
            if _escape_hold is None:
                self._escape_hold = set()
                _escape_hold = self._escape_hold

            # Universal 0..200 m keep-lane for ALL types; Lat RL owns CAV LC
            # in 200..Lp (leaders + followers). Escape stays on FREE (1621).
            is_leader = bool(vid in (getattr(self, "_leader_vids", None) or set()))
            _v7_blocked = False
            if getattr(self, "_v7_evt", None) is not None and not is_in_junction:
                try:
                    _v7_blocked = self._v7_evt.lane_blocked_ahead(
                        _lane_now, float(v_data.get(tc.VAR_LANEPOSITION, 0.0) or 0.0), vid=vid
                    )
                except Exception:
                    _v7_blocked = False
            _needs_escape = bool(
                (in_platoon_zone and _on_illegal and not is_in_junction) or _v7_blocked
            )
            if _needs_escape:
                _escape_hold.add(vid)
            elif vid in _escape_hold and (
                is_in_junction or not _on_illegal or not in_platoon_zone
            ):
                _escape_hold.discard(vid)
            _lc_mode = desired_lc_mode(
                in_control_zone=in_control_zone,
                in_platoon_zone=in_platoon_zone,
                is_in_junction=is_in_junction,
                is_cav=is_cav,
                is_leader=is_leader,
                lateral_rl_owns=bool(getattr(self, "LATERAL_RL_OWNS_LC", False)),
                needs_escape=bool(vid in _escape_hold),
                control_keep_lane=bool(
                    getattr(self, "CONTROL_ZONE_KEEP_LANE", True)
                ),
                control_keep_lane_hdv=bool(
                    getattr(self, "CONTROL_ZONE_KEEP_LANE_HDV", False)
                ),
                dof_mode=_dof_now,
            )
            if self.vehicle_lane_mode_cache.get(vid) != _lc_mode:
                traci.vehicle.setLaneChangeMode(vid, _lc_mode)
                self.vehicle_lane_mode_cache[vid] = _lc_mode

            # Cross-net silent changeTarget-by-lane removed: OD matrix must stay intact.

            if not is_cav:
                # HDV last-60 m rescue: retarget gives a valid connection when
                # strategic LC can no longer complete before the stop line.
                # Plus TraCI stepwise escape in 0..200 when on an illegal lane
                # (escape_hold / LC 1621 already covers all types; force LC
                # closes the gap where keep-lane would otherwise stick HDVs).
                if in_control_zone and not is_in_junction:
                    _hdv_lane = str(v_data.get(tc.VAR_LANE_ID, '') or '')
                    try:
                        self._step_hdv_rescue(
                            vid, str(edge_id), _hdv_lane, v_data, True
                        )
                    except Exception:
                        pass
                    if vid in _escape_hold:
                        try:
                            if self._force_cav_onto_route_lane(
                                vid, edge_id, _hdv_lane
                            ):
                                self._mark_control_escape(vid)
                        except Exception:
                            pass

            if is_cav:
                lane_id = v_data.get(tc.VAR_LANE_ID, '')
                forced = False
                # Force TraCI escape only inside the 0..200 m control band.
                # Outside, followers keep FREE/strategic LC; leaders use Lat RL.
                if in_control_zone and not is_in_junction:
                    forced = self._force_cav_onto_route_lane(vid, edge_id, lane_id)
                    if forced:
                        self._mark_control_escape(vid)

                # Lateral RL: any CAV with a lat action (formation band or
                # control-zone escape). Lon stays leaders-only via _cav_action_applies.
                # Skip if force already requested LC.
                if (
                    bool(self.CAV_RL_ENABLED)
                    and in_platoon_zone
                    and not is_in_junction
                    and not forced
                    and vid in cav_lat_actions
                ):
                    try:
                        cur_lane = int(str(lane_id).rsplit('_', 1)[-1])
                    except Exception:
                        cur_lane = 0
                    next_e, proj_map = (
                        (_next_edge, _proj_lane_map)
                        if edge_id == _edge_now
                        else self._corridor_route_target_and_lane_map(vid, edge_id)
                    )
                    on_illegal = not self._lane_reaches_route(
                        edge_id, cur_lane, next_e, lane_map_override=proj_map
                    )
                    allow_lat = (not in_control_zone) or on_illegal
                    if allow_lat:
                        try:
                            lat = int(cav_lat_actions[vid])
                        except (TypeError, ValueError):
                            lat = 0
                        lat = int(np.clip(lat, -1, 1))
                        # Discretionary DLC keep-lock after a recent LC request.
                        # Escape from an illegal lane must never be frozen.
                        now_t = float(getattr(self, "_sim_time", 0.0) or 0.0)
                        cool_until = float(
                            (getattr(self, "_lc_cooldown_until", {}) or {}).get(vid, 0.0)
                            or 0.0
                        )
                        if (
                            lat != 0
                            and (not on_illegal)
                            and now_t < cool_until
                        ):
                            lat = 0
                        if lat != 0:
                            # Driver-relative: RHT left→+index; LHT left→-index.
                            try:
                                d_idx = int(driver_lane_offset(lat, {
                                    "lefthand": bool(getattr(self, "lefthand", False))
                                }))
                            except Exception:
                                d_idx = (1 if lat < 0 else -1) * (
                                    -1 if getattr(self, "lefthand", False) else 1
                                )
                            tgt_lane = cur_lane + d_idx
                            tgt_ok = self._lane_reaches_route(
                                edge_id, tgt_lane, next_e, lane_map_override=proj_map
                            )
                            # Fail-open: still request physical LC when trapped
                            # anywhere in the platoon band (escape hold uses 1621).
                            if tgt_ok or (on_illegal and in_platoon_zone):
                                try:
                                    # changeLaneRelative offset is pure lane-index delta.
                                    traci.vehicle.changeLaneRelative(vid, int(d_idx), 3.0)
                                    if in_control_zone and on_illegal:
                                        self._mark_control_escape(vid)
                                    elif not on_illegal:
                                        # Arm keep-lock only for discretionary DLC.
                                        cd = float(lc_cooldown_seconds())
                                        if cd > 1e-9:
                                            if not hasattr(self, "_lc_cooldown_until"):
                                                self._lc_cooldown_until = {}
                                            self._lc_cooldown_until[vid] = (
                                                now_t + cd
                                            )
                                except Exception:
                                    pass

                _cid = None
                try:
                    _cid = self.platoon_tracker.cluster_of.get(vid)
                except Exception:
                    _cid = None
                _d_stop_now = self._dist_to_stopline_from_vdata(v_data)
                apply_rl = self._cav_action_applies(
                    vid,
                    cav_actions,
                    is_leader,
                    in_control_zone,
                    is_in_junction,
                    in_platoon_zone=in_platoon_zone,
                    dist_to_stopline=_d_stop_now,
                    cluster_id=_cid,
                )
                if apply_rl and bool(getattr(self, "ABLATE_CAV_NATIVE_IDM", False)):
                    # v5.2.1 A0: hand the CAV back to SUMO's own IDM. v5.2.4: the
                    # sample is reported as a no-op so PPO does not credit it.
                    self._note_handback(
                        vid, "native_idm", applied_cav_actions, shield_clip_deltas
                    )
                    continue
                if apply_rl:
                    # v5.2.4 bisection: near-stop-line / junction-box handback.
                    _hb = self._lon_handback_reason(is_in_junction, _d_stop_now)
                    if _hb:
                        self._note_handback(
                            vid, _hb, applied_cav_actions, shield_clip_deltas
                        )
                        continue
                if apply_rl:
                    raw_accel = np.asarray(cav_actions[vid], dtype=np.float32).reshape(-1)
                    raw_val = float(raw_accel[0]) if raw_accel.size else 0.0
                    max_accel, max_decel = self._vtype_limits(vtype)
                    use_res_idm = bool(getattr(self, "LON_RESIDUAL_IDM", True))
                    res_bound = float(getattr(self, "LON_RESIDUAL_BOUND", 2.2) or 2.2)
                    res_low = float(getattr(self, "LON_RESIDUAL_LOW", -res_bound))
                    res_high = float(getattr(self, "LON_RESIDUAL_HIGH", 1.0))

                    # v6-P0 perf: speed mode 31 is SUMO's default and is restored on
                    # every release, so re-sending it each step was a pure TraCI no-op.
                    if vid not in self.controlled_cavs:
                        traci.vehicle.setSpeedMode(vid, 31)

                    current_speed = float(v_data[tc.VAR_SPEED])
                    detail = self._zone_detail.get(vid)
                    if detail is not None:
                        speed_without_traci = detail['speed_without_traci']
                        leader_id = detail.get('leader_id')
                        leader_gap = detail['leader_gap']
                        leader_speed_d = float(detail.get('leader_speed', current_speed))
                        has_leader = leader_id is not None
                        follower_gap = float(detail.get('follower_gap', 100.0) or 100.0)
                        has_follower = detail.get('follower_id') is not None
                        next_link_open = detail['next_link_open']
                        has_foe = bool(detail.get('has_foe', False))
                        red_light_ahead = detail['red_light_ahead']
                        tls_distance = detail['tls_distance']
                        tls_state_now = str(detail.get('tls_state', 'n') or 'n').lower()
                        ttg_now = float(detail.get('time_to_green', -1.0))
                    else:
                        speed_without_traci = self._parse_speed_without_traci(vid, v_data, current_speed)
                        leader_id, leader_gap, leader_speed_d, _ = self._parse_leader(vid, v_data, current_speed)
                        has_leader = leader_id is not None
                        follower_id, follower_gap = self._parse_follower(vid, v_data)
                        has_follower = follower_id is not None
                        next_link_open, has_foe = self._parse_next_links(vid, v_data)
                        _ntls, _nlink, tls_distance, tls_state = self._parse_next_tls(vid, v_data)
                        tls_state_now = str(tls_state or 'n').lower()
                        ttg_now = float(
                            self._time_to_green(
                                _ntls,
                                _nlink,
                                tls_state_now,
                                (getattr(self, '_signals', None) or {}).get(_ntls),
                            )
                        )
                        red_light_ahead = (
                            tls_distance >= 0.0
                            and tls_distance < 220.0
                            and tls_state_now in ('r', 'y')
                        )

                    if (
                        apply_rl
                        and bool(getattr(self, "IDM_FOLLOWER_ENABLED", False))
                        and tls_state_now in ("r", "y")
                        and has_leader
                        and float(leader_gap) < float(self.IDM_FOLLOWER_MAX_GAP_M)
                        and float(current_speed) < float(self.IDM_FOLLOWER_MAX_SPEED_MS)
                        and float(leader_speed_d) < float(self.IDM_FOLLOWER_MAX_SPEED_MS)
                    ):
                        self._note_handback(
                            vid, "idm_follower", applied_cav_actions, shield_clip_deltas
                        )
                        continue

                    dt = max(float(self.step_length), 1e-3)
                    current_accel = float(v_data.get(tc.VAR_ACCELERATION, 0.0) or 0.0)
                    a_idm = current_accel + (float(speed_without_traci) - current_speed) / dt
                    a_idm = float(np.clip(a_idm, -max_decel, max_accel))
                    if not hasattr(self, "_last_a_idm") or self._last_a_idm is None:
                        self._last_a_idm = {}
                    self._last_a_idm[vid] = float(a_idm)

                    beta = float(getattr(self, "LON_IDM_MIX_BETA", 1.0) or 1.0)
                    beta = float(np.clip(beta, 0.0, 1.0))
                    if use_res_idm:
                        delta_pi = float(np.clip(raw_val, res_low, res_high))
                        if bool(getattr(self, "ABLATE_ZERO_LON_RESIDUAL", False)):
                            # v4 ablation: rule stack only (IDM + CACC + envelopes +
                            # shield). Answers "does the Lon RL residual add value?".
                            delta_pi = 0.0
                        accel_rl_mixed = float(np.clip(a_idm + beta * delta_pi, -max_decel, max_accel))
                    else:
                        a_pi = float(np.clip(raw_val, -max_decel, max_accel))
                        if beta < 1.0 - 1e-9:
                            accel_rl_mixed = float(np.clip((1.0 - beta) * a_idm + beta * a_pi, -max_decel, max_accel))
                        else:
                            accel_rl_mixed = a_pi
                    if str(getattr(self, "LON_ACTION_MODE", "residual")) == "target_speed":
                        # v6-P1: the actor names a target speed. CACC/ACC and the
                        # RSS shield below still execute it.
                        from environment.p1_control import accel_for_target_speed

                        _vlim = float(
                            (getattr(self, "lane_speeds_cache", None) or {}).get(
                                _lane_now, getattr(self, "MAX_SPEED", 16.67)
                            )
                            or getattr(self, "MAX_SPEED", 16.67)
                        )
                        accel_rl_mixed = accel_for_target_speed(
                            raw_val,
                            current_speed,
                            _vlim,
                            res_low,
                            res_high,
                            max_accel,
                            -max_decel,
                        )

                    # Closed-loop CACC car-following blend:
                    #   - Preserves RL authority floor (default 0.25) even inside 8 m.
                    #   - Uses smooth saturating tanh on positive gap error (no max_accel surge).
                    #   - Caps positive catch-up acceleration by a_idm (+ bounded V2V feedforward).
                    from environment.cav_state_builder import compute_lon_rl_authority

                    cacc_on = bool(getattr(self, "CACC_SOFT_PLATOON_ENABLED", True))
                    cacc_full = float(getattr(self, "CACC_FULL_GAP_M", 8.0))
                    cacc_free = float(getattr(self, "CACC_FREE_GAP_M", 22.0))
                    cacc_floor = float(getattr(self, "CACC_RL_AUTHORITY_FLOOR", 0.25))
                    alpha_rl = compute_lon_rl_authority(
                        leader_gap,
                        has_leader=bool(has_leader),
                        enabled=cacc_on,
                        full_gap_m=cacc_full,
                        free_gap_m=cacc_free,
                        min_authority=cacc_floor,
                    )
                    if alpha_rl < 1.0 - 1e-6 and has_leader:
                        lead_data = self.sub_results.get(leader_id, {}) if leader_id else {}
                        lead_vtype = str(lead_data.get(tc.VAR_TYPE, "") or "")
                        lead_acc_raw = self._traci_valid_double(lead_data.get(tc.VAR_ACCELERATION, 0.0))
                        lead_acc = 0.0 if lead_acc_raw is None else float(lead_acc_raw)
                        if leader_id in applied_abs_accels:
                            lead_acc = float(applied_abs_accels[leader_id])
                        _lead_is_cav = bool(
                            "CAV" in lead_vtype or leader_id in applied_abs_accels
                        )
                        # v6-P0: CACC target from gap_policy (legacy = 0.65 + 0.60 v
                        # for every leader; unified = 0.6 s behind CAV, 1.2 s behind HDV).
                        g_star = _gap_policy.cacc_target_gap(current_speed, _lead_is_cav)
                        e_g = float(leader_gap) - g_star
                        e_v = float(leader_speed_d) - float(current_speed)
                        k_ff = float(getattr(self, "CACC_LEADER_ACCEL_GAIN", 0.35))
                        if _lead_is_cav:
                            if lead_acc > 0.0:
                                pos_gate = float(np.clip((e_g + 0.50) / 1.50, 0.0, 1.0))
                                a_ff = k_ff * pos_gate * lead_acc
                            else:
                                a_ff = k_ff * lead_acc
                        else:
                            a_ff = 0.0
                        if e_g < 0.0:
                            a_gap = 0.40 * e_g
                        else:
                            a_gap = 0.85 * math.tanh(0.15 * e_g)
                        a_cacc_raw = float(
                            np.clip(a_gap + 0.55 * e_v + a_ff, -max_decel, max_accel)
                        )
                        if e_g < 0.0 or e_v < -0.20 or red_light_ahead:
                            a_cacc = min(a_cacc_raw, float(a_idm))
                        else:
                            # On green with positive gap error: bound by SUMO IDM + gentle V2V
                            # feedforward so CACC never slams max_accel at medium gaps!
                            idm_cap = float(a_idm) + min(0.30, max(0.0, float(a_ff)))
                            a_cacc = min(a_cacc_raw, idm_cap, 1.50)
                        accel = float(
                            np.clip(
                                alpha_rl * accel_rl_mixed + (1.0 - alpha_rl) * a_cacc,
                                -max_decel,
                                max_accel,
                            )
                        )
                    else:
                        accel = accel_rl_mixed
                    requested_accel = accel

                    v_des = float(
                        (getattr(self, "lane_speeds_cache", None) or {}).get(
                            _lane_now, getattr(self, "MAX_SPEED", 16.67)
                        )
                        or getattr(self, "MAX_SPEED", 16.67)
                        or 16.67
                    )

                    # 1. Continuous Lyapunov Glide & Smooth GLOSA Envelope:
                    #    v5.2.2 keeps stop-line smoothing for head-of-queue / clear
                    #    approach and skips slow followers so gaps remain compact.
                    _head_only_skip = False
                    if (
                        bool(getattr(self, "RED_GLIDE_ENVELOPE_ENABLED", True))
                        and bool(getattr(self, "RED_GLIDE_HEAD_ONLY", True))
                        and has_leader
                        and not is_in_junction
                    ):
                        _leader_past_line = (
                            np.isfinite(tls_distance)
                            and float(leader_gap) >= float(tls_distance) - 0.5
                        )
                        _clear_follower = (
                            float(leader_gap) > float(self.RED_GLIDE_FOLLOWER_LEADER_MIN_M)
                            and float(leader_speed_d) >= float(self.GLOSA_MIN_SPEED_MS)
                        )
                        _head_only_skip = not (_leader_past_line or _clear_follower)
                    if (
                        bool(getattr(self, "RED_GLIDE_ENVELOPE_ENABLED", True))
                        and not is_in_junction
                        and not _head_only_skip
                    ):
                        _glosa_active = False
                        _clear_to_line = (not has_leader) or (
                            np.isfinite(tls_distance) and float(leader_gap) > float(tls_distance)
                        ) or (
                            float(leader_gap) > 30.0 and float(leader_speed_d) >= float(self.GLOSA_MIN_SPEED_MS)
                        )
                        if (
                            red_light_ahead
                            and _clear_to_line
                            and tls_state_now == 'r'
                            and np.isfinite(tls_distance)
                            and float(self.GLOSA_MIN_DIST_M) <= float(tls_distance) <= float(self.GLOSA_MAX_DIST_M)
                            and 0.5 <= float(ttg_now) <= float(self.GLOSA_MAX_TTG_S)
                        ):
                            _v_glosa = float(tls_distance) / (float(ttg_now) + float(self.GLOSA_ARRIVAL_BUFFER_S))
                            _min_glosa_v = 2.2 if float(ttg_now) <= 4.0 else float(self.GLOSA_MIN_SPEED_MS)
                            if _min_glosa_v <= _v_glosa <= v_des:
                                _glosa_active = True
                                if current_speed > _v_glosa + 0.4:
                                    _a_glosa_cap = float(
                                        np.clip((_v_glosa - current_speed) / 1.8, -1.5, 0.3)
                                    )
                                    accel = min(accel, _a_glosa_cap)

                        if not _glosa_active:
                            _d_target = None
                            _decouple_green = bool(
                                getattr(self, "GREEN_GLIDE_DECOUPLE_ENABLED", True)
                            )
                            if red_light_ahead and np.isfinite(tls_distance) and float(tls_distance) >= 0.0:
                                _d_target = float(tls_distance) - float(self.RED_STOP_BUFFER_M)
                            if has_leader:
                                if (not _decouple_green) or red_light_ahead:
                                    if float(leader_speed_d) < 1.8 and float(leader_gap) < 85.0:
                                        _d_lead_stop = float(leader_gap) - 0.35
                                        if _d_target is None or _d_lead_stop < _d_target:
                                            _d_target = _d_lead_stop
                                else:
                                    if float(leader_speed_d) < 0.35 and float(leader_gap) < 28.0:
                                        _d_lead_stop = float(leader_gap) - 0.35
                                        if _d_target is None or _d_lead_stop < _d_target:
                                            _d_target = _d_lead_stop
                                    elif (
                                        float(leader_speed_d) < 2.5
                                        and float(leader_gap) < 35.0
                                        and float(current_speed) > float(leader_speed_d) + 0.5
                                    ):
                                        accel = min(accel, max(float(a_idm), -1.2) + 0.35)

                            if _d_target is not None and _d_target <= float(self.RED_GLIDE_HORIZON_M):
                                _d_eff = max(0.0, float(_d_target))
                                _b_glide = float(self.RED_GLIDE_DECEL)
                                _v_glide = float(np.sqrt(2.0 * _b_glide * _d_eff))
                                if _v_glide < v_des:
                                    # Exact feedforward + proportional tracking along v_glide(d):
                                    # dv_glide/dt = -b_glide * (v / v_glide), continuous down to v = 0!
                                    _ff_ratio = min(current_speed / max(_v_glide, 0.40), 1.20)
                                    _a_glide_cap = -_b_glide * _ff_ratio + (_v_glide - current_speed) / 1.20
                                    if current_speed > _v_glide and _d_eff > 0.25:
                                        _a_kin = -(current_speed * current_speed) / (2.0 * _d_eff)
                                        _a_glide_cap = min(_a_glide_cap, _a_kin)
                                    # Standstill brake hold in pocket: stops IDM a_idm > 0 from
                                    # pushing the stopped CAV forward into a secondary creep cycle.
                                    if _d_eff <= 0.30 and current_speed < 0.35:
                                        _a_glide_cap = min(_a_glide_cap, -0.50)
                                    accel = min(accel, float(np.clip(_a_glide_cap, -max_decel, max_accel)))

                    # 2. Lower-bound cruise / follower / junction-clearance nudges
                    #    (placed BEFORE the hard collision & red-line safety barrier so
                    #    no lower-bound nudge can ever override physical safety braking!).
                    #    v5.2.4: LON_NO_FLOORS=1 disables all four (bisection B2).
                    _floors_on = not bool(getattr(self, "LON_NO_FLOORS", False))
                    if (
                        _floors_on
                        and not red_light_ahead
                        and (not has_leader or leader_gap > 18.0)
                        and current_speed < 0.75 * v_des
                        and a_idm > 0.2
                    ):
                        accel = max(accel, a_idm - 0.8)

                    if (
                        _floors_on
                        and has_follower
                        and follower_gap < 15.0
                        and a_idm > -0.5
                        and not red_light_ahead
                        and (not has_leader or leader_gap > max(12.0, 1.6 * current_speed))
                    ):
                        accel = max(accel, a_idm - 1.5)

                    if (
                        _floors_on
                        and is_in_junction
                        and speed_without_traci > 0.2
                        and next_link_open
                        and not has_foe
                        and (not has_leader or leader_gap > 15.0)
                    ):
                        accel = max(accel, self.JUNCTION_CLEARANCE_ACCEL)

                    if (
                        _floors_on
                        and not is_in_junction
                        and current_speed < 1.0
                        and accel <= 0.0
                        and not red_light_ahead
                        and (not has_leader or leader_gap > 25.0)
                    ):
                        accel = self.JUNCTION_CLEARANCE_ACCEL

                    accel_pre_shield = float(accel)

                    # 3. Final Post-Rule Kinematic Gipps / RSS Collision-Free Safety Shield:
                    #    Accounts for 0.4s action-hold delay + 0.35m net buffer (keeping physical
                    #    bumper gap >= 1.35m, well clear of SUMO IDM's 0.50m collision threshold).
                    tau_react = 0.45
                    b_ego = max(float(max_decel), 3.5)
                    b_lead = 3.5
                    ttc_now = 99.0

                    if has_leader:
                        _ls = max(
                            0.0,
                            float(
                                self.sub_results.get(leader_id, {}).get(tc.VAR_SPEED, leader_speed_d)
                                or 0.0
                            )
                            if leader_id is not None
                            else float(leader_speed_d),
                        )
                        _closing = float(current_speed) - _ls
                        if _closing > 0.05:
                            ttc_now = max(0.0, float(leader_gap)) / _closing

                        g_eff = max(0.0, float(leader_gap) - 0.35)
                        v_safe_sq = (
                            (b_ego * tau_react) ** 2
                            + (_ls ** 2) * (b_ego / b_lead)
                            + 2.0 * b_ego * g_eff
                        )
                        v_safe = max(0.0, -b_ego * tau_react + float(np.sqrt(max(0.0, v_safe_sq))))
                        a_safe_cf = (v_safe - current_speed) / tau_react

                        headway_s = float(leader_gap) / max(current_speed, 0.5)
                        # v6-P0: trigger from gap_policy (legacy 4.5 m / 0.85 s / 2.2 s;
                        # unified 1.0 m / 0.5 s / 2.2 s, strictly below the CACC target).
                        if _gap_policy.shield_caps_to_idm(leader_gap, headway_s, ttc_now):
                            a_safe_cf = min(a_safe_cf, a_idm)
                        if float(leader_gap) < 0.45 and _ls < 0.2 and current_speed < 0.45:
                            a_safe_cf = min(a_safe_cf, -0.50)

                        accel = min(accel, a_safe_cf)

                    if red_light_ahead and not is_in_junction and np.isfinite(tls_distance) and float(tls_distance) >= 0.0:
                        d_stop_eff = max(0.0, float(tls_distance) - float(self.RED_STOP_BUFFER_M))
                        v_safe_red = max(
                            0.0,
                            -b_ego * tau_react + float(np.sqrt((b_ego * tau_react) ** 2 + 2.0 * b_ego * d_stop_eff)),
                        )
                        a_safe_red = (v_safe_red - current_speed) / tau_react
                        if float(tls_distance) < 0.60 and current_speed < 0.40:
                            a_safe_red = min(a_safe_red, -0.50)
                        accel = min(accel, a_safe_red)

                    accel = float(np.clip(accel, -max_decel, max_accel))
                    if str(self.LON_ACTUATION) == "speed" and self._env_on("V7_SHIELD_SPEED_FIX"):
                        # v7: under speed actuation commands >= a_IDM are never executed
                        # (_actuate_cav only caps below IDM), so a request the shield
                        # trims back to a_IDM changed nothing and must not be charged
                        # to the policy as an intervention (v6p0 penalised it via
                        # the Lagrangian term, biasing the residual towards braking).
                        raw_shield_cut = max(
                            0.0,
                            min(accel_pre_shield, float(a_idm)) - min(accel, float(a_idm)),
                        )
                    else:
                        raw_shield_cut = max(0.0, accel_pre_shield - accel)
                    eff_shield_delta = (
                        float(alpha_rl) * raw_shield_cut if float(alpha_rl) >= 0.05 else 0.0
                    )
                    shield_clip_deltas[vid] = float(eff_shield_delta)
                    if ttc_now < 1.5 and raw_shield_cut > 0.5:
                        safety_interventions += 1
                    applied_abs_accels[vid] = accel
                    if use_res_idm:
                        applied_cav_actions[vid] = float(
                            np.clip(accel - a_idm, res_low, res_high)
                        )
                    else:
                        applied_cav_actions[vid] = accel

                    self._auth_record(vid, accel_rl_mixed, accel, a_idm)
                    self._actuate_cav(vid, accel, a_idm, current_speed)
                    self._jstall["lon_exec"] += 1
                    current_controlled_cavs.add(vid)
                elif (in_platoon_zone or is_in_junction) and (
                    vid in self.controlled_cavs or vid in self._speed_capped
                ):
                    # v6-P0 perf: never-controlled CAVs carry no influence; releasing
                    # them cost two TraCI calls per CAV per step for nothing.
                    self._release_cav_to_sumo(vid)

        for cav_id in self.controlled_cavs - current_controlled_cavs:
            if cav_id in all_vehicles:
                self._release_cav_to_sumo(cav_id)

        self.controlled_cavs = current_controlled_cavs

        now_sig = self._sim_time or traci.simulation.getTime()
        for tls_id in list(self.tls_ids or []):
            if self.signal_programs.get(f"{tls_id}_synth"):
                self._advance_synth_transition(tls_id, now_sig)

        if signal_actions:
            # Prefer cached signal snapshot from last get_state (same sim time)
            if not self._signals:
                self._refresh_signals()
            now = self._sim_time or traci.simulation.getTime()
            for tls_id, action in signal_actions.items():
                try:
                    action_arr = np.asarray(action, dtype=np.float64).reshape(-1)
                    action_value_raw = float(action_arr[0]) if action_arr.size else 0.0
                    raw_action = int(action_value_raw) if np.isfinite(action_value_raw) else 0
                except (TypeError, ValueError, OverflowError):
                    raw_action = 0
                cached = self._signals.get(tls_id)
                if self.signal_programs.get(f"{tls_id}_synth"):
                    continue

                current_phase = (
                    int(cached['phase']) if cached is not None
                    else traci.trafficlight.getPhase(tls_id)
                )

                if self.last_signal_phase.get(tls_id) != current_phase:
                    self.last_signal_phase[tls_id] = current_phase
                    self.phase_started_at[tls_id] = now

                elapsed = now - self.phase_started_at.get(tls_id, now)
                kind = self._phase_kind(tls_id, current_phase)
                greens = self._green_phase_indices(tls_id)
                n_green = max(1, len(greens))
                cur_g = self._green_index_of_phase(tls_id, current_phase)
                if kind == "green":
                    served = self._green_last_served.setdefault(tls_id, {})
                    served[int(cur_g)] = float(now)
                    cyc = self._cycle_served.setdefault(tls_id, set())
                    cyc.add(int(cur_g))
                    self._maybe_complete_cycle(tls_id, n_green)
                # v6-P0: optional rule controller in the agent's own envelope.
                # The trainer still sees the agent's sampled action as `_req_g`
                # below, so an overridden sample is excluded from PPO.
                _agent_action = int(raw_action)
                _rule = self._signal_rule_name()
                if _rule == "fixed":
                    # Leave the SUMO TLS program from warmup running (fixed-timing baseline).
                    continue
                if _rule and kind == "green":
                    _choice = self._rule_signal_choice(tls_id, current_phase, _rule)
                    if _choice is not None:
                        raw_action = int(_choice)
                # Enforce min/planned green on the agent's discrete phase choice.
                action_value = self._clamp_signal_action(
                    tls_id, raw_action, current_phase, elapsed
                )
                # v5 (1.1): record requested -> executed green index so the trainer can
                # exclude samples whose sampled phase was overridden (PPO credit).
                try:
                    _req_g = int(_agent_action)
                except (TypeError, ValueError):
                    _req_g = -1
                if getattr(self, "_signal_exec_log", None) is None:
                    self._signal_exec_log = {}
                self._signal_exec_log[str(tls_id)] = (int(_req_g), int(action_value))

                if kind == 'green':
                    gmin = float(self._min_green_for(tls_id, cur_g))
                    last_decision = float(
                        self.signal_programs.get(f"{tls_id}_last_decision", 0.0)
                    )
                    target_g = self._planned_green_for(tls_id, cur_g)
                    remaining = (
                        float(cached['remaining_time']) if cached is not None
                        else traci.trafficlight.getNextSwitch(tls_id) - now
                    )
                    # Reassert SUMO timer to planned T; never pad past the budget.
                    budget_left = target_g - elapsed
                    if budget_left > self.step_length and remaining < budget_left - self.step_length:
                        traci.trafficlight.setPhaseDuration(
                            tls_id, float(max(self.step_length, budget_left))
                        )

                    # Hard cut when formula T is reached.
                    if elapsed >= target_g - 1e-3:
                        next_g = action_value if action_value != cur_g else self._fallback_switch_index(tls_id, cur_g, n_green)
                        next_phase = greens[next_g]
                        self._begin_phase_transition(tls_id, current_phase, next_phase, now)
                        continue

                    # Do NOT write last_decision while elapsed < gmin.
                    if elapsed < gmin - 1e-3:
                        continue

                    # Unlock first decision at gmin; then roll every GREEN_DECISION_INTERVAL.
                    if last_decision <= 0.0:
                        decision_ready = True
                    else:
                        decision_ready = (
                            elapsed - last_decision >= self.GREEN_DECISION_INTERVAL - 1e-3
                        )
                    if not decision_ready:
                        continue

                    if action_value == cur_g:
                        self.signal_programs[f"{tls_id}_last_decision"] = elapsed
                    else:
                        next_phase = greens[action_value]
                        self._begin_phase_transition(tls_id, current_phase, next_phase, now)

                elif kind == 'yellow' and elapsed >= self.YELLOW_DURATION - 1e-3:
                    phases = self._get_tls_phases(tls_id)
                    nxt = current_phase + 1
                    if nxt < len(phases) and self._phase_kind(tls_id, nxt) == 'red':
                        traci.trafficlight.setPhase(tls_id, nxt)
                        self.last_signal_phase[tls_id] = nxt
                        self.phase_started_at[tls_id] = now
                        traci.trafficlight.setPhaseDuration(
                            tls_id, float(self.ALL_RED_DURATION)
                        )
                    else:
                        next_green = int(
                            self.signal_programs.get(
                                f"{tls_id}_next", greens[(cur_g + 1) % n_green]
                            )
                        )
                        next_g_idx = self._green_index_of_phase(tls_id, next_green)
                        T = self._compute_green_duration(tls_id, next_g_idx)
                        traci.trafficlight.setPhase(tls_id, next_green)
                        self.last_signal_phase[tls_id] = next_green
                        self.phase_started_at[tls_id] = now
                        traci.trafficlight.setPhaseDuration(tls_id, float(T))
                        self.signal_programs[f"{tls_id}_last_decision"] = 0.0

                elif kind == 'red' and elapsed >= self.ALL_RED_DURATION - 1e-3:
                    next_green = int(
                        self.signal_programs.get(
                            f"{tls_id}_next", greens[(cur_g + 1) % n_green]
                        )
                    )
                    next_g_idx = self._green_index_of_phase(tls_id, next_green)
                    T = self._compute_green_duration(tls_id, next_g_idx)
                    traci.trafficlight.setPhase(tls_id, next_green)
                    self.last_signal_phase[tls_id] = next_green
                    self.phase_started_at[tls_id] = now
                    traci.trafficlight.setPhaseDuration(tls_id, float(T))
                    self.signal_programs[f"{tls_id}_last_decision"] = 0.0

        _evt = getattr(self, "_v7_evt", None)
        if _evt is not None:
            _evt.tick(float(traci.simulation.getTime()))
        traci.simulationStep()

        for vid in traci.simulation.getDepartedIDList():
            if str(vid).startswith("evt_"):
                continue  # v7.1 obstacle: physical only, never observed/controlled
            self._subscribe_vehicle(vid, in_zone=False)

        self.sub_results = traci.vehicle.getAllSubscriptionResults()
        prev_zone = set(self._zone_subscribed)
        self._sync_zone_subscriptions()
        # After upgrade/downgrade, one bulk pull so get_state can read zone vars
        # without per-vehicle TraCI fallbacks on the first frame in-zone.
        if self._zone_subscribed != prev_zone:
            self.sub_results = traci.vehicle.getAllSubscriptionResults()

        self._update_episode_kpis()

        now = traci.simulation.getTime()
        try:
            self._jstall_accumulate(current_controlled_cavs, now)
        except Exception:
            pass
        try:
            self._auth_realize()
        except Exception:
            pass
        if not self.tls_ids:
            self.tls_ids = self._resolve_controlled_tls_ids()
        for tls_id in self.tls_ids:
            if self.signal_programs.get(f"{tls_id}_synth"):
                continue
            current_phase = traci.trafficlight.getPhase(tls_id)
            if self.last_signal_phase.get(tls_id) != current_phase:
                self.last_signal_phase[tls_id] = current_phase
                self.phase_started_at[tls_id] = now

        state = self.get_state()
        reward = self.get_reward()
        self._control_steps += 1
        done = self.is_done()

        return state, reward, done, {
            'applied_cav_actions': applied_cav_actions,
            'applied_abs_accels': applied_abs_accels,
            'shield_clip_deltas': shield_clip_deltas,
            'safety_interventions': safety_interventions,
            'lon_noop_vids': list(self._lon_noop_vids_step),
            'done_reason': self._done_reason if done else "",
        }

    def get_state(self):
        state = {
            'cavs': {},
            'hdvs': {},
            'signals': {},
            'action_mask': np.ones(MAX_SIGNAL_ACTIONS, dtype=np.float32),
            'action_masks': {},
        }

        signals = self._refresh_signals()
        for tls_id, sig in signals.items():
            state['signals'][tls_id] = dict(sig)
        if bool(getattr(self, "IN_MEMORY_FOLLOWER_LOOKUP", True)):
            self._step_follower_map = self._build_in_memory_followers(self.sub_results, max_dist=100.0)
        else:
            self._step_follower_map = None
        # v4: stray mask build removed (masks are rebuilt after platoon tracking).

        if state['action_masks']:
            first_tls = next(iter(state['action_masks']))
            state['action_mask'] = state['action_masks'][first_tls]

        total_network_speed = 0.0
        network_vehicle_count = 0
        total_waiting_time = 0.0
        step_fuel = 0.0
        step_co2 = 0.0
        step_waiting_vehicles = 0
        zone_detail = {}

        # Per-step valid rates for emission/distance integration (skip TraCI sentinels).
        step_veh_fuel_rates = {}
        step_veh_co2_rates = {}
        step_veh_speeds = {}

        for vid, v_data in self.sub_results.items():
            vtype = self._vehicle_type(vid, v_data)

            edge_id = v_data[tc.VAR_ROAD_ID]
            lane_id = v_data[tc.VAR_LANE_ID]
            lane_pos = v_data[tc.VAR_LANEPOSITION]
            speed_raw = self._traci_valid_double(v_data.get(tc.VAR_SPEED, 0.0))
            speed = 0.0 if speed_raw is None else float(speed_raw)
            acc_raw = self._traci_valid_double(v_data.get(tc.VAR_ACCELERATION, 0.0))
            acceleration = 0.0 if acc_raw is None else float(acc_raw)
            position = v_data[tc.VAR_POSITION]
            angle = v_data[tc.VAR_ANGLE]
            wait_raw = self._traci_valid_double(
                v_data.get(tc.VAR_ACCUMULATED_WAITING_TIME, 0.0), non_negative=True
            )
            waiting_time = 0.0 if wait_raw is None else float(wait_raw)

            fuel_rate = None
            co2_rate = None
            if self.enable_emissions:
                fuel_rate = self._traci_valid_double(
                    v_data.get(tc.VAR_FUELCONSUMPTION, 0.0), non_negative=True
                )
                co2_rate = self._traci_valid_double(
                    v_data.get(tc.VAR_CO2EMISSION, 0.0), non_negative=True
                )
            # Only integrate KPIs when speed is a real TraCI value (not -2^30 sentinel).
            if speed_raw is not None:
                total_network_speed += speed
                network_vehicle_count += 1
                total_waiting_time += waiting_time
                self._ep_vehicle_ids.add(vid)
                step_veh_speeds[vid] = speed
                if fuel_rate is not None:
                    step_fuel += fuel_rate
                    step_veh_fuel_rates[vid] = fuel_rate
                if co2_rate is not None:
                    step_co2 += co2_rate
                    step_veh_co2_rates[vid] = co2_rate
                if speed < 0.1:
                    step_waiting_vehicles += 1

            is_in_junction = edge_id.startswith(':')
            dist_to_stopline = float(self._dist_to_stopline_from_vdata(v_data))
            tls_dist_ahead = dist_to_stopline if dist_to_stopline >= 0.0 else -1.0
            is_approaching = (
                edge_id.endswith('A0')
                or edge_id in self._approach_cardinal
                or tls_dist_ahead >= 0.0
            )

            zf = zone_flags(
                dist_to_stopline,
                is_in_junction,
                control_zone_m=float(self.CONTROL_ZONE_DISTANCE),
                platoon_zone_m=float(
                    getattr(self, "PLATOON_ZONE_DISTANCE", self.CONTROL_ZONE_DISTANCE)
                ),
            )
            in_control_zone = bool(zf["in_control_zone"])
            in_platoon_zone = bool(zf["in_platoon_zone"])
            zone_type = str(zf["zone_type"])
            lateral_allowed = bool(zf["lateral_allowed"])
            if in_platoon_zone:
                if vid not in self._zone_enter_time:
                    self._zone_enter_time[vid] = float(self._sim_time)
                control_time = max(0.0, float(self._sim_time) - float(self._zone_enter_time[vid]))
            else:
                self._zone_enter_time.pop(vid, None)
                control_time = 0.0
            # Re-arm one-shot escape only after leaving the whole corridor
            # (avoids 200 m boundary flicker from re-penalizing).
            if not in_platoon_zone:
                getattr(self, '_escape_penalty_issued', set()).discard(vid)

            next_tls_id, tls_link_index, tls_distance, tls_state = None, -1, -1.0, 'n'
            time_to_green = -1.0
            leader_id, leader_gap, leader_speed = None, 100.0, speed
            ttc = None
            follower_id, follower_gap = None, 100.0
            speed_without_traci = speed
            next_link_open = True
            has_foe = False
            red_light_ahead = False

            # Fine TraCI fields for formation + control (hierarchical CAV).
            if in_platoon_zone:
                next_tls_id, tls_link_index, tls_distance, tls_state = self._parse_next_tls(vid, v_data)
                time_to_green = self._time_to_green(
                    next_tls_id, tls_link_index, tls_state, signals.get(next_tls_id)
                )
                leader_id, leader_gap, leader_speed, ttc = self._parse_leader(vid, v_data, speed)

                # Follower / foe fields are only consumed by CAV obs; skip HDV TraCI.
                if 'CAV' in vtype:
                    follower_id, follower_gap = self._parse_follower(vid, v_data)
                    speed_without_traci = self._parse_speed_without_traci(vid, v_data, speed)
                    next_link_open, has_foe = self._parse_next_links(vid, v_data)

                red_light_ahead = (
                    tls_distance >= 0.0
                    and tls_distance < 220.0
                    and str(tls_state).lower() in ('r', 'y')
                )

                zone_detail[vid] = {
                    'speed_without_traci': speed_without_traci,
                    'leader_id': leader_id,
                    'leader_gap': leader_gap,
                    'leader_speed': float(leader_speed),
                    'follower_id': follower_id,
                    'follower_gap': follower_gap,
                    'next_link_open': next_link_open,
                    'has_foe': bool(has_foe),
                    'red_light_ahead': red_light_ahead,
                    'tls_distance': tls_distance if tls_distance >= 0.0 else float('inf'),
                    'tls_state': str(tls_state or 'n').lower(),
                    'time_to_green': float(time_to_green),
                }

            length_raw = self._cached_vehicle_length(vid, v_data)

            prev_a = float(getattr(self, '_prev_accel', {}).get(vid, acceleration))
            if not hasattr(self, '_prev_accel'):
                self._prev_accel = {}
            jerk = (float(acceleration) - prev_a) / max(float(self.step_length), 1e-6)
            self._prev_accel[vid] = float(acceleration)
            n_lanes = (
                int(self._n_lanes_for(edge_id))
                if edge_id and not str(edge_id).startswith(':')
                else 1
            )
            card = (getattr(self, "_approach_cardinal", None) or {}).get(edge_id)
            chain = (getattr(self, "_approach_chains", None) or {}).get(card) if card else None
            approach_edges = tuple(chain) if chain else ((edge_id,) if edge_id else ())
            if edge_id and not str(edge_id).startswith(':'):
                route_next, lane_to_edges = self._corridor_route_target_and_lane_map(
                    vid, edge_id
                )
            else:
                route_next, lane_to_edges = None, {}
            cool_until = float(
                (getattr(self, "_lc_cooldown_until", {}) or {}).get(vid, 0.0) or 0.0
            )
            lc_cooldown_active = bool(
                float(getattr(self, "_sim_time", 0.0) or 0.0) < cool_until
            )
            v_info = {
                'speed': speed,
                'acceleration': acceleration,
                'jerk': float(jerk),
                'position': position,
                'angle': angle,
                'length': float(length_raw),
                'lane': lane_id,
                'lane_max_speed': float(
                    (getattr(self, 'lane_speeds_cache', None) or {}).get(
                        lane_id, getattr(self, 'MAX_SPEED', 16.67)
                    )
                    or getattr(self, 'MAX_SPEED', 16.67)
                ),
                'lane_position': lane_pos,
                'edge': edge_id,
                'approach_edges': approach_edges,
                'n_lanes': int(n_lanes),
                'lefthand': bool(getattr(self, 'lefthand', False)),
                'dist_to_stopline': dist_to_stopline,
                'is_approaching': is_approaching,
                'is_in_junction': is_in_junction,
                'zone_type': zone_type,
                'lateral_allowed': lateral_allowed,
                'in_control_zone': in_control_zone,
                'in_platoon_zone': in_platoon_zone,
                'control_time': float(control_time),
                'route_next_edge': route_next,
                'lane_to_edges': lane_to_edges,
                'triggered_escape': bool(
                    vid in getattr(self, '_step_escape_triggered', ())
                ),
                'lc_cooldown_active': bool(lc_cooldown_active),
                'tls_id': next_tls_id,
                'tls_link_index': tls_link_index,
                'tls_distance': tls_distance,
                'tls_state': tls_state,
                'time_to_green': time_to_green,
                'leader_id': leader_id,
                'leader_gap': leader_gap,
                'leader_speed': leader_speed,
                'follower_id': follower_id,
                'follower_gap': follower_gap,
                'ttc': ttc,
                'speed_without_traci': speed_without_traci,
                'next_link_open': next_link_open,
                'has_foe': has_foe,
                'waiting_time': waiting_time,
            }
            # IDM baseline accel for lon obs (from last control step, else CF proxy).
            last_a = getattr(self, "_last_a_idm", None) or {}
            a_idm_val = last_a.get(vid)
            if a_idm_val is None and in_platoon_zone and "CAV" in vtype:
                dt = max(float(self.step_length), 1e-3)
                _ma, _md = self._vtype_limits(vtype)
                a_idm_val = float(acceleration) + (float(speed_without_traci) - float(speed)) / dt
                a_idm_val = float(np.clip(a_idm_val, -_md, _ma))
            if a_idm_val is not None:
                v_info["a_idm"] = float(a_idm_val)
            # RL CAV agents in formation + control zones.
            if 'CAV' in vtype and in_platoon_zone:
                v_info['is_cav'] = True
                v_info['vtype'] = vtype
                state['cavs'][vid] = v_info
            else:
                v_info['is_cav'] = 'CAV' in vtype
                v_info['vtype'] = vtype
                state['hdvs'][vid] = v_info

        self._zone_detail = zone_detail
        # Drop departed / expired LC keep-locks.
        if getattr(self, "_lc_cooldown_until", None):
            now_cd = float(getattr(self, "_sim_time", 0.0) or 0.0)
            alive_ids = set(state["cavs"]) | set(state["hdvs"])
            self._lc_cooldown_until = {
                vid: float(until)
                for vid, until in self._lc_cooldown_until.items()
                if vid in alive_ids and float(until) > now_cd
            }

        # DBSCAN over full platoon corridor (formation + control), not control-only.
        all_zone = {}
        cav_ids = set()
        for vid, vinfo in state['cavs'].items():
            all_zone[vid] = vinfo
            cav_ids.add(vid)
        for vid, vinfo in state['hdvs'].items():
            if vinfo.get('in_platoon_zone', False) or vinfo.get('in_control_zone', False):
                all_zone[vid] = vinfo
                if vinfo.get('is_cav'):
                    cav_ids.add(vid)
        platoon = self.platoon_tracker.update(all_zone, cav_ids=cav_ids)
        self._platoon_info = platoon
        leader_vids = set(platoon.get('leader_vids') or ())
        # Sticky Leaders: keep RL for current DBSCAN leaders, vehicles already
        # inside the junction (DBSCAN skips interiors), and near-stopline
        # (<=25 m) so a mid-queue merge cannot yank control at the stop line.
        # Do NOT sticky-lock former solo leaders across the whole 200..700 m
        # corridor — that forced almost every CAV onto lon_actor and starved
        # compact IDM/CACC following inside platoons.
        sticky = set()
        for vid in self._sticky_leader_vids | leader_vids:
            vinfo = state['cavs'].get(vid) or state['hdvs'].get(vid)
            if should_keep_sticky_leader(vid, vinfo, leader_vids):
                sticky.add(vid)
        self._sticky_leader_vids = sticky
        self._leader_vids = leader_vids | sticky
        for vid, vinfo in list(state['cavs'].items()) + list(state['hdvs'].items()):
            key = self.platoon_tracker.cluster_of.get(vid)
            vinfo['cluster_id'] = key
            vinfo['is_leader'] = bool(vid in self._leader_vids)
            vinfo['platoon_length'] = float(
                self.platoon_tracker.cluster_length.get(key, 0.0) if key else 0.0
            )
        state['platoon'] = {
            'leader_vids': list(self._leader_vids),
            'cluster_of': dict(self.platoon_tracker.cluster_of),
            'cluster_length': dict(self.platoon_tracker.cluster_length),
            'last_T': dict(self._last_green_T),
            'last_lv': dict(self._last_green_lv),
        }
        # Rebuild Top-3 masks with this step's cluster lengths.
        for tls_id, sig in state['signals'].items():
            state['action_masks'][tls_id] = self._build_action_mask(
                tls_id, sig['phase'], sig['elapsed_time']
            )
        if state['action_masks']:
            first_tls = next(iter(state['action_masks']))
            state['action_mask'] = state['action_masks'][first_tls]

        total_speed = 0.0
        min_ttc = 999.0
        # Include scenario-specific approaches (e.g. Xuancheng Fazhi "FZ").
        queue_dict = {'N': 0, 'S': 0, 'E': 0, 'W': 0}
        veh_count_dict = {'N': 0, 'S': 0, 'E': 0, 'W': 0}
        max_wait_dict = {'N': 0.0, 'S': 0.0, 'E': 0.0, 'W': 0.0}
        n_prog_dict = {'N': 0, 'S': 0, 'E': 0, 'W': 0}
        for card in set(self._approach_cardinal.values()):
            queue_dict.setdefault(card, 0)
            veh_count_dict.setdefault(card, 0)
            max_wait_dict.setdefault(card, 0.0)
            n_prog_dict.setdefault(card, 0)
        danger_event_number = 0
        accels = []
        hdv_speeds = []
        approaching_etas = []
        green_wave_candidate_number = 0
        n_approach_veh = 0
        n_starve = 0
        # Match starve / anti-teleport absolute wait (STARVE_WAIT_S).
        try:
            starve_thr = float(STARVE_WAIT_S)
        except Exception:
            starve_thr = 105.0
        # VLM lateral/longitudinal keys (were dead defaults in prompts):
        # platoon_rate (clustered CAVs / all CAVs), lane_change_rate
        # (CAVs that switched lane index since last step), n_dlc (# of
        # RL_DLC-eligible CAVs) and thru_dlc_queue_diff (max over edges of
        # max-min waiting counts across that edge's lanes).
        n_dlc = 0
        dlc_edge_lanes: dict = {}
        platooned_cavs = 0
        total_cavs_seen = 0
        lc_changed = 0
        lc_total = 0
        _lat_dof = lat_dof_mode
        prev_lane_idx = getattr(self, '_prev_lane_idx', None)
        if prev_lane_idx is None:
            prev_lane_idx = {}
            self._prev_lane_idx = prev_lane_idx
        cur_lane_idx: dict = {}

        tls_id_0 = self.tls_ids[0] if self.tls_ids else None
        current_rem_time = state['signals'][tls_id_0]['remaining_time'] if tls_id_0 else 0.0

        def process_vehicle(vid, vinfo, is_cav=False):
            """Aggregate log KPIs over every vehicle currently on the network."""
            nonlocal total_speed, min_ttc, danger_event_number, green_wave_candidate_number
            nonlocal n_approach_veh, n_starve
            nonlocal n_dlc, platooned_cavs, total_cavs_seen, lc_changed, lc_total

            speed = float(vinfo.get('speed', 0.0) or 0.0)
            total_speed += speed
            edge = vinfo.get('edge')
            card = self._queue_cardinal(edge)

            accels.append(float(vinfo.get('acceleration', 0.0) or 0.0))

            if not is_cav:
                hdv_speeds.append(speed)

            if card:
                veh_count_dict[card] = int(veh_count_dict.get(card, 0)) + 1
                try:
                    wt = float(vinfo.get('waiting_time', 0.0) or 0.0)
                except (TypeError, ValueError):
                    wt = 0.0
                if wt > float(max_wait_dict.get(card, 0.0)):
                    max_wait_dict[card] = wt
                n_approach_veh += 1
                if wt > starve_thr:
                    n_starve += 1

            if speed < 0.5:
                if card:
                    queue_dict[card] += 1

            raw_d = vinfo.get('dist_to_stopline', -1.0)
            dist = -1.0 if raw_d is None else float(raw_d)
            if dist > 0 and speed > 0:
                eta = dist / speed
                approaching_etas.append(eta)
                tls_state = str(vinfo.get('tls_state', 'n') or 'n').lower()
                if dist < 200.0 and eta < current_rem_time and tls_state == 'g':
                    green_wave_candidate_number += 1
                    if card:
                        n_prog_dict[card] = int(n_prog_dict.get(card, 0)) + 1

            ttc = vinfo.get('ttc')
            if ttc is not None:
                if ttc < min_ttc:
                    min_ttc = ttc
                # Align KPI with longitudinal DANGER_TTC (shared constant).
                if ttc < float(DANGER_TTC):
                    danger_event_number += 1

            # DLC / platoon / lane-change aggregates for VLM prompts.
            try:
                is_cav_v = bool(vinfo.get('is_cav', False))
                if is_cav_v:
                    total_cavs_seen += 1
                    if vinfo.get('cluster_id') is not None:
                        platooned_cavs += 1
                    lane_id_v = str(vinfo.get('lane', '') or '')
                    try:
                        cur_idx = int(lane_id_v.rsplit('_', 1)[-1])
                    except (TypeError, ValueError):
                        cur_idx = 0
                    cur_lane_idx[vid] = cur_idx
                    lc_total += 1
                    if vid in prev_lane_idx and prev_lane_idx[vid] != cur_idx:
                        lc_changed += 1
                    n_lanes_v = max(int(vinfo.get('n_lanes', 1) or 1), 1)
                    dlc_ok = False
                    if n_lanes_v >= 2 and _lat_dof is not None:
                        try:
                            _m, _ = _lat_dof(vinfo, n_lanes_v)
                            dlc_ok = str(_m) == 'RL_DLC'
                        except Exception:
                            dlc_ok = False
                    elif n_lanes_v >= 2:
                        dlc_ok = True
                    if dlc_ok and vinfo.get('in_platoon_zone', False):
                        n_dlc += 1
                    edge_v = vinfo.get('edge', '')
                    if edge_v and not str(edge_v).startswith(':'):
                        per_lane = dlc_edge_lanes.setdefault(edge_v, {})
                        per_lane[cur_idx] = per_lane.get(cur_idx, 0) + (
                            1 if speed < 0.5 else 0
                        )
            except Exception:
                pass

        for vid, vinfo in state['cavs'].items():
            process_vehicle(vid, vinfo, is_cav=True)

        for vid, vinfo in state['hdvs'].items():
            process_vehicle(vid, vinfo, is_cav=False)

        # Finalize DLC / platoon / lane-change stats.
        thru_dlc_queue_diff = 0.0
        try:
            for per_lane in dlc_edge_lanes.values():
                if len(per_lane) >= 2:
                    vals = list(per_lane.values())
                    thru_dlc_queue_diff = max(
                        thru_dlc_queue_diff, float(max(vals) - min(vals))
                    )
            self._prev_lane_idx = cur_lane_idx
        except Exception:
            pass
        platoon_rate = (
            float(platooned_cavs) / float(total_cavs_seen) if total_cavs_seen > 0 else 0.0
        )
        lane_change_rate = (
            float(lc_changed) / float(lc_total) if lc_total > 0 else 0.0
        )

        # Log KPIs use the full network fleet (same basis as emission integration).
        total_vehicles = int(network_vehicle_count)
        avg_speed = (
            float(total_network_speed) / float(total_vehicles) if total_vehicles > 0 else 0.0
        )
        acc_variance = np.var(accels) if len(accels) > 0 else 0.0
        hdv_var = np.var(hdv_speeds) if len(hdv_speeds) > 0 else 0.0
        average_eta = np.mean(approaching_etas) if len(approaching_etas) > 0 else 0.0

        if hdv_var < 5.0: hdv_state = "Stable"
        elif hdv_var < 15.0: hdv_state = "Moderate fluctuation"
        else: hdv_state = "Highly unstable"

        collider_ids = set()
        victim_ids = set()
        teleport_ids = set()
        try:
            arrived = traci.simulation.getArrivedNumber()
            departed = traci.simulation.getDepartedNumber()
            raw_colls = traci.simulation.getCollisions() or ()
            collisions = len(raw_colls)
            for c_obj in raw_colls:
                c_id = getattr(c_obj, "collider", None)
                v_id = getattr(c_obj, "victim", None)
                if c_id:
                    collider_ids.add(str(c_id))
                if v_id:
                    victim_ids.add(str(v_id))
        except Exception:
            arrived, departed, collisions = 0, 0, 0
        try:
            # Jam / collision teleports clear the road and can fake high speed.
            teleports = int(traci.simulation.getStartingTeleportNumber())
            try:
                for tid in traci.simulation.getStartingTeleportIDList() or ():
                    if tid:
                        teleport_ids.add(str(tid))
            except Exception:
                pass
        except Exception:
            teleports = 0
        self._last_collisions = collisions
        self._last_teleports = teleports

        # TraCI fuel/CO2 are rates (mg/s). Integrate over step_length; distance via Σ v·Δt.
        # Invalid TraCI sentinels (-2^30) are excluded above before summing.
        dt = float(self.step_length)
        step_fuel_mg = float(step_fuel) * dt
        step_co2_mg = float(step_co2) * dt
        step_dist_m = float(total_network_speed) * dt
        self._ep_fuel_mg += step_fuel_mg
        self._ep_co2_mg += step_co2_mg
        self._ep_dist_m += step_dist_m
        for vid, spd in step_veh_speeds.items():
            self._ep_veh_dist_m[vid] = float(self._ep_veh_dist_m.get(vid, 0.0)) + float(spd) * dt
            if vid in step_veh_fuel_rates:
                self._ep_veh_fuel_mg[vid] = (
                    float(self._ep_veh_fuel_mg.get(vid, 0.0))
                    + float(step_veh_fuel_rates[vid]) * dt
                )
            if vid in step_veh_co2_rates:
                self._ep_veh_co2_mg[vid] = (
                    float(self._ep_veh_co2_mg.get(vid, 0.0))
                    + float(step_veh_co2_rates[vid]) * dt
                )
        emission = self._emission_kpis()
        fleet_avg_fuel = float(emission['fleet_avg_fuel'])  # L/100km
        fleet_avg_co2 = float(emission['fleet_avg_co2'])    # g/km

        state['stats'] = {
            'time': self._sim_time,
            'average_speed': avg_speed,
            'network_avg_speed': total_network_speed / network_vehicle_count if network_vehicle_count > 0 else 0.0,
            # Instantaneous mean of control-period true wait over vehicles currently on net.
            # (Episode KPI avg_waiting_time below is uncensored all-sample AWT.)
            'network_avg_waiting_time': (
                float(
                    sum(float(self._last_accum_wait.get(vid, 0.0)) for vid in step_veh_speeds)
                    / float(len(step_veh_speeds))
                )
                if step_veh_speeds
                else 0.0
            ),
            # Raw TraCI rates (mg/s) this step — prefer step_*_mg / fleet_* / total_* for KPIs.
            'step_fuel': step_fuel,
            'step_co2': step_co2,
            'step_fuel_mg': step_fuel_mg,
            'step_co2_mg': step_co2_mg,
            'step_distance_m': step_dist_m,
            'step_waiting_vehicles': step_waiting_vehicles,
            # Instantaneous queue length: vehicles waiting (v < 0.1 m/s) in the road network.
            'queue_length': int(step_waiting_vehicles),
            'arrived_vehicles': arrived,
            'departed_vehicles': departed,
            'avg_travel_time': (
                float(np.mean(self._episode_travel_times)) if self._episode_travel_times else 0.0
            ),
            # Completed + still-on-net travel times (control-period, warm-up clipped).
            'uncensored_avg_travel_time': self._uncensored_avg_travel_time(
                float(getattr(self, "_sim_time", 0.0) or 0.0)
            ),
            # Uncensored all-sample AWT (completed + still-on-net), control-period true wait.
            'avg_waiting_time': self.all_sample_avg_waiting_time(
                self._episode_waiting_times, self._last_accum_wait.values()
            ),
            # Fleet emission intensities (distance-normalized; formerly avg_fuel / avg_co2).
            'fleet_avg_fuel': fleet_avg_fuel,  # L/100km
            'fleet_avg_co2': fleet_avg_co2,    # g/km
            # Backward-compatible aliases → fleet averages.
            'avg_fuel': fleet_avg_fuel,
            'avg_co2': fleet_avg_co2,
            # Episode sums over all observed vehicles.
            'total_fuel_L': float(emission['total_fuel_L']),
            'total_co2_g': float(emission['total_co2_g']),
            'total_fuel_mg': float(self._ep_fuel_mg),
            'total_co2_mg': float(self._ep_co2_mg),
            # Mean of per-vehicle intensities (same units as fleet averages).
            'veh_avg_fuel_L': float(emission['veh_avg_fuel_L']),  # L/100km
            'veh_avg_co2_g': float(emission['veh_avg_co2_g']),    # g/km
            'emission_vehicle_count': int(emission['emission_vehicle_count']),
            'total_distance_m': float(self._ep_dist_m),
            'completed_trips': len(self._episode_travel_times),
            # v4 KPIs: insertion-aware time in system, insertion backlog, OD rewrites.
            'avg_time_in_system': float(self._tis_value(float(self._sim_time))),
            'insertion_backlog': int(self._insertion_backlog()),
            'od_rewrites': int(getattr(self, '_od_rewrites', 0)),
            # v5.2.4 observe-only: junction-box standstill and Lon no-op share.
            **self.jstall_stats(),
            # v6-P0 observe-only: longitudinal execution-authority audit.
            **self.auth_stats(),
            'num_stops': int(self._episode_stops),
            'min_ttc': float(min_ttc) if min_ttc < 999.0 else 99.0,
            **{f'queue_{k}': v for k, v in queue_dict.items()},
            **{f'veh_count_{k}': v for k, v in veh_count_dict.items()},
            **{f'max_wait_{k}': float(v) for k, v in max_wait_dict.items()},
            **{f'n_prog_{k}': int(v) for k, v in n_prog_dict.items()},
            'starve_fraction': float(n_starve) / float(max(n_approach_veh, 1)),
            'n_starve': int(n_starve),
            'danger_event_number': danger_event_number,
            'acc_variance': acc_variance,
            'approaching_vehicle_number': len(approaching_etas),
            'average_ETA': average_eta,
            'green_wave_candidate_number': green_wave_candidate_number,
            'n_prog': int(green_wave_candidate_number),
            # Lateral/longitudinal VLM keys (live values; prompts + drift
            # preempt + key-frame cache consume these instead of dead 0.0).
            'platoon_rate': float(platoon_rate),
            'lane_change_rate': float(lane_change_rate),
            'thru_dlc_queue_diff': float(thru_dlc_queue_diff),
            'n_dlc': int(n_dlc),
            'HDV_following_state': hdv_state,
            'total_vehicles': total_vehicles,
            'network_total_vehicles': network_vehicle_count,
            'cav_number': sum(
                1
                for group in ('cavs', 'hdvs')
                for v in state[group].values()
                if bool(v.get('is_cav', False))
            ),
            'hdv_number': sum(
                1
                for group in ('cavs', 'hdvs')
                for v in state[group].values()
                if not bool(v.get('is_cav', False))
            ),
        }

        # Per-green-phase queue / wait labels for the VLM signal teacher.
        # Also publish fixed-topology lane queues + phase-mean waits for signal formal.
        phase_labels = {}
        state['stats']['lane_queue_lengths_m'] = {}
        state['stats']['phase_avg_waits_s'] = []
        state['stats']['phase_queue_lengths_m'] = []
        state['stats']['phase_max_waits_s'] = []
        if tls_id_0:
            try:
                self._ensure_phase_lane_map(tls_id_0)
                n_g0 = int(state['signals'].get(tls_id_0, {}).get('n_green', 0) or 0)
                lane_map = self._phase_incoming_lanes.get(tls_id_0, {})
                lane_q = self._approach_lane_queue_lengths_m(tls_id_0)
                phase_waits = self._phase_avg_waits_s(tls_id_0)
                state['stats']['lane_queue_lengths_m'] = {
                    str(k): float(v) for k, v in lane_q.items()
                }
                state['stats']['phase_avg_waits_s'] = [
                    float(w) for w in phase_waits
                ]
                state['stats']['n_approach_lanes'] = float(len(lane_q))
                state['stats']['n_green_phases'] = float(len(phase_waits))
                phase_queues = []
                phase_max_waits = []
                for g_i in range(n_g0):
                    q_m = float(self._queue_length_for_green(tls_id_0, g_i))
                    w_s = float(self._max_wait_for_green(tls_id_0, g_i))
                    w_avg = (
                        float(phase_waits[g_i]) if g_i < len(phase_waits) else 0.0
                    )
                    phase_queues.append(q_m)
                    phase_max_waits.append(w_s)
                    state['stats'][f'queue_phase_{g_i}'] = q_m
                    state['stats'][f'max_wait_phase_{g_i}'] = w_s
                    state['stats'][f'avg_wait_phase_{g_i}'] = w_avg
                    lanes_i = lane_map.get(g_i, []) or []
                    cards = []
                    for lid in lanes_i:
                        c = self._queue_cardinal(self._edge_of_lane(lid))
                        if c and c not in cards:
                            cards.append(str(c))
                    dirs_txt = "/".join(cards) if cards else "mixed"
                    phase_labels[g_i] = (
                        f"green_index={g_i} (approaches={dirs_txt}, "
                        f"queue_m={q_m:.1f}m, max_wait={w_s:.1f}s, "
                        f"avg_wait={w_avg:.1f}s)"
                    )
                state['stats']['phase_queue_lengths_m'] = list(phase_queues)
                state['stats']['phase_max_waits_s'] = list(phase_max_waits)
                state['stats']['phase_near_counts'] = [
                    int(self._near_count_for_green(tls_id_0, g_i))
                    for g_i in range(n_g0)
                ]
                if self._env_on("V7_SIGNAL_PRESSURE_OBS") or str(
                    os.environ.get("V7_TEACHER", "")
                ).strip().lower() == "maxpressure":
                    # v7: Max-Pressure per decision green (incoming within 200 m
                    # minus downstream), for the signal observation and MP teacher.
                    state['stats']['phase_pressures'] = [
                        float(self._phase_pressure(tls_id_0, g_i)) for g_i in range(n_g0)
                    ]
                try:
                    self._v7_events_state(state, tls_id_0, n_g0)
                except Exception as exc:
                    print(f"[Events] state skipped: {exc}", flush=True)
            except Exception as exc:
                print(f"[SUMO] phase_labels skipped: {exc}", flush=True)
        state['phase_labels'] = phase_labels

        state['collisions'] = collisions
        state['teleports'] = teleports
        state['collider_ids'] = sorted(collider_ids)
        state['victim_ids'] = sorted(victim_ids)
        state['teleport_ids'] = sorted(teleport_ids)
        # Safety incident count for best-ckpt gating (crash + jam teleport).
        state['safety_incidents'] = int(collisions) + int(teleports)
        if collisions > 0:
            self._collision_episodes += collisions

        return state

    def _build_action_mask(self, tls_id, current_phase, elapsed_time):
        """Signal action mask, cached as the CONTRACT for the next step's clamp (v5.1)."""
        mask = self._build_action_mask_raw(tls_id, current_phase, elapsed_time)
        try:
            if getattr(self, "_last_signal_mask", None) is None:
                self._last_signal_mask = {}
            self._last_signal_mask[tls_id] = (
                int(current_phase), np.asarray(mask, dtype=np.float32).copy()
            )
        except Exception:
            pass
        return mask

    def _build_action_mask_raw(self, tls_id, current_phase, elapsed_time):
        """Mask illegal signal actions: yellow/all-red, early green, max-green keep."""
        greens = self._green_phase_indices(tls_id)
        n = max(1, len(greens))
        mask = np.zeros(n, dtype=np.float32)
        cur_g = self._green_index_of_phase(tls_id, current_phase)
        cur_g = int(np.clip(cur_g, 0, n - 1))
        if self.signal_programs.get(f"{tls_id}_synth"):
            mask[cur_g] = 1.0
            return mask
        kind = self._phase_kind(tls_id, current_phase)
        if self._env_on("SIGNAL_COMMITMENT") and not self.signal_programs.get(f"{tls_id}_synth"):
            from environment.p1_control import commitment_action_mask

            gmin = float(self._min_green_for(tls_id, cur_g))
            gmax = float(self._max_green_for(tls_id, cur_g))
            try:
                next_g = int(self._fallback_switch_index(tls_id, cur_g, n))
            except Exception:
                next_g = (int(cur_g) + 1) % int(n)
            return commitment_action_mask(
                n, cur_g, float(elapsed_time), gmin, gmax, next_g, kind == "green"
            )
        last_decision = float(self.signal_programs.get(f"{tls_id}_last_decision", 0.0))
        # First unlock at gmin uses last_decision<=0 (same as step()); do not
        # wait a full GREEN_DECISION_INTERVAL from t=0.
        if last_decision <= 0.0:
            decision_ready = True
        else:
            decision_ready = (
                elapsed_time - last_decision >= self.GREEN_DECISION_INTERVAL - 1e-3
            )
        target_g = self._planned_green_for(tls_id, cur_g)

        # Yellow / all-red, or below min green: hold current green index.
        if kind != 'green':
            mask[cur_g] = 1.0
            return mask

        gmin = self._min_green_for(tls_id, cur_g)
        if elapsed_time < gmin - 1e-3:
            mask[cur_g] = 1.0
            return mask

        # Non-decision hold inside planned T: never expose a non-cur action.
        # Starve used to open starve_g here and leak ~49 fake learnable steps.
        if elapsed_time < target_g - 1e-3 and not decision_ready:
            mask[cur_g] = 1.0
            return mask

        # Planned T reached: must switch (Keep illegal), even if not decision_ready.
        # Prefer a starving phase when force is allowed; else cycle fairness / others.
        if elapsed_time >= target_g - 1e-3:
            if self._starve_may_force(tls_id, cur_g, elapsed_time, target_g, gmin):
                starve_mask = self._starve_override_mask(tls_id, n, cur_g)
                if starve_mask is not None and float(starve_mask.sum()) > 0.5:
                    # Multiple starved → keep sum>=2 for actor gradient; one → hard lock.
                    return starve_mask
                starve_g = self._starving_green_phase(tls_id, cur_g)
                if starve_g is not None:
                    mask[int(starve_g)] = 1.0
                    return mask
            for i in range(n):
                if i != cur_g:
                    mask[i] = 1.0
            mask = self._apply_cycle_fairness_mask(
                mask, tls_id, n, cur_g, must_switch=True
            )
            if not mask.any():
                mask[self._fallback_switch_index(tls_id, cur_g, n)] = 1.0
            return mask

        # Decision-ready inside T: starve only after current green has drained.
        if self._starve_may_force(tls_id, cur_g, elapsed_time, target_g, gmin):
            starve_mask = self._starve_override_mask(tls_id, n, cur_g)
            if starve_mask is not None and float(starve_mask.sum()) > 0.5:
                return starve_mask
            starve_g = self._starving_green_phase(tls_id, cur_g)
            if starve_g is not None:
                mask[int(starve_g)] = 1.0
                return mask

        # Normal 10 s decision point, still inside planned T: Keep is legal.
        mask[:n] = 1.0
        mask = self._apply_cycle_fairness_mask(
            mask, tls_id, n, cur_g, must_switch=False
        )
        if self._top3_mask_active(n) and float(mask.sum()) > 1.5:
            # Only shrink further when fairness left multiple options.
            top = self._congestion_top3_indices(tls_id, n)
            pending = set(self._cycle_pending_demand(tls_id, n))
            for i in range(n):
                if i == cur_g or i in pending:
                    continue
                if i not in top:
                    mask[i] = 0.0
            mask[cur_g] = 1.0
            if not mask.any():
                mask[:n] = 1.0
        return mask

    def get_reward(self):
        return 0.0

    def is_done(self):
        """Return True when the episode should end; set ``_done_reason``.

        Collisions are KPI/reward only — they never hard-stop (that used to
        cause deterministic ~41-step episodes on 3leg_3phases).

        Gridlock early-stop is optional (``terminate_on_gridlock``, default
        False). Learning methods keep running through heavy queues until
        horizon or traffic_exhausted.
        """
        self._done_reason = ""
        if traci.simulation.getMinExpectedNumber() <= 0:
            self._done_reason = "traffic_exhausted"
            return True

        if not self.terminate_on_gridlock:
            return False

        try:
            # Grace after warmup handover: allow the controller to clear inherited queues.
            if self._control_steps < self._gridlock_grace_steps:
                self._gridlock_streak = 0
                return False

            waiting_count = 0
            for v_data in self.sub_results.values():
                spd = self._traci_valid_double(v_data.get(tc.VAR_SPEED, 0.0))
                if spd is not None and spd < 0.1:
                    waiting_count += 1
            if waiting_count > self._gridlock_waiting_threshold:
                self._gridlock_streak += 1
            else:
                self._gridlock_streak = 0
            if self._gridlock_streak >= self._gridlock_hold_steps:
                self._done_reason = "gridlock"
                return True
        except Exception:
            pass

        return False

    def close(self):
        self._close_traci()
