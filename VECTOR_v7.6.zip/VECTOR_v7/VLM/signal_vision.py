"""Asynchronous BEV visual-semantic channel for the signal actor.

The VLM only reports scene semantics. It does not choose signal phases or
produce signal reward weights. Failed/stale observations are marked invalid.
"""
from __future__ import annotations

import copy
import json
import math
import os
import re
import threading
from collections.abc import Mapping
from typing import Any, Callable, Dict, Optional

import numpy as np

SIGNAL_CYCLE_BY_TOPOLOGY = {
    "3leg": 90.0,
    "4leg": 144.0,
    "5leg": 161.0,
}
DEFAULT_NGREEN_BY_TOPOLOGY = {
    "3leg": 3,
    "4leg": 4,
    "5leg": 5,
}

# Engineering refresh intervals for this project's signal cycles.
# Override via SIGNAL_VLM_INTERVAL_{3LEG,4LEG,5LEG} (seconds) for grids.
def _interval_from_env(topo: str, default: float) -> float:
    key = f"SIGNAL_VLM_INTERVAL_{topo.upper()}"
    raw = os.environ.get(key)
    if raw is None or not str(raw).strip():
        return float(default)
    try:
        val = float(str(raw).strip())
    except (TypeError, ValueError, OverflowError):
        return float(default)
    return float(val) if math.isfinite(val) and val > 0.0 else float(default)


SIGNAL_VLM_VISION_INTERVAL_BY_TOPOLOGY = {
    "3leg": _interval_from_env("3leg", 60.0),
    "4leg": _interval_from_env("4leg", 75.0),
    "5leg": _interval_from_env("5leg", 90.0),
}


def _env_bool(name: str, default: bool) -> bool:
    raw = os.environ.get(name)
    if raw is None:
        return bool(default)
    return str(raw).strip().lower() in {"1", "true", "yes", "on", "enabled"}


SIGNAL_VLM_EVENT_TRIGGER_ENABLED = _env_bool(
    "SIGNAL_VLM_EVENT_TRIGGER_ENABLED", True
)
# Teacher-guided Mode-B: longer cooldown so queue/wait spikes do not burn the
# episode budget in the first half (was 30 s; pure vision used 10 s).
SIGNAL_VLM_EVENT_MIN_COOLDOWN_S = 45.0
SIGNAL_VLM_ASYNC_UPDATE = _env_bool("SIGNAL_VLM_ASYNC_UPDATE", True)
SIGNAL_VLM_CACHE_MAX_AGE_MULTIPLIER = 2.0
# Per-topology teacher call caps for ~900 s control (was sized for 1200 s).
# With topology intervals 60/75/90: periodics ≈15/12/10; caps 26/28/30
# leave ample event-burst slots (keep caps; shorter horizon uses fewer calls).
# Override via SIGNAL_TEACHER_MAX_CALLS_{3LEG,4LEG,5LEG} for grids.
def _max_calls_from_env(topo: str, default: int) -> int:
    key = f"SIGNAL_TEACHER_MAX_CALLS_{topo.upper()}"
    raw = os.environ.get(key)
    if raw is None or not str(raw).strip():
        return int(default)
    try:
        val = int(str(raw).strip())
    except (TypeError, ValueError, OverflowError):
        return int(default)
    return max(0, int(val))


SIGNAL_TEACHER_MAX_CALLS_BY_TOPOLOGY = {
    "3leg": _max_calls_from_env("3leg", 26),
    "4leg": _max_calls_from_env("4leg", 28),
    "5leg": _max_calls_from_env("5leg", 30),
}
# Event bands for Stage-S teacher refresh (severity >= 0.7 fires).
# High bands alone cross 0.7; mid bands are diagnostic only (need stacking).
# Wait/queue highs sit above fixed-timing steady state so events are spikes,
# not every cooldown tick (diag: 5leg mean queue≈157, wait often ~100).
SIGNAL_EVENT_MAX_WAIT_HIGH_S = 90.0
SIGNAL_EVENT_MAX_WAIT_MID_S = 65.0
SIGNAL_EVENT_QUEUE_HIGH_BY_TOPOLOGY = {
    "3leg": 95.0,
    "4leg": 180.0,
    "5leg": 220.0,
}
SIGNAL_EVENT_QUEUE_MID_BY_TOPOLOGY = {
    "3leg": 70.0,
    "4leg": 140.0,
    "5leg": 170.0,
}
# Alias kept for older call sites that expect a single thr dict.
SIGNAL_EVENT_QUEUE_THR_BY_TOPOLOGY = dict(SIGNAL_EVENT_QUEUE_HIGH_BY_TOPOLOGY)
# Legacy aliases (= 4leg defaults) for older call sites / tests.
SIGNAL_EVENT_QUEUE_HIGH = SIGNAL_EVENT_QUEUE_HIGH_BY_TOPOLOGY["4leg"]
SIGNAL_EVENT_QUEUE_MID = SIGNAL_EVENT_QUEUE_MID_BY_TOPOLOGY["4leg"]

# Legacy scalar default (4leg/unknown); prefer teacher_max_calls_per_episode().
SIGNAL_TEACHER_MAX_CALLS_PER_EPISODE = SIGNAL_TEACHER_MAX_CALLS_BY_TOPOLOGY["4leg"]
SIGNAL_TEACHER_CONFIDENCE_THRESHOLD = 0.60
# Overridable via SIGNAL_TEACHER_SOFT_START_EPISODES (for short diagnostic grids).
try:
    SIGNAL_TEACHER_SOFT_START_EPISODES = max(
        0, int(str(os.environ.get("SIGNAL_TEACHER_SOFT_START_EPISODES", "5")).strip() or "5")
    )
except (TypeError, ValueError, OverflowError):
    SIGNAL_TEACHER_SOFT_START_EPISODES = 5
# Deliberately disabled unless explicitly enabled by constructor or environment.
SIGNAL_VLM_VISION_ENABLED = _env_bool("SIGNAL_VLM_VISION_ENABLED", False)

VISION_FIELDS = (
    "lane_blockage",
    "spillback",
    "incident_obstruction",
    "roadwork",
    "special_vehicle",
    "unseen_scene",
    "confidence",
    "valid",
)


def topology_key(scenario: str) -> str:
    name = str(scenario or "").strip().lower()
    if name.startswith("3leg"):
        return "3leg"
    if name.startswith("5leg"):
        return "5leg"
    return "4leg"


def vision_interval_s(scenario: str) -> float:
    return float(SIGNAL_VLM_VISION_INTERVAL_BY_TOPOLOGY[topology_key(scenario)])


def vision_cache_max_age_s(scenario: str) -> float:
    return vision_interval_s(scenario) * float(SIGNAL_VLM_CACHE_MAX_AGE_MULTIPLIER)


def teacher_max_calls_per_episode(scenario: str) -> int:
    """Episode teacher API cap for the given scenario / topology."""
    key = topology_key(scenario)
    return int(
        SIGNAL_TEACHER_MAX_CALLS_BY_TOPOLOGY.get(
            key, SIGNAL_TEACHER_MAX_CALLS_PER_EPISODE
        )
    )


def event_queue_bands(scenario: str = "") -> tuple:
    """Return (queue_high, queue_mid) waiting-vehicle bands for ``scenario``."""
    key = topology_key(scenario)
    high = float(SIGNAL_EVENT_QUEUE_HIGH_BY_TOPOLOGY.get(key, SIGNAL_EVENT_QUEUE_HIGH))
    mid = float(SIGNAL_EVENT_QUEUE_MID_BY_TOPOLOGY.get(key, SIGNAL_EVENT_QUEUE_MID))
    return high, mid


def _number(value: Any, default: Optional[float] = None) -> Optional[float]:
    if value is None or isinstance(value, bool):
        return default
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError):
        return default
    return result if math.isfinite(result) else default


def _clip01(x: Any) -> float:
    value = _number(x, 0.0)
    return float(max(0.0, min(1.0, value if value is not None else 0.0)))


# Teacher aux sample weights (Stage-S). Routine imbalance is weakly guided;
# hard visual / geometric spill events keep full weight.
TEACHER_SEVERITY_HARD = 1.0
TEACHER_SEVERITY_GEOMETRIC = 0.7
TEACHER_SEVERITY_ROUTINE = 0.30
TEACHER_SEVERITY_GEOMETRIC_SPILL_THR = 0.5


def teacher_sample_severity(
    visual_event: Any = "none",
    spill_proxy: float = 0.0,
) -> float:
    """Per-sample Teacher CE weight in (0, 1].

    v4: weight only by simulator-verifiable evidence. v3 gave hallucination-
    prone visual labels (blockage / special_vehicle - events that never occur
    in the shipped scenarios) the maximum weight 1.0.
    Set SIGNAL_TEACHER_SEVERITY_LEGACY=1 to restore v3 behaviour.
      - geometric spill_proxy >= 0.5 -> 1.0
      - otherwise                    -> 0.30
    """
    try:
        proxy = float(spill_proxy)
    except (TypeError, ValueError, OverflowError):
        proxy = 0.0
    if str(os.environ.get("SIGNAL_TEACHER_SEVERITY_LEGACY", "0")).strip().lower() in (
        "1", "true", "yes", "on"
    ):
        ev = str(visual_event or "none").strip().lower()
        if ev in {"spillback", "blockage", "special_vehicle"}:
            return float(TEACHER_SEVERITY_HARD)
        if math.isfinite(proxy) and proxy >= float(TEACHER_SEVERITY_GEOMETRIC_SPILL_THR):
            return float(TEACHER_SEVERITY_GEOMETRIC)
        return float(TEACHER_SEVERITY_ROUTINE)
    if math.isfinite(proxy) and proxy >= float(TEACHER_SEVERITY_GEOMETRIC_SPILL_THR):
        return float(TEACHER_SEVERITY_HARD)
    return float(TEACHER_SEVERITY_ROUTINE)

def observation_features(sem: Optional[Mapping[str, Any]]) -> list:
    """Return four finite [0,1] features; invalid semantics map to zeros."""
    if not isinstance(sem, Mapping) or (_number(sem.get("valid"), 0.0) or 0.0) < 0.5:
        return [0.0, 0.0, 0.0, 0.0]
    incident = max(
        _clip01(sem.get("incident_obstruction", 0.0)),
        _clip01(sem.get("roadwork", 0.0)),
    )
    return [
        _clip01(sem.get("lane_blockage", 0.0)),
        _clip01(sem.get("spillback", 0.0)),
        incident,
        _clip01(sem.get("special_vehicle", 0.0)),
    ]


def invalid_semantics() -> dict:
    return {
        "lane_blockage": 0.0,
        "spillback": 0.0,
        "incident_obstruction": 0.0,
        "roadwork": 0.0,
        "special_vehicle": 0.0,
        "unseen_scene": 1.0,
        "confidence": 0.0,
        "valid": 0.0,
    }


def _extract_json_object(raw: str) -> Optional[str]:
    """Extract the first balanced JSON object, respecting escaped quotes."""
    start = raw.find("{")
    if start < 0:
        return None
    depth = 0
    in_string = False
    escaped = False
    for index in range(start, len(raw)):
        char = raw[index]
        if in_string:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                in_string = False
            continue
        if char == '"':
            in_string = True
        elif char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                return raw[start:index + 1]
    return None


def parse_vision_semantics(text: str) -> Dict[str, float]:
    """Strictly parse the eight-field schema; malformed or partial output is invalid."""
    out = invalid_semantics()
    raw = str(text or "").strip()
    if not raw:
        return out
    if "```" in raw:
        match = re.search(r"```(?:json)?\s*([\s\S]*?)```", raw, flags=re.I)
        if match:
            raw = match.group(1).strip()

    candidate = _extract_json_object(raw)
    if candidate is None:
        return out

    def reject_constant(value):
        raise ValueError(f"Non-standard JSON numeric constant: {value}")

    try:
        data = json.loads(
            candidate,
            parse_constant=reject_constant,
        )
    except (json.JSONDecodeError, ValueError, TypeError):
        return out
    if not isinstance(data, Mapping):
        return out

    normalized: Dict[str, float] = {}
    for key in VISION_FIELDS:
        if key not in data:
            return out
        value = data[key]
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            return out
        value = float(value)
        if not math.isfinite(value) or value < 0.0 or value > 1.0:
            return out
        normalized[key] = round(value, 4)

    normalized["valid"] = 1.0 if normalized["valid"] >= 0.5 else 0.0
    if normalized["valid"] < 0.5:
        normalized["lane_blockage"] = 0.0
        normalized["spillback"] = 0.0
        normalized["incident_obstruction"] = 0.0
        normalized["roadwork"] = 0.0
        normalized["special_vehicle"] = 0.0
        normalized["unseen_scene"] = max(normalized["unseen_scene"], 0.8)
        normalized["confidence"] = min(normalized["confidence"], 0.3)
    return normalized


def event_severity(
    state: Mapping[str, Any],
    scenario: str = "",
) -> float:
    """Heuristic [0,1] for event-triggered teacher refresh."""
    state = state if isinstance(state, Mapping) else {}
    stats = state.get("stats") or {}
    if not isinstance(stats, Mapping):
        stats = {}
    scen = str(scenario or "").strip()
    if not scen:
        scen = str(
            state.get("junction_name")
            or state.get("scenario")
            or state.get("scenario_key")
            or ""
        )
    q_high, q_mid = event_queue_bands(scen)
    max_wait = _number(stats.get("max_waiting_time", stats.get("max_wait", 0.0)), 0.0) or 0.0
    for k, v in stats.items():
        if str(k).startswith("max_wait_"):
            w = _number(v, 0.0) or 0.0
            if w > max_wait:
                max_wait = w
    queue = _number(stats.get("queue_length", stats.get("avg_queue_length", 0.0)), 0.0) or 0.0
    collisions = _number(state.get("collisions", 0), 0.0) or 0.0
    teleports = _number(state.get("teleports", 0), 0.0) or 0.0

    score = 0.0
    if max_wait >= SIGNAL_EVENT_MAX_WAIT_HIGH_S:
        score = max(score, 0.80)
    elif max_wait >= SIGNAL_EVENT_MAX_WAIT_MID_S:
        score = max(score, 0.55)
    if queue >= q_high:
        score = max(score, 0.75)
    elif queue >= q_mid:
        score = max(score, 0.50)
    if collisions > 0.0 or teleports > 0.0:
        score = max(score, 0.95)
    return _clip01(score)


def _snapshot_for_vision(state: Mapping[str, Any]) -> dict:
    """Copy the renderer inputs so background inference never reads mutating state."""
    state = state if isinstance(state, Mapping) else {}
    stats = state.get("stats") or {}
    phase_labels = state.get("phase_labels") or {}
    snap = {
        "cavs": state.get("cavs") or {},
        "hdvs": state.get("hdvs") or {},
        "signals": state.get("signals") or {},
        "stats": stats if isinstance(stats, Mapping) else {},
        "phase_labels": dict(phase_labels) if isinstance(phase_labels, Mapping) else {},
        "collisions": state.get("collisions", 0),
        "teleports": state.get("teleports", 0),
        "sim_time": stats.get("time") if isinstance(stats, Mapping) else None,
        "junction_name": state.get("junction_name"),
        "image_source": "sumo_bev_synthetic",
    }
    if "events_visual" in state:  # v7.1: render injected events for the teacher too
        snap["events_visual"] = list(state.get("events_visual") or [])
    try:
        return copy.deepcopy(snap)
    except Exception:
        # State snapshots are expected to be simple dictionaries; retain a
        # safe shallow fallback for unusual non-copyable values.
        return {
            **snap,
            "cavs": dict(snap["cavs"]) if isinstance(snap["cavs"], Mapping) else {},
            "hdvs": dict(snap["hdvs"]) if isinstance(snap["hdvs"], Mapping) else {},
            "signals": dict(snap["signals"]) if isinstance(snap["signals"], Mapping) else {},
            "stats": dict(snap["stats"]) if isinstance(snap["stats"], Mapping) else {},
            "phase_labels": dict(snap["phase_labels"]),
        }


class SignalVisionScheduler:
    """Async BEV → vision-schema VLM; never blocks control when async is enabled."""

    def __init__(
        self,
        *,
        encoder: Any,
        scenario: str,
        enabled: Optional[bool] = None,
        on_update: Optional[Callable[[Dict[str, float]], None]] = None,
        fail_stop_on_vlm_error: bool = False,
        max_consecutive_failures: int = 3,
    ):
        self.encoder = encoder
        self.scenario = str(scenario or "4leg")
        self.enabled = SIGNAL_VLM_VISION_ENABLED if enabled is None else bool(enabled)
        self.on_update = on_update
        self.fail_stop_on_vlm_error = bool(fail_stop_on_vlm_error)
        self.max_consecutive_failures = max(1, int(max_consecutive_failures))
        self._vlm_fatal_error = None
        # Keep encoder fail-stop in sync so teacher fetch re-raises into workers.
        if encoder is not None:
            try:
                encoder.fail_stop_on_vlm_error = bool(self.fail_stop_on_vlm_error)
            except Exception:
                pass
        self.interval_s = vision_interval_s(self.scenario)
        self.cache_max_age_s = vision_cache_max_age_s(self.scenario)
        self._max_teacher_calls = int(teacher_max_calls_per_episode(self.scenario))
        self.event_enabled = bool(SIGNAL_VLM_EVENT_TRIGGER_ENABLED)
        self.event_cooldown_s = float(SIGNAL_VLM_EVENT_MIN_COOLDOWN_S)
        self._lock = threading.RLock()
        self._thread_running = False
        self._active_generation: Optional[int] = None
        self._generation = 0
        # Separate teacher worker so vision + teacher can prefetch in parallel.
        self._teacher_thread_running = False
        self._teacher_active_generation: Optional[int] = None
        self._teacher_generation = 0
        self._last_request_t = -1e18
        self._last_event_t = -1e18
        self._last_success_t = -1e18
        self._last_fingerprint = None
        self._semantics = invalid_semantics()
        self._pending = True
        self._fail_count = 0
        self._episode_teacher_calls = 0
        self._pending_teacher_trigger = False
        self._has_unconsumed_advice = False
        self._advice_request_t = -1e18
        self._soft_start_episodes = int(SIGNAL_TEACHER_SOFT_START_EPISODES)
        self._conf_threshold = float(SIGNAL_TEACHER_CONFIDENCE_THRESHOLD)
        self._training_stage = "S"
        self._stage_episode = 0
        self._last_ep = 0
        self._last_step = 0
        self._teacher_advice = {
            "recommended_phase": -1,
            "confidence": 0.0,
            "valid": 0.0,
            "reason": "reset",
        }
        self._teacher_by_tls = {}

    def reset(self):
        with self._lock:
            self._generation += 1
            self._teacher_generation += 1
            self._vlm_fatal_error = None
            # If an old worker is still executing, keep the busy flag until it
            # exits. Its generation token prevents it from publishing stale data.
            if not self._thread_running:
                self._active_generation = None
            if not self._teacher_thread_running:
                self._teacher_active_generation = None
            self._last_request_t = -1e18
            self._last_event_t = -1e18
            self._last_success_t = -1e18
            self._last_fingerprint = None
            self._semantics = invalid_semantics()
            self._pending = True
            self._fail_count = 0
            self._episode_teacher_calls = 0
            self._pending_teacher_trigger = False
            self._has_unconsumed_advice = False
            self._advice_request_t = -1e18
            self._teacher_advice = {
                "recommended_phase": -1,
                "confidence": 0.0,
                "valid": 0.0,
                "reason": "reset",
            }
            self._teacher_by_tls = {}
            snapshot = dict(self._semantics)
        self._emit(snapshot)

    def set_stage_context(self, stage: str = "S", stage_episode: int = 0):
        """Update curriculum stage; invalidate Stage-S semantics outside S.

        Lon/Lat must not keep using cached spillback/blockage semantics from
        Stage-S (those feed signal-reward residual via ``vlm_signal_semantic``).
        """
        emit_snapshot = None
        with self._lock:
            prev = str(getattr(self, "_training_stage", "S") or "S")
            self._training_stage = str(stage or "S")
            try:
                self._stage_episode = int(stage_episode or 0)
            except (TypeError, ValueError, OverflowError):
                self._stage_episode = 0
            # Leaving Stage-S: drop cache so features()/live reads go invalid.
            if prev == "S" and self._training_stage != "S":
                self._semantics = invalid_semantics()
                self._last_success_t = -1e18
                self._pending = True
                self._pending_teacher_trigger = False
                self._has_unconsumed_advice = False
                self._advice_request_t = -1e18
                self._teacher_advice = self._invalid_teacher("stage_left_S")
                self._teacher_by_tls = {}
                emit_snapshot = dict(self._semantics)
        if emit_snapshot is not None:
            self._emit(emit_snapshot)

    def pending_teacher_trigger(self) -> bool:
        """True when either a new VLM request is due OR completed async advice awaits consumption."""
        with self._lock:
            return bool(self._pending_teacher_trigger or self._has_unconsumed_advice)

    def has_ready_teacher_advice(self, sim_time: Optional[float] = None) -> bool:
        with self._lock:
            if not self._has_unconsumed_advice:
                return False
            if sim_time is not None and self._advice_request_t >= 0.0:
                age = float(sim_time) - float(self._advice_request_t)
                if age < -1e-6 or age > self.cache_max_age_s:
                    return False
            return float(self._teacher_advice.get("valid", 0.0) or 0.0) >= 0.5

    @staticmethod
    def _invalid_teacher(reason="invalid"):
        return {
            "recommended_phase": -1,
            "confidence": 0.0,
            "valid": 0.0,
            "visual_event": "none",
            "reason": str(reason or "invalid"),
        }

    def last_teacher_advice(self, tls_id=None) -> Dict[str, Any]:
        with self._lock:
            if tls_id is not None and tls_id in self._teacher_by_tls:
                return dict(self._teacher_by_tls[tls_id])
            return dict(self._teacher_advice)

    def features(self, sim_time: float) -> Dict[str, float]:
        t = _number(sim_time, None)
        if t is None:
            return invalid_semantics()
        with self._lock:
            if str(getattr(self, "_training_stage", "S") or "S") != "S":
                return invalid_semantics()
            if self._last_success_t < 0:
                return invalid_semantics()
            age = t - float(self._last_success_t)
            if age < -1e-6 or age > self.cache_max_age_s:
                return invalid_semantics()
            return dict(self._semantics)

    def tick(
        self,
        sim_time: float,
        state: Mapping[str, Any],
        *,
        ep: int = 0,
        step: int = 0,
        action_mask=None,
        n_green: Optional[int] = None,
        training_stage: str = "S",
        stage_episode: int = 0,
        tls_id: Optional[str] = None,
    ) -> Dict[str, float]:
        """Mark a pending teacher refresh; prefetch 3-5s ahead even if action_mask is omitted."""
        inferred_n_green = n_green
        if not self.enabled:
            return invalid_semantics()
        t = _number(sim_time, None)
        if t is None:
            return invalid_semantics()
        state = state if isinstance(state, Mapping) else {}
        stats = state.get("stats") or {}
        if not isinstance(stats, Mapping):
            stats = {}

        stage = str(training_stage or getattr(self, "_training_stage", "S") or "S")
        try:
            stage_ep = int(
                stage_episode
                if stage_episode is not None
                else getattr(self, "_stage_episode", 0)
            )
        except (TypeError, ValueError, OverflowError):
            stage_ep = int(getattr(self, "_stage_episode", 0) or 0)
        with self._lock:
            self._training_stage = stage
            self._stage_episode = stage_ep
            self._last_ep = int(ep)
            self._last_step = int(step)
            last_request_t = self._last_request_t
            last_event_t = self._last_event_t
            ep_calls = int(self._episode_teacher_calls)

        soft_start = int(getattr(self, "_soft_start_episodes", SIGNAL_TEACHER_SOFT_START_EPISODES))
        stage_ready = stage == "S" and stage_ep >= soft_start
        due_periodic = (t - last_request_t) >= self.interval_s - 1e-6
        due_event = False
        severity = 0.0
        if self.event_enabled and (t - last_event_t) >= self.event_cooldown_s - 1e-6:
            severity = event_severity(state, scenario=self.scenario)
            due_event = severity >= 0.7

        reason = "periodic" if due_periodic else ""
        if due_event:
            tags = []
            max_wait = _number(stats.get("max_waiting_time", stats.get("max_wait", 0.0)), 0.0) or 0.0
            queue = _number(stats.get("queue_length", stats.get("avg_queue_length", 0.0)), 0.0) or 0.0
            collisions = _number(state.get("collisions", 0), 0.0) or 0.0
            teleports = _number(state.get("teleports", 0), 0.0) or 0.0
            q_high, _q_mid = event_queue_bands(self.scenario)
            # Tag with the same high bands that alone yield severity >= 0.7.
            if max_wait >= SIGNAL_EVENT_MAX_WAIT_HIGH_S:
                tags.append("max_wait")
            if queue >= q_high:
                tags.append("queue")
            if collisions > 0:
                tags.append("collision")
            if teleports > 0:
                tags.append("teleport")
            reason = "+".join(tags) if tags else "event"

        max_calls = int(
            getattr(self, "_max_teacher_calls", SIGNAL_TEACHER_MAX_CALLS_PER_EPISODE)
        )
        if (
            stage_ready
            and (due_periodic or due_event)
            and ep_calls < max_calls
        ):
            fp = (
                round(severity, 2),
                int(_number(state.get("collisions", 0), 0.0) or 0),
                int(_number(state.get("teleports", 0), 0.0) or 0),
                round(_number(stats.get("queue_length", 0), 0.0) or 0.0, 1),
            )
            with self._lock:
                dedup = (
                    due_event
                    and fp == self._last_fingerprint
                    and (t - self._last_request_t) < self.interval_s
                )
                if not dedup:
                    self._pending_teacher_trigger = True
                    self._last_request_t = t
                    if due_event:
                        self._last_event_t = t
                    self._last_fingerprint = fp
                    print(
                        f"[SignalTeacher] pending reason={reason} sim_t={float(t):.1f}s "
                        f"interval={self.interval_s:.0f}s cooldown={self.event_cooldown_s:.0f}s "
                        f"call_budget={ep_calls}/{max_calls}",
                        flush=True,
                    )
        # Prefetch 3-5 s before the next decision window even when marl_env omits action_mask.
        if stage_ready and ep_calls < max_calls:
            if action_mask is not None:
                try:
                    mask_arr = list(np.asarray(action_mask, dtype=np.float32).reshape(-1))
                except Exception:
                    mask_arr = []
                legal = [i for i, v in enumerate(mask_arr) if float(v) > 0.0]
            else:
                ng = inferred_n_green
                if ng is None:
                    pw = stats.get("phase_avg_waits_s")
                    if isinstance(pw, (list, tuple)) and len(pw) >= 2:
                        ng = len(pw)
                    else:
                        ng = DEFAULT_NGREEN_BY_TOPOLOGY.get(topology_key(self.scenario), 4)
                legal = list(range(max(0, int(ng))))
            soon = False
            signals = state.get("signals") if isinstance(state, Mapping) else {}
            if isinstance(signals, Mapping):
                for sig in signals.values():
                    if not isinstance(sig, Mapping):
                        continue
                    rem = _number(sig.get("remaining_time"), None)
                    if rem is not None and 3.0 <= float(rem) <= 5.2:
                        soon = True
                        break
            if soon and len(legal) >= 2:
                tls_pref = str(tls_id) if tls_id else None
                if tls_pref is None and isinstance(signals, Mapping) and len(signals) == 1:
                    tls_pref = str(next(iter(signals)))
                with self._lock:
                    busy = bool(self._teacher_thread_running)
                    has_ready = bool(self._has_unconsumed_advice)
                    since_req = float(t) - float(self._last_request_t)
                if (not busy) and (not has_ready) and since_req >= min(15.0, 0.5 * self.interval_s):
                    self._launch_teacher(
                        float(t),
                        state,
                        legal_phases=legal,
                        ep=int(ep),
                        step=int(step),
                        event=False,
                        fingerprint=("prefetch", tuple(legal)),
                        reason="prefetch_3_5s",
                        tls_id=tls_pref,
                    )
        return self.features(t)

    def consume_teacher_if_ready(
        self,
        state: Mapping[str, Any],
        legal_phases,
        *,
        tls_id: Optional[str] = None,
        ep: Optional[int] = None,
        step: Optional[int] = None,
        sim_time: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Launch async teacher prefetch on a multi-legal decision step.

        Does not block the control loop when ``SIGNAL_VLM_ASYNC_UPDATE`` is on:
        starts a background worker and returns the latest cached advice (may be
        from a prior prefetch). Sync path used when async is disabled.
        """
        invalid = self._invalid_teacher("no_trigger")
        if not self.enabled:
            return invalid
        legal = []
        for item in list(legal_phases or []):
            try:
                legal.append(int(item))
            except (TypeError, ValueError, OverflowError):
                continue
        legal = sorted(set(p for p in legal if p >= 0))
        t = _number(sim_time, None)
        if t is None:
            stats = (state or {}).get("stats") if isinstance(state, Mapping) else {}
            t = _number((stats or {}).get("time"), 0.0) or 0.0

        with self._lock:
            pending = bool(self._pending_teacher_trigger)
            ready = bool(self._has_unconsumed_advice)
            req_t = float(self._advice_request_t)
            stage = str(self._training_stage or "S")
            stage_ep = int(self._stage_episode or 0)
            ep_calls = int(self._episode_teacher_calls)
            ep_i = int(self._last_ep if ep is None else ep)
            step_i = int(self._last_step if step is None else step)
            busy = bool(self._teacher_thread_running)
        soft_start = int(getattr(self, "_soft_start_episodes", SIGNAL_TEACHER_SOFT_START_EPISODES))
        max_calls = int(
            getattr(self, "_max_teacher_calls", SIGNAL_TEACHER_MAX_CALLS_PER_EPISODE)
        )
        if stage != "S" or stage_ep < soft_start or len(legal) < 2:
            return invalid

        # 1) Deliver completed async advice first so background worker results are never orphaned!
        ready_advice = None
        if ready:
            cand = self.last_teacher_advice(tls_id)
            age = float(t) - req_t if req_t >= 0.0 else 0.0
            rec_p = int(cand.get("recommended_phase", -1))
            max_age = float(self.cache_max_age_s)
            try:
                _v7_age = float(os.environ.get("V7_TEACHER_MAX_AGE_S", "0") or 0.0)
            except (TypeError, ValueError):
                _v7_age = 0.0
            if _v7_age > 0.0:
                # v7: a CE label must describe the state it is attached to. The
                # legacy window (2 x interval = 120-180 s) let advice computed for
                # a snapshot two minutes old label the current decision.
                max_age = min(max_age, _v7_age)
            if (
                float(cand.get("valid", 0.0) or 0.0) >= 0.5
                and -1e-6 <= age <= max_age
                and rec_p in legal
            ):
                # Align green_cycle when advice was prefetched right before this decision window.
                if age <= 15.0:
                    try:
                        sigs = state.get("signals") if isinstance(state, Mapping) else {}
                        if isinstance(sigs, Mapping) and tls_id and tls_id in sigs:
                            cand["green_cycle"] = f"{tls_id}:{int((sigs.get(tls_id) or {}).get('phase', -1))}"
                        elif isinstance(sigs, Mapping) and len(sigs) == 1:
                            only_id, only_sig = next(iter(sigs.items()))
                            cand["green_cycle"] = f"{only_id}:{int((only_sig or {}).get('phase', -1))}"
                    except (TypeError, ValueError, OverflowError):
                        pass
                ready_advice = cand
            with self._lock:
                self._has_unconsumed_advice = False

        # 2) Launch a newly due request if pending and budget/worker allow.
        if pending and ep_calls < max_calls and not busy:
            with self._lock:
                self._pending_teacher_trigger = False
            print(
                f"[SignalTeacher] consume sim_t={float(t):.1f}s legal={legal}",
                flush=True,
            )
            self._launch_teacher(
                float(t),
                state,
                legal_phases=legal,
                ep=ep_i,
                step=step_i,
                event=False,
                fingerprint=("consume", tuple(legal)),
                reason="consume_decision",
                tls_id=tls_id,
            )
            if not SIGNAL_VLM_ASYNC_UPDATE:
                with self._lock:
                    self._has_unconsumed_advice = False
                return self.last_teacher_advice(tls_id)

        if ready_advice is not None:
            return ready_advice
        return invalid

    def _launch_teacher(
        self,
        t: float,
        state: Mapping[str, Any],
        *,
        legal_phases,
        ep: int,
        step: int,
        event: bool,
        fingerprint,
        reason: str,
        tls_id: Optional[str],
    ):
        """Start teacher prefetch (async by default; sync when ASYNC_UPDATE=0)."""
        snap = _snapshot_for_vision(state)
        with self._lock:
            if self._teacher_thread_running:
                return
            self._teacher_thread_running = True
            generation = int(self._teacher_generation)
            self._teacher_active_generation = generation
            self._last_request_t = t
            if event:
                self._last_event_t = t
            self._last_fingerprint = fingerprint
            self._episode_teacher_calls += 1
            call_n = int(self._episode_teacher_calls)
            max_calls = int(
                getattr(self, "_max_teacher_calls", SIGNAL_TEACHER_MAX_CALLS_PER_EPISODE)
            )

        print(
            f"[SignalTeacher] refresh reason={reason} sim_t={float(t):.1f}s "
            f"interval={self.interval_s:.0f}s cooldown={self.event_cooldown_s:.0f}s "
            f"call={call_n}/{max_calls} "
            f"legal={list(legal_phases)}",
            flush=True,
        )
        args = (
            snap,
            list(legal_phases),
            int(ep),
            int(step),
            int(generation),
            float(t),
            None if tls_id is None else str(tls_id),
        )
        if not SIGNAL_VLM_ASYNC_UPDATE:
            self._teacher_worker(*args)
            return
        thread = threading.Thread(
            target=self._teacher_worker,
            args=args,
            daemon=True,
            name="signal-teacher-worker",
        )
        try:
            thread.start()
        except Exception as exc:
            with self._lock:
                if self._teacher_active_generation == generation:
                    self._teacher_thread_running = False
                    self._teacher_active_generation = None
                self._fail_count += 1
            self._note_vlm_failure(exc)
            print(f"[SignalTeacher] unable to start worker: {exc}", flush=True)

    def _teacher_worker(
        self,
        state: dict,
        legal_phases: list,
        ep: int,
        step: int,
        generation: int,
        request_t: float,
        tls_id: Optional[str],
    ):
        """Background teacher fetch; publishes advice when generation still current."""
        emitted = None
        try:
            advice = self._invalid_teacher("encoder_missing")
            try:
                if self.encoder is not None and hasattr(
                    self.encoder, "fetch_signal_teacher_advice"
                ):
                    advice = self.encoder.fetch_signal_teacher_advice(
                        state,
                        legal_phases,
                        prepared_image=None,
                        ep=ep,
                        step=step,
                    )
                    with self._lock:
                        if generation == self._teacher_generation:
                            self._fail_count = 0
            except Exception as exc:
                print(f"[SignalTeacher] request failed: {exc}", flush=True)
                advice = self._invalid_teacher("exception")
                with self._lock:
                    if generation == self._teacher_generation:
                        self._fail_count += 1
                self._note_vlm_failure(exc)

            try:
                phase = int(advice.get("recommended_phase", -1))
            except (TypeError, ValueError, OverflowError):
                phase = -1
            try:
                conf = float(advice.get("confidence", 0.0) or 0.0)
            except (TypeError, ValueError, OverflowError):
                conf = 0.0
            try:
                valid = float(advice.get("valid", 0.0) or 0.0)
            except (TypeError, ValueError, OverflowError):
                valid = 0.0
            legal_set = {int(x) for x in legal_phases}
            cycle = ""
            try:
                sigs = state.get("signals") if isinstance(state, Mapping) else {}
                if isinstance(sigs, Mapping) and tls_id and tls_id in sigs:
                    cycle = f"{tls_id}:{int((sigs.get(tls_id) or {}).get('phase', -1))}"
                elif isinstance(sigs, Mapping) and len(sigs) == 1:
                    only_id, only_sig = next(iter(sigs.items()))
                    cycle = f"{only_id}:{int((only_sig or {}).get('phase', -1))}"
            except (TypeError, ValueError, OverflowError):
                cycle = ""
            if (
                valid >= 0.5
                and conf >= float(SIGNAL_TEACHER_CONFIDENCE_THRESHOLD)
                and phase in legal_set
            ):
                out = {
                    "recommended_phase": int(phase),
                    "confidence": float(conf),
                    "valid": 1.0,
                    "visual_event": str(advice.get("visual_event") or "none"),
                    "reason": str(advice.get("reason") or "ok"),
                    "green_cycle": cycle,
                }
            else:
                out = self._invalid_teacher("below_threshold")

            with self._lock:
                if generation != self._teacher_generation:
                    return
                self._teacher_advice = dict(out)
                if tls_id is not None:
                    self._teacher_by_tls[str(tls_id)] = dict(out)
                if float(out.get("valid", 0.0)) >= 0.5:
                    self._last_success_t = float(request_t)
                    self._advice_request_t = float(request_t)
                    self._has_unconsumed_advice = True
                    ev = str(out.get("visual_event") or "none").strip().lower()
                    spill_val = 1.0 if ev == "spillback" else 0.0
                    block_val = 1.0 if ev == "blockage" else 0.0
                    inc_val = 1.0 if ev == "incident" else 0.0
                    work_val = 1.0 if ev == "roadwork" else 0.0
                    spec_val = 1.0 if ev == "special_vehicle" else 0.0
                    self._semantics = {
                        "lane_blockage": block_val,
                        "spillback": spill_val,
                        "spillback_risk": spill_val,
                        "incident_obstruction": inc_val,
                        "roadwork": work_val,
                        "special_vehicle": spec_val,
                        "unseen_scene": 0.0,
                        "junction_blocked": bool(block_val > 0.5 or inc_val > 0.5),
                        "visual_event": ev,
                        "confidence": float(out.get("confidence", 0.0)),
                        "valid": 1.0,
                    }
                    self._pending = False
                    emitted = dict(self._semantics)
        finally:
            with self._lock:
                if self._teacher_active_generation == generation:
                    self._teacher_thread_running = False
                    self._teacher_active_generation = None
        if emitted is not None:
            self._emit(emitted)

    def _emit(self, sem: Dict[str, float]):
        if callable(self.on_update):
            try:
                self.on_update(dict(sem))
            except Exception:
                # A callback must never break the simulator/control loop.
                pass

    def _note_vlm_failure(self, exc: BaseException):
        """Accumulate consecutive failures; optionally arm fail-stop for train."""
        with self._lock:
            fails = int(self._fail_count)
            if (
                self.fail_stop_on_vlm_error
                and fails >= int(self.max_consecutive_failures)
                and self._vlm_fatal_error is None
            ):
                self._vlm_fatal_error = exc

    def _launch(
        self,
        t: float,
        state: Mapping[str, Any],
        *,
        ep: int,
        step: int,
        event: bool,
        fingerprint,
        reason: str = "periodic",
    ):
        snap = _snapshot_for_vision(state)
        with self._lock:
            if self._thread_running:
                return
            self._thread_running = True
            generation = self._generation
            self._active_generation = generation
            self._last_request_t = t
            if event:
                self._last_event_t = t
            self._last_fingerprint = fingerprint
            self._pending = True

        print(
            f"[SignalVision] refresh reason={reason} sim_t={float(t):.1f}s "
            f"interval={self.interval_s:.0f}s cooldown={self.event_cooldown_s:.0f}s",
            flush=True,
        )
        if not SIGNAL_VLM_ASYNC_UPDATE:
            self._worker(snap, ep, step, generation, t)
            return
        thread = threading.Thread(
            target=self._worker,
            args=(snap, ep, step, generation, t),
            daemon=True,
            name="signal-vision-worker",
        )
        try:
            thread.start()
        except Exception as exc:
            with self._lock:
                if self._active_generation == generation:
                    self._thread_running = False
                    self._active_generation = None
                    self._pending = False
            print(f"[SignalVision] unable to start worker: {exc}", flush=True)
            self._emit(invalid_semantics())

    def _worker(self, state: dict, ep: int, step: int, generation: int, request_t: float):
        emitted = None
        try:
            prepared = self.encoder.prepare_scene_image(
                state, ep=ep, step=step, prefer_key_frame=False, save_to_disk=False
            )
            text = self.encoder.fetch_signal_vision_text(
                state, prepared_image=prepared, ep=ep, step=step
            )
            sem = parse_vision_semantics(text)
            with self._lock:
                if generation == self._generation:
                    self._pending = False
                    if float(sem.get("valid", 0.0)) >= 0.5:
                        self._semantics = sem
                        self._last_success_t = float(request_t)
                        self._fail_count = 0
                    else:
                        self._fail_count += 1
                        # Retain a recent good result until its cache age expires.
                        if self._last_success_t < 0:
                            self._semantics = sem
                    emitted = dict(self._semantics)
        except Exception as exc:
            print(f"[SignalVision] request failed (control continues): {exc}", flush=True)
            with self._lock:
                if generation == self._generation:
                    self._fail_count += 1
                    self._pending = False
                    # Keep the last good semantics when available; otherwise fail closed.
                    if self._last_success_t < 0:
                        self._semantics = invalid_semantics()
                    emitted = dict(self._semantics)
            self._note_vlm_failure(exc)
        finally:
            with self._lock:
                if self._active_generation == generation:
                    self._thread_running = False
                    self._active_generation = None
        if emitted is not None:
            self._emit(emitted)
