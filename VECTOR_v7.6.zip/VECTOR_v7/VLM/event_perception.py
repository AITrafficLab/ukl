"""VLM event perception channel (VECTOR v7.1, scheduler rewritten in v7.5).

Role: perception, not control. The VLM looks at the BEV render (with approach
labels) and reports, per approach, how many lanes are blocked by a
broken-down vehicle or a work zone. The result becomes per-phase capacity
features for the signal policy, the Max-Pressure teacher and the
capacity-aware Max-Pressure baseline. It runs in EVERY stage and in
evaluation (unlike the Stage-S teacher), so a policy trained with it can use
it at test time.

Triggers: periodic (default 30 s) plus numeric-anomaly triggers (a lane stall
reported by the detector-level baseline), with a per-episode call budget.
Events persist for minutes, so a few seconds of VLM latency is acceptable;
the latest valid answer is held until replaced or until it expires.
"""
from __future__ import annotations

import csv
import json
import os
import random
import re
import threading
import time
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence

EVENT_TYPES = ("breakdown", "roadwork", "none")

SYSTEM_PROMPT_EVENT_PERCEPTION = """
You are a traffic-camera perception module looking at a bird's-eye-view (BEV)
render of one signalized intersection.

Normal traffic (NEVER an event):
- White cars are human-driven vehicles; ORANGE cars are connected vehicles.
- Long queues of white/orange cars at a red stop bar are normal congestion.

Events (the only two symbols you must report):
- WORK ZONE (lane closure): a rectangular board with YELLOW-AND-BLACK diagonal
  stripes and a RED border lying across one lane, with a small white square
  sign (red border, black X) next to it.
- BROKEN-DOWN VEHICLE: a DARK car with a thick YELLOW outline and yellow corner
  lights, with a RED-AND-WHITE warning TRIANGLE next to it.

Approach names are printed in white letters on black boxes next to each
approach (e.g. N, S, E, W, FZ). Each event belongs to the approach whose lanes
it lies on, near that approach's stop bar.

Task: for every listed approach, count the lanes covered by a work-zone board
or a broken-down vehicle. Report 0 when you see neither symbol.

Return exactly one JSON object and nothing else:
{"approaches": {"N": {"blocked_lanes": 0, "type": "none"}, ...},
 "confidence": 0.0}
type is one of breakdown | roadwork | none. confidence is in [0, 1].
""".strip()


def build_event_prompt(approaches: Sequence[str]) -> str:
    names = ", ".join(str(a) for a in approaches)
    return (
        f"Approaches in this picture: {names}.\n"
        "Count blocked lanes per approach (broken-down vehicle or work zone only).\n"
        "Return the JSON object only."
    )


def _extract_json(text: str) -> Optional[dict]:
    if not text:
        return None
    m = re.search(r"\{.*\}", str(text), flags=re.S)
    if not m:
        return None
    raw = m.group(0)
    for cand in (raw, raw.replace("'", '"')):
        try:
            obj = json.loads(cand)
            return obj if isinstance(obj, dict) else None
        except (ValueError, TypeError):
            continue
    return None


def parse_event_json(text: str, approaches: Sequence[str], max_lanes: int = 4) -> Dict[str, Any]:
    """-> {"counts": {app: int}, "types": {app: str}, "confidence": float, "valid": 0/1}."""
    obj = _extract_json(text)
    invalid = {"counts": {}, "types": {}, "confidence": 0.0, "valid": 0.0}
    if obj is None:
        return invalid
    apps_obj = obj.get("approaches")
    if not isinstance(apps_obj, Mapping):
        return invalid
    counts: Dict[str, int] = {}
    types: Dict[str, str] = {}
    known = {str(a).upper(): str(a) for a in approaches}
    for key, val in apps_obj.items():
        app = known.get(str(key).strip().upper())
        if app is None or not isinstance(val, Mapping):
            continue
        try:
            k = int(round(float(val.get("blocked_lanes", 0) or 0)))
        except (TypeError, ValueError):
            k = 0
        k = max(0, min(int(max_lanes), k))
        t = str(val.get("type", "none") or "none").strip().lower()
        if t not in EVENT_TYPES:
            t = "none" if k == 0 else "breakdown"
        if k == 0:
            t = "none"
        counts[app] = k
        types[app] = t
    try:
        conf = float(obj.get("confidence", 0.0) or 0.0)
    except (TypeError, ValueError):
        conf = 0.0
    conf = max(0.0, min(1.0, conf))
    return {"counts": counts, "types": types, "confidence": conf, "valid": 1.0}


def fetch_event_perception(encoder, state: Mapping[str, Any], approaches: Sequence[str]) -> Dict[str, Any]:
    """One VLM call through the project's VLMSceneEncoder (duck-typed)."""
    from VLM.vlm_call_config import CHANNEL_SIGNAL_VISION

    img = encoder.prepare_scene_image(dict(state), prefer_key_frame=False, save_to_disk=False)
    if not img:
        raise RuntimeError("no BEV image for event perception")
    messages = [
        {"role": "system", "content": SYSTEM_PROMPT_EVENT_PERCEPTION},
        {"role": "user", "content": [
            {"type": "text", "text": build_event_prompt(approaches)},
            {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{img}"}},
        ]},
    ]
    _mode, _body, max_tokens, _meta = encoder.resolve_call_budget(CHANNEL_SIGNAL_VISION)
    # v7.5: retries=0 -> the scheduler owns retries (rate-limit aware, counted).
    # v7.6: with retries=0 the encoder can no longer double max_tokens after a
    # reasoning model used the whole budget (finish_reason='length', empty
    # content), so do that one budget escalation here (counted by the encoder).
    try:
        raw = encoder._chat_once(messages, max_tokens=max_tokens, retries=0, channel=CHANNEL_SIGNAL_VISION)
    except RuntimeError as exc:
        text = str(exc).lower()
        if "length" not in text or "empty" not in text:
            raise
        bigger = int(min(max(2 * int(max_tokens or 512), 1024), 4096))
        raw = encoder._chat_once(messages, max_tokens=bigger, retries=0, channel=CHANNEL_SIGNAL_VISION)
    return parse_event_json(raw, approaches)


def _env_float(name: str, default: float) -> float:
    try:
        return float(os.environ.get(name, default))
    except (TypeError, ValueError):
        return float(default)


# ---------------------------------------------------------------------------
# v7.5: API error classification, rate-limit aware retry, call accounting
# ---------------------------------------------------------------------------
_RATE_PATTERNS = (
    "429", "rate limit", "ratelimit", "too many requests", "rate_limit",
    "1302", "1303", "1305",            # Zhipu: concurrency / frequency / model overloaded
    "并发", "频率", "访问量过大", "请求过多", "overloaded", "qps",
)
_FATAL_PATTERNS = (
    # checked BEFORE rate limits: Zhipu answers HTTP 429 with code 1113 for an
    # empty balance; retrying that only burns the retry window.
    "余额不足", "无可用资源包", "1113", "insufficient", "invalid api key", "incorrect api key",
    "authentication", "unauthorized", "permission denied", "model not found", "does not exist",
)
_TRANSIENT_PATTERNS = (
    "timeout", "timed out", "connection", "temporarily", "500", "502", "503", "504",
    "server error", "bad gateway", "service unavailable", "empty message content",
    "remote end closed", "reset by peer",
)


def _status_code(exc) -> Optional[int]:
    for obj in (exc, getattr(exc, "response", None)):
        code = getattr(obj, "status_code", None)
        if isinstance(code, int):
            return code
    return None


def classify_vlm_error(exc: BaseException) -> str:
    """'rate_limit' | 'transient' | 'fatal'."""
    code = _status_code(exc)
    name = type(exc).__name__.lower()
    text = f"{name} {exc}".lower()
    if code in (401, 403) or any(p in text for p in _FATAL_PATTERNS):
        return "fatal"
    if code == 429 or "ratelimit" in name or any(p in text for p in _RATE_PATTERNS):
        return "rate_limit"
    if code in (400, 404) or any(p in text for p in ("401", "403")):
        return "fatal"
    if (code is not None and code >= 500) or "timeout" in name or "connection" in name \
            or any(p in text for p in _TRANSIENT_PATTERNS):
        return "transient"
    return "fatal"


def retry_after_s(exc: BaseException) -> Optional[float]:
    resp = getattr(exc, "response", None)
    headers = getattr(resp, "headers", None) or {}
    try:
        val = headers.get("retry-after") or headers.get("Retry-After")
    except Exception:
        val = None
    try:
        return max(0.0, float(val)) if val is not None else None
    except (TypeError, ValueError):
        return None


def backoff_delay(attempt: int, base_s: float, cap_s: float, rng: random.Random,
                  retry_after: Optional[float] = None) -> float:
    """Equal-jitter exponential backoff; a server Retry-After wins (capped)."""
    if retry_after is not None:
        return float(min(max(retry_after, 0.0), max(cap_s, 60.0)))
    d = min(float(cap_s), float(base_s) * (2.0 ** max(0, int(attempt) - 1)))
    return float(d * (0.5 + 0.5 * rng.random()))


_TAG = threading.local()


class vlm_channel_tag:
    """Context manager: attribute encoder calls made inside to a logical channel."""

    def __init__(self, tag: str):
        self.tag = str(tag)

    def __enter__(self):
        self._prev = getattr(_TAG, "tag", None)
        _TAG.tag = self.tag
        return self

    def __exit__(self, *exc):
        _TAG.tag = self._prev
        return False


class VLMCallCounter:
    """Counts every encoder._chat_once invocation (all channels, incl. retries).

    Installed once per encoder by wrapping the instance method; per-episode
    deltas are reported as Metrics/v7_vlm_calls_* so the paper can quote the
    total VLM load per episode (teacher + reward weights + event perception).
    """

    CHANNELS = ("event", "signal_vision", "lon", "lat", "sig")

    def __init__(self):
        self._lock = threading.Lock()
        self.calls = {c: 0 for c in self.CHANNELS}
        self.errors = 0
        self._base = None
        self.episode_reset()

    @classmethod
    def install(cls, encoder):
        existing = getattr(encoder, "_v7_call_counter", None)
        if existing is not None:
            return existing
        counter = cls()
        original = encoder._chat_once

        def counted(messages, *args, **kwargs):
            ch = getattr(_TAG, "tag", None) or str(kwargs.get("channel", "lon"))
            try:
                from VLM.vlm_call_config import normalize_channel
                if ch != "event":
                    ch = normalize_channel(ch)
            except Exception:
                pass
            with counter._lock:
                counter.calls[ch] = counter.calls.get(ch, 0) + 1
            try:
                return original(messages, *args, **kwargs)
            except Exception:
                with counter._lock:
                    counter.errors += 1
                raise

        encoder._chat_once = counted
        encoder._v7_call_counter = counter
        return counter

    def episode_reset(self) -> None:
        with self._lock:
            self._base = (dict(self.calls), int(self.errors))

    def episode_stats(self) -> Dict[str, float]:
        with self._lock:
            base_calls, base_err = self._base
            delta = {c: self.calls.get(c, 0) - base_calls.get(c, 0) for c in set(self.calls) | set(base_calls)}
            err = self.errors - base_err
        out = {f"v7_vlm_calls_{c}": float(delta.get(c, 0)) for c in self.CHANNELS}
        out["v7_vlm_calls_total"] = float(sum(delta.values()))
        out["v7_vlm_errors_total"] = float(err)
        return out


CALL_RECORD_FIELDS = (
    "pid", "episode", "request_t", "arrival_t", "latency_sim_s", "latency_wall_s", "trigger",
    "status", "attempts", "rate_limited", "counts", "types", "confidence",
    "truth_apps", "pred_apps", "tp", "fp", "fn", "tn", "error",
)


class VLMOutageError(RuntimeError):
    """The VLM API stayed unavailable beyond the configured outage policy."""


class EventPerceptionScheduler:
    """Budgeted, rate-limit aware VLM perception (v7.5).

    Cadence
      * periodic every ``interval_s`` (30 s), or ``active_interval_s`` (15 s)
        while the adopted answer reports any blockage;
      * edge trigger when the set of approaches flagged by the numeric stall
        detector changes (a new stall, or a stall clearing = discharge resumed),
        with ``trigger_cooldown_s``; a trigger that arrives while a call is in
        flight is kept pending. (v7.4 triggered on the LEVEL of the flag: one
        call every 10 s for as long as any lane stayed stalled.)
    Answers
      * committed on the main thread at the next tick; ``latency_sim_s`` =
        arrival - request; answers older than ``max_answer_age_s`` are scored
        but not adopted ("late");
      * answer-level metrics compare each answer with the ground truth at its
        snapshot (request) time - perception quality; the time-held,
        "in use" metrics are computed by SUMOEnvironment (v7_evt_perc_*).
    Retries (worker thread)
      * rate_limit: backoff with jitter (Retry-After honoured); transient:
        same backoff; fatal: no retry. Bounded by ``max_attempts`` and
        ``max_retry_wall_s``; the in-flight call blocks new calls, which is
        itself the throttle.
    """

    def __init__(self, encoder, approaches: Sequence[str], *, interval_s: Optional[float] = None,
                 active_interval_s: Optional[float] = None, trigger_cooldown_s: float = 10.0,
                 max_calls: Optional[int] = None, expire_s: Optional[float] = None,
                 max_answer_age_s: Optional[float] = None, min_conf: float = 0.5,
                 async_calls: bool = True, fetch_fn=None, max_attempts: Optional[int] = None,
                 backoff_base_s: Optional[float] = None, backoff_cap_s: Optional[float] = None,
                 max_retry_wall_s: Optional[float] = None, sleep_fn=None, clock=None,
                 rng: Optional[random.Random] = None, record_path_fn=None, log=print,
                 anomaly_cooldown_s: Optional[float] = None, outage_policy: Optional[str] = None,
                 outage_after: Optional[int] = None, probe_interval_s: Optional[float] = None,
                 max_outage_s: Optional[float] = None):
        self.encoder = encoder
        self.approaches = [str(a) for a in approaches]
        self.interval_s = float(interval_s if interval_s is not None else _env_float("V7_EVENT_VLM_INTERVAL_S", 30.0))
        self.active_interval_s = float(active_interval_s if active_interval_s is not None
                                       else _env_float("V7_EVENT_VLM_ACTIVE_INTERVAL_S", 15.0))
        cd = anomaly_cooldown_s if anomaly_cooldown_s is not None else trigger_cooldown_s
        self.trigger_cooldown_s = float(cd)
        self.max_calls = int(max_calls if max_calls is not None else _env_float("V7_EVENT_VLM_MAX_CALLS", 60))
        self.expire_s = float(expire_s if expire_s is not None else 4.0 * self.interval_s)
        self.max_answer_age_s = float(max_answer_age_s if max_answer_age_s is not None
                                      else _env_float("V7_EVENT_VLM_MAX_ANSWER_AGE_S", 45.0))
        self.min_conf = float(min_conf)
        self.async_calls = bool(async_calls)
        self.fetch_fn = fetch_fn or fetch_event_perception
        self.max_attempts = int(max_attempts if max_attempts is not None else _env_float("V7_VLM_MAX_ATTEMPTS", 6))
        self.backoff_base_s = float(backoff_base_s if backoff_base_s is not None else _env_float("V7_VLM_BACKOFF_BASE_S", 2.0))
        self.backoff_cap_s = float(backoff_cap_s if backoff_cap_s is not None else _env_float("V7_VLM_BACKOFF_CAP_S", 30.0))
        self.max_retry_wall_s = float(max_retry_wall_s if max_retry_wall_s is not None
                                      else _env_float("V7_VLM_MAX_RETRY_WALL_S", 90.0))
        self.sleep_fn = sleep_fn or time.sleep
        self.clock = clock or time.monotonic
        self.rng = rng or random.Random(12345)
        self.record_path_fn = record_path_fn
        self.log = log or (lambda *a, **k: None)
        pol = str(outage_policy if outage_policy is not None
                  else os.environ.get("V7_VLM_OUTAGE_POLICY", "wait")).strip().lower()
        self.outage_policy = pol if pol in ("wait", "abort", "continue") else "wait"
        self.outage_after = int(outage_after if outage_after is not None else _env_float("V7_VLM_OUTAGE_AFTER", 3))
        self.probe_interval_s = float(probe_interval_s if probe_interval_s is not None
                                      else _env_float("V7_VLM_PROBE_INTERVAL_S", 30.0))
        self.max_outage_s = float(max_outage_s if max_outage_s is not None
                                  else _env_float("V7_VLM_MAX_OUTAGE_S", 3600.0))
        self._vlm_fatal_error = None
        self._lock = threading.Lock()
        self.episode = -1
        self.reset()

    # ---------------------------------------------------------------- episode
    def reset(self) -> None:
        with self._lock:
            self.episode += 1
            self._generation = getattr(self, "_generation", 0) + 1
            self._busy = False
            self._pending = None
            self._inflight = None
            self._last_request_t = -1e9
            self._last_trigger_t = -1e9
            self._pending_trigger = None
            self._prev_stalled = None
            self._prev_anomaly = False
            self._result = {"counts": {}, "types": {}, "confidence": 0.0, "valid": 0.0}
            self._result_t = -1e9
            self._logged = 0
            self._consec_fail = 0
            self.outage_wall_s = 0.0
            self.outages = 0
            self.c = {k: 0 for k in ("calls", "ok", "invalid", "late", "error", "ratelimited_drop",
                                     "attempts", "retries", "rate_limited", "periodic", "active",
                                     "trigger_new", "trigger_clear", "trigger_legacy", "outage_probe")}
            self.lat_wall: List[float] = []
            self.lat_sim: List[float] = []
            self.ans = {"tp": 0, "fp": 0, "fn": 0, "tn": 0, "n": 0, "exact": 0}

    # ---------------------------------------------------------------- main loop
    def _belief_active(self) -> bool:
        return any(int(k) > 0 for k in (self._result.get("counts") or {}).values()) \
            and float(self._result.get("valid", 0.0)) >= 0.5

    def tick(self, now: float, state: Mapping[str, Any], anomaly: bool = False,
             stalled_apps: Optional[Iterable[str]] = None,
             truth_apps: Optional[Iterable[str]] = None) -> None:
        now = float(now)
        self._commit(now)
        if self._vlm_fatal_error:
            return  # fail-stop already reported; never block or call again
        if self._consec_fail >= self.outage_after and self.outage_policy != "continue":
            self._handle_outage(now, state, truth_apps)
            if self._vlm_fatal_error:
                return
        with self._lock:
            trigger = None
            if stalled_apps is not None:
                cur = frozenset(str(a) for a in stalled_apps)
                prev = self._prev_stalled
                self._prev_stalled = cur
                if prev is not None and cur != prev:
                    self._pending_trigger = "trigger_new" if (cur - prev) else "trigger_clear"
            else:
                rising = bool(anomaly) and not self._prev_anomaly
                self._prev_anomaly = bool(anomaly)
                if rising:
                    self._pending_trigger = "trigger_legacy"
            if self._busy or self.c["calls"] >= self.max_calls:
                return
            if self._pending_trigger and now - self._last_trigger_t >= self.trigger_cooldown_s:
                trigger = self._pending_trigger
            else:
                period = min(self.active_interval_s, self.interval_s) if self._belief_active() else self.interval_s
                if now - self._last_request_t >= period:
                    trigger = "active" if self._belief_active() else "periodic"
            if trigger is None:
                return
            if trigger.startswith("trigger"):
                self._last_trigger_t = now
                self._pending_trigger = None
            self._busy = True
            self.c["calls"] += 1
            self.c[trigger] += 1
            self._last_request_t = now
            gen = self._generation
            truth = sorted(str(a) for a in (truth_apps or ()))
            self._inflight = {"request_t": now, "trigger": trigger, "truth": truth}
        snap = self._snapshot(state)
        args = (snap, gen)
        if self.async_calls:
            threading.Thread(target=self._worker, args=args, daemon=True, name="v7-event-vlm").start()
        else:
            self._worker(*args)
            self._commit(now)

    def _snapshot(self, state: Mapping[str, Any]) -> Dict[str, Any]:
        snap = {k: state.get(k) for k in ("cavs", "hdvs", "signals", "events_visual",
                                          "junction_name", "phase_labels") if k in state}
        st = state.get("stats")
        if isinstance(st, Mapping):  # renderer needs the clock only; never leak v7 diagnostics
            snap["stats"] = {k: v for k, v in st.items() if not str(k).startswith("v7_")}
        return snap

    def _handle_outage(self, now: float, state: Mapping[str, Any], truth_apps) -> None:
        """v7.6: K consecutive failed calls = API outage.

        * abort: report via _vlm_fatal_error -> train_RL saves an emergency
          checkpoint and exits 2 (resume re-runs this episode);
        * wait (default): block the main thread - the simulation is paused, so
          the perception channel never silently goes dark mid-experiment -
          and probe every ``probe_interval_s`` until an answer arrives or
          ``max_outage_s`` passes (then abort as above).
        """
        msg_base = (f"VLM event perception: {self._consec_fail} consecutive failed calls "
                    f"(policy={self.outage_policy})")
        if self.outage_policy == "abort":
            self._vlm_fatal_error = msg_base
            self.log(f"[EventVLM] OUTAGE -> abort: {msg_base}", flush=True)
            return
        self.outages += 1
        t0 = self.clock()
        self.log(f"[EventVLM] OUTAGE at sim t={now:.0f}s: {msg_base}; simulation paused, probing every "
                 f"{self.probe_interval_s:.0f}s for up to {self.max_outage_s:.0f}s", flush=True)
        snap = self._snapshot(state)
        truth = sorted(str(a) for a in (truth_apps or ()))
        probes = 0
        while True:
            elapsed = self.clock() - t0
            if elapsed >= self.max_outage_s:
                self.outage_wall_s += elapsed
                self._vlm_fatal_error = f"{msg_base}; no answer for {elapsed:.0f}s while paused"
                self.log(f"[EventVLM] OUTAGE -> abort after {elapsed:.0f}s", flush=True)
                return
            self.sleep_fn(min(self.probe_interval_s, max(0.0, self.max_outage_s - elapsed)))
            probes += 1
            with self._lock:
                self._busy = True
                self.c["calls"] += 1
                self._inflight = {"request_t": now, "trigger": "outage_probe", "truth": truth}
                gen = self._generation
            self._worker(snap, gen)
            ok = bool(self._pending) and self._pending.get("status") == "ok"
            self._commit(now)
            if ok:
                dt = self.clock() - t0
                self.outage_wall_s += dt
                self._last_request_t = now
                self.log(f"[EventVLM] RECOVERED after {dt:.0f}s ({probes} probes); simulation resumes", flush=True)
                return

    def _worker(self, snap, gen) -> None:
        t0 = self.clock()
        attempts, rl_hits, status, res, err_txt = 0, 0, "error", None, ""
        while True:
            attempts += 1
            try:
                with vlm_channel_tag("event"):
                    res = self.fetch_fn(self.encoder, snap, self.approaches)
                status = "ok" if (res and float(res.get("valid", 0.0)) >= 0.5) else "invalid"
                break
            except Exception as exc:
                kind = classify_vlm_error(exc)
                err_txt = f"{type(exc).__name__}: {str(exc)[:160]}"
                if kind == "rate_limit":
                    rl_hits += 1
                elapsed = self.clock() - t0
                if kind == "fatal" or attempts >= self.max_attempts or elapsed >= self.max_retry_wall_s:
                    status = "ratelimited_drop" if kind == "rate_limit" else "error"
                    break
                delay = backoff_delay(attempts, self.backoff_base_s, self.backoff_cap_s, self.rng,
                                      retry_after_s(exc))
                delay = min(delay, max(0.0, self.max_retry_wall_s - elapsed))
                self.log(f"[EventVLM] {kind} (attempt {attempts}/{self.max_attempts}), "
                         f"retry in {delay:.1f}s: {err_txt}", flush=True)
                self.sleep_fn(delay)
        wall = self.clock() - t0
        with self._lock:
            if gen != self._generation:
                return
            self._pending = {"status": status, "res": res, "attempts": attempts,
                             "rate_limited": rl_hits, "wall": wall, "err": err_txt}

    def _commit(self, now: float) -> None:
        with self._lock:
            pend, info = self._pending, self._inflight
            if pend is None or info is None:
                return
            self._pending, self._inflight, self._busy = None, None, False
            c = self.c
            c["attempts"] += int(pend["attempts"])
            c["retries"] += max(0, int(pend["attempts"]) - 1)
            c["rate_limited"] += int(pend["rate_limited"])
            lat_sim = max(0.0, float(now) - float(info["request_t"]))
            status = pend["status"]
            res = pend["res"] or {}
            row = {"pid": os.getpid(), "episode": self.episode, "request_t": round(info["request_t"], 2),
                   "arrival_t": round(float(now), 2), "latency_sim_s": round(lat_sim, 2),
                   "latency_wall_s": round(float(pend["wall"]), 3), "trigger": info["trigger"],
                   "attempts": int(pend["attempts"]), "rate_limited": int(pend["rate_limited"]),
                   "truth_apps": "|".join(info["truth"]), "error": str(pend.get("err") or "")[:200]}
            if status == "ok":
                self.lat_wall.append(float(pend["wall"]))
                self.lat_sim.append(lat_sim)
                pred = {a for a, k in (res.get("counts") or {}).items() if int(k) > 0}
                truth = set(info["truth"])
                tp, fp = len(pred & truth), len(pred - truth)
                fn = len(truth - pred)
                tn = len(set(self.approaches) - pred - truth)
                for k, v in (("tp", tp), ("fp", fp), ("fn", fn), ("tn", tn)):
                    self.ans[k] += v
                self.ans["n"] += 1
                self.ans["exact"] += int(fp == 0 and fn == 0)
                row.update({"tp": tp, "fp": fp, "fn": fn, "tn": tn, "pred_apps": "|".join(sorted(pred)),
                            "counts": json.dumps(res.get("counts") or {}, sort_keys=True),
                            "types": json.dumps(res.get("types") or {}, sort_keys=True),
                            "confidence": float(res.get("confidence", 0.0))})
                if lat_sim > self.max_answer_age_s:
                    status = "late"
                    c["late"] += 1
                else:
                    c["ok"] += 1
                    self._result, self._result_t = res, float(info["request_t"])
                self._consec_fail = 0
            elif status == "invalid":
                c["invalid"] += 1
            elif status == "ratelimited_drop":
                c["ratelimited_drop"] += 1
                self._consec_fail += 1
            else:
                c["error"] += 1
                self._consec_fail += 1
            row["status"] = status
            log_it = self._logged < 40 and (self._logged < 2 or status != "ok"
                                            or bool(row.get("pred_apps")) or bool(info["truth"]))
            if log_it:
                self._logged += 1
        self._write_record(row)
        if log_it:
            self.log(f"[EventVLM] t={row['request_t']:.0f}s +{lat_sim:.1f}s {status} trig={info['trigger']} "
                     f"pred={row.get('pred_apps', '-') or '-'} truth={row['truth_apps'] or '-'} "
                     f"conf={row.get('confidence', 0.0):.2f} attempts={row['attempts']}", flush=True)

    def _write_record(self, row: Dict[str, Any]) -> None:
        if self.record_path_fn is None:
            return
        try:
            path = self.record_path_fn()
            if not path:
                return
            os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
            new = not os.path.isfile(path)
            with open(path, "a", newline="", encoding="utf-8") as fh:
                w = csv.DictWriter(fh, fieldnames=list(CALL_RECORD_FIELDS), extrasaction="ignore")
                if new:
                    w.writeheader()
                w.writerow({k: row.get(k, "") for k in CALL_RECORD_FIELDS})
        except Exception as exc:
            self.log(f"[EventVLM] call log write failed: {exc}", flush=True)
            self.record_path_fn = None

    # ---------------------------------------------------------------- readers
    def blockage(self, now: float) -> Dict[str, int]:
        """Approach -> blocked lane count from the latest adopted, confident answer."""
        with self._lock:
            res, t = self._result, self._result_t
        if float(res.get("valid", 0.0)) < 0.5 or float(now) - t > self.expire_s:
            return {}
        if float(res.get("confidence", 0.0)) < self.min_conf:
            return {}
        return {a: int(k) for a, k in (res.get("counts") or {}).items() if int(k) > 0}

    def stats(self) -> Dict[str, float]:
        with self._lock:
            c, a = dict(self.c), dict(self.ans)
            lw, ls = list(self.lat_wall), list(self.lat_sim)
        prec = a["tp"] / (a["tp"] + a["fp"]) if (a["tp"] + a["fp"]) else 0.0
        rec = a["tp"] / (a["tp"] + a["fn"]) if (a["tp"] + a["fn"]) else 0.0
        fpr = a["fp"] / (a["fp"] + a["tn"]) if (a["fp"] + a["tn"]) else 0.0
        return {
            "v7_evt_vlm_calls": float(c["calls"]),
            "v7_evt_vlm_fails": float(c["invalid"] + c["error"] + c["ratelimited_drop"]),
            "v7_evt_vlm_ok": float(c["ok"]),
            "v7_evt_vlm_invalid": float(c["invalid"]),
            "v7_evt_vlm_late": float(c["late"]),
            "v7_evt_vlm_errors": float(c["error"]),
            "v7_evt_vlm_ratelimited_drop": float(c["ratelimited_drop"]),
            "v7_evt_vlm_attempts": float(c["attempts"]),
            "v7_evt_vlm_retries": float(c["retries"]),
            "v7_evt_vlm_rate_limited": float(c["rate_limited"]),
            "v7_evt_vlm_periodic": float(c["periodic"]),
            "v7_evt_vlm_active": float(c["active"]),
            "v7_evt_vlm_trig_new": float(c["trigger_new"] + c["trigger_legacy"]),
            "v7_evt_vlm_trig_clear": float(c["trigger_clear"]),
            "v7_evt_vlm_lat_wall_mean": float(sum(lw) / len(lw)) if lw else 0.0,
            "v7_evt_vlm_lat_wall_p95": float(sorted(lw)[min(len(lw) - 1, int(0.95 * len(lw)))]) if lw else 0.0,
            "v7_evt_vlm_lat_sim_mean": float(sum(ls) / len(ls)) if ls else 0.0,
            "v7_evt_ans_n": float(a["n"]),
            "v7_evt_ans_precision": float(prec),
            "v7_evt_ans_recall": float(rec),
            "v7_evt_ans_fp_rate": float(fpr),
            "v7_evt_ans_exact": float(a["exact"] / a["n"]) if a["n"] else 0.0,
            "v7_evt_vlm_outages": float(self.outages),
            "v7_evt_vlm_outage_wall_s": float(self.outage_wall_s),
        }


SCHEDULER_STAT_KEYS = tuple(EventPerceptionScheduler(None, [], async_calls=False, log=None).stats().keys())
