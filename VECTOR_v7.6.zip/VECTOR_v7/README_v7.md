# VECTOR v7.6 —— 接入、训练与门控指南

v7.5 = v7 学习型栈 + VLM 子系统修复 + VLM 事件分支（第 10 节）+ 感知指标拆分、调用节奏、限流重试与调用计数（CHANGELOG 第十节）。先导实验见第 12 节；v7.6 的中断与重复进程防护见 CHANGELOG 第十一节、本文 12.4 节。`docs/bev_events_example.png` 是 VLM 实际看到的事件画面示例。

本包是覆盖式补丁：目录结构与你的仓库一致，只包含新增和修改的文件。所有 v7 行为都由 `--profile v7`（或对应的单项开关）开启；不加开关时，除 CHANGELOG 第二节列出的缺陷修复外，v524 / v6p0 / landable 的行为与原来一致。

## 1. 安装

```bash
cd <你的 VECTOR 仓库根目录>
git stash || cp -r . ../VECTOR_backup          # 先备份
cp -r <解压目录>/VECTOR_v7/* .                  # 覆盖同名文件
git diff --stat                                  # 应只涉及 CHANGELOG 第四节列出的文件
```

`patches/` 下有每个修改文件相对你上传版本的 unified diff，可逐行审阅，或用 `git apply` 代替整文件覆盖。

## 2. 验证

```bash
python tests/test_numpy_core.py      # 9 项：GAE 与 v5 逐位一致、截断、归一化、信号缓冲
python tests/test_v7_pure.py         # 11 项：逐车选项级 GAE 对照暴力展开、影响段奖励、目标速度映射、MP 教师、ValueNorm
python tests/test_v7_glue.py         # 3 项：从 train_RL / marl_env 抽取新增函数，在合成 rollout 上端到端校验
python tests/test_v7_vlm.py          # 1 项：VLM 教师过期标签过滤（真实调度器）
python tests/test_v71_events.py      # 15 项：事件调度/生命周期（假 TraCI）、选道与空位、停滞检测、感知评分、
                                     #        VLM 解析与调度、渲染出图、SUMO 端四种感知模式、KPI 键一致性
pytest -q tests/test_mappo_v7_torch.py   # 需要 torch + torch_geometric（构建环境没有，未运行）
python tools/static_check.py .       # 你项目自带的检查，补丁后 0 问题
python tools/diagnose_v7.py          # 复现诊断中的全部数值
```

## 3. 冒烟

```bash
python train/train_RL.py --profile v7 --smoke --no-vision \
  --sumocfg "environment/sumo_net/4-leg(4phases)/4-leg(4phases).sumocfg"
```

启动日志应出现：
- `[v7] per-agent option-level GAE: value input=61 (lon 23 + signal ctx 38)`；
- `signal_obs_dim=38`；
- `[v7] agent overrides: {...}`。

## 4. 训练与门控（按顺序，任一门不过就停在上一层）

### Gate-L：学习型 CAV 层能否赢 G2（信号固定为 MP）

```bash
python scripts/p0_gate.py --sumocfg "environment/sumo_net/4-leg(4phases)/4-leg(4phases).sumocfg" \
  --configs G2_p0,G6_v7 --lon-episodes 120 --control-seconds 900 --seed 7 --workers 2
```

`GATE-V7` 行只是训练期筛查。通过后再用确定性策略在验证种子上复核，最后在测试种子上报告：

```bash
python scripts/evaluate_policy.py --checkpoints "results/train/p0gate_G6_v7/*/seed_7/checkpoints/best_stage_lon.pt" \
  --seeds validation --workers 4 --out-dir results/eval/G6_v7_val -- \
  --profile v7 --signal-rule maxpressure --eval-stage Lon --no-vision \
  --sumocfg "environment/sumo_net/4-leg(4phases)/4-leg(4phases).sumocfg"
```

### Gate-S：RL 信号能否赢 MP（同一包络）

正式跑 `--profile v7`。Stage-S 使用 MP 教师预热和压力观测，随后用 `evaluate_policy.py --eval-stage S` 把 Best-S 检查点与 `--signal-rule maxpressure` 在验证种子上配对比较。不过门就把 MP 作为信号层，CAV 层沿用 Gate-L 的结果。

### 横向

先做消融：JointAll 对比"仅 Lon 检查点 + SUMO LC2013"。无显著收益就去掉横向头。

### 统计

训练用 `--num-envs 4` 提高吞吐；论文统计仍按 `experiment_seeds.py` 的独立运行种子做均值 ± 置信区间，不要把并行环境当样本。

## 5. 训练时必须盯住的 TensorBoard 指标

| 指标 | 期望 | 异常含义 |
|---|---|---|
| `V7/agent_value_ev` | 前 20 个 Lon 回合升到 > 0.3，之后稳定 | 长期 < 0：价值输入不含所需信息或学习率过低 |
| `V7/lon_epoch0_logratio_dev` | < 1e-4 | 采样与评估分布不一致（tanh 边界、观测缓存） |
| `V7/lon_actor_approx_kl` / `clipfrac` | 0.005–0.02 / 0.05–0.25 | 过大降学习率，长期为 0 说明优势为噪声 |
| `Reward/*` 中的 `v7_inf_seg_len_mean` | 1.5–4 | 恒为 1：follower 链没取到 |
| 安全盾干预率 | 下降并稳定在 5% 附近 | 持续上升：策略在前车附近要求过激的减速 |
| `V7/signal_temperature` | JointAll 中从 0.25 单调升到 0.65 | 不动：信号头没在更新 |

## 6. 消融开关（逐项关闭以定位贡献）

`--no-v7-influence-reward`、`--cav-credit-mode coop_xapp`（回到旧信用）、`--no-v7-rl-owns-glosa`、`--cacc-soft-platoon`、`--no-v7-shield-speed-fix`、`--target-speed-map p1`、`--no-v7-signal-pressure-obs`、`--v7-teacher queue`、`--no-v7-agent-overrides`、`--v7-gmax-budget`（A1：去掉计划 T 强制切换）。

## 7. 验证边界与已知限制

- 已在本地执行：纯 numpy 模块、胶水函数（AST 抽取）、你项目的 `static_check`、未定义名称差分检查、全部文件编译。
- 未执行：torch 集成测试与 SUMO 端到端运行（构建环境无 torch、SUMO 且不能联网）。请先跑 `pytest` 和 `--smoke`，有报错把日志发我。
- 影响段只沿同车道跟随者链。HDV 换道插入会让段长度跳变，这由价值函数吸收；若 `v7_inf_seg_len_mean` 抖动过大，可把 `--v7-inf-max-followers` 降到 4。
- `--v7-signal-pressure-obs` 会把信号观测从 33 维改为 38 维，旧的信号检查点不能直接加载，需要从 Stage-S 重新训练。
- 下一步路线（未实现）：信号输出"下一相位 + 时长档位"的承诺式 SPaT，让 CAV 的绿灯倒计时变为精确值。这是 Gate-L 通过之后提升协同收益的主要方向。

## 8. 两条主线：有 VLM 与无 VLM

两条线共用同一套代码，只差一个开关：

```bash
# VLM 主方法（需本地 VLM 服务，参数同你原来的 VLM 运行方式）
python train/train_RL.py --profile v7 --sumocfg "<场景>" --seed 7
# 无 VLM 对照
python train/train_RL.py --profile v7 --no-vision --sumocfg "<场景>" --seed 7
# 隔离 VLM 本身贡献的消融：同一规则表，不调用 VLM
python train/train_RL.py --profile v7 --vlm-heuristic --sumocfg "<场景>" --seed 7
```

VLM 只在训练期参与（Stage-S 事件门控教师、横向奖励权重），部署策略不需要 VLM。在当前三个场景中没有只能靠视觉发现的事件，预期两条线结果接近；要让 VLM 线显著领先，需要先实现 CHANGELOG 第五节 V7 的事件注入。

## 9. 从候选版本到最终版本

本包是代码完整的候选版本。最终版本由下面的决策树确定，每一步的日志发给我后再出 v7.x 修订：

1. `pytest` 与 `--smoke` 通过 → 进入 Gate-L。
2. Gate-L（v7 CAV 层 vs G2，信号固定 MP）：
   - 通过 → 进入 Gate-S；
   - 未通过 → 按第 5 节指标定位，调 `--v7-value-lr`、`--gamma-seconds`（0.97/0.98/0.99）、`--v7-inf-max-followers`、`--cav-action-interval` 等，最多 3 轮；仍不过则 CAV 层保留 G2 规则栈。
3. Gate-S（RL 信号 vs MP）：通过用 RL 信号，未通过用 MP 信号。
4. 按选定组合跑完整课程：3 个场景 × 5 个运行种子 × {VLM, no-VLM}，在验证种子上选检查点，在测试种子上报告。

## 10. v7.1 VLM 事件研究（信号层）

### 10.1 实验矩阵

事件研究只涉及信号层，用 `GRID_FORCE_EPISODES=250` 只跑 Stage-S（CAV 由 SUMO 驾驶）。每组 3 个场景 × 5 个运行种子：

```bash
COMMON="--profile v7 --sumocfg <场景> --seed <s> --v7-events --v7-event-obs"
GRID_FORCE_EPISODES=250 python train/train_RL.py $COMMON --no-vision --v7-event-perception off      # E-off：无事件信息
GRID_FORCE_EPISODES=250 python train/train_RL.py $COMMON --no-vision --v7-event-perception numeric  # E-num：检测器级强基线
GRID_FORCE_EPISODES=250 python train/train_RL.py $COMMON --no-vision --v7-event-perception vlm      # E-vlm：主方法（只用 VLM 做感知）
GRID_FORCE_EPISODES=250 python train/train_RL.py $COMMON --no-vision --v7-event-perception oracle   # E-oracle：上界
```

`--no-vision` 只关闭 VLM 教师与奖励权重通道；`--v7-event-perception vlm` 仍会使用同一个 VLM 服务做感知。需要验证"教师 + 感知"组合时，去掉 `--no-vision` 再加一组。

规则基线不需要训练，直接评估：

```bash
python train/train_RL.py --profile v7 --no-vision --eval-only --eval-stage S --signal-rule maxpressure \
  --v7-events --v7-mp-capacity-aware --v7-event-perception {off,numeric,vlm,oracle} \
  --eval-seeds validation --eval-out results/eval/mp_<mode>.csv --sumocfg <场景>
```

### 10.2 评估

- 用 `scripts/evaluate_policy.py` 在验证种子上选检查点，在测试种子上报告。事件随 SUMO 种子生成，所以评估事件与训练事件互不重叠。
- 对每个检查点再加跑一组 `--no-v7-events`（无事件测试集），验证感知通道在正常交通下不会帮倒忙（数值检测器可能把溢出误判为阻塞）。
- 使用 `vlm` 感知的组在评估时同样需要 VLM 服务在线。

### 10.3 判定"VLM 带来显著提升"

主指标：`Metrics/v7_evt_halted_in`（事件窗口内平均停驻车辆数）和全程 TIS。比较要用配对 bootstrap 95% 置信区间：

1. E-vlm 显著优于 E-num：VLM 的贡献超出检测器级感知，这是论文主张的必要条件。
2. E-vlm 接近 E-oracle：感知损失小。
3. MP+vlm 优于 MP+off：收益来自感知本身，对控制器类型不敏感。
4. 无事件测试集上 E-vlm 不劣于 E-off。

另外报告 `v7_evt_perc_precision / recall / detect_latency_s` 与 VLM 调用次数。如果第 1 条不成立，结论就应写成"事件感知有价值，但检测器级方法已足够"。这同样是可发表的诚实结论。


## 11. 事件短检查（v7.4）

```powershell
$env:GRID_FORCE_EPISODES = "2"
python train/train_RL.py --profile v7 --no-vision --device cuda --seed 7 `
  --sumocfg "environment/sumo_net/4-leg(4phases)/4-leg(4phases).sumocfg" `
  --v7-events --v7-event-count 2 --v7-event-perception oracle 2>&1 | Out-File -Encoding utf8 v74_oracle.log
# 再跑一次 --v7-event-perception vlm，输出到 v74_vlm.log
```

- `Out-File -Encoding utf8` 让日志是 UTF-8（v7.1 的日志是 PowerShell 默认的 UTF-16）。
- `pj_obj_create: Cannot find proj.db` 是 SUMO 的地理投影警告，与本项目无关，可以忽略；PowerShell 会把它显示成 NativeCommandError。
- `--v7-event-count 2` 让每回合固定 2 个事件（泊松抽样在这两个种子上恰好都是 1）；正式实验用 `--v7-event-rate 2` 或固定数量均可，但各组必须一致。

日志中应看到：

```
[Events] seed=70000 scheduled=… roadwork@W:+361s/180s, …
[Events] ACTIVE roadwork@W #0 mode=convert vid=<车辆ID> lane=3819238#1_0 d_stopline=… until=+180s attempts=1 convert_rejections=0
[Events] DONE roadwork@W #0 vid=<车辆ID>
[EventVLM] t=…s counts={'W': 1} types={'W': 'roadwork'} conf=0.80     # 仅 vlm 运行
```

检查项：

1. `v7_evt_started` 接近 `v7_evt_scheduled`，`v7_evt_converted` 大于 0；如有 FAILED，看 reason。
2. 传送次数与无事件冒烟相比没有明显上升。
3. vlm 运行中 `v7_evt_vlm_fails` 远小于 `v7_evt_vlm_calls`，再看 `v7_evt_perc_recall / precision / fp_rate / detect_latency_s`。
4. vlm 运行前先设 `$env:BEV_SAVE_EVERY = "1"`（默认每 100 次调用才存一张，短检查里存不下来），再打开 `bev_renders/<方法>/<场景>/seed_7/` 中事件期间的图，确认事件画得清楚、方位标签正确。

### 11.1 判断第 2 回合是"还在跑"还是"卡住"

日志里没有逐分钟的进度行，复制日志时如果进程还在第 2 回合，看起来就像停住了。区分方法：

- `Get-Process python | Select-Object Id,CPU,StartTime` 隔 30 秒看两次：CPU 时间在增长说明仍在运行。
- 正常结束会依次出现 `Stage S | Episode 2/2 - …`、`[timing] ep=2 …`、`Episode metrics saved to …`，然后进程退出（exit 0）。
- 如果进程已退出却没有这几行，或者 CPU 时间不再增长超过 5 分钟，那才是故障。这时把完整日志和 `results/train/<方法>/4leg_4phases/seed_7/` 下最新的文件列表发过来。

### 11.2 发送 BEV 图

请把 PNG 文件本身作为附件上传。Markdown 里的本地路径（如 `![](New folder/…png)`）我这边看不到。


## 12. 先导实验（v7.5）：四岔路口 × 3 个种子 × 每组 120 回合

### 12.1 运行

四组只差 `--v7-event-perception` 和结果目录名。事件按 SUMO 种子生成，同一种子下四组遇到的事件完全相同，可以做配对比较。

```powershell
$env:GRID_FORCE_EPISODES = "120"
$env:VLM_API_MAX_RETRIES = "0"   # 关掉 OpenAI SDK 的隐式重试，所有重试都走 v7.5 的计数重试
$cfg = "environment/sumo_net/4-leg(4phases)/4-leg(4phases).sumocfg"
foreach ($mode in "vlm","numeric") { foreach ($s in 7,8,9) {
  Start-Process -NoNewWindow python -ArgumentList @(
    "train/train_RL.py","--profile","v7","--no-vision","--device","cuda","--seed",$s,"--sumocfg",$cfg,
    "--v7-events","--v7-event-count","2","--v7-event-obs","--v7-event-perception",$mode,
    "--results-method","pilot_evt_$mode") -RedirectStandardOutput "logs/pilot_${mode}_s$s.log" -RedirectStandardError "logs/pilot_${mode}_s$s.err"
} }
# 第二批：把 "vlm","numeric" 换成 "off","oracle"
```

- 只有 vlm 组调用 API。按上面的分批，同一时刻最多 3 个任务在调 API。按回放估计，每回合约 41–44 次调用、每回合 12–15 分钟，总计约每分钟 10 次，最多 3 个请求同时在途。
- 规则 MP 基线（不训练）按第 10.1 节的 `--eval-only` 命令单独评估。

### 12.2 每个任务的输出（直接用于论文）

`results/train/pilot_evt_<组>/4leg_4phases/seed_<N>/` 下：

| 文件 | 内容 |
|---|---|
| `vlm_calls_per_episode.csv` | 每回合一行：VLM 总调用次数（含重试）及分渠道次数、感知请求数、重试、限流次数、放弃 / 迟到 / 无效次数、时延均值与 p95、单次答案与使用中的精确率 / 召回率 / 误报率 |
| `vlm_event_calls.csv` | 每次感知调用一行：请求 / 到达仿真时刻、仿真与墙钟时延、触发原因、状态、尝试次数、限流次数、预测与真值进口、TP/FP/FN/TN |
| `episode_metrics.npz` | 上述 34 个 `v7_*` 键与原有 KPI 一起按回合保存 |
| TensorBoard | `Metrics/v7_*`、`Metrics/v7_vlm_calls_*` |

日志每回合一行汇总，例如：
```
[VLM-Calls] ep=37 stage=S total=43 (event=43 teacher=0 lon=0 lat=0) perception_calls=43 retries=2 rate_limited=2 dropped=0 late=0 lat_wall=9.8s ans_P/R/FPR=1.000/0.960/0.000 inuse_P/R/FPR=0.930/0.880/0.021
```

论文中建议同时报告：每回合 VLM 调用次数（均值 ± 标准差）、重试与限流比例、单次答案精确率 / 召回率 / 误报率（感知能力）、使用中指标（控制器实际收到的信息质量），以及检测时延。

### 12.3 Gate-L：在验证种子上确认 G6

训练回合只是筛查。以下命令和判据在看结果之前写定：

```powershell
# G6：事先指定 latest.pt，不挑检查点
python scripts/evaluate_policy.py --checkpoints "results/train/p0gate_G6_v7/4leg_4phases/seed_7/checkpoints/latest.pt" `
  --seeds validation --workers 4 --out-dir results/eval/G6_val -- `
  --profile v7 --signal-rule maxpressure --eval-stage Lon --no-vision --sumocfg $cfg
# G2：同一批验证种子
python scripts/run_landable.py --methods G2 --scenarios 4-leg --seeds 900001,900002,900003,900004,900005,900006,900007,900008,900009,900010 --out-dir results/eval/G2_val
```

判据：G6 平均 TIS 相对 G2 至少下降 1%，逐种子配对 bootstrap 95% 上界小于 0，碰撞和传送不劣于 G2。


### 12.4 重新启动先导实验前（v7.6）

1. **确认是否有重复进程。** 6 个先导任务应该正好对应 6 个 python 进程：

```powershell
Get-CimInstance Win32_Process -Filter "Name='python.exe'" |
  Where-Object { $_.CommandLine -like '*train_RL.py*' } |
  Select-Object ProcessId, CreationDate, CommandLine | Format-List
```

   如果同一个 `--results-method` 加 `--seed` 出现两次，或者有来自其他版本文件夹（例如 `VECTOR_v7.4`）的进程，就是重复运行。

2. **全部停止，清理受影响的结果目录。** E-vlm 组第 2 回合起感知已中断；并且只要存在重复进程，检查点、`episode_metrics.npz` 和 TensorBoard 就可能被交叉写入。建议删除 `results/train/pilot_evt_*/4leg_4phases/` 后，用 v7.6 从头重跑两批。

3. **用 v7.6 启动。** 命令同 12.1 节，默认 `--v7-vlm-outage-policy wait`。启动日志应出现 `[run-lock] …/.run.lock (pid N)`。如果打印 `[ABORT] results directory already in use by PID …`，说明这个目录已经有一份训练在跑。

4. **定期检查。**

```powershell
python tools/summarize_vlm_calls.py results/train/pilot_evt_vlm/4leg_4phases/seed_7/vlm_event_calls.csv `
  results/train/pilot_evt_vlm/4leg_4phases/seed_8/vlm_event_calls.csv results/train/pilot_evt_vlm/4leg_4phases/seed_9/vlm_event_calls.csv
```

   如果出现 `!! more than one process wrote this file`，说明重复运行仍然存在。如果日志出现 `[EventVLM] OUTAGE … simulation paused`，说明 API 中断，仿真已暂停等待；恢复时会打印 `RECOVERED`。失败原因看 CSV 的 `error` 列，或者看日志里的 `[EventVLM] transient/rate_limit (attempt k/6) …` 行。


### 12.5 Gate-L 结论与后续（v7.6）

Gate-L 在验证种子上未通过（CHANGELOG 第十二节）。主系统的 CAV 层采用 G2 规则栈；算力集中到信号层（Gate-S）与 VLM 事件研究。

两项不需要训练的补充评估，用于论文中的消融段：

```powershell
# 1) CAV 层对 TIS 的总体空间：G0（原生 IDM）对 G2，同一批验证种子
python scripts/run_landable.py --methods G0,G2 --scenarios 4-leg --seeds 900001,900002,900003,900004,900005,900006,900007,900008,900009,900010 --out-dir results/eval/G0_G2_val
python tools/paired_compare.py --a "results/eval/G0_G2_val/4leg_G0.csv" --b "results/eval/G0_G2_val/4leg_G2.csv" --name-a G0 --name-b G2

# 2) G6 对 G2 的次要终点（停车次数、油耗、等待时间），只作探索
python tools/paired_compare.py --a "results/eval/G2_val/4leg_G2.csv" --b "results/eval/G6_val/*.csv" --name-a G2 --name-b G6 --out results/eval/G6_vs_G2_val.md
```

如果第 2 项显示某个次要终点有明显差异（例如停车次数大幅下降），它只能作为假设：需要先把它写成主终点和阈值，再在测试种子上用新的评估确认，不能直接写成结论。
