"""Per-CAV option-level (SMDP) GAE with a learned state value (VECTOR v7).

Why this replaces the v4-v6 CAV credit path
-------------------------------------------
``train_RL.compute_gae_for_rollout`` (v4-v6.p1) gives every CAV sample

    A_i(t) = sum_k decay_k * (r_i - b)_{t+k}          (no value function)

with ``b`` an action-independent cross-approach mean and ``decay`` = gamma per
0.2 s step and an extra lambda at every 0.4 s decision. Without a value
bootstrap lambda acts as a second discount: the effective credit horizon is
~6 s (half-life ~4 s) in v5.2.4/v6p0. Eco-approach consequences (arriving on
green, not stopping, the followers it shields) materialise 10-40 s later and
are invisible; the baseline is not state-conditioned, so a CAV stuck in a
queue gets a large negative "advantage" for any action. The residual policy
therefore receives mostly noise, which matches GATE-2 (G3 <= G2).

v7 computes, per agent and per contiguous alive segment,

    delta_n = R_n + gamma^tau_n * V(s_{n+1}) - V(s_n)
    A_n     = delta_n + gamma^tau_n * lambda * A_{n+1}

over the agent's own options (decision -> next decision), with V a learned
agent value V(o_i (+) c) (agents/agent_value.py). gamma is per simulation step
(gamma_seconds ** dt), so the horizon is set in seconds and lambda only trades
bias for variance.

Episode/segment boundaries
  * env done                          -> terminal (bootstrap 0)
  * agent leaves RL control (absent at t+1) -> terminal (bootstrap 0)
  * rollout cut while the agent is alive -> bootstrap V(final obs)
Pure numpy; unit-tested in tests/test_cav_gae_v7.py.
"""
from __future__ import annotations

from typing import Dict, Hashable, List, Mapping, Optional, Sequence, Set, Tuple

import numpy as np

Key = Tuple[int, Hashable]


def agent_option_gae(
    rewards: Sequence[float],
    decision: Sequence[bool],
    values: Sequence[float],
    *,
    gamma: float,
    lam: float,
    bootstrap: float = 0.0,
    terminal: bool = True,
) -> Dict[int, Tuple[float, float]]:
    """Option-level GAE for ONE contiguous segment of ONE agent.

    ``rewards[t]`` is the reward of the transition leaving step t.
    ``decision[t]`` marks steps where a new (executed) option starts.
    ``values[t]`` is read only at decision steps.
    Rewards before the first decision of the segment belong to an option that
    started in an earlier rollout and are not credited.
    Returns ``{t: (advantage, return_target)}`` for decision steps.
    """
    r = np.asarray(rewards, dtype=np.float64).reshape(-1)
    d = np.asarray(decision, dtype=bool).reshape(-1)
    v = np.asarray(values, dtype=np.float64).reshape(-1)
    T = int(r.shape[0])
    if T == 0 or d.shape[0] != T or v.shape[0] != T:
        if T and (d.shape[0] != T or v.shape[0] != T):
            raise ValueError("agent_option_gae: rewards/decision/values length mismatch")
        return {}
    g = float(gamma)
    lam = float(lam)
    dec_idx = np.flatnonzero(d).tolist()
    if not dec_idx:
        return {}
    ends = dec_idx[1:] + [T]
    out: Dict[int, Tuple[float, float]] = {}
    next_adv = 0.0
    last = len(dec_idx) - 1
    tail_value = 0.0 if terminal else float(bootstrap)
    if not np.isfinite(tail_value):
        tail_value = 0.0
    for n in range(last, -1, -1):
        s, e = dec_idx[n], ends[n]
        tau = e - s
        disc = g ** np.arange(tau, dtype=np.float64)
        R = float(np.dot(disc, r[s:e]))
        g_tau = g ** tau
        if n == last:
            v_next = tail_value
            a_next = 0.0
            lam_term = 0.0
        else:
            v_next = float(v[e])
            a_next = next_adv
            lam_term = g_tau * lam * a_next
        delta = R + g_tau * v_next - float(v[s])
        adv = delta + lam_term
        out[s] = (float(adv), float(adv + v[s]))
        next_adv = adv
    return out


def rollout_cav_gae(
    step_rewards: Sequence[Mapping[Hashable, float]],
    step_decisions: Sequence[Set[Hashable]],
    step_alive: Sequence[Set[Hashable]],
    values_at: Mapping[Key, float],
    *,
    gamma: float,
    lam: float,
    env_dones: Optional[Sequence[bool]] = None,
    final_alive: Optional[Set[Hashable]] = None,
    final_values: Optional[Mapping[Hashable, float]] = None,
) -> Tuple[Dict[Key, Tuple[float, float]], Dict[str, int]]:
    """Per-agent option-level GAE over a whole rollout.

    ``step_alive[t]``      agents present (controlled) at step t
    ``step_decisions[t]``  subset of alive agents whose sampled action is
                           executed from step t (new option)
    ``values_at[(t,aid)]`` V at decision steps (missing -> 0, counted)
    ``final_alive``        agents present in the observation after the last step
    ``final_values[aid]``  V of that final observation (bootstrap on rollout cut)
    Returns ``({(t, aid): (adv, ret)}, stats)``.
    """
    n = len(step_rewards)
    if not (len(step_decisions) == n and len(step_alive) == n):
        raise ValueError("rollout_cav_gae: per-step sequences must have equal length")
    dones = [False] * n if env_dones is None else [bool(x) for x in env_dones]
    if len(dones) != n:
        raise ValueError("rollout_cav_gae: env_dones length mismatch")
    final_alive = set(final_alive or ())
    final_values = dict(final_values or {})
    agents: Set[Hashable] = set()
    for s in step_alive:
        agents |= set(s)
    out: Dict[Key, Tuple[float, float]] = {}
    stats = {"agents": 0, "segments": 0, "decisions": 0, "missing_values": 0,
             "bootstrapped_segments": 0}
    for aid in sorted(agents, key=lambda x: str(x)):
        stats["agents"] += 1
        t = 0
        while t < n:
            if aid not in step_alive[t]:
                t += 1
                continue
            start = t
            while t < n and aid in step_alive[t] and not (t > start and dones[t - 1]):
                t += 1
            end = t  # exclusive
            last = end - 1
            if dones[last]:
                terminal, boot = True, 0.0
            elif last == n - 1:
                if aid in final_alive and aid in final_values:
                    terminal, boot = False, float(final_values[aid])
                    stats["bootstrapped_segments"] += 1
                else:
                    terminal, boot = True, 0.0
            else:
                terminal, boot = True, 0.0  # left RL control
            rew = [float((step_rewards[k] or {}).get(aid, 0.0)) for k in range(start, end)]
            dec = [aid in step_decisions[k] for k in range(start, end)]
            vals = []
            for k in range(start, end):
                if aid in step_decisions[k]:
                    key = (k, aid)
                    if key in values_at:
                        vals.append(float(values_at[key]))
                    else:
                        vals.append(0.0)
                        stats["missing_values"] += 1
                else:
                    vals.append(0.0)
            seg = agent_option_gae(rew, dec, vals, gamma=gamma, lam=lam,
                                   bootstrap=boot, terminal=terminal)
            stats["segments"] += 1
            for local_t, pair in seg.items():
                out[(start + local_t, aid)] = pair
                stats["decisions"] += 1
    return out, stats


def build_value_input(agent_vector, context_vector, context_dim: int) -> np.ndarray:
    """Agent-specific global state: own observation (+) shared signal context.

    MAPPO (Yu et al., 2022) recommends agent-specific global state for the
    value input. The signal observation is a compact, already-normalised
    summary of the junction (phase, timers, per-phase queue/count/wait).
    """
    a = np.asarray(agent_vector, dtype=np.float32).reshape(-1)
    c = np.zeros(int(context_dim), dtype=np.float32)
    if context_vector is not None:
        cv = np.asarray(context_vector, dtype=np.float32).reshape(-1)
        k = min(int(context_dim), int(cv.size))
        c[:k] = cv[:k]
    out = np.concatenate([a, c]).astype(np.float32)
    return np.nan_to_num(out, nan=0.0, posinf=5.0, neginf=-5.0)
