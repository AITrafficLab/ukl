#!/usr/bin/env python3
"""Paired seed-level comparison of two evaluation result sets (VECTOR v7.6).

  python tools/paired_compare.py --a "results/eval/G2_val/*.csv" --b "results/eval/G6_val/*.csv" \
      --name-a G2 --name-b G6 --primary avg_time_in_system --out results/eval/G6_vs_G2_val.md

Rows are joined on the ``seed`` column. For every KPI: means, ratio-of-means
change of B vs A, paired bootstrap 95% CI (resampling seeds), exact Wilcoxon
signed-rank p (n <= 20), count of seeds where B is lower, and the between-seed
correlation. Only ``--primary`` is a confirmatory endpoint; all other KPIs are
labelled exploratory (they were not pre-specified).
"""
from __future__ import annotations

import argparse
import csv
import glob
import itertools
import math
import random
from typing import Dict, List

DEFAULT_KPIS = ("avg_time_in_system", "avg_waiting_time", "num_stops", "avg_fuel",
                "collisions_total", "teleports_total", "insertion_backlog")


def load(patterns: List[str]) -> Dict[int, Dict[str, float]]:
    out: Dict[int, Dict[str, float]] = {}
    for pat in patterns:
        for path in sorted(glob.glob(pat)) or ([pat] if pat.endswith(".csv") else []):
            try:
                rows = list(csv.DictReader(open(path, encoding="utf-8-sig")))
            except FileNotFoundError:
                continue
            for r in rows:
                try:
                    sd = int(float(r.get("seed", "nan")))
                except (TypeError, ValueError):
                    continue
                vals = {}
                for k, v in r.items():
                    try:
                        vals[k] = float(v)
                    except (TypeError, ValueError):
                        pass
                out[sd] = vals
    return out


def wilcoxon_exact_p(d: List[float]) -> float:
    d = [x for x in d if abs(x) > 1e-12]
    n = len(d)
    if n == 0 or n > 20:
        return float("nan")
    order = sorted(range(n), key=lambda i: abs(d[i]))
    ranks = [0.0] * n
    i = 0
    while i < n:                                   # average ranks for ties
        j = i
        while j + 1 < n and abs(abs(d[order[j + 1]]) - abs(d[order[i]])) < 1e-12:
            j += 1
        for k in range(i, j + 1):
            ranks[order[k]] = (i + j) / 2.0 + 1.0
        i = j + 1
    w_plus = sum(r for r, x in zip(ranks, d) if x > 0)
    total = sum(ranks)
    w = min(w_plus, total - w_plus)
    cnt = sum(1 for signs in itertools.product((0, 1), repeat=n)
              if sum(r for r, s in zip(ranks, signs) if s) <= w + 1e-9)
    return min(1.0, 2.0 * cnt / 2 ** n)


def compare(a: Dict[int, Dict[str, float]], b: Dict[int, Dict[str, float]], kpi: str,
            n_boot: int = 4000, seed: int = 7) -> Dict[str, float]:
    seeds = sorted(s for s in set(a) & set(b) if kpi in a[s] and kpi in b[s])
    xa = [a[s][kpi] for s in seeds]
    xb = [b[s][kpi] for s in seeds]
    n = len(seeds)
    res = {"n": n}
    if n == 0:
        return res
    ma, mb = sum(xa) / n, sum(xb) / n
    res.update(mean_a=ma, mean_b=mb, rel=(100.0 * (mb / ma - 1.0)) if ma else float("nan"),
               b_lower=sum(1 for p, q in zip(xa, xb) if q < p), p_wilcoxon=wilcoxon_exact_p([q - p for p, q in zip(xa, xb)]))
    if n >= 2 and ma and any(abs(x) > 0 for x in xa):
        rng = random.Random(seed)
        bs = []
        for _ in range(n_boot):
            idx = [rng.randrange(n) for _ in range(n)]
            sa = sum(xa[i] for i in idx)
            if sa:
                bs.append(100.0 * (sum(xb[i] for i in idx) / sa - 1.0))
        bs.sort()
        res.update(ci_lo=bs[int(0.025 * (len(bs) - 1))], ci_hi=bs[int(0.975 * (len(bs) - 1))])
        sa_ = math.sqrt(sum((x - ma) ** 2 for x in xa) / (n - 1))
        sb_ = math.sqrt(sum((x - mb) ** 2 for x in xb) / (n - 1))
        if sa_ > 0 and sb_ > 0:
            res["corr"] = sum((p - ma) * (q - mb) for p, q in zip(xa, xb)) / ((n - 1) * sa_ * sb_)
    return res


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--a", nargs="+", required=True, help="CSV paths/globs of the reference (A)")
    ap.add_argument("--b", nargs="+", required=True, help="CSV paths/globs of the candidate (B)")
    ap.add_argument("--name-a", default="A")
    ap.add_argument("--name-b", default="B")
    ap.add_argument("--primary", default="avg_time_in_system")
    ap.add_argument("--kpis", default=",".join(DEFAULT_KPIS))
    ap.add_argument("--threshold", type=float, default=-1.0, help="primary pass: rel <= threshold %% and CI upper < 0")
    ap.add_argument("--out", default="")
    args = ap.parse_args(argv)
    A, B = load(args.a), load(args.b)
    kpis = [args.primary] + [k for k in args.kpis.split(",") if k and k != args.primary]
    lines = [f"# {args.name_b} vs {args.name_a} (paired by seed)", "",
             f"| KPI | role | n | {args.name_a} | {args.name_b} | change | 95% CI | Wilcoxon p | {args.name_b} lower | corr |",
             "|---|---|---:|---:|---:|---:|---|---:|---:|---:|"]
    verdict = ""
    for k in kpis:
        r = compare(A, B, k)
        if not r.get("n"):
            continue
        role = "primary" if k == args.primary else "exploratory"
        ci = f"[{r['ci_lo']:+.2f}%, {r['ci_hi']:+.2f}%]" if "ci_lo" in r else "-"
        fmt = lambda v, spec: "-" if v is None or (isinstance(v, float) and math.isnan(v)) else format(v, spec)
        rel_txt = fmt(r["rel"], "+.2f") + ("%" if fmt(r["rel"], "+.2f") != "-" else "")
        lines.append(f"| {k} | {role} | {r['n']} | {r['mean_a']:.3f} | {r['mean_b']:.3f} | {rel_txt} | {ci} | "
                     f"{fmt(r['p_wilcoxon'], '.3f')} | {r['b_lower']}/{r['n']} | {fmt(r.get('corr', float('nan')), '+.2f')} |")
        if k == args.primary and "ci_hi" in r:
            ok = r["rel"] <= args.threshold and r["ci_hi"] < 0.0
            verdict = (f"Primary ({k}): {'PASS' if ok else 'FAIL'} — change {r['rel']:+.2f}% "
                       f"(threshold {args.threshold:+.1f}%), 95% CI upper {r['ci_hi']:+.2f}%.")
            if not ok and r["ci_lo"] > args.threshold:
                verdict += (f" The CI lower bound {r['ci_lo']:+.2f}% does not reach the threshold: "
                            f"an effect of that size is inconsistent with these data.")
    lines += ["", verdict, "",
              "Exploratory rows were not pre-specified; any claim based on them needs a new, "
              "pre-registered confirmation on untouched seeds (TEST_SEEDS)."]
    text = "\n".join(lines)
    print(text)
    if args.out:
        with open(args.out, "w", encoding="utf-8") as fh:
            fh.write(text + "\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
