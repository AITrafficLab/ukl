#!/usr/bin/env python3
"""Summarise vlm_event_calls.csv files (VECTOR v7.5+).

  python tools/summarize_vlm_calls.py results/train/pilot_evt_vlm/4leg_4phases/seed_*/vlm_event_calls.csv

Per file and pooled: answer-level precision / recall / FPR over successful
answers, status counts, error messages grouped, latency, and a check that
each file was written by ONE process (v7.6 'pid' column).
"""
from __future__ import annotations

import collections
import csv
import sys


def summarize(paths):
    pooled = collections.Counter()
    for path in paths:
        rows = list(csv.DictReader(open(path, encoding="utf-8-sig")))
        st = collections.Counter(r.get("status", "") for r in rows)
        ok = [r for r in rows if r.get("status") == "ok"]
        c = collections.Counter()
        for r in ok:
            for k in ("tp", "fp", "fn", "tn"):
                c[k] += int(r.get(k) or 0)
        pooled.update(c)
        pooled["answers"] += len(ok)
        pooled["calls"] += len(rows)
        pooled["failed"] += st.get("error", 0) + st.get("ratelimited_drop", 0)
        pids = sorted({r.get("pid") for r in rows if r.get("pid")})
        eps = sorted({r.get("episode") for r in rows}, key=lambda x: int(x or 0))
        lat = [float(r["latency_wall_s"]) for r in ok[1:] if r.get("latency_wall_s")]
        print(f"== {path}")
        print(f"   episodes={eps} status={dict(st)} pids={pids or 'n/a (pre-v7.6 file)'}")
        if len(pids) > 1:
            print("   !! more than one process wrote this file -> duplicate runs share a results directory")
        P = c["tp"] / (c["tp"] + c["fp"]) if c["tp"] + c["fp"] else float("nan")
        R = c["tp"] / (c["tp"] + c["fn"]) if c["tp"] + c["fn"] else float("nan")
        F = c["fp"] / (c["fp"] + c["tn"]) if c["fp"] + c["tn"] else float("nan")
        print(f"   answers={len(ok)} precision={P:.3f} recall={R:.3f} FPR={F:.4f} "
              f"wall latency mean={sum(lat) / max(len(lat), 1):.1f}s")
        bad = [r for r in rows if r.get("status") in ("error", "ratelimited_drop")]
        if bad:
            first = min(bad, key=lambda r: (int(r.get("episode") or 0), float(r.get("request_t") or 0)))
            print(f"   failures={len(bad)} first at episode {first.get('episode')} t={first.get('request_t')}")
            msgs = collections.Counter((r.get("error") or "(no error text: pre-v7.6 file)")[:120] for r in bad)
            for m, k in msgs.most_common(5):
                print(f"     {k:4d} x {m}")
        for r in ok:
            if int(r.get("fp") or 0) or int(r.get("fn") or 0):
                print(f"   miss/false alarm: ep={r.get('episode')} t={r.get('request_t')} "
                      f"pred={r.get('pred_apps') or '-'} truth={r.get('truth_apps') or '-'} conf={r.get('confidence')}")
    c = pooled
    if c["answers"]:
        P = c["tp"] / (c["tp"] + c["fp"]) if c["tp"] + c["fp"] else float("nan")
        R = c["tp"] / (c["tp"] + c["fn"]) if c["tp"] + c["fn"] else float("nan")
        F = c["fp"] / (c["fp"] + c["tn"]) if c["fp"] + c["tn"] else float("nan")
        print(f"== POOLED: {c['answers']} answers, precision={P:.3f} recall={R:.3f} FPR={F:.4f}; "
              f"{c['failed']} of {c['calls']} calls failed")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    summarize(sys.argv[1:])
