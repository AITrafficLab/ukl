"""Reproduce the numeric evidence behind VECTOR v7 (numpy only, ~1 s).

  python tools/diagnose_v7.py
Assumptions are printed next to every number.
"""
import math

import numpy as np


def softmax(z):
    z = np.asarray(z, float) - np.max(z)
    e = np.exp(z)
    return e / e.sum()


def horizon(gamma_step, lam, steps_per_decision, dt=0.2):
    per_s = gamma_step ** (1 / dt) * lam ** (1 / (steps_per_decision * dt))
    return per_s, 1 / (1 - per_s), math.log(0.5) / math.log(per_s)


def main():
    print("== D1 CAV credit horizon of the critic-free relative GAE (train_RL v4-v6.p1) ==")
    for name, g, lam, h in (("v5.2.4/v6p0 residual (gamma 0.99/step, lambda 0.95, 0.4 s)", 0.99, 0.95, 2),
                            ("v6p1 (gamma_s 0.98, lambda 0.95, 1 s)", 0.98 ** 0.2, 0.95, 5)):
        ps, H, hl = horizon(g, lam, h)
        print(f"  {name}: decay/s={ps:.3f}, effective horizon={H:.1f} s, half-life={hl:.1f} s")
    print("  v7 (value bootstrap, gamma_s 0.98): horizon 1/(1-0.98) = 50 s; lambda only trades bias/variance")

    print("== D2 v6p1 target-speed initialisation ==")
    frac = (0.0 - (-2.2)) / (1.0 - (-2.2))
    print(f"  neutral actor output 0 -> v* = {frac:.4f} * v_lim = {frac * 16.67:.2f} m/s at 60 km/h")
    print("  v7 map: raw 0 -> v* = v_lim (no cap, IDM drives)")

    print("== D3 spurious shield penalty under speed actuation (illustrative scenario) ==")
    sigma_raw = math.exp(-1.35)                      # LongitudinalActor init log_std
    a = np.tanh(0.3942 + np.random.default_rng(0).normal(0, sigma_raw, 200000)) * 1.6 - 0.6
    p_pos = float(np.mean(a > 0.05))
    print(f"  initial residual std={a.std():.2f} m/s^2, P(residual > 0.05)={p_pos:.2f}")
    for trig in (0.2, 0.4):
        rate = trig * p_pos
        eta, hist = 0.05, []
        for _ in range(180):                         # Lon episodes, dual ascent lr 0.02, target 5 %
            eta = float(np.clip(eta + 0.02 * (rate - 0.05), 0.02, 0.5))
        print(f"  if the shield trigger (TTC<2.2s / headway / gap) is active on {trig:.0%} of steps:"
              f" counted 'intervention' rate {rate:.1%} -> eta after 180 eps = {eta:.2f} per step"
              f" (reward scale [-1, 0]); these requests were no-ops (>= a_IDM)")

    print("== D4 joint-stage anchor KL vs temperature (T=0.65) ==")
    anc = np.array([2.0, 0.5, 0.0, -0.5, -1.0])
    z = anc.copy()
    for _ in range(20000):
        z -= 0.5 * (softmax(z / 0.65) - softmax(anc)) / 0.65
    print(f"  BC optimum raw/anchor logit ratio = {((z - z.mean()) / (anc - anc.mean()))[0]:.3f} (= T)")

    print("== D5 Lat -> JointAll entry: argmax signal becomes T=0.65 sampling ==")
    for logits in ([2, 0.5, 0, -0.5, -1], [1, 0.6, 0.2, 0, -0.5]):
        for t in (0.65, 0.25):
            p = softmax(np.array(logits, float) / t)
            print(f"  logits={logits} T={t}: P(non-argmax)={1 - p.max():.3f}")

    print("== D6 return-RMS reset at Lon -> Lat (joint_lon_sig=0) ==")
    mu, sd, y = -850.0, 120.0, (-900 + 850.0) / 120.0
    print(f"  V_raw before={y * sd + mu:.0f}, after reset to (0,1)={y:.3f}")

    print("== D7 demand intensity (from shipped .rou/.net, control window 300-1200 s) ==")
    for name, vph, lanes in (("3-leg", 3824, 9), ("4-leg", 6852, 12), ("5-leg", 7024, 17)):
        print(f"  {name}: {vph} veh/h over {lanes} incoming lanes = {vph / lanes:.0f} veh/h/lane "
              f"(near/over saturation for 3-5 phase cycles); CAV share 30 %, CAV tau 0.6 s, accel 3.0")


if __name__ == "__main__":
    main()
