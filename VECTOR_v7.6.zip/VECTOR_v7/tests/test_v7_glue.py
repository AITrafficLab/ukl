"""Glue tests for code added to train_RL.py / marl_env.py (no torch, no SUMO).

The functions are extracted from the patched source files with ``ast`` and
executed against synthetic rollouts / states built like the real ones.
"""
import ast
import os
import sys

import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from train.cav_gae_v7 import build_value_input, rollout_cav_gae  # noqa: E402

try:
    from train.credit_utils import is_lon_noop  # real repo
except Exception:  # overlay-only checkout: identical re-implementation
    def is_lon_noop(noop_steps, step_idx, agent_id):
        s = str(agent_id)
        vid = s[len("cav_lon_"):] if s.startswith("cav_lon_") else (s[4:] if s.startswith("cav_") else s)
        if noop_steps is None or step_idx < 0 or step_idx >= len(noop_steps):
            return False
        return vid in (noop_steps[step_idx] or ())


def _extract(path, names, cls=None):
    src = open(os.path.join(ROOT, path), encoding="utf-8").read()
    tree = ast.parse(src)
    body = tree.body
    if cls:
        body = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == cls).body
    out = []
    for n in body:
        if isinstance(n, ast.FunctionDef) and n.name in names:
            out.append(ast.get_source_segment(src, n))
    assert len(out) == len(names), (path, names)
    import textwrap
    return "\n\n".join(textwrap.dedent(s) for s in out)


class FakeAgent:
    gamma = 0.98 ** 0.2
    gae_lambda = 0.95
    v7_value_context_dim = 4

    def agent_values(self, x):
        x = np.asarray(x, dtype=np.float64)
        return (x[:, 0] * 10.0 - x[:, -1]).astype(np.float32)


def _ns():
    ns = {"np": np, "is_lon_noop": is_lon_noop}
    exec(_extract("train/train_RL.py", ["_v7_signal_context", "_v7_lon_credit"]), ns)
    return ns


def _rollout(n=30, hold=5, seed=0):
    rng = np.random.default_rng(seed)
    obs, acts, rews, noop, dones = [], [], [], [], []
    for t in range(n):
        om = {"signal_0": {"vector": np.array([0.1, 0.2, 0.3, float(t) / n], np.float32)}, "__graph__": {}}
        am, rm = {}, {}
        for v in ("a", "b"):
            if v == "b" and t >= 18:
                continue  # b leaves RL control at t=18
            aid = f"cav_lon_{v}"
            om[aid] = {"vector": rng.normal(size=3).astype(np.float32)}
            am[aid] = (rng.normal(size=1).astype(np.float32) if t % hold == 0 else None)
            rm[aid] = float(rng.normal())
        am["signal_0"] = -1
        rm["signal_0"] = -0.5
        obs.append(om); acts.append(am); rews.append(rm)
        noop.append(frozenset({"a"}) if t == 10 else frozenset())
        dones.append(False)
    nxt = {"cav_lon_a": {"vector": np.ones(3, np.float32)},
           "signal_0": {"vector": np.zeros(4, np.float32)}}
    return {"obs": obs, "actions": acts, "rewards": rews, "lon_noop_vids": noop, "dones": dones}, nxt


def test_v7_lon_credit_matches_direct_computation():
    ns = _ns()
    agent = FakeAgent()
    ro, nxt = _rollout()
    adv = [dict() for _ in range(len(ro["rewards"]))]
    stats = ns["_v7_lon_credit"](agent, ro, nxt, False, adv)
    # direct reference
    alive = [{k for k in o if k.startswith("cav_lon_")} for o in ro["obs"]]
    dec = [{k for k in alive[t] if ro["actions"][t].get(k) is not None and not is_lon_noop(ro["lon_noop_vids"], t, k)}
           for t in range(len(alive))]
    keys = [(t, a) for t in range(len(dec)) for a in sorted(dec[t])]
    X = np.stack([build_value_input(ro["obs"][t][a]["vector"], ro["obs"][t]["signal_0"]["vector"], 4) for t, a in keys])
    V = agent.agent_values(X)
    fv = agent.agent_values(build_value_input(nxt["cav_lon_a"]["vector"], nxt["signal_0"]["vector"], 4)[None])[0]
    ref, _ = rollout_cav_gae(
        [{k: v for k, v in r.items() if k.startswith("cav_lon_")} for r in ro["rewards"]], dec, alive,
        dict(zip(keys, V.tolist())), gamma=agent.gamma, lam=agent.gae_lambda,
        final_alive={"cav_lon_a"}, final_values={"cav_lon_a": float(fv)})
    for (t, a), (A, _R) in ref.items():
        assert abs(adv[t][a] - A) < 1e-5
    assert (10, "cav_lon_a") not in ref and "cav_lon_a" not in adv[10]   # noop step not a decision
    assert stats["bootstrapped_segments"] == 1                           # a alive at cut, b left
    assert len(ro["v7_value_inputs"]) == len(ro["v7_value_returns"]) == len(ref)
    assert all(np.isfinite(ro["v7_value_returns"]))


def test_v7_lon_credit_terminal_no_bootstrap():
    ns = _ns()
    ro, nxt = _rollout()
    adv = [dict() for _ in range(len(ro["rewards"]))]
    st = ns["_v7_lon_credit"](FakeAgent(), ro, nxt, True, adv)
    assert st["bootstrapped_segments"] == 0


def test_marl_env_influence_hook_rewrites_only_lon():
    src = _extract("environment/marl_env.py", ["_apply_v7_influence_reward", "_v7_kpis"],
                   cls="MultiAgentTrafficEnv")
    tree = ast.parse(open(os.path.join(ROOT, "environment/marl_env.py"), encoding="utf-8").read())
    consts = {n.targets[0].id: ast.literal_eval(n.value) for n in tree.body
              if isinstance(n, ast.Assign) and getattr(n.targets[0], "id", "") in
              ("V7_EVENT_KPI_KEYS", "V7_VLM_COUNTER_KEYS")}
    from VLM.event_perception import SCHEDULER_STAT_KEYS
    consts["V7_EVENT_VLM_KEYS"] = tuple(SCHEDULER_STAT_KEYS) + tuple(consts["V7_VLM_COUNTER_KEYS"])
    ns = {"os": os, "_finite_float": lambda v, d=0.0: float(v) if v is not None else d, **consts}
    exec(src, ns)
    from types import SimpleNamespace
    env = SimpleNamespace()
    veh = lambda sp, fol=None: {"speed": sp, "follower_id": fol, "follower_gap": 5.0, "lane_max_speed": 16.67,
                                "length": 5.0, "acceleration": 0.0, "jerk": 0.0, "ttc": 99.0}
    state = {"cavs": {"c1": veh(16.67, "h1")}, "hdvs": {"h1": veh(0.0)}}
    rewards = {"cav_lon_c1": -0.9, "cav_lat_c1": 0.3, "signal_0": -0.4}
    gdict = {}
    ns["_apply_v7_influence_reward"](env, state, rewards, gdict)
    assert rewards["cav_lat_c1"] == 0.3 and rewards["signal_0"] == -0.4
    assert -1.0 <= rewards["cav_lon_c1"] <= 0.0 and rewards["cav_lon_c1"] != -0.9
    assert gdict["v7_inf_seg_len_mean"] == 2.0
    ns["_apply_v7_influence_reward"](env, state, {"cav_lon_c1": 0.0}, {})
    kpi = ns["_v7_kpis"](env)
    assert kpi["v7_inf_seg_len_ep_mean"] == 2.0 and env._v7_inf_acc[3] == 2
    assert ns["_v7_kpis"](SimpleNamespace())["v7_inf_reward_ep_mean"] == 0.0
    ev = ns["_v7_kpis"](SimpleNamespace(raw_state={"stats": {"v7_evt_started": 2.0}}))
    assert ev["v7_evt_started"] == 2.0 and ev["v7_evt_vlm_calls"] == 0.0
    counted = SimpleNamespace(raw_state={"stats": {}}, _v7_vlm_counter=SimpleNamespace(
        episode_stats=lambda: {"v7_vlm_calls_total": 41.0, "v7_vlm_calls_event": 41.0}))
    ev2 = ns["_v7_kpis"](counted)
    assert ev2["v7_vlm_calls_total"] == 41.0 and ev2["v7_vlm_calls_event"] == 41.0


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for f in fns:
        f()
        print("PASS", f.__name__)
    print(f"{len(fns)} glue tests passed")
