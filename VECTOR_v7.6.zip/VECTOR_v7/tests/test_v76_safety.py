"""VECTOR v7.6: VLM outage policy, call-log columns, token-budget retry, run lock."""
import ast
import csv
import json
import os
import sys
import tempfile
import textwrap
import types

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from VLM import event_perception as ep  # noqa: E402

APPS = ["N", "S", "E", "W"]
OK = {"counts": {a: 0 for a in APPS}, "types": {}, "confidence": 0.9, "valid": 1.0}


class Clock:
    def __init__(self):
        self.t = 0.0

    def __call__(self):
        return self.t

    def sleep(self, d):
        self.t += float(d)


def _mk(fetch, **kw):
    clk = Clock()
    kw.setdefault("interval_s", 10.0)
    s = ep.EventPerceptionScheduler(None, APPS, fetch_fn=fetch, async_calls=False, log=None,
                                    max_attempts=1, sleep_fn=clk.sleep, clock=clk, **kw)
    return s, clk


def _flaky(n_fail):
    box = {"n": 0}

    def fetch(e, snap, a):
        box["n"] += 1
        if box["n"] <= n_fail:
            raise ConnectionError("Connection error.")
        return dict(OK)
    return fetch, box


def test_wait_policy_pauses_and_recovers():
    fetch, box = _flaky(5)                      # 3 failed calls -> outage, 2 failed probes, then ok
    s, clk = _mk(fetch, outage_policy="wait", outage_after=3, probe_interval_s=30.0, max_outage_s=3600.0)
    for t in (0.0, 10.0, 20.0, 30.0):
        s.tick(t, {"stats": {"time": t}})
    st = s.stats()
    assert s._vlm_fatal_error is None and box["n"] == 6
    assert st["v7_evt_vlm_outages"] == 1 and st["v7_evt_vlm_outage_wall_s"] == 90.0   # 3 probes x 30 s
    assert st["v7_evt_vlm_errors"] == 5 and st["v7_evt_vlm_ok"] == 1 and s._consec_fail == 0


def test_wait_policy_escalates_to_fail_stop():
    fetch, _ = _flaky(10 ** 6)
    s, clk = _mk(fetch, outage_policy="wait", outage_after=3, probe_interval_s=30.0, max_outage_s=120.0)
    for t in (0.0, 10.0, 20.0, 30.0, 40.0):
        s.tick(t, {})
    assert s._vlm_fatal_error and "no answer for" in s._vlm_fatal_error
    assert clk.t <= 120.0 + 1e-9


def test_abort_and_continue_policies():
    fetch, _ = _flaky(10 ** 6)
    s, _ = _mk(fetch, outage_policy="abort", outage_after=3)
    for t in (0.0, 10.0, 20.0, 30.0):
        s.tick(t, {})
    assert s._vlm_fatal_error and "3 consecutive failed calls" in s._vlm_fatal_error
    s2, clk2 = _mk(fetch, outage_policy="continue", outage_after=3)
    for t in (0.0, 10.0, 20.0, 30.0, 40.0):
        s2.tick(t, {})
    assert s2._vlm_fatal_error is None and clk2.t == 0.0 and s2.stats()["v7_evt_vlm_errors"] == 5


def test_invalid_replies_do_not_count_as_outage():
    s, _ = _mk(lambda e, snap, a: {"valid": 0.0}, outage_policy="abort", outage_after=2)
    for t in (0.0, 10.0, 20.0, 30.0):
        s.tick(t, {})
    assert s._vlm_fatal_error is None and s.stats()["v7_evt_vlm_invalid"] == 4


def test_call_log_has_pid_and_error():
    with tempfile.TemporaryDirectory() as d:
        path = os.path.join(d, "vlm_event_calls.csv")
        fetch, _ = _flaky(1)
        s, _ = _mk(fetch, outage_policy="continue", record_path_fn=lambda: path)
        s.tick(0.0, {})
        s.tick(10.0, {})
        rows = list(csv.DictReader(open(path, encoding="utf-8")))
        assert rows[0]["status"] == "error" and "ConnectionError" in rows[0]["error"]
        assert rows[0]["pid"] == str(os.getpid()) and rows[1]["status"] == "ok" and rows[1]["error"] == ""


def test_length_truncation_retries_with_bigger_budget():
    sys.modules.setdefault("VLM.vlm_call_config", types.SimpleNamespace(CHANNEL_SIGNAL_VISION="signal_vision"))
    seen = []

    class Enc:
        def prepare_scene_image(self, state, **kw): return "AAAA"
        def resolve_call_budget(self, ch): return ("low", {}, 512, {})
        def _chat_once(self, msgs, max_tokens=0, retries=0, channel=""):
            seen.append(max_tokens)
            if len(seen) == 1:
                raise RuntimeError("VLM returned empty message content (finish_reason='length', max_tokens=512)")
            return '{"approaches": {"N": {"blocked_lanes": 1, "type": "roadwork"}}, "confidence": 0.9}'

    r = ep.fetch_event_perception(Enc(), {}, APPS)
    assert seen == [512, 1024] and r["counts"]["N"] == 1

    class Enc2(Enc):
        def _chat_once(self, msgs, max_tokens=0, retries=0, channel=""):
            raise RuntimeError("Connection error.")

    try:
        ep.fetch_event_perception(Enc2(), {}, APPS)
        raise AssertionError("non-length errors must propagate to the scheduler")
    except RuntimeError as exc:
        assert "Connection" in str(exc)


def _lock_fns():
    src = open(os.path.join(ROOT, "train", "train_RL.py"), encoding="utf-8").read()
    tree = ast.parse(src)
    code = "\n\n".join(ast.get_source_segment(src, n) for n in tree.body
                       if isinstance(n, ast.FunctionDef) and n.name in ("_pid_alive", "_acquire_run_lock"))
    import time as _time
    ns = {"os": os, "sys": sys, "time": _time}
    exec(code, ns)
    return ns


def test_run_lock_blocks_live_owner_and_takes_over_stale():
    ns = _lock_fns()
    assert ns["_pid_alive"](os.getpid()) and not ns["_pid_alive"](-5)
    with tempfile.TemporaryDirectory() as d:
        p = ns["_acquire_run_lock"](d)
        assert json.load(open(p))["pid"] == os.getpid()
        json.dump({"pid": os.getppid(), "started": "x"}, open(p, "w"))       # live foreign owner
        try:
            ns["_acquire_run_lock"](d)
            raise AssertionError("must refuse a directory owned by a live process")
        except SystemExit as exc:
            assert exc.code == 3
        ns["_acquire_run_lock"](d, force=True)                                # explicit override
        assert json.load(open(p))["pid"] == os.getpid()
        json.dump({"pid": 2 ** 22 + 12345, "started": "x"}, open(p, "w"))    # dead owner
        ns["_acquire_run_lock"](d)
        assert json.load(open(p))["pid"] == os.getpid()


def test_env_reports_event_vlm_fatal_error():
    src = open(os.path.join(ROOT, "environment", "marl_env.py"), encoding="utf-8").read()
    i = src.index('"vlm_fatal_error": (')
    assert '"_v7_event_vlm", None), "_vlm_fatal_error"' in src[i:i + 400]


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for f in fns:
        f()
        print("PASS", f.__name__)
    print(f"{len(fns)} v7.6 safety tests passed")
