"""Integration tests for agents/mappo.py v7 with tiny fake networks.

Run:  pytest -q tests/test_mappo_v7_torch.py
Needs torch + torch_geometric (skipped otherwise). No SUMO required.
"""
import os
import sys

import numpy as np
import pytest

torch = pytest.importorskip("torch")
pytest.importorskip("torch_geometric")
import torch.nn as nn  # noqa: E402

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from agents import mappo as mappo_mod  # noqa: E402
from agents.agent_value import AgentValueNet  # noqa: E402
from agents.mappo import CURRICULUM_STAGES, JOINT_STAGES, MAPPOAgent  # noqa: E402

V7_OVERRIDES = {
    "kl_stop_factor": 1.5, "anchor_kl_adaptive": True, "anchor_kl_target": 0.01,
    "joint_signal_temp_start": 0.25, "joint_signal_temp_anneal_updates": 30,
    "joint_signal_lr_scale": 0.20, "joint_all_signal_lr_scale": 0.10, "joint_signal_adv_scale": 1.0,
    "entropy_coef_lon": 0.0, "actor_lr_signal": 1e-4, "actor_lr_lat": 1e-4,
}  # mirrors train_RL.V7_AGENT_OVERRIDES

OBS_DIM, NODE_F, N_SIG_ACT = 6, 4, 5


class FakeSignal(nn.Module):
    def __init__(self):
        super().__init__()
        self.l = nn.Linear(OBS_DIM, N_SIG_ACT)

    def forward(self, obs):
        z = self.l(obs["vector"])
        m = obs.get("action_mask")
        return z.masked_fill(m <= 0, -1e9) if m is not None else z


class FakeLat(nn.Module):
    """forward() accepts soft_start_beta and returns the blended logits (v6 contract)."""
    KEEP = 1

    def __init__(self):
        super().__init__()
        self.l = nn.Linear(OBS_DIM, 3)

    def _raw(self, obs):
        z = self.l(obs["vector"])
        m = obs.get("action_mask")
        return z.masked_fill(m <= 0, -1e9) if m is not None else z

    def _blend(self, z, beta):
        if beta >= 1.0:
            return z
        p = torch.softmax(z, -1)
        keep = torch.zeros_like(p)
        keep[:, self.KEEP] = 1.0
        return torch.log((beta * p + (1.0 - beta) * keep).clamp_min(1e-12))

    def forward(self, obs, soft_start_beta=1.0):
        return self._blend(self._raw(obs), soft_start_beta)

    def get_action(self, obs, deterministic=False, soft_start_beta=1.0):
        z = self._blend(self._raw(obs), soft_start_beta)
        d = torch.distributions.Categorical(logits=z)
        a = z.argmax(-1) if deterministic else d.sample()
        return a, d.log_prob(a)


class FakeLatNoBetaAPI(FakeLat):
    """Emulates a v5-style actor: get_action blends, forward() does not."""

    def forward(self, obs):  # noqa: D401
        return self._raw(obs)


class FakeLon(nn.Module):
    def __init__(self):
        super().__init__()
        self.mu = nn.Linear(OBS_DIM, 1)
        self.log_std = nn.Parameter(torch.full((1,), -1.0))

    def _dist(self, obs):
        return torch.distributions.Normal(self.mu(obs["vector"]), self.log_std.exp())

    def get_action(self, obs, deterministic=False):
        d = self._dist(obs)
        a = d.mean if deterministic else d.sample()
        return a, d.log_prob(a).sum(-1)

    def evaluate_actions(self, obs, actions):
        d = self._dist(obs)
        return d.log_prob(actions).sum(-1), d.entropy().sum(-1)


class FakeCritic(nn.Module):
    def __init__(self, h=16):
        super().__init__()
        self.enc = nn.Sequential(nn.Linear(NODE_F, h), nn.ReLU())
        self.net = nn.Sequential(nn.Linear(h, h), nn.ReLU(), nn.Linear(h, 1))
        self.signal_head = nn.Sequential(nn.Linear(h, h), nn.ReLU(), nn.Linear(h, 1))
        self.ind = nn.Sequential(nn.Linear(h + OBS_DIM, h), nn.ReLU(), nn.Linear(h, 1))
        self.seen_graph_sums = []

    def _pool(self, gd):
        x = self.enc(gd["node_features"])
        b = gd["batch_index"]
        B = int(b.max().item()) + 1
        s = torch.zeros(B, x.shape[1]).index_add_(0, b, x)
        c = torch.zeros(B).index_add_(0, b, torch.ones(b.shape[0])).clamp_min(1.0).unsqueeze(-1)
        return s / c

    def forward(self, gd):
        return self.net(self._pool(gd)).reshape(-1)

    def forward_dual(self, gd):
        h = self._pool(gd)
        return self.net(h).reshape(-1), self.signal_head(h).reshape(-1)

    def forward_signal(self, gd):
        return self.signal_head(self._pool(gd)).reshape(-1)

    def forward_individual(self, gd, packed):
        self.seen_graph_sums.append(float(gd["node_features"].sum().item()))
        h = self._pool(gd)
        p = torch.as_tensor(packed, dtype=torch.float32)
        return self.ind(torch.cat([h.expand(p.shape[0], -1), p], -1)).reshape(-1)

    def reset_team_head(self):
        for m in self.net:
            if isinstance(m, nn.Linear):
                m.reset_parameters()


def make_agent(lat_cls=FakeLat, v7=False, **kw):
    torch.manual_seed(0)
    np.random.seed(0)
    agent = MAPPOAgent(
        lon_actor=FakeLon(), lat_actor=lat_cls(), signal_actor=FakeSignal(), critic=FakeCritic(),
        minibatch_size=kw.pop("minibatch_size", 256), **kw,
    )
    if v7:
        for k, v in V7_OVERRIDES.items():
            setattr(agent, k, v)
    return agent


RNG = np.random.default_rng(0)


def _graph():
    return {"node_features": (RNG.normal(size=(7, NODE_F)) * 100).astype(np.float32),
            "edge_index": np.array([[0, 1, 2, 3], [1, 2, 3, 4]], dtype=np.int64)}


def collect(agent, n_steps=64, n_cav=3, add_zero_dof=True):
    R = {k: [] for k in (
        "global_obs", "signal_obs", "signal_actions", "signal_log_probs", "signal_ind_advantages",
        "lon_obs", "lon_actions", "lon_log_probs", "lon_ind_advantages",
        "lat_obs", "lat_actions", "lat_log_probs", "lat_ind_advantages", "lat_soft_betas")}
    for _ in range(n_steps):
        obs = {"signal_0": {"vector": (RNG.normal(size=OBS_DIM) * 50).astype(np.float32),
                            "action_mask": np.array([1, 1, 0, 1, 1], np.float32)}}
        for i in range(n_cav):
            obs[f"cav_lon_{i}"] = {"vector": RNG.normal(size=OBS_DIM).astype(np.float32)}
            obs[f"cav_lat_{i}"] = {"vector": RNG.normal(size=OBS_DIM).astype(np.float32),
                                   "action_mask": np.array([1, 1, 1], np.float32)}
        acts, lps = agent.select_actions(obs)
        R["global_obs"].append(_graph())
        if "signal_0" in lps:
            R["signal_obs"].append(obs["signal_0"])
            R["signal_actions"].append(acts["signal_0"])
            R["signal_log_probs"].append(lps["signal_0"])
            R["signal_ind_advantages"].append(RNG.normal())
        for i in range(n_cav):
            k = f"cav_lon_{i}"
            if k in lps:
                R["lon_obs"].append(obs[k])
                R["lon_actions"].append(np.asarray(acts[k]).reshape(-1)[0])
                R["lon_log_probs"].append(lps[k])
                R["lon_ind_advantages"].append(RNG.normal())
            k = f"cav_lat_{i}"
            if k in lps:
                R["lat_obs"].append(obs[k])
                R["lat_actions"].append(acts[k])
                R["lat_log_probs"].append(lps[k])
                R["lat_ind_advantages"].append(RNG.normal())
                R["lat_soft_betas"].append(agent.last_lat_beta)
    if add_zero_dof and R["signal_obs"]:
        R["signal_obs"].append({"vector": np.zeros(OBS_DIM, np.float32),
                                "action_mask": np.array([0, 1, 0, 0, 0], np.float32)})
        R["signal_actions"].append(1)
        R["signal_log_probs"].append(0.0)
        R["signal_ind_advantages"].append(5.0)
    # ndarray fields on purpose: v5 crashed on `if not ndarray` in the zero-DoF filter.
    for k in list(R):
        if not k.endswith("_obs") and k != "global_obs":
            R[k] = np.asarray(R[k])
    R["team_returns"] = RNG.normal(size=n_steps) * 100 - 500
    R["signal_returns"] = RNG.normal(size=n_steps) * 300 - 2000
    return R


def _enter(agent, stage):
    agent.set_training_stage(stage)
    if stage in JOINT_STAGES:
        agent.set_policy_anchors(agent.signal_actor.state_dict(), agent.lon_actor.state_dict(),
                                 agent.lat_actor.state_dict())


def test_full_curriculum_with_ndarray_rollouts():
    agent = make_agent()
    for stage in CURRICULUM_STAGES:
        _enter(agent, stage)
        out = agent.update(collect(agent))
        assert all(np.isfinite(v) for v in out.values()), (stage, out)


def test_legacy_defaults_are_v5_values():
    a = make_agent()
    assert mappo_mod.DEFAULT_JOINT_SIGNAL_LR_SCALE == 0.08
    assert mappo_mod.DEFAULT_JOINT_ALL_SIGNAL_LR_SCALE == 0.05
    assert mappo_mod.DEFAULT_JOINT_SIGNAL_ADV_SCALE == 0.5
    assert a.kl_stop_factor == 1.0 and a.anchor_kl_adaptive is False
    _enter(a, "JointLonSig")
    assert a.current_signal_temperature() == pytest.approx(0.65)   # fixed T, no anneal


def test_epoch0_ratio_exact_and_anchor_kl_zero_in_joint_stage():
    agent = make_agent(ppo_epochs=1, v7=True)
    _enter(agent, "Lon")
    _enter(agent, "JointLonSig")
    assert agent.current_signal_temperature() == pytest.approx(0.25)
    out = agent.update(collect(agent))
    assert agent._epoch0_ratio_dev["signal"] < 1e-5
    assert agent._epoch0_ratio_dev["lon"] < 1e-5
    assert out["diag/anchor_kl_signal"] < 1e-6          # F1: KL is 0 at the anchor
    # The v5 formulation (untempered anchor vs tempered policy) is NOT zero at the anchor:
    obs = agent._batch_observations(
        [{"vector": RNG.normal(size=OBS_DIM).astype(np.float32),
          "action_mask": np.array([1, 1, 0, 1, 1], np.float32)} for _ in range(32)], head="signal")
    anchor = agent._anchor_signal
    with torch.no_grad():
        lg = agent._effective_signal_logits(anchor(obs), obs["action_mask"])
    _, kl_v5 = agent._anchor_bc_discrete(lg, anchor, obs, 1.0, tempered=False)
    _, kl_v6 = agent._anchor_bc_discrete(lg, anchor, obs, 1.0, tempered=True)
    assert kl_v5 > 1e-3 and kl_v6 < 1e-6


def test_temperature_anneals_per_signal_update_and_has_floor():
    agent = make_agent(ppo_epochs=1, v7=True)
    _enter(agent, "JointLonSig")
    t0 = agent.current_signal_temperature()
    agent.update(collect(agent, n_steps=16))
    assert agent.current_signal_temperature() > t0
    agent.joint_signal_temp_start = 0.0
    agent._joint_sig_updates = 0
    assert agent.current_signal_temperature() == pytest.approx(0.05)  # v5 returned raw (T=1)


def test_lat_soft_start_beta_consistency():
    agent = make_agent(ppo_epochs=1)
    _enter(agent, "Lat")
    agent.action_blend_beta = 0.5
    agent.update(collect(agent))
    assert agent._epoch0_ratio_dev["lat"] < 1e-5


def test_lat_beta_mismatch_is_detected_for_v5_style_actor():
    agent = make_agent(lat_cls=FakeLatNoBetaAPI, ppo_epochs=1)
    _enter(agent, "Lat")
    agent.action_blend_beta = 0.5
    agent.update(collect(agent))
    assert agent._epoch0_ratio_dev["lat"] > 1e-3
    assert "lat" in agent._ratio_warned and "lat_beta_api" in agent._ratio_warned


def test_return_rms_survives_stage_switch_without_head_reset():
    agent = make_agent()
    _enter(agent, "JointLonSig")
    agent._ret_rms_mean, agent._ret_rms_var, agent._ret_rms_count = -850.0, 14400.0, 1000.0
    _enter(agent, "Lat")
    assert agent._ret_rms_mean == -850.0 and agent._ret_rms_var == 14400.0
    agent.reset_rms_on_stage_switch = True       # legacy behaviour still available
    _enter(agent, "S")
    assert agent._ret_rms_mean == 0.0


def test_fit_individual_uses_each_samples_graph():
    agent = make_agent()
    agent.individual_critic = True
    _enter(agent, "Lon")
    g1, g2 = _graph(), _graph()
    samples = [(np.ones(OBS_DIM), -10.0, g1), (np.ones(OBS_DIM), -20.0, g2), (np.zeros(OBS_DIM), -5.0, g1)]
    agent.critic.seen_graph_sums.clear()
    loss = agent.fit_individual(samples)
    assert np.isfinite(loss) and len(agent.critic.seen_graph_sums) == 2   # v5: 1 (graphs[0] only)


def test_obs_norm_keeps_epoch0_ratio_exact_across_flushes():
    agent = make_agent(obs_norm=True, ppo_epochs=1)
    agent.update(collect(agent))                       # stats move only at the end of update
    assert agent._obs_rms["signal"].initialised and agent._obs_rms["critic"].initialised
    agent.update(collect(agent))
    assert agent._epoch0_ratio_dev["signal"] < 1e-5


def test_signal_buffer_defers_then_releases():
    agent = make_agent(ppo_epochs=1)
    agent.signal_min_batch = 100
    out1 = agent.update(collect(agent, n_steps=64))
    assert out1["diag/signal_deferred"] == 1.0
    out2 = agent.update(collect(agent, n_steps=64))
    assert out2["diag/signal_deferred"] == 0.0 and out2["diag/signal_samples"] >= 100


def test_batch_dual_values_matches_per_step():
    agent = make_agent()
    _enter(agent, "Lon")
    agent._ret_rms_mean, agent._ret_rms_var = -500.0, 2500.0
    graphs = [_graph() for _ in range(10)]
    team, sig = agent.batch_dual_values(graphs, chunk_size=4)
    for i, g in enumerate(graphs):
        vt, vs = agent.get_dual_values(g)
        assert team[i] == pytest.approx(vt, rel=1e-4, abs=1e-3)
        assert sig[i] == pytest.approx(vs, rel=1e-4, abs=1e-3)


def test_export_import_roundtrip():
    a = make_agent(obs_norm=True)
    a.update(collect(a))
    a._ret_rms_mean = -123.0
    st = a.export_state()
    b = make_agent()
    b.import_state(st)
    assert b.obs_norm and b._ret_rms_mean == -123.0
    x = np.random.default_rng(1).normal(size=(4, OBS_DIM))
    assert np.allclose(a._obs_rms["signal"].normalize(x), b._obs_rms["signal"].normalize(x))


def test_agent_value_net_learns_and_popart_preserves_outputs():
    agent = make_agent(ppo_epochs=4)
    net = AgentValueNet(8)
    agent.attach_agent_value_net(net, lr=3e-3)
    rng = np.random.default_rng(0)
    X = rng.normal(size=(2048, 8)).astype(np.float32)
    w = rng.normal(size=8)
    Y = -300.0 + 40.0 * (X @ w) / np.sqrt(8.0)          # large offset/scale like real returns
    ro = {"global_obs": [], "v7_value_inputs": list(X), "v7_value_returns": Y.tolist()}
    evs = []
    for _ in range(8):
        st = agent._update_agent_value(dict(ro))
        evs.append(st["agent_value_ev"])
    assert evs[-1] > 0.8 and evs[-1] > evs[0]
    before = agent.agent_values(X[:16])
    m0, s0 = agent.agent_value_norm.stats()
    agent.agent_value_norm.update(Y + 500.0)               # shift stats ...
    m1, s1 = agent.agent_value_norm.stats()
    agent._popart_preserve(net.last_linear, m0, s0, m1, s1)  # ... PopArt keeps raw outputs
    after = agent.agent_values(X[:16])
    assert np.allclose(before, after, rtol=1e-4, atol=1e-2)


def test_update_trains_agent_value_from_merged_rollout():
    agent = make_agent(ppo_epochs=1)
    agent.attach_agent_value_net(AgentValueNet(OBS_DIM + 4))
    _enter(agent, "Lon")
    R = collect(agent)
    R["v7_value_inputs"] = [np.ones(OBS_DIM + 4, np.float32)] * 64
    R["v7_value_returns"] = list(np.linspace(-50, -10, 64))
    out = agent.update(R)
    assert out["diag/agent_value_n"] == 64.0 and np.isfinite(out["agent_value"])
    st = agent.export_state()
    b = make_agent()
    b.import_state(st)
    assert b.agent_value_norm.stats() == agent.agent_value_norm.stats()
