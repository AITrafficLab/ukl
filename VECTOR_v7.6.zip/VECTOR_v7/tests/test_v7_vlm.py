"""VLM-side v7 tests (numpy only; no VLM server, no SUMO)."""
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from VLM.signal_vision import SignalVisionScheduler  # noqa: E402


def _scheduler_with_ready_advice(request_t):
    s = SignalVisionScheduler(encoder=None, scenario="4leg", enabled=True)
    with s._lock:
        s._training_stage = "S"
        s._stage_episode = 99
        s._pending_teacher_trigger = False
        s._has_unconsumed_advice = True
        s._advice_request_t = float(request_t)
        adv = {"recommended_phase": 1, "confidence": 0.8, "valid": 1.0,
               "visual_event": "none", "reason": "ok", "green_cycle": ""}
        s._teacher_advice = dict(adv)
        s._teacher_by_tls["t"] = dict(adv)
    return s


def _consume(s, now):
    return s.consume_teacher_if_ready({"stats": {"time": now}}, [0, 1, 2], tls_id="t", sim_time=now)


def test_stale_label_rejected_only_with_v7_guard():
    os.environ.pop("V7_TEACHER_MAX_AGE_S", None)
    legacy = _consume(_scheduler_with_ready_advice(1000.0), 1060.0)       # 60 s old
    assert legacy.get("recommended_phase") == 1                            # legacy accepts (<= 150 s)
    os.environ["V7_TEACHER_MAX_AGE_S"] = "10"
    try:
        stale = _consume(_scheduler_with_ready_advice(1000.0), 1060.0)
        assert float(stale.get("valid", 0.0)) < 0.5                        # v7 rejects stale label
        fresh = _consume(_scheduler_with_ready_advice(1000.0), 1004.0)     # prefetch-aged
        assert fresh.get("recommended_phase") == 1
    finally:
        os.environ.pop("V7_TEACHER_MAX_AGE_S", None)


if __name__ == "__main__":
    test_stale_label_rejected_only_with_v7_guard()
    print("PASS test_stale_label_rejected_only_with_v7_guard\n1 VLM test passed")
