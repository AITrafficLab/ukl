"""Pure numpy tests for VECTOR v6 (no torch / SUMO needed)."""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from agents.gae_utils import smdp_gae  # noqa: E402
from agents.running_norm import RunningMeanStd  # noqa: E402
from agents.signal_buffer import SignalSampleBuffer  # noqa: E402
from tests._ref.gae_utils_v5 import smdp_gae as smdp_gae_v5  # noqa: E402

RNG = np.random.default_rng(42)


def test_gae_bit_identical_to_v5_without_truncation():
    for _ in range(50):
        n = int(RNG.integers(5, 300))
        r, v = RNG.normal(size=n), RNG.normal(size=n)
        d = (RNG.random(n) < 0.02).astype(float)
        dec = RNG.random(n) < 0.15
        dec[0] = True
        for dm in (None, dec):
            a = smdp_gae(r, v, d, next_value=0.3, gamma=0.998, gae_lambda=0.98, decision_mask=dm)
            b = smdp_gae_v5(r, v, d, next_value=0.3, gamma=0.998, gae_lambda=0.98, decision_mask=dm)
            assert np.array_equal(a[0], b[0]) and np.array_equal(a[1], b[1])


def test_smdp_equals_option_level_gae():
    n, g, lam = 60, 0.998, 0.98
    r, v, d = RNG.normal(size=n), RNG.normal(size=n), np.zeros(n)
    dec = np.zeros(n, bool)
    starts = [0, 7, 17, 30, 41, 52]
    dec[starts] = True
    _, adv = smdp_gae(r, v, d, next_value=0.7, gamma=g, gae_lambda=lam, decision_mask=dec)
    ends = starts[1:] + [n]
    A = {}
    for s, e in reversed(list(zip(starts, ends))):
        tau = e - s
        R = sum(g ** k * r[s + k] for k in range(tau))
        vn = 0.7 if e == n else v[e]
        delta = R + g ** tau * vn - v[s]
        A[s] = delta + (g ** tau * lam * A[e] if e in A else 0.0)
    assert max(abs(adv[s] - A[s]) for s in starts) < 1e-5


def test_truncation_bootstrap_removes_time_limit_bias():
    T, g = 3600, 0.998
    r = -5.0 * np.ones(T)
    v_true = -5.0 / (1 - g)
    v = np.full(T, v_true)
    d = np.zeros(T)
    d[-1] = 1.0
    tr = np.zeros(T, bool)
    tr[-1] = True
    ret_bad, _ = smdp_gae(r, v, d, gamma=g, gae_lambda=0.95)
    ret_ok, _ = smdp_gae(r, v, d, gamma=g, gae_lambda=0.95, truncateds=tr,
                         bootstrap_values=np.full(T, v_true))
    assert abs(ret_bad[-1] - (-5.0)) < 1e-3              # v5: last target = -5 (vs -2500)
    assert np.allclose(ret_ok, v_true, rtol=1e-4)         # v6: stationary everywhere
    ret_fb, _ = smdp_gae(r, v, d, gamma=g, gae_lambda=0.95, truncateds=tr)  # fallback V(s_T)~V(s_T-1)
    assert np.allclose(ret_fb, v_true, rtol=1e-4)


def test_truncation_cuts_recursion_and_terminal_still_zero():
    r = np.array([1.0, 1.0, 1.0, 1.0])
    v = np.zeros(4)
    d = np.array([0, 1, 0, 1], float)
    tr = np.array([False, True, False, False])
    ret, _ = smdp_gae(r, v, d, gamma=0.9, gae_lambda=1.0, truncateds=tr,
                      bootstrap_values=np.array([0, 10.0, 0, 0]))
    assert abs(ret[1] - (1 + 0.9 * 10.0)) < 1e-5   # truncated: bootstrap
    assert abs(ret[3] - 1.0) < 1e-6                # terminal: no bootstrap
    assert abs(ret[2] - (1 + 0.9 * 1.0)) < 1e-6    # recursion cut at index 1


def test_running_norm_matches_numpy_and_roundtrips():
    rms = RunningMeanStd(clip=10.0)
    chunks = [RNG.normal(loc=[0, 50, 390], scale=[1, 10, 120], size=(int(RNG.integers(5, 400)), 3))
              for _ in range(20)]
    for c in chunks:
        rms.update(c)
    allx = np.concatenate(chunks)
    assert np.allclose(rms.mean, allx.mean(0), rtol=1e-3, atol=1e-3)
    assert np.allclose(rms.var, allx.var(0), rtol=1e-2)
    z = rms.normalize(np.array([[0, 50, 390], [0, 50, 1000]], np.float32))
    assert abs(z[0, 2]) < 0.2 and z[1, 2] > 4.0      # 390 vs 1000 distinguishable
    r2 = RunningMeanStd()
    r2.load_state_dict(rms.state_dict())
    assert np.allclose(r2.normalize(allx[:10]), rms.normalize(allx[:10]))


def test_running_norm_ignores_nonfinite_and_dim_change_disables():
    rms = RunningMeanStd()
    rms.update(np.array([[1.0, np.nan], [2.0, 3.0]]))
    assert rms.count > 1.0 and np.isfinite(rms.mean).all()
    rms.update(np.ones((4, 5)))
    assert rms.disabled
    out = rms.normalize(np.full((1, 5), 99.0))
    assert np.all(out == 10.0)                        # falls back to legacy clip


def test_frozen_normaliser_does_not_move():
    rms = RunningMeanStd()
    rms.update(RNG.normal(size=(100, 2)))
    snap = rms.state_dict()
    rms.frozen = True
    rms.update(RNG.normal(loc=100, size=(100, 2)))
    assert np.allclose(rms.mean, snap["mean"])


def _flush(n, a0=0):
    return {
        "signal_obs": [{"vector": np.zeros(3)} for _ in range(n)],
        "signal_actions": np.arange(a0, a0 + n) % 4,
        "signal_log_probs": np.zeros(n),
        "signal_ind_advantages": np.ones(n),
    }


def test_signal_buffer_signature_change_discards():
    buf = SignalSampleBuffer(min_batch=10)
    buf.add(_flush(6), "JointLonSig", signature=(0.25, False))
    assert len(buf) == 6 and not buf.ready()
    buf.add(_flush(6), "JointLonSig", signature=(0.30, False))   # temperature moved
    assert len(buf) == 6 and buf.discarded == 6
    buf.add(_flush(6), "JointLonSig", signature=(0.30, False))
    assert buf.ready()
    out = buf.release()
    assert len(out["signal_obs"]) == 12 and out["signal_teacher_actions"].tolist() == [-1] * 12
    assert len(buf) == 0


def test_signal_buffer_stage_change_discards_v5_semantics():
    buf = SignalSampleBuffer(min_batch=4)
    buf.add(_flush(3), "S")
    buf.add(_flush(3), "JointLonSig")
    assert len(buf) == 3


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for f in fns:
        f()
        print("PASS", f.__name__)
    print(f"{len(fns)} numpy tests passed")
