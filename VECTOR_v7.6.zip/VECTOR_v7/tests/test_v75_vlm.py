"""VECTOR v7.5 VLM perception scheduler / rate-limit / accounting tests (no API, no SUMO)."""
import csv
import os
import sys
import tempfile
import threading
import time
from types import SimpleNamespace

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from VLM import event_perception as ep  # noqa: E402

APPS = ["N", "S", "E", "W"]


def ans(**counts):
    c = {a: int(counts.get(a, 0)) for a in APPS}
    return {"counts": c, "types": {a: ("roadwork" if c[a] else "none") for a in APPS},
            "confidence": 0.9, "valid": 1.0}


def mk(fetch, **kw):
    kw.setdefault("interval_s", 30.0)
    kw.setdefault("active_interval_s", 15.0)
    kw.setdefault("async_calls", False)
    kw.setdefault("sleep_fn", lambda s: None)
    kw.setdefault("log", None)
    return ep.EventPerceptionScheduler(None, APPS, fetch_fn=fetch, **kw)


def test_cadence_switches_between_30s_and_15s():
    plan = {0.0: ans(), 30.0: ans(W=1), 45.0: ans(W=1), 60.0: ans(), 90.0: ans()}
    calls = []

    def fetch(enc, snap, apps):
        t = snap["stats"]["time"]
        calls.append(t)
        return plan.get(t, ans())

    s = mk(fetch)
    for t in range(0, 125, 1):
        s.tick(float(t), {"stats": {"time": float(t)}})
    assert calls[:5] == [0.0, 30.0, 45.0, 60.0, 90.0]           # 30 -> 15 (while W) -> 30
    st = s.stats()
    assert st["v7_evt_vlm_active"] == 2 and st["v7_evt_vlm_periodic"] >= 3


def test_edge_trigger_not_level_and_cooldown():
    calls = []
    s = mk(lambda e, snap, a: calls.append(snap["stats"]["time"]) or ans(), interval_s=1000.0)
    s.tick(0.0, {"stats": {"time": 0.0}}, stalled_apps=[])          # periodic at t=0
    for t in range(1, 60):                                          # E stalled from t=5 on (level high)
        s.tick(float(t), {"stats": {"time": float(t)}}, stalled_apps=["E"] if t >= 5 else [])
    assert calls == [0.0, 5.0]                                      # ONE call for the new stall, not every 10 s
    s.tick(60.0, {"stats": {"time": 60.0}}, stalled_apps=[])        # stall clears -> recheck
    s.tick(61.0, {"stats": {"time": 61.0}}, stalled_apps=["N"])     # new stall within cooldown -> pending
    s.tick(65.0, {"stats": {"time": 65.0}}, stalled_apps=["N"])
    s.tick(70.0, {"stats": {"time": 70.0}}, stalled_apps=["N"])     # cooldown over -> fires
    assert calls == [0.0, 5.0, 60.0, 70.0]
    st = s.stats()
    assert st["v7_evt_vlm_trig_new"] == 2 and st["v7_evt_vlm_trig_clear"] == 1


def test_trigger_while_busy_is_kept_pending():
    gate = threading.Event()
    calls = []

    def fetch(e, snap, a):
        calls.append(snap["stats"]["time"])
        if len(calls) == 1:
            gate.wait(2.0)
        return ans()

    s = mk(fetch, async_calls=True, interval_s=1000.0)
    s.tick(0.0, {"stats": {"time": 0.0}}, stalled_apps=[])
    s.tick(20.0, {"stats": {"time": 20.0}}, stalled_apps=["W"])     # busy: trigger stays pending
    gate.set()
    for _ in range(200):
        if s._pending is not None:
            break
        time.sleep(0.005)
    s.tick(21.0, {"stats": {"time": 21.0}}, stalled_apps=["W"])     # commit + fire the pending trigger
    for _ in range(200):
        if len(calls) >= 2:
            break
        time.sleep(0.005)
    assert calls == [0.0, 21.0]


def test_late_answer_scored_but_not_adopted():
    gate = threading.Event()
    s = mk(lambda e, snap, a: (gate.wait(2.0), ans(W=1))[1], async_calls=True, max_answer_age_s=45.0)
    s.tick(0.0, {"stats": {"time": 0.0}}, truth_apps=["W"])
    gate.set()
    for _ in range(200):
        if s._pending is not None:
            break
        time.sleep(0.005)
    s.tick(50.0, {"stats": {"time": 50.0}}, truth_apps=[])          # arrives 50 s after request
    st = s.stats()
    assert st["v7_evt_vlm_late"] == 1 and st["v7_evt_vlm_ok"] == 0
    assert s.blockage(50.0) == {}                                    # not adopted
    assert st["v7_evt_ans_recall"] == 1.0 and st["v7_evt_ans_n"] == 1   # scored vs truth at request


def test_answer_level_scoring_uses_truth_at_request():
    seq = iter([ans(W=1), ans(W=1, N=1), ans()])
    s = mk(lambda e, snap, a: next(seq), interval_s=10.0)
    s.tick(0.0, {}, truth_apps=["W"])         # TP W, TN N S E
    s.tick(10.0, {}, truth_apps=["W"])        # TP W, FP N
    s.tick(20.0, {}, truth_apps=["S"])        # FN S
    a = s.ans
    assert (a["tp"], a["fp"], a["fn"], a["n"], a["exact"]) == (2, 1, 1, 3, 1)
    st = s.stats()
    assert abs(st["v7_evt_ans_precision"] - 2 / 3) < 1e-9 and abs(st["v7_evt_ans_recall"] - 2 / 3) < 1e-9


class RateLimit(Exception):
    def __init__(self, msg="Error code: 429 - {'code': '1302', 'message': '您当前使用该API的并发数过高'}", retry_after=None):
        super().__init__(msg)
        self.status_code = 429
        self.response = SimpleNamespace(status_code=429, headers={"retry-after": retry_after} if retry_after else {})


def test_rate_limit_retry_with_backoff_and_retry_after():
    sleeps, n = [], {"k": 0}

    def fetch(e, snap, a):
        n["k"] += 1
        if n["k"] == 1:
            raise RateLimit()
        if n["k"] == 2:
            raise RateLimit(retry_after="7")
        return ans(E=1)

    s = mk(fetch, sleep_fn=sleeps.append, rng=ep.random.Random(0))
    s.tick(0.0, {})
    st = s.stats()
    assert st["v7_evt_vlm_ok"] == 1 and st["v7_evt_vlm_attempts"] == 3
    assert st["v7_evt_vlm_retries"] == 2 and st["v7_evt_vlm_rate_limited"] == 2
    assert 1.0 <= sleeps[0] <= 2.0 and sleeps[1] == 7.0               # jittered base 2 s, then Retry-After


def test_fatal_not_retried_and_drop_after_max_attempts_or_wall():
    s = mk(lambda e, snap, a: (_ for _ in ()).throw(RuntimeError("Error code: 401 invalid api key")))
    s.tick(0.0, {})
    st = s.stats()
    assert st["v7_evt_vlm_attempts"] == 1 and st["v7_evt_vlm_errors"] == 1
    s2 = mk(lambda e, snap, a: (_ for _ in ()).throw(RateLimit()), max_attempts=4)
    s2.tick(0.0, {})
    st2 = s2.stats()
    assert st2["v7_evt_vlm_attempts"] == 4 and st2["v7_evt_vlm_ratelimited_drop"] == 1
    clock = {"t": 0.0}

    def slow_sleep(d):
        clock["t"] += d

    s3 = mk(lambda e, snap, a: (_ for _ in ()).throw(RateLimit()), max_attempts=50, max_retry_wall_s=20.0,
            sleep_fn=slow_sleep, clock=lambda: clock["t"], backoff_base_s=8.0)
    s3.tick(0.0, {})
    st3 = s3.stats()
    assert st3["v7_evt_vlm_ratelimited_drop"] == 1 and st3["v7_evt_vlm_attempts"] < 50 and clock["t"] <= 20.0 + 1e-9
    assert s3.blockage(1.0) == {} and s3._busy is False               # scheduler free for the next call


def test_classify_errors():
    c = ep.classify_vlm_error
    assert c(RateLimit()) == "rate_limit"
    assert c(RuntimeError("Error code: 400 - {'error': {'code': '1305', 'message': '该模型当前访问量过大'}}")) == "rate_limit"
    assert c(RuntimeError("请求频率过高 1303")) == "rate_limit"
    assert c(RuntimeError("Error code: 429 - {'code': '1113', 'message': '余额不足或无可用资源包'}")) == "fatal"
    assert c(RuntimeError("1113 余额不足")) == "fatal"
    assert c(RuntimeError("Error code: 401 - invalid api key")) == "fatal"
    assert c(TimeoutError("Request timed out.")) == "transient"
    assert c(RuntimeError("VLM returned empty message content (finish_reason='stop')")) == "transient"
    assert c(SimpleNamespace(status_code=503, response=None, __str__=lambda self: "x")) in ("transient", "fatal")


def test_call_records_csv():
    with tempfile.TemporaryDirectory() as d:
        path = os.path.join(d, "sub", "vlm_event_calls.csv")
        seq = iter([ans(W=1), ans()])
        s = mk(lambda e, snap, a: next(seq), interval_s=10.0, record_path_fn=lambda: path)
        s.tick(0.0, {}, truth_apps=["W"])
        s.tick(10.0, {}, truth_apps=[])
        rows = list(csv.DictReader(open(path, encoding="utf-8")))
        assert len(rows) == 2 and rows[0]["status"] == "ok" and rows[0]["tp"] == "1"
        assert rows[0]["truth_apps"] == "W" and rows[1]["pred_apps"] == "" and rows[0]["episode"] == "0"
        s.reset()
        seq2 = iter([ans()])
        s.fetch_fn = lambda e, snap, a: next(seq2)
        s.tick(0.0, {})
        rows = list(csv.DictReader(open(path, encoding="utf-8")))
        assert len(rows) == 3 and rows[2]["episode"] == "1"


def test_snapshot_strips_v7_diagnostics():
    seen = {}
    s = mk(lambda e, snap, a: seen.update(snap) or ans())
    s.tick(0.0, {"stats": {"time": 3.0, "v7_evt_truth_apps": ["W"], "v7_numeric_stall_apps": ["W"]},
                 "events_visual": [], "cavs": {}})
    assert seen["stats"] == {"time": 3.0} and "events_visual" in seen


def test_call_counter_all_channels_and_event_tag():
    calls = []

    class Enc:
        def _chat_once(self, messages, max_tokens=128, retries=0, channel="lon"):
            calls.append(channel)
            if messages == "boom":
                raise RuntimeError("x")
            return "ok"

    enc = Enc()
    cnt = ep.VLMCallCounter.install(enc)
    assert ep.VLMCallCounter.install(enc) is cnt                      # idempotent
    enc._chat_once("m", channel="signal_vision")
    enc._chat_once("m", channel="lat")
    with ep.vlm_channel_tag("event"):
        enc._chat_once("m", channel="signal_vision")
    try:
        enc._chat_once("boom", channel="lon")
    except RuntimeError:
        pass
    st = cnt.episode_stats()
    assert st["v7_vlm_calls_total"] == 4 and st["v7_vlm_calls_event"] == 1
    assert st["v7_vlm_calls_signal_vision"] == 1 and st["v7_vlm_calls_lat"] == 1 and st["v7_vlm_errors_total"] == 1
    cnt.episode_reset()
    assert cnt.episode_stats()["v7_vlm_calls_total"] == 0


def test_stat_keys_stable():
    assert tuple(mk(lambda *a: ans()).stats().keys()) == ep.SCHEDULER_STAT_KEYS


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for f in fns:
        f()
        print("PASS", f.__name__)
    print(f"{len(fns)} v7.5 VLM tests passed")
