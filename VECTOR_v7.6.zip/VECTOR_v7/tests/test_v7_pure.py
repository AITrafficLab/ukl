"""Pure-python/numpy tests for VECTOR v7 modules (no torch, no SUMO)."""
import os
import sys

import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from train.cav_gae_v7 import agent_option_gae, build_value_input, rollout_cav_gae  # noqa: E402
from reward.influence_reward import influence_delay_reward, influence_segment  # noqa: E402
from agents.value_norm import ValueNorm  # noqa: E402

RNG = np.random.default_rng(3)


def _brute_option_gae(r, d, v, g, lam, boot, terminal):
    T = len(r)
    dec = [t for t in range(T) if d[t]]
    ends = dec[1:] + [T]
    deltas, taus = [], []
    for n, (s, e) in enumerate(zip(dec, ends)):
        tau = e - s
        R = sum(g ** k * r[s + k] for k in range(tau))
        vn = (0.0 if terminal else boot) if n == len(dec) - 1 else v[e]
        deltas.append(R + g ** tau * vn - v[s])
        taus.append(tau)
    out = {}
    for n, s in enumerate(dec):
        a, w = 0.0, 1.0
        for m in range(n, len(dec)):
            a += w * deltas[m]
            w *= g ** taus[m] * lam
        out[s] = (a, a + v[s])
    return out


def test_agent_option_gae_matches_bruteforce():
    for _ in range(200):
        T = int(RNG.integers(1, 60))
        r, v = RNG.normal(size=T), RNG.normal(size=T)
        d = RNG.random(T) < 0.3
        g, lam = 0.996, 0.95
        boot, term = float(RNG.normal()), bool(RNG.random() < 0.5)
        got = agent_option_gae(r, d, v, gamma=g, lam=lam, bootstrap=boot, terminal=term)
        ref = _brute_option_gae(r, d, v, g, lam, boot, term)
        assert set(got) == set(ref)
        for k in ref:
            assert abs(got[k][0] - ref[k][0]) < 1e-9 and abs(got[k][1] - ref[k][1]) < 1e-9


def test_lambda_one_zero_value_is_discounted_return():
    r = np.array([1.0, 2.0, 3.0, 4.0, 5.0])
    d = np.array([True, False, True, False, False])
    out = agent_option_gae(r, d, np.zeros(5), gamma=0.9, lam=1.0, terminal=True)
    mc0 = sum(0.9 ** k * r[k] for k in range(5))
    mc2 = sum(0.9 ** k * r[2 + k] for k in range(3))
    assert abs(out[0][1] - mc0) < 1e-12 and abs(out[2][1] - mc2) < 1e-12


def test_perfect_value_gives_zero_advantage():
    g = 0.99
    T = 40
    r = -np.ones(T)
    v = np.array([-(1 - g ** (T - t)) / (1 - g) for t in range(T)])  # exact for terminal at T
    d = np.zeros(T, bool)
    d[::5] = True
    out = agent_option_gae(r, d, v, gamma=g, lam=0.95, terminal=True)
    assert max(abs(a) for a, _ in out.values()) < 1e-9


def test_rollout_segments_exit_and_bootstrap():
    # agent A alive 0..5 then leaves (terminal); agent B alive 3..9 till rollout end (bootstrap)
    n = 10
    alive = [set() for _ in range(n)]
    dec = [set() for _ in range(n)]
    rew = [{} for _ in range(n)]
    for t in range(0, 6):
        alive[t].add("A"); rew[t]["A"] = -1.0
    for t in range(3, 10):
        alive[t].add("B"); rew[t]["B"] = -0.5
    for t in (0, 2, 4):
        dec[t].add("A")
    for t in (3, 6, 9):
        dec[t].add("B")
    vals = {(t, a): 0.0 for t in range(n) for a in ("A", "B")}
    out, st = rollout_cav_gae(rew, dec, alive, vals, gamma=1.0, lam=1.0,
                              final_alive={"B"}, final_values={"B": 10.0})
    assert abs(out[(0, "A")][1] - (-6.0)) < 1e-12           # terminal at exit
    assert abs(out[(9, "B")][1] - (-0.5 + 10.0)) < 1e-12     # bootstrap at cut
    assert abs(out[(3, "B")][1] - (-3.5 + 10.0)) < 1e-12
    assert st["bootstrapped_segments"] == 1 and st["missing_values"] == 0


def test_rollout_reentry_creates_new_segment():
    n = 6
    alive = [{"A"}, {"A"}, set(), {"A"}, {"A"}, set()]
    dec = [{"A"}, set(), set(), {"A"}, set(), set()]
    rew = [{"A": 1.0} if "A" in s else {} for s in alive]
    out, st = rollout_cav_gae(rew, dec, alive, {}, gamma=1.0, lam=1.0)
    assert st["segments"] == 2 and st["missing_values"] == 2
    assert out[(0, "A")][1] == 2.0 and out[(3, "A")][1] == 2.0


def test_value_input_padding():
    x = build_value_input(np.ones(3), np.arange(5), 7)
    assert x.shape == (10,) and x[3:8].tolist() == [0, 1, 2, 3, 4] and x[8:].tolist() == [0, 0]
    y = build_value_input(np.ones(3), None, 4)
    assert y.tolist() == [1, 1, 1, 0, 0, 0, 0]


def _veh(speed, follower=None, gap=5.0, vmax=16.67, length=5.0):
    return {"speed": speed, "follower_id": follower, "follower_gap": gap,
            "lane_max_speed": vmax, "length": length}


def test_influence_segment_stops_at_next_cav_and_distance():
    state = {
        "cavs": {"c1": _veh(10.0, "h1"), "c2": _veh(5.0, "h3")},
        "hdvs": {"h1": _veh(8.0, "h2"), "h2": _veh(0.0, "c2"), "h3": _veh(0.0, None)},
    }
    assert influence_segment(state, "c1") == ["c1", "h1", "h2"]
    assert influence_segment(state, "c2") == ["c2", "h3"]
    far = {"cavs": {"c": _veh(10.0, "h1", gap=80.0)}, "hdvs": {"h1": _veh(0.0, "h2", gap=5.0), "h2": _veh(0.0)}}
    assert influence_segment(far, "c", max_dist_m=90.0) == ["c", "h1"]
    assert influence_segment(far, "c", max_dist_m=50.0) == ["c"]


def test_influence_reward_values():
    state = {"cavs": {"c": _veh(16.67, "h1")}, "hdvs": {"h1": _veh(0.0, "h2"), "h2": _veh(8.335)}}
    r, comps = influence_delay_reward(state, "c", max_followers=6)
    assert abs(r - (-(0.0 + 1.0 + 0.5) / 7.0)) < 1e-6
    assert comps["n_seg"] == 3.0
    r0, _ = influence_delay_reward(state, "missing")
    assert r0 == 0.0
    loop = {"cavs": {"c": _veh(0.0, "h1")}, "hdvs": {"h1": _veh(0.0, "h1")}}
    assert influence_segment(loop, "c") == ["c", "h1"]


def test_target_speed_v7_neutral_and_bounds():
    os.environ["LON_TARGET_SPEED_MAP"] = "v7"
    try:
        from environment.p1_control import accel_for_target_speed, target_speed_from_action
        assert abs(target_speed_from_action(0.0, 16.67) - 16.67) < 1e-9
        assert abs(target_speed_from_action(-2.2, 16.67) - 0.2 * 16.67) < 1e-9
        assert target_speed_from_action(1.0, 16.67) > 16.67
        a = accel_for_target_speed(0.0, 10.0, 16.67)
        assert a > 0.0
    finally:
        os.environ.pop("LON_TARGET_SPEED_MAP", None)
    from environment.p1_control import target_speed_from_action as tsa
    assert abs(tsa(0.0, 16.67) - 0.6875 * 16.67) < 1e-9   # legacy P1 behaviour preserved by default


def test_mp_teacher_picks_max_pressure_and_falls_back():
    from environment.rule_signal_teacher import mp_recommend_phase
    st = {"stats": {"phase_pressures": [2.0, 9.0, 4.0], "queue_phase_0": 50.0},
          "signals": {"t": {"green_index": 0}}}
    adv = mp_recommend_phase(st, [0, 1, 2])
    assert adv["recommended_phase"] == 1 and adv["confidence"] == 0.85
    adv2 = mp_recommend_phase(st, [0, 2])
    assert adv2["recommended_phase"] == 2
    fb = mp_recommend_phase({"stats": {"queue_phase_0": 9.0, "queue_phase_1": 1.0}}, [0, 1])
    assert fb["recommended_phase"] == 0 and fb["reason"] == "max_queue_then_wait"
    assert mp_recommend_phase(st, [1]) is None


def test_value_norm_tracks_scale():
    vn = ValueNorm(beta=0.9)
    for _ in range(200):
        vn.update(RNG.normal(-300.0, 40.0, size=256))
    m, s = vn.stats()
    assert abs(m + 300.0) < 10.0 and abs(s - 40.0) < 6.0
    x = np.array([-340.0, -300.0, -260.0])
    assert np.allclose(vn.denormalize(vn.normalize(x)), x)
    v2 = ValueNorm()
    v2.load_state_dict(vn.state_dict())
    assert v2.stats() == vn.stats()


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for f in fns:
        f()
        print("PASS", f.__name__)
    print(f"{len(fns)} v7 pure tests passed")
