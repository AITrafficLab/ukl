"""VECTOR v7.1 event branch tests (no SUMO, no torch; cv2 optional)."""
import ast
import os
import sys
import textwrap
import types
from types import SimpleNamespace

import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from environment import event_injector as ei  # noqa: E402
from VLM import event_perception as ep  # noqa: E402

APPS = {"N": "eN", "S": "eS", "E": "eE", "W": "eW"}


# ------------------------------------------------------------------ schedule
def test_schedule_deterministic_disjoint_and_in_window():
    a = ei.make_schedule(11, 300.0, 1200.0, APPS, rate=3.0)
    b = ei.make_schedule(11, 300.0, 1200.0, APPS, rate=3.0)
    assert [(e.kind, e.approach, round(e.onset_s, 6)) for e in a] == \
           [(e.kind, e.approach, round(e.onset_s, 6)) for e in b]
    seen_diff = any(
        [(e.approach, round(e.onset_s)) for e in ei.make_schedule(s, 300.0, 1200.0, APPS, rate=3.0)]
        != [(e.approach, round(e.onset_s)) for e in a] for s in range(12, 20))
    assert seen_diff
    for seed in range(50):
        evs = ei.make_schedule(seed, 300.0, 1200.0, APPS, rate=3.0)
        assert len(evs) <= 4
        for e in evs:
            assert 360.0 <= e.onset_s and e.end_s <= 1200.0 - 30.0 + 1e-6
            assert e.kind in ei.KIND_PARAMS
        by = {}
        for e in evs:
            for (s0, s1) in by.get(e.approach, []):
                assert e.onset_s >= s1 + 20 or e.end_s + 20 <= s0
            by.setdefault(e.approach, []).append((e.onset_s, e.end_s))
    assert ei.make_schedule(1, 300.0, 1200.0, APPS, rate=0.0) == []


def test_eligible_lanes_requires_escape_neighbour():
    t = {0: {"a"}, 1: {"a", "b"}, 2: {"c"}}
    assert ei.eligible_lanes(t) == [0]          # 0 -> neighbour 1 covers {a}; 1,2 have no cover
    assert ei.eligible_lanes({0: {"a"}}) == []


def test_choose_stop_pos_respects_gaps_and_braking():
    rng = np.random.default_rng(0)
    pos = ei.choose_stop_pos(100.0, [], 5.0, rng)
    assert pos is not None and 100.0 - 60.0 <= pos <= 96.0
    # a fast follower 30 m behind the window blocks spots too close ahead of it
    for _ in range(20):
        p = ei.choose_stop_pos(100.0, [(45.0, 5.0, 12.0)], 5.0, rng)
        assert p is None or (p - 5.0) - 45.0 >= 12.0 ** 2 / 6.0 + 5.0 - 1e-6
    full = [(100.0 - 3.0 * k, 5.0, 0.0) for k in range(25)]
    assert ei.choose_stop_pos(100.0, full, 5.0, rng) is None


# ------------------------------------------------------------- lifecycle
class FakeAdapter:
    def __init__(self, insert_ok=True, gap=True, cands=None, convert_raises=False):
        self.insert_ok, self.gap = insert_ok, gap
        self.cands = list(cands or [])
        self.convert_raises = convert_raises
        self.present_set, self.removed, self.inserted = set(), [], []
        self.converted, self.resumed = [], []

    def lane_candidates(self, lane): return list(self.cands)
    def convert(self, ev, vid, end_pos, lane_index):
        if int(lane_index) < 0:
            raise RuntimeError(f"No lane with index '{lane_index}' on edge '{ev.edge}'.")
        if self.convert_raises:
            raise RuntimeError("too close to break")
        self.converted.append((vid, end_pos, int(lane_index)))
    def resume(self, vid): self.resumed.append(vid)

    def ensure_types(self): pass
    def lane_targets(self, edge): return {0: {"x"}, 1: {"x"}}
    def lane_length(self, lane): return 80.0
    def lane_vehicles(self, lane): return [] if self.gap else [(80.0 - 3 * k, 5.0, 0.0) for k in range(30)]
    def insert(self, ev): self.inserted.append(ev.vid)
    def present(self, vid):
        if self.insert_ok and vid in self.inserted:
            self.present_set.add(vid)
        return vid in self.present_set
    def freeze(self, vid): pass
    def pose(self, vid): return (1.0, 2.0, 90.0)
    def remove(self, vid): self.removed.append(vid); self.present_set.discard(vid)


def _one_event(onset=10.0, dur=100.0):
    return [ei.EventSpec(eid=0, kind="breakdown", approach="E", edge="eE", onset_s=onset,
                         duration_s=dur, length_m=4.8)]


def test_injector_lifecycle_and_queries():
    ad = FakeAdapter()
    inj = ei.EventInjector(ad, _one_event(), seed=3)
    for t in np.arange(0.0, 130.0, 1.0):
        inj.tick(float(t))
        if 12.0 <= t <= 100.0:
            ev = inj.events[0]
            assert ev.status == "active"
            assert inj.blocked_lanes() == {ev.lane_id}
            assert inj.lane_blocked_ahead(ev.lane_id, ev.stop_pos - 30.0)
            assert not inj.lane_blocked_ahead(ev.lane_id, ev.stop_pos + 1.0)
            assert inj.truth_approaches() == {"E": 1}
            assert inj.visual_list()[0]["kind"] == "breakdown"
    assert inj.events[0].status == "done" and ad.removed == ["evt_0"]
    assert inj.stats["started"] == 1 and inj.stats["failed"] == 0
    assert 95.0 <= inj.stats["active_s"] <= 101.0


def test_injector_insert_timeout_and_no_gap_retry():
    ad = FakeAdapter(insert_ok=False)
    inj = ei.EventInjector(ad, _one_event(), seed=1, insert_timeout_s=5.0)
    for t in range(0, 30):
        inj.tick(float(t))
    assert inj.events[0].status == "failed" and inj.stats["failed"] == 1 and "evt_0" in ad.removed
    ad2 = FakeAdapter(gap=False)
    inj2 = ei.EventInjector(ad2, _one_event(), seed=1)
    for t in range(0, 20):
        inj2.tick(float(t))
    assert inj2.events[0].status == "scheduled" and inj2.events[0].attempts >= 5   # keeps retrying
    for t in range(20, 130):
        inj2.tick(float(t))
    assert inj2.events[0].status == "failed"                                       # expired unseen


class FakeTraci:
    def __init__(self):
        self.calls = []
        outer = self

        class _VT:
            def getIDList(self): return ["DEFAULT_VEHTYPE"]
            def copy(self, a, b): outer.calls.append(("vt.copy", a, b))
            def setLength(self, *a): outer.calls.append(("vt.len",) + a)
            def setMinGap(self, *a): pass
            def setColor(self, *a): pass

        class _Edge:
            def getLaneNumber(self, e): return 2

        class _Lane:
            def getLinks(self, l): return [("out_0", True, True, False, ":j", "G", "s", 1.0)] if l.endswith("_0") \
                else [("out_1", True, True, False, ":j", "G", "s", 1.0), ("left_0", True, True, False, ":j", "g", "l", 1.0)]
            def getLength(self, l): return 50.0
            def getLastStepVehicleIDs(self, l): return []

        class _Route:
            def getIDList(self): return []
            def add(self, rid, edges): outer.calls.append(("route.add", rid, tuple(edges)))

        class _Veh:
            def add(self, vid, rid, **kw): outer.calls.append(("veh.add", vid, rid, kw))
            def setStop(self, vid, edge, **kw): outer.calls.append(("veh.stop", vid, edge, kw))
            def getIDList(self): return []

        self.vehicletype, self.edge, self.lane, self.route, self.vehicle = _VT(), _Edge(), _Lane(), _Route(), _Veh()


def test_traci_adapter_calls():
    ft = FakeTraci()
    ad = ei.TraciEventAdapter(ft)
    ad.ensure_types()
    assert {c[2] for c in ft.calls if c[0] == "vt.copy"} == {"EVT_BREAKDOWN", "EVT_ROADWORK"}
    assert ad.lane_targets("eE") == {0: {"out"}, 1: {"out", "left"}}
    ev = ei.EventSpec(eid=4, kind="roadwork", approach="E", edge="eE", onset_s=0.0, duration_s=200.0,
                      length_m=14.0, lane_index=0, lane_id="eE_0", stop_pos=40.0)
    ad.insert(ev)
    ad.insert(ev)
    assert sum(1 for c in ft.calls if c[0] == "route.add") == 1
    add = [c for c in ft.calls if c[0] == "veh.add"][0]
    assert add[1] == "evt_4" and add[3]["typeID"] == "EVT_ROADWORK" and add[3]["departSpeed"] == "0"
    stop = [c for c in ft.calls if c[0] == "veh.stop"][0]
    assert stop[3]["laneIndex"] == 0 and stop[3]["duration"] >= 200.0 and stop[3]["startPos"] < 40.0
    fresh = ei.EventSpec(eid=5, kind="breakdown", approach="E", edge="eE", onset_s=0.0, duration_s=200.0,
                         length_m=4.8)
    assert fresh.lane_index == -1
    ad.convert(fresh, "h9", 30.0, 1)
    conv = [c for c in ft.calls if c[0] == "veh.stop" and c[1] == "h9"][0]
    assert conv[2] == "eE" and conv[3]["pos"] == 30.0 and conv[3]["duration"] == 200.0 \
        and conv[3]["startPos"] == 24.0 and conv[3]["laneIndex"] == 1
    try:
        ad.convert(fresh, "h9", 30.0, -1)
        raise AssertionError("negative lane index must be rejected")
    except ValueError:
        pass


# ------------------------------------------------------- capacity & perception
def test_capacity_factors_and_approach_spread():
    lanes = {0: ["eE_0", "eE_1"], 1: ["eE_2"], 2: ["eN_0"]}
    assert ei.phase_capacity_factors(lanes, 3, ei.lane_probs_from_lanes({"eE_1"})) == [0.5, 1.0, 1.0]
    probs = ei.lane_probs_from_approach_counts({"E": 1}, {"E": ["eE_0", "eE_1", "eE_2"]})
    f = ei.phase_capacity_factors(lanes, 3, probs)
    assert abs(f[0] - (1 - 1 / 3)) < 1e-9 and abs(f[1] - (1 - 1 / 3)) < 1e-9 and f[2] == 1.0
    assert ei.phase_capacity_factors({}, 2, {}) == [1.0, 1.0]


def test_stall_detector():
    d = ei.LaneStallDetector(stall_s=8.0)
    ids = frozenset({"a", "b"})
    for t in range(0, 6):
        d.update(t, {"L": (False, 2, ids)})            # red: never flagged
    assert d.stalled() == set()
    for t in range(6, 16):
        d.update(t, {"L": (True, 2, ids)})             # green, halted, no departure
    assert d.stalled() == {"L"}
    d.update(16, {"L": (True, 1, frozenset({"b"}))})   # 'a' discharged -> recovered
    assert d.stalled() == set()


def test_perception_score():
    sc = ei.PerceptionScore()
    ev = ei.EventSpec(eid=0, kind="breakdown", approach="E", edge="eE", onset_s=100.0, duration_s=100.0,
                      length_m=4.8, insert_t=100.0)
    sc.update(100.0, [ev], set())
    sc.update(104.0, [ev], {"E"})
    sc.update(105.0, [ev], {"E", "N"})
    s = sc.summary()
    assert s["v7_evt_detect_latency_s"] == 4.0 and s["v7_evt_detected_frac"] == 1.0
    assert abs(s["v7_evt_perc_precision"] - 2 / 3) < 1e-9 and abs(s["v7_evt_perc_recall"] - 2 / 3) < 1e-9


def test_parse_event_json_robust():
    apps = ["N", "S", "E", "W"]
    assert "ORANGE cars are connected vehicles" in ep.SYSTEM_PROMPT_EVENT_PERCEPTION
    assert "YELLOW-AND-BLACK" in ep.SYSTEM_PROMPT_EVENT_PERCEPTION and "TRIANGLE" in ep.SYSTEM_PROMPT_EVENT_PERCEPTION
    r = ep.parse_event_json('```json\n{"approaches": {"e": {"blocked_lanes": 1, "type": "roadwork"}, '
                            '"N": {"blocked_lanes": "0"}, "X": {"blocked_lanes": 3}}, "confidence": 0.8}\n```', apps)
    assert r["valid"] == 1.0 and r["counts"] == {"E": 1, "N": 0} and r["types"]["E"] == "roadwork"
    assert ep.parse_event_json("{'approaches': {'W': {'blocked_lanes': 9, 'type': 'odd'}}}", apps)["counts"] == {"W": 4}
    assert ep.parse_event_json("no json here", apps)["valid"] == 0.0
    assert ep.parse_event_json('{"approaches": []}', apps)["valid"] == 0.0


def test_perception_scheduler_triggers_budget_expiry():
    calls = []

    def fake_fetch(enc, snap, apps):
        calls.append(snap.get("stats", {}).get("time"))
        return {"counts": {"E": 1}, "types": {"E": "breakdown"}, "confidence": 0.9, "valid": 1.0}

    s = ep.EventPerceptionScheduler(None, ["N", "E"], interval_s=30.0, max_calls=3,
                                    async_calls=False, fetch_fn=fake_fetch, expire_s=60.0)
    s.tick(0.0, {"stats": {"time": 0.0}})                      # periodic; answer reports E -> 15 s cadence
    s.tick(10.0, {"stats": {"time": 10.0}})                    # not due (15 s active cadence)
    s.tick(15.0, {"stats": {"time": 15.0}}, anomaly=True)     # rising edge of the legacy flag -> trigger
    s.tick(20.0, {"stats": {"time": 20.0}}, anomaly=True)     # level stays high -> no new trigger (v7.5)
    s.tick(40.0, {"stats": {"time": 40.0}})                    # 25 s after 15 >= 15 s active cadence -> due
    s.tick(46.0, {"stats": {"time": 46.0}})                    # budget (3) exhausted
    s.tick(90.0, {"stats": {"time": 90.0}})
    assert calls == [0.0, 15.0, 40.0]
    assert s.blockage(47.0) == {"E": 1} and s.blockage(107.0) == {}   # expires 60 s after request
    s.reset()
    assert s.blockage(1.0) == {} and s.stats()["v7_evt_vlm_calls"] == 0.0
    low = ep.EventPerceptionScheduler(None, ["E"], interval_s=1.0, async_calls=False, min_conf=0.5,
                                      fetch_fn=lambda *a: {"counts": {"E": 2}, "confidence": 0.3, "valid": 1.0})
    low.tick(0.0, {})
    assert low.blockage(0.5) == {}


# --------------------------------------------------------------- integration
def _ast_tuple(path, name, cls=None):
    tree = ast.parse(open(os.path.join(ROOT, path), encoding="utf-8").read())
    body = tree.body
    if cls:
        body = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == cls).body
    for n in body:
        if isinstance(n, ast.Assign) and any(getattr(t, "id", None) == name for t in n.targets):
            return ast.literal_eval(n.value)
    raise KeyError(name)


def test_kpi_keys_consistent_between_env_and_sumo():
    a = _ast_tuple("environment/SUMO_interface.py", "V7_EVENT_KPI_KEYS", cls="SUMOEnvironment")
    b = _ast_tuple("environment/marl_env.py", "V7_EVENT_KPI_KEYS")
    assert tuple(a) == tuple(b)


def test_marl_env_vlm_tick_end_to_end_with_fake_encoder():
    src = open(os.path.join(ROOT, "environment/marl_env.py"), encoding="utf-8").read()
    tree = ast.parse(src)
    cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == "MultiAgentTrafficEnv")
    fn = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == "_v7_event_vlm_tick")
    from collections.abc import Mapping
    ns = {"Mapping": Mapping, "os": os, "_finite_float": lambda v, d=0.0: float(v) if v is not None else d}
    exec(textwrap.dedent(ast.get_source_segment(src, fn)), ns)
    sys.modules.setdefault("VLM.vlm_call_config", types.SimpleNamespace(CHANNEL_SIGNAL_VISION="signal_vision"))

    class Enc:
        def prepare_scene_image(self, state, **kw):
            assert "events_visual" in state
            return "AAAA"
        def resolve_call_budget(self, ch): return ("off", {}, 128, {})
        def _chat_once(self, msgs, **kw):
            assert "Approaches in this picture: N, E" in msgs[1]["content"][0]["text"]
            return '{"approaches": {"E": {"blocked_lanes": 1, "type": "breakdown"}}, "confidence": 0.9}'

    pushed = {}
    sumo = SimpleNamespace(scenario_approach_edges={"N": ("eN",), "E": ("eE",)}, _sim_time=0.0,
                           set_v7_vlm_blockage=lambda c: pushed.update({"c": dict(c)}))
    env = SimpleNamespace(reward_fn=SimpleNamespace(vlm=Enc()), sumo_env=sumo, scenario_key="4leg")
    os.environ["V7_EVENT_VLM_INTERVAL_S"] = "30"
    try:
        ns["_v7_event_vlm_tick"](env, {"stats": {"time": 500.0, "v7_numeric_stall_apps": [],
                                                 "v7_evt_truth_apps": ["E"]}})
        import time as _t
        for _ in range(400):                                   # async worker finishes the call
            if env._v7_event_vlm._pending is not None:
                break
            _t.sleep(0.005)
        ns["_v7_event_vlm_tick"](env, {"stats": {"time": 509.0}})   # commit on the main thread
        assert pushed["c"] == {"E": 1}
        st = env._v7_event_vlm.stats()
        assert st["v7_evt_ans_recall"] == 1.0 and 8.9 <= st["v7_evt_vlm_lat_sim_mean"] <= 9.1
    finally:
        os.environ.pop("V7_EVENT_VLM_INTERVAL_S", None)


def test_renderer_draws_events_and_labels():
    try:
        import cv2  # noqa: F401
    except Exception:
        return
    net = os.environ.get("V7_TEST_NET", "/mnt/user-data/uploads/4-leg_4phases__net.xml")
    if not os.path.isfile(net):
        return
    import math
    import xml.etree.ElementTree as ET
    from VLM.bev_renderer import BEVRenderer
    lanes = {l.get("id"): [tuple(map(float, p.split(","))) for p in l.get("shape").split()]
             for e in ET.parse(net).getroot().iter("edge") for l in e.iter("lane")}
    pts = lanes["610330469#0_1"]
    (x0, y0), (x1, y1) = pts[-2], pts[-1]
    L = math.hypot(x1 - x0, y1 - y0)
    ux, uy = (x1 - x0) / L, (y1 - y0) / L
    ang = math.degrees(math.atan2(ux, uy)) % 360.0
    r = BEVRenderer(width=512, height=512, map_range=90.0, layout="dublin", net_xml_path=net,
                    junction_center=(9446.71, 4073.57))
    r.configure_scenario(net_xml_path=net, junction_center=(9446.71, 4073.57),
                         approach_edges={"E": ("610330469#0",), "N": ("610330470#0",)})
    base = {"cavs": {}, "hdvs": {}, "signals": {}, "stats": {"time": 1.0}}
    plain = r.render(dict(base))
    ev = {"kind": "roadwork", "x": x1 - ux * 6, "y": y1 - uy * 6, "angle": ang, "length_m": 14.0}
    with_ev = r.render({**base, "events_visual": [ev]})
    diff = np.abs(with_ev.astype(int) - plain.astype(int)).sum(axis=2) > 30
    assert diff.sum() > 200                                    # barrier + cones + labels drawn
    yellow = (with_ev[:, :, 0] > 200) & (with_ev[:, :, 1] > 180) & (with_ev[:, :, 2] < 60)
    dark = (with_ev.sum(axis=2) < 90) & diff
    assert yellow.sum() > 20 and dark.sum() > 5            # v7.4 yellow/black hatched closure board
    orange_new = ((with_ev[:, :, 0] > 200) & (with_ev[:, :, 1] > 100) & (with_ev[:, :, 1] < 170)
                  & (with_ev[:, :, 2] < 60) & ~((plain[:, :, 0] > 200) & (plain[:, :, 1] > 100)))
    assert orange_new.sum() < 5                              # no orange (CAV colour) in event symbols




def _sumo_stub_class(fake_traci):
    src = open(os.path.join(ROOT, "environment/SUMO_interface.py"), encoding="utf-8").read()
    tree = ast.parse(src)
    cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == "SUMOEnvironment")
    names = ("_v7_perception_mode", "_v7_events_reset", "set_v7_vlm_blockage", "_v7_lane_links",
             "_v7_events_state", "_v7_exclude_vehicle")
    ns = {"os": os, "traci": fake_traci, "tc": SimpleNamespace(VAR_SPEED=64)}
    body = "\n".join(textwrap.indent(textwrap.dedent(ast.get_source_segment(src, n)), "    ")
                     for n in cls.body if isinstance(n, ast.FunctionDef) and n.name in names)
    code = "class Stub:\n" + body + "\n"
    exec(code, ns)
    Stub = ns["Stub"]
    Stub._env_on = staticmethod(lambda name, default="0": os.environ.get(name, default) in ("1", "true"))
    Stub._traci_valid_double = classmethod(lambda cls, v, non_negative=False: None if v is None else float(v))
    return Stub


class FakeTraci2:
    def __init__(self):
        self.t = 300.0
        self.halting = {}
        self.ids = {}
        self.sig = "GGrr"
        outer = self
        self.simulation = SimpleNamespace(getTime=lambda: outer.t)
        self.trafficlight = SimpleNamespace(
            getRedYellowGreenState=lambda tls: outer.sig,
            getControlledLinks=lambda tls: [[("eE_0", "o", ":v")], [("eE_1", "o", ":v")],
                                            [("eN_0", "o", ":v")], [("eN_1", "o", ":v")]])
        self.lane = SimpleNamespace(getLastStepHaltingNumber=lambda l: outer.halting.get(l, 0),
                                    getLastStepVehicleIDs=lambda l: list(outer.ids.get(l, ())))


def _mk_stub(mode, events_on="0"):
    ft = FakeTraci2()
    Stub = _sumo_stub_class(ft)
    os.environ["V7_EVENT_PERCEPTION"] = mode
    os.environ["V7_EVENTS"] = events_on
    st = Stub()
    st.scenario_approach_edges = {"E": ("eE",), "N": ("eN",)}
    st._phase_incoming_lanes = {"tls": {0: ["eE_0", "eE_1"], 1: ["eN_0", "eN_1"]}}
    st.sub_results = {"h1": {64: 0.0}, "h2": {64: 5.0}}
    st._v7_events_reset(seed=5)
    return st, ft


def _state():
    return {"stats": {}}


def test_sumo_events_state_modes():
    try:
        # oracle: an active injected event on eE_1 halves phase 0
        st, ft = _mk_stub("oracle", events_on="1")
        st._v7_evt = ei.EventInjector(FakeAdapter(), _one_event(onset=300.0, dur=200.0), seed=2)
        st._v7_evt.events[0].edge = "eE"
        for k in range(3):
            ft.t = 300.0 + k
            st._v7_evt.tick(ft.t)
        s = _state()
        st._v7_events_state(s, "tls", 2)
        lane = st._v7_evt.events[0].lane_id
        assert lane in ("eE_0", "eE_1")
        assert s["stats"]["phase_capacity_factor"] == [0.5, 1.0]
        assert s["events_visual"] and s["stats"]["v7_evt_started"] == 1.0
        assert s["stats"]["v7_evt_perc_recall"] == 1.0
        assert s["stats"]["v7_evt_truth_apps"] == ["E"]
        assert s["stats"]["v7_evt_halted_in"] == 1.0          # one halted subscribed vehicle

        # numeric: eE_1 green, halted, no departures for > 8 s -> stalled
        st, ft = _mk_stub("numeric")
        ft.halting = {"eE_1": 3}
        ft.ids = {"eE_1": ("a", "b", "c")}
        for k in range(12):
            ft.t = 300.0 + k
            s = _state()
            st._v7_events_state(s, "tls", 2)
        assert s["stats"]["phase_capacity_factor"] == [0.5, 1.0]
        assert s["stats"]["v7_numeric_stall_any"] == 1.0
        assert s["stats"]["v7_numeric_stall_apps"] == ["E"] and s["stats"]["v7_evt_truth_apps"] == []
        assert "events_visual" not in s                      # no events injected

        # vlm: approach-level count spread over the approach lanes
        st, ft = _mk_stub("vlm")
        st.set_v7_vlm_blockage({"N": 1})
        s = _state()
        st._v7_events_state(s, "tls", 2)
        assert s["stats"]["phase_capacity_factor"] == [1.0, 0.5]

        # off + events: no capacity information, KPIs still logged
        st, ft = _mk_stub("off", events_on="1")
        s = _state()
        st._v7_events_state(s, "tls", 2)
        assert s["stats"]["phase_capacity_factor"] == [1.0, 1.0]
        assert "v7_evt_scheduled" in s["stats"]

        # nothing enabled -> no work at all
        st, ft = _mk_stub("off", events_on="0")
        s = _state()
        st._v7_events_state(s, "tls", 2)
        assert s["stats"] == {}
    finally:
        os.environ.pop("V7_EVENT_PERCEPTION", None)
        os.environ.pop("V7_EVENTS", None)




def test_choose_convert_candidate():
    vs = [("h_far", 40.0, 0.0, 5.0, False), ("h_head", 76.0, 0.0, 5.0, False),
          ("c_head", 79.0, 0.0, 5.0, True), ("evt_3", 78.0, 0.0, 5.0, False)]
    assert ei.choose_convert_candidate(80.0, vs)[0] == "h_head"           # head-most HDV, skip CAV/evt
    fast = [("h_fast", 70.0, 12.0, 5.0, False), ("h_slow", 50.0, 2.0, 5.0, False)]
    vid, end = ei.choose_convert_candidate(80.0, fast)
    assert vid == "h_slow" and abs(end - (50.0 + 4.0 / 6.0 + 0.1)) < 1e-9   # 12 m/s cannot stop in 10 m
    assert ei.choose_convert_candidate(80.0, [("h", 10.0, 0.0, 5.0, False)]) is None   # outside 60 m window
    assert ei.choose_convert_candidate(30.0, []) is None


def test_injector_convert_mode_lifecycle():
    excluded = []
    ad = FakeAdapter(cands=[("h1", 70.0, 0.0, 5.0, False), ("c1", 75.0, 0.0, 5.0, True)])
    inj = ei.EventInjector(ad, _one_event(onset=10.0, dur=100.0), seed=1, on_convert=excluded.append,
                           log=lambda *a, **k: None)
    for t in range(0, 12):
        inj.tick(float(t))
    ev = inj.events[0]
    assert ev.status == "active" and ev.mode == "convert" and ev.vid == "h1"
    assert excluded == ["h1"] and ad.converted and ad.inserted == []
    assert ad.converted[0][2] == ev.lane_index >= 0
    assert inj.host_vids() == {"h1"}
    assert not inj.lane_blocked_ahead(ev.lane_id, 69.0, vid="h1")          # host itself stays put
    assert inj.lane_blocked_ahead(ev.lane_id, 50.0, vid="h2")              # followers may escape
    vis = inj.visual_list()[0]
    assert vis["vid"] == "h1" and vis["length_m"] == 4.8
    for t in range(12, 115):
        inj.tick(float(t))
    assert ev.status == "done" and ad.resumed == ["h1"] and ad.removed == []
    assert inj.stats["converted"] == 1 and inj.stats["started"] == 1


def test_injector_convert_rejected_falls_back_to_insert():
    ad = FakeAdapter(cands=[("h1", 70.0, 0.0, 5.0, False)], convert_raises=True)
    inj = ei.EventInjector(ad, _one_event(), seed=1, log=lambda *a, **k: None)
    for t in range(0, 15):
        inj.tick(float(t))
    assert inj.events[0].mode == "insert" and inj.events[0].status == "active"
    ad2 = FakeAdapter(cands=[], gap=False)
    inj2 = ei.EventInjector(ad2, _one_event(), seed=1, allow_insert=False, log=lambda *a, **k: None)
    for t in range(0, 130):
        inj2.tick(float(t))
    assert inj2.events[0].status == "failed" and inj2.events[0].fail_reason == "no_candidate"
    assert inj2.stats.get("fail_no_candidate") == 1.0


def test_perception_fp_rate():
    sc = ei.PerceptionScore()
    for _ in range(4):
        sc.update(0.0, [], {"N"}, all_approaches=["N", "E", "S", "W"])
    assert abs(sc.summary()["v7_evt_perc_fp_rate"] - 0.25) < 1e-9


def test_sumo_convert_excludes_kpis_and_fp_without_events():
    try:
        st, ft = _mk_stub("vlm", events_on="0")
        st._tis_s = {"h1": 100.0, "h2": 120.0}
        st._tis_unf_n, st._tis_unf_sum = 2, 220.0
        st._v7_exclude_vehicle("h1")
        assert "h1" in st._v7_evt_excluded and st._tis_unf_n == 1 and st._tis_unf_sum == 120.0
        st.set_v7_vlm_blockage({"N": 1})
        s = _state()
        st._v7_events_state(s, "tls", 2)
        assert s["stats"]["v7_evt_perc_fp_rate"] == 0.5                    # N predicted, E clear
        ft.t += 0.2                                                         # non-sampled step keeps the KPI
        s2 = _state()
        st._v7_events_state(s2, "tls", 2)
        assert s2["stats"]["v7_evt_perc_fp_rate"] == 0.5
    finally:
        os.environ.pop("V7_EVENT_PERCEPTION", None)
        os.environ.pop("V7_EVENTS", None)


def test_renderer_skips_host_vehicle():
    try:
        import cv2  # noqa: F401
    except Exception:
        return
    net = os.environ.get("V7_TEST_NET", "/mnt/user-data/uploads/4-leg_4phases__net.xml")
    if not os.path.isfile(net):
        return
    drawn = []
    sys.modules["VLM.vehicle_shape"] = types.SimpleNamespace(
        draw_sumo_car=lambda renderer, img, px, py, ang, is_cav=False, length_m=None: drawn.append((px, py)))
    from VLM.bev_renderer import BEVRenderer
    r = BEVRenderer(width=256, height=256, map_range=90.0, layout="dublin", net_xml_path=net,
                    junction_center=(9446.71, 4073.57))
    car = {"position": (9446.71 + 20.0, 4073.57 - 20.0), "angle": 300.0, "lane": "610330469#0_1", "speed": 0.0}
    base = {"cavs": {}, "hdvs": {"h1": dict(car), "h2": dict(car, position=(9446.71 + 30.0, 4073.57 - 25.0))},
            "signals": {}, "stats": {"time": 1.0}}
    r.render(base)
    n_plain = len(drawn)
    drawn.clear()
    r.render({**base, "events_visual": [{"kind": "breakdown", "vid": "h1", "x": car["position"][0],
                                         "y": car["position"][1], "angle": 300.0, "length_m": 4.8,
                                         "lane": "610330469#0_1"}]})
    assert n_plain == 2 and len(drawn) == 1


class SumoLikeTraci:
    """Fake TraCI that validates setStop like SUMO (lane index, edge, braking)."""

    def __init__(self, lane_len=36.1, n_lanes=3, queue=None, decel=4.5):
        self.edge_id = "W"
        self.lane_len = lane_len
        self.n_lanes = n_lanes
        self.decel = decel
        # vid -> dict(lane, pos, speed, length, type)
        self.veh = dict(queue or {})
        self.stopped = {}
        self.stops = []
        outer = self

        class _Edge:
            def getLaneNumber(self, e): return outer.n_lanes

        class _Lane:
            def getLinks(self, l):
                i = int(l.rsplit("_", 1)[1])
                return [("thru_0", True, True, False, ":j", "G", "s", 1.0)] if i < 2 else \
                       [("left_0", True, True, False, ":j", "G", "l", 1.0)]
            def getLength(self, l): return outer.lane_len
            def getLastStepVehicleIDs(self, l): return [v for v, d in outer.veh.items() if d["lane"] == l]

        class _Veh:
            def getTypeID(self, v): return outer.veh[v]["type"]
            def getLanePosition(self, v): return outer.veh[v]["pos"]
            def getSpeed(self, v): return outer.veh[v]["speed"]
            def getLength(self, v): return outer.veh[v]["length"]
            def getPosition(self, v): return (100.0 + outer.veh[v]["pos"], 50.0)
            def getAngle(self, v): return 90.0
            def getIDList(self): return list(outer.veh)
            def setStop(self, v, edge, pos=1.0, laneIndex=0, duration=-1, flags=0, startPos=-1, until=-1):
                if edge != outer.edge_id:
                    raise RuntimeError(f"Edge '{edge}' is not known.")
                if not (0 <= int(laneIndex) < outer.n_lanes):
                    raise RuntimeError(f"No lane with index '{laneIndex}' on edge '{edge}'.")
                d = outer.veh[v]
                if d["lane"] != f"{edge}_{laneIndex}":
                    raise RuntimeError("stop not on the vehicle's lane")
                brake = d["speed"] ** 2 / (2.0 * outer.decel)
                if pos < d["pos"] + brake - 1e-6 or pos > outer.lane_len:
                    raise RuntimeError(f"Stop for vehicle '{v}' is too close to brake.")
                outer.stopped[v] = True
                outer.stops.append((v, edge, pos, int(laneIndex), duration))
            def isStopped(self, v): return bool(outer.stopped.get(v))
            def resume(self, v): outer.stopped[v] = False
            def remove(self, v): outer.veh.pop(v, None)
            def setLaneChangeMode(self, v, m): pass
            def add(self, *a, **k): raise RuntimeError("no insertion in this test")

        self.edge, self.lane, self.vehicle = _Edge(), _Lane(), _Veh()
        self.vehicletype = SimpleNamespace(getIDList=lambda: ["DEFAULT_VEHTYPE"], copy=lambda *a: None,
                                           setLength=lambda *a: None, setMinGap=lambda *a: None,
                                           setColor=lambda *a: None)
        self.route = SimpleNamespace(getIDList=lambda: [], add=lambda *a: None)


def test_real_adapter_converts_head_vehicle_on_short_saturated_edge():
    # 36.1 m near-junction lane fully queued (the v7.2 smoke situation)
    q = {}
    for lane in ("W_0", "W_1"):
        for k, pos in enumerate((35.0, 27.5, 20.0, 12.5, 5.0)):
            q[f"{lane}_h{k}"] = {"lane": lane, "pos": pos, "speed": 0.0, "length": 5.0,
                                 "type": "HDV" if k != 1 else "CAV_type"}
    ft = SumoLikeTraci(queue=q)
    logs = []
    ev = ei.EventSpec(eid=0, kind="roadwork", approach="W", edge="W", onset_s=10.0, duration_s=180.0,
                      length_m=14.0)
    inj = ei.EventInjector(ei.TraciEventAdapter(ft), [ev], seed=0, allow_insert=False,
                           log=lambda *a, **k: logs.append(a[0]))
    for t in range(0, 12):
        inj.tick(float(t))
    assert ev.status == "active" and ev.mode == "convert", logs
    assert ev.host_vid.endswith("_h0") and ev.lane_index in (0, 1) and ev.rejections == 0
    assert ft.stops[0][3] == ev.lane_index and ft.stopped[ev.host_vid]
    assert any("ACTIVE" in m for m in logs)
    for t in range(12, 200):
        inj.tick(float(t))
    assert ev.status == "done" and not ft.stopped[ev.host_vid]       # released, not removed
    assert ev.host_vid in ft.veh


def test_retry_throttle_and_rejection_log_limit():
    q = {"W_0_h0": {"lane": "W_0", "pos": 35.0, "speed": 0.0, "length": 5.0, "type": "HDV"}}
    ft = SumoLikeTraci(queue=q)
    ft.vehicle.setStop = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("always rejected"))
    logs = []
    ev = ei.EventSpec(eid=0, kind="breakdown", approach="W", edge="W", onset_s=0.0, duration_s=100.0,
                      length_m=4.8)
    inj = ei.EventInjector(ei.TraciEventAdapter(ft), [ev], seed=0, allow_insert=False,
                           log=lambda *a, **k: logs.append(a[0]))
    for k in range(0, 50):                     # 10 s of 0.2 s steps
        inj.tick(k * 0.2)
    assert 9 <= ev.attempts <= 11               # one attempt per second
    assert sum("convert rejected" in m for m in logs) == 3 and ev.rejections >= 9


def test_fixed_event_count():
    apps = {"N": "eN", "S": "eS", "E": "eE", "W": "eW"}
    base = ei.make_schedule(70000 + 7000003, 300.0, 1200.0, apps, rate=3.0)
    same = ei.make_schedule(70000 + 7000003, 300.0, 1200.0, apps, rate=3.0, count=0)
    assert [(e.approach, e.onset_s) for e in base] == [(e.approach, e.onset_s) for e in same]
    for seed in range(20):
        assert len(ei.make_schedule(seed, 300.0, 1200.0, apps, rate=1.0, count=3)) == 3


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for f in fns:
        f()
        print("PASS", f.__name__)
    print(f"{len(fns)} v7.1 event tests passed")
