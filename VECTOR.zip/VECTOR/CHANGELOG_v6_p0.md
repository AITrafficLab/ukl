# CHANGELOG v5.2.4 → v6-P0（可行性关口 + 执行权限审计）

依据：《VECTOR v5.2.4 全面诊断与 v6 落地方案》第 3–4、8 节。
原则：默认 `--profile v524` 与 v5.2.4 行为一致（差分测试：200 组随机回合控制指令逐条相同）；
`--profile v6p0` 一次打开全部 P0 改动；命令行显式给出的参数永远优先于 profile。

## 1. `--profile v6p0` 打开的改动

| 改动 | 开关 | v524 | v6p0 |
|---|---|---|---|
| 纵向 RL 作用区上限 | `--lon-rl-max-dist-m` | 300 | 200 |
| 停车线前不做 RL（无观测、无样本） | `--lon-rl-min-dist-m` | 0 | 20 |
| 路口内部做 RL | `--lon-rl-in-junction` | 开 | 关 |
| 执行方式 | `--lon-actuation` | accel | speed |
| 四个加速度下限 | `--lon-no-floors` | 关 | 开 |
| 停车线前交还 SUMO | `--lon-handback-near-m` | 0 | 20 |
| 间距策略 | `--gap-policy` | legacy | unified |
| 信号奖励饱和上限 | `--signal-reward-sat` | 1.0 | 4.0 |
| 软启动模仿系数 | `--lon-imitation-scale` | 0.10 | 0 |
| PPO 权限过滤阈值 | `--cacc-ppo-authority-min` | 0.20（死代码） | 0.5 |
| VLM 纵向观测尺度 | 随 profile | ×0.02 | ×0.05 |

## 2. 统一间距策略 `environment/gap_policy.py`（新增）

所有间距/时距阈值的唯一来源。`unified` 的顺序：
屏蔽触发 0.5 s / 1.0 m < CACC 跟 CAV 0.6 s = 奖励下沿 < 编队上沿 1.0 s < CACC 跟 HDV 1.2 s = HDV 奖励下沿。
修复 v5.2.4 的冲突：CACC 目标 0.6 s 低于屏蔽触发 0.85 s（控制器一达到目标就被压回 a_IDM）；跟 HDV 也用 0.6 s 而奖励要求 1.2–2.0 s。
接入点：`platoon_manager.safe_gap/platoon_gap`、`SUMO_interface` 的 CACC 目标与屏蔽触发、`longitudinal_reward` 的 v2 时距区间。

## 3. 新增诊断与工具（默认开启，只观测）

- `[Diag-Auth]`（每回合一行，同时写 TensorBoard `Metrics/auth_*`）：策略残差、规则栈残差、SUMO 实际残差（均相对 a_IDM），
  `stack_cut`、`stack_lift`、`pos_exec_ratio`（策略要求加速且被执行的比例）、`sumo_cut`、`sumo_lift`。
- `--signal-rule maxpressure|longest_queue`：在 RL 自己的掩码内用规则选相位；被替换的智能体样本记为被覆盖、不进 PPO。
  用作 Max-Pressure 基线，或在定位 CAV 控制栈时固定信号侧。
- `--gate-lon-episodes N`：关口排程 S2 / Lon N / Lat1，无联合阶段。
- `scripts/p0_gate.py`：并行跑 G0 原生 IDM / G1 v5.2.4 规则栈 / G2 P0 规则栈 / G3 P0 + RL，解析日志并给出 GATE-1、GATE-2 结论。

## 4. 性能（行为不变）

- 受控 CAV 不再每步重发 `setSpeedMode(31)`；
- 从未受控的 CAV 不再每步被"释放"（每车每步省两次 TraCI 调用）。

## 验证

- 原有 67 项 + 新增 36 项离线测试（`tests/test_v6_p0.py`，含 5 个 `step()` 端到端测试）全部通过，1 项按设计跳过；静态检查 0 问题。
- 差分测试：默认配置下 200 组随机 30 步回合，控制与信号指令与原始 v5.2.4 逐条相同。
- 沙箱无 SUMO/torch：真实效果以 `scripts/p0_gate.py` 的结果为准。
