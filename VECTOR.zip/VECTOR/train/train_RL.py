import argparse
import os
import random
import sys
import shutil
import time
import tempfile

import numpy as np
import torch
import torch.multiprocessing as mp
# mp.set_start_method belongs in main(), not at import time.
import yaml

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Bind TraCI backend before environment.SUMO_interface imports traci.
# Headless → libsumo (USE_LIBSUMO default 1); --gui → classic TraCI sockets.
if "--gui" in sys.argv:
    os.environ["USE_LIBSUMO"] = "0"
elif "USE_LIBSUMO" not in os.environ:
    os.environ["USE_LIBSUMO"] = "1"

# CRITICAL (Windows): load libsumo/_libsumo.pyd BEFORE torch_geometric.
# agents.mappo imports torch_geometric, which pulls DLLs that conflict with
# sumo-data's arrow/z stack ("DLL load failed ... specified procedure could
# not be found"). Binding here (and on spawn re-import) keeps headless train
# on in-process libsumo; algorithm code is unchanged.
if str(os.environ.get("USE_LIBSUMO", "1")).strip().lower() not in (
    "0",
    "false",
    "no",
    "off",
):
    if "SUMO_HOME" in os.environ:
        _sumo_tools = os.path.join(os.environ["SUMO_HOME"], "tools")
        if _sumo_tools not in sys.path:
            sys.path.insert(0, _sumo_tools)
    try:
        import libsumo as _libsumo_early

        os.environ.setdefault("LIBSUMO_AS_TRACI", "1")
        sys.modules["traci"] = _libsumo_early
        if "traci.constants" not in sys.modules and hasattr(
            _libsumo_early, "constants"
        ):
            sys.modules["traci.constants"] = _libsumo_early.constants
        print("[SUMO] early-bind: libsumo before torch_geometric", flush=True)
    except Exception as _libsumo_exc:
        print(
            f"[SUMO] early-bind libsumo failed ({type(_libsumo_exc).__name__}: "
            f"{_libsumo_exc}); will try again in SUMO_interface",
            flush=True,
        )

from agents.mappo import MAPPOAgent
from baselines.curve_band import save_curve_bands
from baselines.experiment_seeds import EXPERIMENT_SEEDS
from baselines.result_paths import (
    MAIN_METHOD,
    VISION_MODE_FULL,
    VISION_MODE_NONE,
    VISION_MODE_ONLY_LAT,
    VISION_MODE_ONLY_LON,
    VISION_MODE_ONLY_SIGNAL,
    allocate_train_tb_run_dir,
    bev_run_dir,
    discover_tb_run_for_resume,
    ensure_dir,
    infer_scenario_key,
    migrate_flat_tb_events_into_run,
    path_looks_volatile,
    resolve_results_method,
    train_ckpt_dir,
    train_run_dir,
    train_tb_dir,
    train_tb_run_dir,
)
from baselines.reward_tb import SafeSummaryWriter, format_episode_log
from baselines.torch_device import resolve_torch_device
from baselines.train_resume import (
    completed_episodes,
    resolve_resume_file,
    resume_tb_run_name,
    torch_load,
    write_resume_meta,
)
from environment.marl_env import MultiAgentTrafficEnv, V524_KPI_KEYS, V6_AUTH_KPI_KEYS
from environment.tls_phases import n_green_from_sumocfg
from agents.cav_lateral_agent import build_lateral_actor
from agents.cav_longitudinal_agent import build_longitudinal_actor
from agents.signal_agent import build_signal_actor
from networks.critic import CentralizedCritic
from train.credit_utils import (
    is_lon_noop,
    rollout_fallback_mean,
    step_deltas as credit_step_deltas,
)


PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
CONFIG_PATH = os.path.join(PROJECT_ROOT, 'experiments', 'config.yaml')


def load_config():
    with open(CONFIG_PATH, 'r', encoding='utf-8') as config_file:
        return yaml.safe_load(config_file) or {}


def _atomic_torch_save(payload, path):
    """Write a checkpoint to a same-directory temporary file, then replace atomically."""
    target = os.path.abspath(os.fspath(path))
    parent = os.path.dirname(target)
    os.makedirs(parent, exist_ok=True)
    fd, temp_path = tempfile.mkstemp(
        prefix=f".{os.path.basename(target)}.",
        suffix=".tmp",
        dir=parent,
    )
    os.close(fd)
    try:
        torch.save(payload, temp_path)
        os.replace(temp_path, target)
    except BaseException:
        try:
            if os.path.exists(temp_path):
                os.remove(temp_path)
        except OSError:
            pass
        raise


def _atomic_savez_compressed(path, **arrays):
    """Atomically replace an NPZ artifact so interruption cannot leave a partial file."""
    target = os.path.abspath(os.fspath(path))
    parent = os.path.dirname(target)
    os.makedirs(parent, exist_ok=True)
    fd, temp_path = tempfile.mkstemp(
        prefix=f".{os.path.basename(target)}.",
        suffix=".tmp",
        dir=parent,
    )
    try:
        with os.fdopen(fd, "wb") as stream:
            np.savez_compressed(stream, **arrays)
        os.replace(temp_path, target)
    except BaseException:
        try:
            if os.path.exists(temp_path):
                os.remove(temp_path)
        except OSError:
            pass
        raise


def _validate_training_args(args):
    """Fail early on settings that otherwise cause hangs or invalid PPO batches."""
    effective_envs = 1 if bool(getattr(args, "gui", False)) else int(args.num_envs)
    if effective_envs < 1:
        raise ValueError("--num-envs must be >= 1")
    if int(args.episodes) < 1:
        raise ValueError("--episodes must be >= 1")
    if int(args.max_steps) < 1:
        raise ValueError("--max-steps must be >= 1")
    if int(args.rollout_horizon) < effective_envs:
        raise ValueError(
            "--rollout-horizon must be >= the effective number of environments "
            "(GUI mode uses one environment)"
        )
    for name in ("step_length", "cav_action_interval", "actor_lr", "critic_lr"):
        try:
            value = float(getattr(args, name))
        except (TypeError, ValueError, AttributeError) as exc:
            raise ValueError(f"{name} must be a finite positive number") from exc
        if not np.isfinite(value) or value <= 0.0:
            raise ValueError(f"{name} must be a finite positive number")
    for name in ("gamma", "gae_lambda"):
        value = float(getattr(args, name))
        if not np.isfinite(value) or not 0.0 <= value <= 1.0:
            raise ValueError(f"{name} must be finite and in [0, 1]")
    if int(getattr(args, "ppo_epochs", 1)) < 1:
        raise ValueError("--ppo-epochs must be >= 1")
    if int(getattr(args, "minibatch_size", 1)) < 1:
        raise ValueError("--minibatch-size must be >= 1")
    lambda_ema = float(getattr(args, "lambda_ema", 0.9))
    if not np.isfinite(lambda_ema) or not 0.0 <= lambda_ema <= 1.0:
        raise ValueError("--lambda-ema must be finite and in [0, 1]")

    if not bool(getattr(args, "use_absolute_stage_schedule", False)):
        stage_fracs = [
            float(getattr(args, "stage_s_frac", 0.0) or 0.0),
            float(getattr(args, "stage_lon_frac", 0.0) or 0.0),
            float(getattr(args, "stage_lat_frac", 0.0) or 0.0),
        ]
        if any(not np.isfinite(x) or x < 0.0 for x in stage_fracs):
            raise ValueError("Stage fractions must be finite and non-negative")
        if sum(stage_fracs) > 1.0 + 1e-6:
            print(
                "[Warn] Stage-S/Lon/Lat fractions sum to more than 1.0; "
                "the configured episode budget may end before Stage-Lat completes.",
                flush=True,
            )


def _join_worker_processes(processes, timeout=10.0):
    """Gracefully join workers, then terminate only processes that refuse to exit."""
    workers = [p for p in (processes or []) if p is not None]
    deadline = time.monotonic() + max(float(timeout), 0.0)
    for proc in workers:
        try:
            proc.join(timeout=max(0.0, deadline - time.monotonic()))
        except (AssertionError, OSError, RuntimeError):
            continue
    for proc in workers:
        try:
            if proc.is_alive():
                proc.terminate()
                proc.join(timeout=2.0)
        except (AssertionError, OSError, RuntimeError):
            pass


def _restore_episode_history(results_dir, start_episode, num_envs, metrics_history):
    """Restore full episode metrics only when rows and env columns match the checkpoint."""
    if int(start_episode) <= 0:
        return None
    path = os.path.join(results_dir, "episode_metrics.npz")
    if not os.path.isfile(path):
        print(
            "[resume] no episode_metrics.npz found; plots will cover the resumed segment only.",
            flush=True,
        )
        return None

    # Newer optional metric keys must not fail restore of older npz files.
    _optional_metric_keys = frozenset({"avg_collisions"})
    required = (
        "total_reward",
        "cav_reward",
        "signal_reward",
        *tuple(k for k in metrics_history.keys() if k not in _optional_metric_keys),
    )
    try:
        with np.load(path, allow_pickle=False) as data:
            missing = [key for key in required if key not in data.files]
            if missing:
                raise ValueError(f"missing fields: {', '.join(missing)}")

            loaded = {}
            for key in required:
                arr = np.asarray(data[key], dtype=np.float64)
                if arr.ndim == 1:
                    arr = arr.reshape(-1, 1)
                if arr.ndim != 2:
                    raise ValueError(f"{key} is not a 2-D episode-by-env array")
                if arr.shape[0] < int(start_episode) or arr.shape[1] != int(num_envs):
                    raise ValueError(
                        f"{key} shape {arr.shape} does not match checkpoint "
                        f"({start_episode} episodes x {num_envs} envs)"
                    )
                loaded[key] = arr[: int(start_episode)]

            # Lon/lat splits and collisions are optional (older npz files lack them).
            zeros = np.zeros((int(start_episode), int(num_envs)), dtype=np.float64)
            for src_key in ("cav_lon_reward", "cav_lat_reward"):
                if src_key not in data.files:
                    loaded[src_key] = zeros.copy()
                    continue
                arr = np.asarray(data[src_key], dtype=np.float64)
                if arr.ndim == 1:
                    arr = arr.reshape(-1, 1)
                if arr.shape[0] >= int(start_episode) and arr.shape[1] == int(num_envs):
                    loaded[src_key] = arr[: int(start_episode)]
                else:
                    loaded[src_key] = zeros.copy()
            for opt_key in _optional_metric_keys:
                if opt_key not in metrics_history:
                    continue
                if opt_key in loaded:
                    continue
                if opt_key not in data.files:
                    loaded[opt_key] = zeros.copy()
                    continue
                arr = np.asarray(data[opt_key], dtype=np.float64)
                if arr.ndim == 1:
                    arr = arr.reshape(-1, 1)
                if arr.shape != zeros.shape:
                    loaded[opt_key] = zeros.copy()
                else:
                    loaded[opt_key] = arr

        restored = {
            "episode_rewards_per_env": loaded["total_reward"].tolist(),
            "cav_rewards_per_env": loaded["cav_reward"].tolist(),
            "cav_lon_rewards_per_env": loaded["cav_lon_reward"].tolist(),
            "cav_lat_rewards_per_env": loaded["cav_lat_reward"].tolist(),
            "signal_rewards_per_env": loaded["signal_reward"].tolist(),
            "metrics_history": {
                key: loaded[key].tolist() for key in metrics_history
            },
        }
        restored["episode_rewards"] = [
            float(np.mean(row)) for row in restored["episode_rewards_per_env"]
        ]
        print(
            f"[resume] restored {start_episode} episodes of metrics from {path}",
            flush=True,
        )
        return restored
    except Exception as exc:
        print(
            "[resume] existing episode metrics do not exactly match the checkpoint; "
            f"starting a new metrics segment ({type(exc).__name__}: {exc}).",
            flush=True,
        )
        return None


def empty_rollout():
    """Step-indexed rollout shared by collect / GAE / merge_and_update."""
    return {
        'global_obs': [],
        'rewards': [],
        'lon_formal_rewards': [],
        'terminal_incidents': [],
        'team_rewards': [],
        'values': [],
        'signal_values': [],
        'dones': [],
        'coop_terms': [],
        'obs': [],
        'actions': [],
        'log_probs': [],
        'agent_dones': [],
        'team_returns': [],
        'signal_returns': [],
        'advantages': [],
        'ind_advantages': [],
        'lon_ind_advantages': [],
        'lat_ind_advantages': [],
        'signal_ind_advantages': [],
        'cav_obs': [],
        'cav_actions': [],
        'cav_log_probs': [],
        'cav_step_indices': [],
        'lon_obs': [],
        'lon_actions': [],
        'lon_log_probs': [],
        'lon_applied_actions': [],
        'applied_cav_actions': [],
        'lat_obs': [],
        'lat_actions': [],
        'lat_log_probs': [],
        'signal_obs': [],
        'signal_actions': [],
        'signal_log_probs': [],
        'signal_overridden': [],  # v5 (1.1): per-step set of overridden signal agents
        'lon_noop_vids': [],  # v5.2.4: per-step CAVs whose sampled Lon action was not executed
        'signal_step_indices': [],
        'signal_teacher_actions': [],
        'signal_teacher_confs': [],
        'signal_teacher_severities': [],
    }


TEACHER_CONFIDENCE_THRESHOLD = 0.60
TEACHER_BETA_MAX = 0.15
TEACHER_BETA_MIN = 0.03
# Stage-S tail: teacher β → 0 while Teacher API / R_res keep running.
# Full Stage-S=240: soft 0~4, hold 5~54, anneal 55~179, β=0 tail 180~239.
STAGE_S_TEACHER_BETA_HOLD_EPISODES = 50
STAGE_S_TEACHER_TAIL_EPISODES = 60


def _stage_s_tail_start(stage_len):
    """First stage-local episode index of the Stage-S teacher-β=0 tail."""
    length = max(0, int(stage_len))
    if length <= 0:
        return 0
    # Prefer 60-ep β=0 window on Full (240); scale down for shorter stages.
    tail = min(int(STAGE_S_TEACHER_TAIL_EPISODES), max(40, length // 4))
    tail = min(tail, length)
    return max(0, length - tail)


def resolve_vision_mode(args):
    """Resolve VLM participation across Stage-S / Lon / Lat.

    Default (main algorithm): signal vision in S + weight VLM in Lon and Lat.
    Ablations (baselines):
      --only-signal-vlm-vision  → Stage-S only (Lon/Lat fixed weights)
      --only-lon-vlm-vision     → Stage-Lon only
      --only-lat-vlm-vision     → Stage-Lat only
      --no-vision / --no-vlm    → no VLM in any stage
    """
    only_signal = bool(getattr(args, "only_signal_vlm_vision", False))
    only_lon = bool(getattr(args, "only_lon_vlm_vision", False))
    only_lat = bool(getattr(args, "only_lat_vlm_vision", False))
    no_vision = bool(getattr(args, "no_vision", False))
    # --no-vlm is a legacy alias for --no-vision when no only-* flag is set.
    no_vlm = bool(getattr(args, "no_vlm", False))

    exclusive = []
    if only_signal:
        exclusive.append(VISION_MODE_ONLY_SIGNAL)
    if only_lon:
        exclusive.append(VISION_MODE_ONLY_LON)
    if only_lat:
        exclusive.append(VISION_MODE_ONLY_LAT)
    if no_vision:
        exclusive.append(VISION_MODE_NONE)
    if len(exclusive) > 1:
        raise SystemExit(
            "[vision-mode] use at most one of --only-signal-vlm-vision / "
            "--only-lon-vlm-vision / --only-lat-vlm-vision / --no-vision"
        )
    if exclusive:
        mode = exclusive[0]
    elif no_vlm:
        mode = VISION_MODE_NONE
    else:
        mode = VISION_MODE_FULL

    if mode in (VISION_MODE_ONLY_LON, VISION_MODE_ONLY_LAT) and no_vlm:
        raise SystemExit(
            f"[vision-mode] --no-vlm conflicts with --only-{mode.split('_')[-1]}-vlm-vision"
        )

    if mode == VISION_MODE_FULL:
        # Main algorithm: signal vision on by default; --no-signal-vlm-vision opts out.
        signal_vision = bool(getattr(args, "signal_vlm_vision", True))
        use_vlm = True
        weight_stages = ("Lon", "Lat")
    elif mode == VISION_MODE_ONLY_SIGNAL:
        signal_vision = True
        use_vlm = False
        weight_stages = ()
    elif mode == VISION_MODE_ONLY_LON:
        signal_vision = False
        use_vlm = True
        weight_stages = ("Lon",)
    elif mode == VISION_MODE_ONLY_LAT:
        signal_vision = False
        use_vlm = True
        weight_stages = ("Lat",)
    else:  # none
        signal_vision = False
        use_vlm = False
        weight_stages = ()

    return {
        "mode": mode,
        "signal_vision": signal_vision,
        "use_vlm": use_vlm,
        "weight_stages": tuple(weight_stages),
    }


def _signal_teacher_beta(
    stage,
    stage_episode,
    stage_len,
    soft_start=5,
    *,
    signal_vlm_vision=False,
    rule_signal_teacher=False,
):
    """Stage-S teacher aux weight (VLM vision or rule teacher); else 0.

    Active when either signal VLM vision or the deterministic rule teacher is
    enabled. Tail freeze (last ``STAGE_S_TEACHER_TAIL_EPISODES``): β=0 so CE no
    longer flattens logits while teacher labels may still be produced.
    """
    from agents.mappo import MAPPOAgent

    stage = MAPPOAgent._normalize_stage(stage)
    teacher_on = bool(signal_vlm_vision) or bool(rule_signal_teacher)
    if stage != "S" or not teacher_on:
        return 0.0
    try:
        ep = int(stage_episode)
        length = int(stage_len)
        soft = int(soft_start)
    except (TypeError, ValueError, OverflowError):
        return 0.0
    if length <= 0 or ep < soft:
        return 0.0
    # P0: cut CE gradient in the Best-S selection window.
    freeze_start = _stage_s_tail_start(length)
    if ep >= freeze_start:
        return 0.0
    # Hold β_max through ep<hold, then anneal to β_min by freeze_start-1 so the
    # pre-Best-S window is already sharp (scaled with Stage-S length).
    hold_cap = max(soft, int(STAGE_S_TEACHER_BETA_HOLD_EPISODES))
    hold_end = min(hold_cap, max(soft, freeze_start - 1))
    if ep < hold_end:
        return float(TEACHER_BETA_MAX)
    if hold_end >= freeze_start - 1:
        return float(TEACHER_BETA_MIN)
    progress = (ep - hold_end) / max(1, (freeze_start - 1) - hold_end)
    progress = float(np.clip(progress, 0.0, 1.0))
    return float(
        TEACHER_BETA_MAX - (TEACHER_BETA_MAX - TEACHER_BETA_MIN) * progress
    )


def _signal_mask_is_locked_keep(agent_obs, mask):
    """True only when the mask is a hold lock on the current green.

    After dynamic-T expiry the mask enables every phase except the current one.
    On 2-phase nets (and TOP3 singletons) that leaves ``sum(mask)==1`` for the
    *other* phase — that is a real forced-switch decision and must train.
    The old ``sum<=1 → -1`` rule dropped those samples.
    """
    m = np.asarray(mask, dtype=np.float32).reshape(-1)
    if m.size == 0 or float(np.sum(m)) < 0.5:
        return True
    if float(np.sum(m)) > 1.0 + 1e-6:
        return False
    only = int(np.argmax(m))
    vec = (agent_obs or {}).get("vector")
    if vec is None:
        return True
    from environment.tls_phases import MAX_SIGNAL_ACTIONS

    oh = np.asarray(vec, dtype=np.float32).reshape(-1)
    gdim = min(int(MAX_SIGNAL_ACTIONS), int(oh.size))
    if gdim <= 0:
        return True
    g_oh = oh[:gdim]
    if float(np.sum(g_oh)) <= 0.5:
        return True
    cur_g = int(np.argmax(g_oh))
    return cur_g == only


def learning_actions_from_obs(obs, actions, cav_decision=True):
    """Mark non-decision / zero-DoF steps so PPO skips them; env still uses real actions.

    - signal: sum(action_mask>0) <= 1 → -1 (locked keep / forced single switch)
    - cav_lat: sum(action_mask>0) <= 1 → None (LC cooldown / unsafe gap [0,1,0])
    - cav: held between cav_action_interval decisions → None
    """
    learning = {}
    for agent_id, action in actions.items():
        if agent_id.startswith('_res_'):
            continue
        if agent_id.startswith('signal_'):
            agent_obs = obs.get(agent_id, {}) or {}
            mask = agent_obs.get('action_mask')
            if mask is not None and _signal_mask_is_locked_keep(agent_obs, mask):
                learning[agent_id] = -1
                continue
            learning[agent_id] = action
        elif agent_id.startswith('cav_'):
            if not cav_decision:
                learning[agent_id] = None
                continue
            agent_obs = obs.get(agent_id, {}) or {}
            mask = agent_obs.get('action_mask')
            if mask is not None and str(agent_id).startswith('cav_lat_'):
                m = np.asarray(mask, dtype=np.float32).reshape(-1)
                if int(np.sum(m > 0)) <= 1:
                    learning[agent_id] = None
                    continue
            learning[agent_id] = action
            res_key = f'_res_{agent_id}'
            if res_key in actions:
                learning[res_key] = actions[res_key]
        else:
            learning[agent_id] = action
    return learning


def env_actions_only(actions):
    """Strip residual bookkeeping keys before sending to the environment."""
    return {
        k: v for k, v in actions.items()
        if k.startswith('cav_') or k.startswith('signal_')
    }


def _is_held_cav_key(key):
    """Keys whose continuous accel is held between CAV decision ticks.

    Lateral discrete actions (cav_lat_*) are NOT held: replaying left/right
    every sim step re-issues changeLaneRelative and double-bills LateralReward.
    """
    return (
        key.startswith('cav_lon_')
        or key.startswith('_res_cav_')
        or (
            key.startswith('cav_')
            and not key.startswith('cav_lat_')
            and not key.startswith('cav_lon_')
        )
    )


def hold_cav_actions(actions, log_probs, cache_actions, cache_log_probs, refresh):
    """Hold longitudinal accel between decision ticks; neutral-keep lateral on holds.

    - Longitudinal (cav_lon_* / legacy cav_*): reuse cached accel on non-refresh.
    - Lateral (cav_lat_*): execute new discrete action only on refresh; on hold
      steps send keep (discrete 1 → signed 0) so SUMO/reward do not re-fire LC.
    - Signal actions always pass through unchanged.
    """
    if refresh:
        new_cache_a = {k: v for k, v in actions.items() if _is_held_cav_key(k)}
        new_cache_lp = {k: v for k, v in log_probs.items() if _is_held_cav_key(k)}
        return actions, log_probs, new_cache_a, new_cache_lp

    out_actions = dict(actions)
    out_lp = dict(log_probs)
    new_cache_a = dict(cache_actions)
    new_cache_lp = dict(cache_log_probs)
    for aid in list(out_actions.keys()):
        if aid.startswith('cav_lat_'):
            # Non-decision tick: execute keep-lane in env; PPO label is None.
            out_actions[aid] = 1
            continue
        if not _is_held_cav_key(aid):
            continue
        if aid in cache_actions:
            out_actions[aid] = cache_actions[aid]
            if aid in cache_log_probs:
                out_lp[aid] = cache_log_probs[aid]
        else:
            new_cache_a[aid] = out_actions[aid]
            if aid in out_lp:
                new_cache_lp[aid] = out_lp[aid]

    active = {k for k in out_actions if _is_held_cav_key(k)}
    new_cache_a = {k: v for k, v in new_cache_a.items() if k in active}
    new_cache_lp = {k: v for k, v in new_cache_lp.items() if k in active}
    return out_actions, out_lp, new_cache_a, new_cache_lp


# Multiprocessing Pipe: one shared traffic graph per obs dict (not per agent).
OBS_SHARED_GRAPH_KEY = "__graph__"


def pack_obs_shared_graph(obs):
    """Strip per-agent ``graph`` copies; keep a single ``__graph__`` for IPC.

    In-process callers may leave per-agent graphs; workers pack before Pipe send
    so pickle does not walk N duplicate graph payloads.
    """
    if not isinstance(obs, dict) or not obs:
        return obs
    shared = obs.get(OBS_SHARED_GRAPH_KEY)
    packed = {}
    for aid, agent_obs in obs.items():
        if aid == OBS_SHARED_GRAPH_KEY:
            continue
        if not isinstance(agent_obs, dict):
            packed[aid] = agent_obs
            continue
        if shared is None and "graph" in agent_obs:
            shared = agent_obs["graph"]
        if "graph" in agent_obs:
            slim = {k: v for k, v in agent_obs.items() if k != "graph"}
            packed[aid] = slim
        else:
            packed[aid] = agent_obs
    if shared is not None:
        packed[OBS_SHARED_GRAPH_KEY] = shared
    return packed


def unpack_obs_shared_graph(obs):
    """Reattach ``__graph__`` onto every agent observation that needs a graph."""
    if not isinstance(obs, dict) or not obs:
        return obs
    shared = obs.get(OBS_SHARED_GRAPH_KEY)
    if shared is None:
        return obs
    out = {}
    for aid, agent_obs in obs.items():
        if aid == OBS_SHARED_GRAPH_KEY:
            continue
        if isinstance(agent_obs, dict) and "vector" in agent_obs and "graph" not in agent_obs:
            attached = dict(agent_obs)
            attached["graph"] = shared
            out[aid] = attached
        else:
            out[aid] = agent_obs
    # Keep __graph__ so graph_from_obs can avoid scanning agents.
    out[OBS_SHARED_GRAPH_KEY] = shared
    return out


def graph_from_obs(obs):
    if not obs:
        return {
            'node_features': np.zeros((1, 10), dtype=np.float32), 
            'edge_index': np.empty((2, 0), dtype=np.int64),
        }
    shared = obs.get(OBS_SHARED_GRAPH_KEY) if isinstance(obs, dict) else None
    if isinstance(shared, dict) and "node_features" in shared:
        return shared
    for agent_obs in obs.values():
        if isinstance(agent_obs, dict) and "graph" in agent_obs:
            return agent_obs["graph"]
    return {
        'node_features': np.zeros((1, 10), dtype=np.float32),
        'edge_index': np.empty((2, 0), dtype=np.int64),
    }


# =========================================================================
# 修复核心：移除 Auto-Reset，加入 TCP 端口缓冲
# =========================================================================
def env_worker(
    remote,
    parent_remote,
    sumocfg_path,
    api_key,
    vlm_model,
    vlm_interval,
    seed,
    step_length,
    use_gui=False,
    use_vlm=True,
    fixed_reward_weights=None,
    sumo_port=None,
    vlm_api_base=None,
    fail_stop_on_vlm_error=None,
    results_method=None,
    scenario_key=None,
    run_seed=None,
    env_index=0,
    enable_lateral=True,
    enable_longitudinal=True,
    fixed_lat_weights=None,
    vlm_warmup_episodes=None,
    vlm_warmup_by_stage=None,
    demand_profile="full",
    signal_vlm_vision_enabled=False,
    vlm_weight_stages=None,
    rule_signal_teacher_enabled=False,
    enable_emissions=None,
    co_opt_config=None,
):
    parent_remote.close()
    try:  # v5.1: env workers do little torch work; avoid CPU oversubscription
        import torch as _torch_w

        _torch_w.set_num_threads(max(1, int(os.environ.get("VECTOR_WORKER_TORCH_THREADS", "1") or 1)))
    except Exception:
        pass
    np.random.seed(seed)
    random.seed(seed)
    # Spawn re-imports train_RL (and thus SUMO_interface) before this function
    # body runs. Still force the flag for any late imports / clarity.
    if use_gui:
        os.environ["USE_LIBSUMO"] = "0"
    else:
        os.environ.setdefault("USE_LIBSUMO", "1")
    if enable_emissions is not None:
        os.environ["SUMO_ENABLE_EMISSIONS"] = (
            "1" if bool(enable_emissions) else "0"
        )

    from environment.marl_env import MultiAgentTrafficEnv
    try:
        from environment.SUMO_interface import using_libsumo

        print(
            f"[env_worker {env_index}] use_gui={use_gui} "
            f"USE_LIBSUMO={os.environ.get('USE_LIBSUMO')} "
            f"using_libsumo={using_libsumo()}",
            flush=True,
        )
    except Exception as exc:
        print(f"[env_worker {env_index}] backend probe failed: {exc}", flush=True)
    env = MultiAgentTrafficEnv(
        sumocfg_file=sumocfg_path,
        use_gui=use_gui,
        step_length=step_length,
        vlm_api_key=api_key,
        vlm_model=vlm_model,
        vlm_api_base=vlm_api_base,
        vlm_update_interval_seconds=vlm_interval,
        use_vlm=use_vlm,
        fixed_reward_weights=fixed_reward_weights,
        fixed_lat_weights=fixed_lat_weights,
        sumo_port=sumo_port,
        fail_stop_on_vlm_error=fail_stop_on_vlm_error,
        results_method=results_method,
        scenario_key=scenario_key,
        run_seed=run_seed if run_seed is not None else seed,
        env_index=env_index,
        enable_lateral=enable_lateral,
        enable_longitudinal=enable_longitudinal,
        vlm_warmup_episodes=vlm_warmup_episodes,
        vlm_warmup_by_stage=vlm_warmup_by_stage,
        demand_profile=demand_profile,
        signal_vlm_vision_enabled=signal_vlm_vision_enabled,
        rule_signal_teacher_enabled=rule_signal_teacher_enabled,
        vlm_weight_stages=vlm_weight_stages,
        enable_emissions=enable_emissions,
        co_opt_config=co_opt_config,
    )
    
    try:
        while True:
            cmd, data = remote.recv()
            if cmd == 'step':
                actions, ep, step_num, lambdas = data
                obs, rewards, dones, infos = env.step(actions, ep=ep, step_num=step_num, lambdas=lambdas)
                # 彻底移除 Auto-Reset，避免与主线程的 Reset 冲突导致死锁
                remote.send((pack_obs_shared_graph(obs), rewards, dones, infos))
            elif cmd == 'reset':
                # Short pause so Windows can release TraCI TCP ports between episodes.
                time.sleep(0.05)
                obs = env.reset(seed=data)
                remote.send(pack_obs_shared_graph(obs))
            elif cmd == 'configure_stage':
                if isinstance(data, (list, tuple)) and len(data) >= 2:
                    stage, top3 = data[0], data[1]
                    coop_policy = data[2] if len(data) >= 3 else None
                    stage_episode = data[3] if len(data) >= 4 else 0
                    soft_start = data[4] if len(data) >= 5 else None
                    stage_len = data[5] if len(data) >= 6 else None
                else:
                    stage, top3, coop_policy, stage_episode, soft_start, stage_len = (
                        data, True, None, 0, None, None
                    )
                if hasattr(env, 'configure_stage'):
                    env.configure_stage(
                        stage,
                        top3_mask=top3,
                        coop_policy=coop_policy,
                        stage_episode=stage_episode,
                        soft_start=soft_start,
                        stage_len=stage_len,
                    )
                remote.send(None)
            elif cmd == 'configure_coop':
                kwargs = data or {}
                rf = env.reward_fn
                if hasattr(rf, 'configure_coop'):
                    rf.configure_coop(**kwargs)
                remote.send(None)
            elif cmd == 'configure_control':
                kwargs = data or {}
                if hasattr(env.sumo_env, 'configure_control'):
                    env.sumo_env.configure_control(**kwargs)
                remote.send(None)
            elif cmd == 'get_vlm_weight_snapshot':
                rf = getattr(env, 'reward_fn', None)
                snap = rf.get_vlm_weight_snapshot() if rf is not None and hasattr(rf, 'get_vlm_weight_snapshot') else {}
                remote.send(snap)
            elif cmd == 'apply_macro_weights':
                rf = getattr(env, 'reward_fn', None)
                kwargs = data or {}
                if rf is not None and hasattr(rf, 'apply_macro_weights'):
                    rf.apply_macro_weights(
                        W_sig=kwargs.get('W_sig'),
                        W_lat=kwargs.get('W_lat'),
                        W_long=kwargs.get('W_long'),
                    )
                remote.send(None)
            elif cmd == 'end_episode_vlm_update':
                rf = getattr(env, 'reward_fn', None)
                ok = rf.end_episode_vlm_update() if rf is not None and hasattr(rf, 'end_episode_vlm_update') else False
                remote.send(bool(ok))
            elif cmd == 'idle':
                remote.send(None)
            elif cmd == 'close':
                env.close()
                remote.close()
                break
    except (BrokenPipeError, EOFError, ConnectionResetError):
        # v5.2.4: trainer exited (Ctrl+C / crash): leave quietly, no traceback.
        try:
            env.close()
        except Exception:
            pass
    except Exception as e:
        import traceback
        print(f"[Worker {seed}] Error: {e}")
        traceback.print_exc()
        try:
            env.close()
        except Exception:
            pass
        try:
            remote.close()
        except Exception:
            pass


class LocalTrafficEnvs:
    """In-process single env (required for reliable SUMO-GUI on Windows)."""

    def __init__(self, env):
        self.env = env
        self.remotes = [None]  # length-compatible with ParallelTrafficEnvs callers

    def reset(self, seeds=None):
        seed = None if not seeds else seeds[0]
        time.sleep(0.05)
        return [self.env.reset(seed=seed)]

    def step(self, actions_list, ep, step_num, lambdas_list, alive_mask=None):
        if alive_mask is not None and not alive_mask[0]:
            idle = ({}, {}, {'__all__': True}, {'__all__': {
                'global_reward': 0.0,
                'episode_total_reward': 0.0,
                'reward_components': {'safe': 0.0, 'eff': 0.0, 'comfort': 0.0, 'coop': 0.0},
                'coop_terms': np.zeros(2, dtype=np.float32),
                'collisions': 0,
                'safety_intervention_rate': 0.0,
                'episode_reward_signal': 0.0,
                'episode_reward_signal_mean': 0.0,
                'episode_reward_signal_formal_mean': 0.0,
                'episode_reward_signal_residual_mean': 0.0,
                'episode_reward_cav_mean': 0.0,
                'episode_reward_cav_lon_mean': 0.0,
                'episode_reward_cav_lat_mean': 0.0,
                'episode_lon_residual_mean': 0.0,
                'episode_lon_residual_nonzero_frac': 0.0,
                'episode_lon_exposed_frac': 0.0,
                'avg_waiting_time': 0.0,
                'network_avg_waiting_time': 0.0,
                'episode_steps': 0,
            }})
            return ([idle[0]], [idle[1]], [idle[2]], [idle[3]])
        obs, rewards, dones, infos = self.env.step(
            actions_list[0], ep=ep, step_num=step_num, lambdas=lambdas_list[0]
        )
        return [obs], [rewards], [dones], [infos]

    def configure_stage(
        self,
        stage,
        top3_mask=True,
        coop_policy=None,
        stage_episode=0,
        soft_start=None,
        stage_len=None,
    ):
        if hasattr(self.env, 'configure_stage'):
            self.env.configure_stage(
                stage,
                top3_mask=top3_mask,
                coop_policy=coop_policy,
                stage_episode=stage_episode,
                soft_start=soft_start,
                stage_len=stage_len,
            )

    def configure_coop(self, **kwargs):
        rf = getattr(self.env, 'reward_fn', None)
        if rf is not None and hasattr(rf, 'configure_coop'):
            rf.configure_coop(**kwargs)

    def configure_control(self, **kwargs):
        if hasattr(self.env.sumo_env, 'configure_control'):
            self.env.sumo_env.configure_control(**kwargs)

    def get_vlm_weight_snapshot(self):
        rf = getattr(self.env, 'reward_fn', None)
        if rf is not None and hasattr(rf, 'get_vlm_weight_snapshot'):
            return rf.get_vlm_weight_snapshot()
        return {}

    def apply_macro_weights(self, W_sig=None, W_lat=None, W_long=None):
        rf = getattr(self.env, 'reward_fn', None)
        if rf is not None and hasattr(rf, 'apply_macro_weights'):
            rf.apply_macro_weights(W_sig=W_sig, W_lat=W_lat, W_long=W_long)

    def end_episode_vlm_update(self):
        rf = getattr(self.env, 'reward_fn', None)
        if rf is not None and hasattr(rf, 'end_episode_vlm_update'):
            return bool(rf.end_episode_vlm_update())
        return False

    def close(self):
        self.env.close()


class ParallelTrafficEnvs:
    def __init__(self, remotes):
        self.remotes = remotes

    def reset(self, seeds=None):
        """Reset all workers. ``seeds`` may be None or a list (one per env)."""
        for i, remote in enumerate(self.remotes):
            seed = None if seeds is None else seeds[i]
            remote.send(('reset', seed))
        return [unpack_obs_shared_graph(remote.recv()) for remote in self.remotes]

    def configure_stage(
        self,
        stage,
        top3_mask=True,
        coop_policy=None,
        stage_episode=0,
        soft_start=None,
        stage_len=None,
    ):
        for remote in self.remotes:
            remote.send(
                (
                    'configure_stage',
                    (stage, top3_mask, coop_policy, stage_episode, soft_start, stage_len),
                )
            )
        for remote in self.remotes:
            remote.recv()

    def configure_coop(self, **kwargs):
        for remote in self.remotes:
            remote.send(('configure_coop', kwargs))
        for remote in self.remotes:
            remote.recv()

    def configure_control(self, **kwargs):
        for remote in self.remotes:
            remote.send(('configure_control', kwargs))
        for remote in self.remotes:
            remote.recv()

    def get_vlm_weight_snapshot(self):
        for remote in self.remotes:
            remote.send(('get_vlm_weight_snapshot', None))
        snaps = [remote.recv() for remote in self.remotes]
        return snaps[0] if snaps else {}

    def apply_macro_weights(self, W_sig=None, W_lat=None, W_long=None):
        payload = {"W_sig": W_sig, "W_lat": W_lat, "W_long": W_long}
        for remote in self.remotes:
            remote.send(('apply_macro_weights', payload))
        for remote in self.remotes:
            remote.recv()

    def end_episode_vlm_update(self):
        for remote in self.remotes:
            remote.send(('end_episode_vlm_update', None))
        return [bool(remote.recv()) for remote in self.remotes]

    def step(self, actions_list, ep, step_num, lambdas_list, alive_mask=None):
        if alive_mask is None:
            alive_mask = [True] * len(self.remotes)
        for i, remote in enumerate(self.remotes):
            if alive_mask[i]:
                remote.send(('step', (actions_list[i], ep, step_num, lambdas_list[i])))
            else:
                remote.send(('idle', None))
        results = []
        for i, remote in enumerate(self.remotes):
            payload = remote.recv()
            if alive_mask[i]:
                obs, rewards, dones, infos = payload
                results.append(
                    (unpack_obs_shared_graph(obs), rewards, dones, infos)
                )
            else:
                results.append(({}, {}, {'__all__': True}, {'__all__': {
                    'global_reward': 0.0,
                    'episode_total_reward': 0.0,
                    'reward_components': {'safe': 0.0, 'eff': 0.0, 'comfort': 0.0, 'coop': 0.0},
                    'coop_terms': np.zeros(2, dtype=np.float32),
                    'collisions': 0,
                    'safety_intervention_rate': 0.0,
                    'episode_reward_signal': 0.0,
                    'episode_reward_signal_mean': 0.0,
                    'episode_reward_signal_formal_mean': 0.0,
                    'episode_reward_signal_residual_mean': 0.0,
                    'episode_reward_cav_mean': 0.0,
                    'episode_reward_cav_lon_mean': 0.0,
                    'episode_reward_cav_lat_mean': 0.0,
                    'episode_lon_residual_mean': 0.0,
                    'episode_lon_residual_nonzero_frac': 0.0,
                    'episode_lon_exposed_frac': 0.0,
                    'avg_waiting_time': 0.0,
                    'network_avg_waiting_time': 0.0,
                    'episode_steps': 0,
                }}))
        obs_list, rewards_list, dones_list, infos_list = zip(*results)
        return obs_list, rewards_list, dones_list, infos_list

    def close(self):
        for remote in self.remotes:
            try:
                remote.send(('close', None))
            except (BrokenPipeError, EOFError, OSError):
                pass
        for remote in self.remotes:
            try:
                remote.close()
            except (EOFError, OSError):
                pass


def _evaluate_critic_values(agent, graph):
    """Return (team_value, signal_value) in raw GAE scale via dual-RMS CentralizedCritic."""
    if hasattr(agent, "get_dual_values"):
        try:
            vt, vs = agent.get_dual_values(graph)
            return float(vt), float(vs)
        except Exception:
            pass
    vt = float(agent.get_value(graph))
    return vt, vt


def compute_gae_for_rollout(agent, rollout, next_obs, terminal):
    if not rollout['global_obs']:
        return rollout
    if terminal:
        next_value, next_sig_value = 0.0, 0.0
    else:
        next_value, next_sig_value = _evaluate_critic_values(agent, graph_from_obs(next_obs))

    if rollout.get('team_rewards') and len(rollout['team_rewards']) == len(rollout['values']):
        team_rewards = [float(r) for r in rollout['team_rewards']]
    else:
        team_rewards = [
            float(np.mean(list(r_dict.values()))) if r_dict else 0.0
            for r_dict in rollout['rewards']
        ]

    team_returns, team_advantages = agent.compute_gae(
        team_rewards,
        rollout['values'],
        rollout['dones'],
        next_value=next_value,
    )

    # Compute long-horizon SMDP signal returns across ALL stages so CentralizedCritic's
    # signal_head and _sig_ret_rms stay continuously calibrated on the live GNN trunk
    # during Lon & Lat (preventing cold-critic drift on JointLonSig / JointAll entry!).
    from agents.mappo import SIGNAL_GAE_GAMMA, SIGNAL_GAE_LAMBDA

    _st = str(getattr(agent, "training_stage", ""))
    signal_rewards = []
    sig_decision_mask = []
    rollout_actions = rollout.get('actions') or []
    for s_i, r_dict in enumerate(rollout['rewards']):
        sig_vals = [
            float(v)
            for k, v in (r_dict or {}).items()
            if str(k).startswith("signal_")
        ]
        signal_rewards.append(float(np.mean(sig_vals)) if sig_vals else 0.0)
        act_map = rollout_actions[s_i] if s_i < len(rollout_actions) else {}
        has_real_sig_dec = any(
            str(k).startswith("signal_") and v is not None and int(v) >= 0
            for k, v in (act_map or {}).items()
        )
        sig_decision_mask.append(bool(has_real_sig_dec))

    sig_value_seq = (
        rollout['signal_values']
        if len(rollout.get('signal_values') or []) == len(rollout['values'])
        else rollout['values']
    )
    signal_returns, signal_advantages = agent.compute_gae(
        signal_rewards,
        sig_value_seq,
        rollout['dones'],
        next_value=next_sig_value,
        gamma=SIGNAL_GAE_GAMMA,
        gae_lambda=SIGNAL_GAE_LAMBDA,
        decision_mask=sig_decision_mask,
    )
    rollout['signal_returns'] = list(signal_returns)
    if _st == "S":
        if not bool(getattr(agent, "freeze_team_critic_in_stage_s", True)):
            team_returns = signal_returns
        team_advantages = signal_advantages

    # Per-CAV backward relative advantage: separate longitudinal and lateral baselines.
    # Fixes Stage-Lat cross-modal baseline pollution and action-hold recursion breaks.
    n_steps = len(rollout['values'])
    cav_rel_running = {}
    cav_dones_list = rollout.get('agent_dones') or [{} for _ in range(n_steps)]
    per_step_cav_rel_adv = [{} for _ in range(n_steps)]
    cav_gamma_lam = float(agent.gamma) * float(agent.gae_lambda)

    use_cross_app = bool(getattr(agent, "cross_approach_baseline", True))
    credit_mode = str(getattr(agent, "cav_credit_mode", "coop_xapp") or "coop_xapp").strip().lower()
    coop_kappa = float(getattr(agent, "coop_kappa", 0.5) or 0.0)
    inc_seq = rollout.get("terminal_incidents") or []
    lon_formal_list = rollout.get("lon_formal_rewards") or []

    # ---- v4 pass 1: per-step baseline-corrected deltas (train/credit_utils.py) ----
    # 'coop_xapp' (default): cooperative reward r_i + kappa*mean(same-approach peers)
    # minus an action-independent CROSS-approach baseline. v3 'relative' subtracted a
    # same-approach mean that ego's own actions move (followers), so hurting followers
    # RAISED ego's advantage. 'relative' reproduces v3 exactly for ablations.
    step_lon_entries = []
    step_lat_entries = []
    for step_idx in range(n_steps):
        r_map = rollout['rewards'][step_idx] or {}
        obs_map = rollout['obs'][step_idx] if step_idx < len(rollout.get('obs', [])) else {}
        formal_map = {}
        if step_idx < len(lon_formal_list) and isinstance(lon_formal_list[step_idx], dict):
            formal_map = lon_formal_list[step_idx] or {}
        lon_entries = []
        lat_entries = []
        for k, v in r_map.items():
            ks = str(k)
            if ks.startswith("cav_lat_"):
                o_dict = obs_map.get(k) or {}
                if not bool(o_dict.get("dlc_eligible", False)):
                    continue
                vf = float(v)
                lat_entries.append((k, str(o_dict.get("approach_key") or ""), vf, vf))
            elif ks.startswith("cav_"):
                own = float(v)
                peer = own
                if k in formal_map:
                    try:
                        peer = float(formal_map[k])
                    except (TypeError, ValueError, OverflowError):
                        peer = own
                lon_entries.append(
                    (k, str((obs_map.get(k) or {}).get("approach_key") or ""), own, peer)
                )
        step_lon_entries.append(lon_entries)
        step_lat_entries.append(lat_entries)
    lon_fallback = rollout_fallback_mean(step_lon_entries, kappa=coop_kappa)
    lat_fallback = rollout_fallback_mean(step_lat_entries, kappa=coop_kappa)
    per_step_deltas = []
    for step_idx in range(n_steps):
        _d = credit_step_deltas(
            step_lon_entries[step_idx], mode=credit_mode, kappa=coop_kappa,
            use_cross_app=use_cross_app, fallback_mean=lon_fallback,
        )
        _d.update(credit_step_deltas(
            step_lat_entries[step_idx], mode=credit_mode, kappa=coop_kappa,
            use_cross_app=use_cross_app, fallback_mean=lat_fallback,
        ))
        per_step_deltas.append(_d)

    # ---- pass 2: backward SMDP recursion per agent ----
    next_is_decision = {}
    for step_idx in reversed(range(n_steps)):
        r_map = rollout['rewards'][step_idx] or {}
        obs_map = rollout['obs'][step_idx] if step_idx < len(rollout.get('obs', [])) else {}
        d_map = cav_dones_list[step_idx] if step_idx < len(cav_dones_list) else {}
        env_done = float(rollout['dones'][step_idx]) if step_idx < len(rollout['dones']) else 0.0
        step_incidents = set(inc_seq[step_idx] or ()) if step_idx < len(inc_seq) else set()
        deltas = per_step_deltas[step_idx]

        # Alive agents: present in observation (reward keys may be absent on hold ticks).
        alive_agents = set()
        for aid in obs_map.keys():
            if str(aid).startswith("cav_"):
                alive_agents.add(aid)

        for aid in alive_agents:
            has_reward = aid in r_map
            ind_reward = float(r_map[aid]) if has_reward else 0.0
            agent_done = bool(d_map.get(aid, False))
            not_done = 0.0 if (env_done > 0.5 or agent_done) else 1.0
            step_learn_act = (
                rollout['actions'][step_idx].get(aid)
                if step_idx < len(rollout.get('actions', []))
                else None
            )
            # Continuous None (CAV hold) and discrete -1 (cooldown / single mask)
            # are non-decision hold ticks of the current option.
            is_hold_tick = (step_learn_act is None) or (
                isinstance(step_learn_act, (int, np.integer)) and int(step_learn_act) == -1
            )
            if not has_reward:
                rel_delta = 0.0
            elif aid in step_incidents:
                rel_delta = ind_reward
            elif str(aid).startswith("cav_lat_"):
                eligible = bool((obs_map.get(aid) or {}).get("dlc_eligible", False))
                if eligible:
                    rel_delta = float(deltas.get(aid, 0.0))
                else:
                    rel_delta = ind_reward if ind_reward <= -1.5 else 0.0
            else:
                rel_delta = float(deltas.get(aid, 0.0))

            prev_rel_gae = float(cav_rel_running.get(aid, 0.0))
            # v4 SMDP: lambda only at option boundaries (step t+1 starts a new
            # decision of this agent); v3 applied it at the decision step itself.
            lam_on = bool(next_is_decision.get(aid, True))
            step_decay = cav_gamma_lam if lam_on else float(agent.gamma)
            cur_rel_gae = rel_delta + step_decay * not_done * prev_rel_gae
            cav_rel_running[aid] = cur_rel_gae
            per_step_cav_rel_adv[step_idx][aid] = cur_rel_gae
            next_is_decision[aid] = not is_hold_tick

        # Clear recursion state only for agents that truly left the environment.
        for aid in list(cav_rel_running):
            if aid not in alive_agents:
                cav_rel_running[aid] = 0.0
                next_is_decision.pop(aid, None)

    expanded_advantages = []
    for step_idx in range(n_steps):
        step_adv = {}
        r_map = rollout['rewards'][step_idx] or {}
        for aid, ind_reward in r_map.items():
            if (
                signal_advantages is not None
                and signal_rewards is not None
                and str(aid).startswith("signal_")
            ):
                t_adv = float(signal_advantages[step_idx])
                t_reward = float(signal_rewards[step_idx])
                a_ind = t_adv + (float(ind_reward) - t_reward)
                step_adv[aid] = 0.5 * t_adv + 0.5 * a_ind
            elif str(aid).startswith("cav_"):
                t_adv = float(team_advantages[step_idx])
                rel_gae = float(per_step_cav_rel_adv[step_idx].get(aid, 0.0))
                # Blend-only: during action soft-start (β<1) lean on per-CAV
                # relative GAE so a cold team critic cannot drown lon/lat grads.
                # β→1 restores the steady 0.6 team + 0.4 rel mix.
                try:
                    _b_raw = getattr(agent, "action_blend_beta", 1.0)
                    beta = 1.0 if _b_raw is None else float(_b_raw)
                except (TypeError, ValueError, OverflowError):
                    beta = 1.0
                if not np.isfinite(beta):
                    beta = 1.0
                beta = min(1.0, max(0.0, beta))
                if credit_mode == "individual":
                    # v6-P1: no team-scalar mix. Subtract V(g ⊕ o_i) when it was
                    # evaluated on this decision; hold ticks keep the return.
                    baseline = 0.0
                    iv = rollout.get("indiv_values") or []
                    if step_idx < len(iv) and isinstance(iv[step_idx], dict):
                        baseline = float(iv[step_idx].get(aid, 0.0) or 0.0)
                    step_adv[aid] = float(rel_gae) - baseline
                else:
                    # Keep local counterfactual driving/lane-choice credit dominant (75% at steady
                    # state) so cross-approach signal phase waves do not pollute single-CAV gradients.
                    w_team = 0.15 + 0.10 * beta
                    w_rel = 0.85 - 0.10 * beta
                    step_adv[aid] = w_team * t_adv + w_rel * rel_gae
            else:
                t_adv = float(team_advantages[step_idx])
                t_reward = float(team_rewards[step_idx])
                a_ind = t_adv + (float(ind_reward) - t_reward)
                step_adv[aid] = 0.5 * t_adv + 0.5 * a_ind
        expanded_advantages.append(step_adv)

    rollout['team_returns'] = team_returns
    rollout['advantages'] = expanded_advantages
    if credit_mode == "individual" and bool(getattr(agent, "individual_critic", False)):
        samples = []
        obs_seq = rollout.get("obs") or []
        iv = rollout.get("indiv_values") or []
        for step_idx, amap in enumerate(per_step_cav_rel_adv):
            if step_idx >= len(iv) or not iv[step_idx]:
                continue
            obs_map = obs_seq[step_idx] if step_idx < len(obs_seq) else {}
            graph = obs_map.get("__graph__") if isinstance(obs_map, dict) else None
            if not isinstance(graph, dict) or graph.get("node_features") is None:
                continue
            for aid, ret in amap.items():
                item = (obs_map or {}).get(aid) if isinstance(obs_map, dict) else None
                vec = (item or {}).get("vector") if isinstance(item, dict) else None
                if vec is None:
                    continue
                samples.append((vec, float(ret), graph))
                if len(samples) >= 64:
                    break
            if len(samples) >= 64:
                break
        if samples and hasattr(agent, "fit_individual"):
            agent.fit_individual(samples)
    return rollout


def merge_and_update(agent, rollouts):
    merged = empty_rollout()
    current_global_offset = 0
    _noop_skipped = [0]  # v5.2.4: Lon samples dropped because the env handed the CAV back

    for r in rollouts:
        if not r['global_obs']:
            continue
        if len(r.get('team_returns', [])) != len(r['global_obs']):
            continue

        merged['global_obs'].extend(r['global_obs'])
        merged['rewards'].extend(r['rewards'])
        formal_seq = r.get('lon_formal_rewards') or []
        if len(formal_seq) == len(r['rewards']):
            merged['lon_formal_rewards'].extend(formal_seq)
        else:
            # Backward-compatible: pad missing formal maps with empty dicts.
            merged['lon_formal_rewards'].extend(
                [{} for _ in range(len(r['rewards']))]
            )
        merged['team_rewards'].extend(r['team_rewards'])
        merged['values'].extend(r['values'])
        if len(r.get('signal_values') or []) == len(r['values']):
            merged['signal_values'].extend(r['signal_values'])
        merged['dones'].extend(r['dones'])
        merged['coop_terms'].extend(r['coop_terms'])
        merged['team_returns'].extend(list(r['team_returns']))
        if len(r.get('signal_returns') or []) == len(r['team_returns']):
            merged['signal_returns'].extend(list(r['signal_returns']))

        step_applied_list = r.get('applied_cav_actions') or []
        _noop_steps = (
            None if bool(getattr(agent, 'keep_lon_noop_samples', False))
            else (r.get('lon_noop_vids') or [])
        )
        for step_idx in range(len(r['global_obs'])):
            step_obs = r['obs'][step_idx]
            step_actions = r['actions'][step_idx]
            step_logs = r['log_probs'][step_idx]
            step_adv = r['advantages'][step_idx]
            step_applied = (
                step_applied_list[step_idx]
                if step_idx < len(step_applied_list)
                else {}
            ) or {}

            for agent_id, agent_obs in step_obs.items():
                if agent_id not in step_actions:
                    continue
                action = step_actions[agent_id]

                if agent_id.startswith('cav_lon_') or (
                    agent_id.startswith('cav_')
                    and not agent_id.startswith('cav_lat_')
                    and not agent_id.startswith('cav_lon_')
                ):
                    if action is None or agent_id not in step_adv:
                        continue
                    if is_lon_noop(_noop_steps, step_idx, agent_id):
                        _noop_skipped[0] += 1
                        continue  # v5.2.4: handed back to SUMO -> action not executed
                    if bool(getattr(agent, 'cacc_soft_platoon_enabled', True)):
                        _min_auth = float(getattr(agent, 'cacc_ppo_authority_min', 0.20))
                        _auth = float((agent_obs or {}).get('lon_authority', 1.0))
                        if _auth < _min_auth:
                            continue
                    merged['lon_obs'].append(agent_obs)
                    merged['lon_actions'].append(action)
                    merged['lon_log_probs'].append(step_logs[agent_id])
                    merged['lon_ind_advantages'].append(float(step_adv.get(agent_id, 0.0)))
                    if agent_id.startswith('cav_lon_'):
                        vid = agent_id[len('cav_lon_'):]
                    else:
                        vid = agent_id[len('cav_'):]
                    try:
                        applied_a = float(step_applied[vid]) if vid in step_applied else float(
                            np.asarray(action).reshape(-1)[0]
                        )
                    except (TypeError, ValueError, KeyError):
                        applied_a = float(np.asarray(action).reshape(-1)[0])
                    merged['lon_applied_actions'].append(applied_a)
                    # Legacy aliases for older update paths
                    merged['cav_obs'].append(agent_obs)
                    merged['cav_actions'].append(action)
                    merged['cav_log_probs'].append(step_logs[agent_id])
                    merged['ind_advantages'].append(float(step_adv.get(agent_id, 0.0)))

                elif agent_id.startswith('cav_lat_'):
                    if action is None or action == -1 or agent_id not in step_adv:
                        continue
                    # DoF-gated buffer: only RL_DLC samples train the lateral head.
                    # Default False matches compute_gae_for_rollout / obs contract.
                    try:
                        _obs_flag = bool((agent_obs or {}).get('dlc_eligible', False))
                    except Exception:
                        _obs_flag = False
                    if not _obs_flag:
                        continue
                    merged['lat_obs'].append(agent_obs)
                    merged['lat_actions'].append(int(action))
                    merged['lat_log_probs'].append(step_logs[agent_id])
                    merged['lat_ind_advantages'].append(float(step_adv.get(agent_id, 0.0)))

                elif agent_id.startswith('signal_'):
                    if action == -1:
                        continue
                    _ovr = r.get('signal_overridden') or []
                    if step_idx < len(_ovr) and agent_id in (_ovr[step_idx] or ()):
                        continue  # v5 (1.1): executed phase != sampled phase
                    merged['signal_obs'].append(agent_obs)
                    merged['signal_actions'].append(action)
                    merged['signal_log_probs'].append(step_logs[agent_id])
                    merged['signal_step_indices'].append(step_idx + current_global_offset)
                    merged['signal_ind_advantages'].append(float(step_adv.get(agent_id, 0.0)))
                    t_act = -1
                    t_conf = 0.0
                    t_sev = 0.0
                    try:
                        t_act = int((agent_obs or {}).get('teacher_action', -1))
                    except (TypeError, ValueError, OverflowError):
                        t_act = -1
                    try:
                        t_conf = float((agent_obs or {}).get('teacher_confidence', 0.0))
                    except (TypeError, ValueError, OverflowError):
                        t_conf = 0.0
                    if not np.isfinite(t_conf):
                        t_conf = 0.0
                    try:
                        t_sev = float((agent_obs or {}).get('teacher_severity', 0.0))
                    except (TypeError, ValueError, OverflowError):
                        t_sev = 0.0
                    if not np.isfinite(t_sev) or t_sev < 0.0:
                        t_sev = 0.0
                    mask = (agent_obs or {}).get('action_mask')
                    legal = False
                    if t_act >= 0 and t_conf >= float(TEACHER_CONFIDENCE_THRESHOLD):
                        if mask is not None:
                            m = np.asarray(mask, dtype=np.float32).reshape(-1)
                            legal = t_act < m.size and float(m[t_act]) > 0.0
                        else:
                            legal = True
                    if not legal:
                        t_act = -1
                        t_conf = 0.0
                        t_sev = 0.0
                    elif t_sev <= 0.0:
                        # Valid teacher without severity → routine default.
                        t_sev = 0.30
                    merged['signal_teacher_actions'].append(int(t_act))
                    merged['signal_teacher_confs'].append(float(t_conf))
                    merged['signal_teacher_severities'].append(float(t_sev))

        current_global_offset += len(r['global_obs'])

    if current_global_offset == 0:
        return None
    # agent.update(merged) jointly updates both CentralizedCritic heads (value_head
    # on _ret_rms-normalized team_returns and signal_head on _sig_ret_rms-normalized
    # signal_returns) in a single shared GNN pass per minibatch.
    losses = agent.update(merged)
    try:
        agent._v524_noop_skipped = int(getattr(agent, '_v524_noop_skipped', 0)) + int(_noop_skipped[0])
        agent._v524_lon_kept = int(getattr(agent, '_v524_lon_kept', 0)) + len(merged.get('lon_obs') or [])
    except Exception:
        pass
    return losses


# v6-P0 feasibility profile: attribute -> (value, CLI spellings that override it).
V6P0_PROFILE = {
    "lon_no_floors": (True, ("--lon-no-floors", "--no-lon-no-floors")),
    "lon_handback_near_m": (20.0, ("--lon-handback-near-m",)),
    "lon_actuation": ("speed", ("--lon-actuation",)),
    "lon_rl_max_dist_m": (200.0, ("--lon-rl-max-dist-m",)),
    "lon_rl_min_dist_m": (20.0, ("--lon-rl-min-dist-m",)),
    "lon_rl_in_junction": (False, ("--lon-rl-in-junction", "--no-lon-rl-in-junction")),
    "gap_policy": ("unified", ("--gap-policy",)),
    "signal_reward_sat": (4.0, ("--signal-reward-sat",)),
    "lon_imitation_scale": (0.0, ("--lon-imitation-scale",)),
    "cacc_ppo_authority_min": (0.5, ("--cacc-ppo-authority-min",)),
}
# P1 keeps the P0 rule stack and replaces the residual learner.
V6P1_PROFILE = {
    **V6P0_PROFILE,
    "lon_action_mode": ("target_speed", ("--lon-action-mode",)),
    "cav_action_interval": (1.0, ("--cav-action-interval",)),
    "gamma_seconds": (0.98, ("--gamma-seconds",)),
    "cav_credit_mode": ("individual", ("--cav-credit-mode",)),
    "cross_approach_baseline": (False, ("--cross-approach-baseline", "--no-cross-approach-baseline")),
    "individual_critic": (True, ("--individual-critic", "--no-individual-critic")),
    "signal_commitment": (True, ("--signal-commitment", "--no-signal-commitment")),
    "p1_obs_on_decision": (True, ("--p1-obs-on-decision", "--no-p1-obs-on-decision")),
    "p1_lat_delayed": (True, ("--p1-lat-delayed", "--no-p1-lat-delayed")),
}
# Gate-accepted paper stack (G2): v6-P0 rules, Lon residual forced to 0,
# Max-Pressure inside the agent envelope. GATE-P1 / G3 diag did not pass;
# do not train residual or v6p1 for paper runs.
LANDABLE_PROFILE = {
    **V6P0_PROFILE,
    "ablate_zero_lon_residual": (True, ("--ablate-zero-lon-residual", "--no-ablate-zero-lon-residual")),
    "signal_rule": ("maxpressure", ("--signal-rule",)),
}


def _flag_given(argv, spellings) -> bool:
    for tok in argv or ():
        t = str(tok)
        for sp in spellings:
            if t == sp or t.startswith(sp + "="):
                return True
    return False


def apply_profile(args, argv=None):
    """Apply ``--profile`` defaults; flags given explicitly on the CLI always win."""
    prof = str(getattr(args, "profile", "v524") or "v524").strip().lower()
    applied = {}
    table = {
        "v6p1": V6P1_PROFILE,
        "v6p0": V6P0_PROFILE,
        "landable": LANDABLE_PROFILE,
    }.get(prof, {})
    for attr, (value, spellings) in table.items():
        if _flag_given(argv, spellings):
            continue
        setattr(args, attr, value)
        applied[attr] = value
    args._profile_applied = applied
    return args


def parse_args():
    config = load_config()
    simulation = config.get('simulation', {})
    marl = config.get('marl', {})
    training = config.get('training', {})
    vlm = config.get('vlm', {})
    co_opt = config.get('co_optimization', {}) or {}
    opt_cfg = config.get('optimization', {}) or {}
    parser = argparse.ArgumentParser(description='Train cooperative signal-CAV MAPPO controller.')
    
    parser.add_argument(
        '--num-envs',
        type=int,
        default=int(training.get('num_envs', 1)),
        help='Parallel SUMO instances per run (default 1; use scripts/train/run_five_seeds.py for 5 independent seeds)',
    )
    parser.add_argument('--episodes', type=int, default=training.get('episodes', 2000))
    parser.add_argument(
        '--max-steps',
        type=int,
        default=training.get('max_steps', 4500),
        help='Controlled horizon in steps (default 4500 = 15 min @ 0.2s); '
        'overridden by --control-seconds / --quick',
    )
    from baselines.episode_timing import add_episode_timing_args
    add_episode_timing_args(parser, training)
    parser.add_argument('--rollout-horizon', type=int, default=training.get('rollout_horizon', 1024))
    parser.add_argument(
        '--checkpoint-dir',
        default=training.get('checkpoint_dir', '') or '',
        help='Override checkpoint folder (default: results/train/<method>/<scenario>/seed_N/checkpoints)',
    )
    parser.add_argument('--checkpoint-interval', type=int, default=training.get('checkpoint_interval', 10))
    parser.add_argument(
        '--resume',
        action='store_true',
        help='Continue from latest.pt in the run checkpoint dir (CPU/GPU via map_location)',
    )
    parser.add_argument(
        '--resume-from',
        type=str,
        default='',
        help='Checkpoint .pt path to load (implies --resume)',
    )
    parser.add_argument(
        '--restart-stage-lon',
        action='store_true',
        help=(
            'Roll back cleanly to the end of Stage-S (e.g. Episode 250 on Full / 120 on Quick) '
            'using best_stage_s.pt, reinitialize lon_actor/critic cleanly, and sanitize TB logs'
        ),
    )
    parser.add_argument(
        '--scenario',
        type=str,
        default='',
        help='Scenario key for results paths (default: inferred from --sumocfg)',
    )
    parser.add_argument(
        '--results-method',
        type=str,
        default='VECTOR',
        help=(
            'results/train|eval/<method>/[vlm-model/]<scenario>/seed_N. '
            'Default VECTOR; --no-vision → no_vlm; '
            '--only-*-vlm-vision → only_signal_vlm / only_lon_vlm / only_lat_vlm. '
            'VECTOR-family methods nest under --vlm-model then scenario then seed.'
        ),
    )
    parser.add_argument('--step-length', type=float, default=simulation.get('step_length', 0.2))
    parser.add_argument(
        '--sumo-port-base',
        type=int,
        default=int(simulation.get('sumo_port_base', 0) or 0),
        help='If >0, env i uses TraCI port (base+i); else allocate a free port per env',
    )
    parser.add_argument(
        '--cav-action-interval',
        type=float,
        default=float(simulation.get('cav_action_interval_s', 0.4)),
        help='Seconds between CAV accel resampling (default 0.4s = exact 2 steps @ 0.2s)',
    )
    parser.add_argument(
        '--gui',
        action=argparse.BooleanOptionalAction,
        default=bool(simulation.get('gui', False)),
        help='Open SUMO-GUI each episode (auto-start; closes at episode end).',
    )
    _emissions_env = str(
        os.environ.get("SUMO_ENABLE_EMISSIONS", "1")
    ).strip().lower() not in ("0", "false", "no", "off")
    parser.add_argument(
        '--emissions',
        action=argparse.BooleanOptionalAction,
        default=bool(simulation.get('enable_emissions', _emissions_env)),
        help=(
            'Compute SUMO HBEFA fuel/CO2 each step for Metrics/* TensorBoard '
            '(default: on, or SUMO_ENABLE_EMISSIONS / config simulation.enable_emissions). '
            'Use --no-emissions to skip for faster training.'
        ),
    )
    parser.add_argument('--live-plot', action='store_true')
    parser.add_argument('--actor-lr', type=float, default=marl.get('actor_lr', 3e-4))
    parser.add_argument('--critic-lr', type=float, default=marl.get('critic_lr', 1e-4))
    parser.add_argument('--gamma', type=float, default=marl.get('gamma', 0.99))
    parser.add_argument('--gae-lambda', type=float, default=marl.get('gae_lambda', 0.95))
    parser.add_argument('--clip-param', type=float, default=marl.get('clip_param', 0.2))
    parser.add_argument('--ppo-epochs', type=int, default=marl.get('ppo_epochs', 4))
    parser.add_argument('--minibatch-size', type=int, default=marl.get('minibatch_size', 64))
    parser.add_argument('--device', type=str, default=marl.get('device', 'cuda'), help="Training device: auto | cuda | cpu. Prefer cuda for MAPPO; keep local VLM on CPU or another GPU (see local_vlm_server.py).")
    parser.add_argument(
        '--vlm-model',
        default=os.environ.get('VLM_MODEL') or vlm.get('model', 'qwen3-vl-flash'),
        help='VLM model id (local served name or online API model name)',
    )
    parser.add_argument(
        '--vlm-api-base',
        default=os.environ.get('VLM_API_BASE') or vlm.get('api_base', 'http://127.0.0.1:8080/v1'),
        help='OpenAI-compatible VLM API base URL (local server or online endpoint)',
    )
    parser.add_argument(
        '--vlm-api-key',
        default=os.environ.get('VLM_API_KEY') or vlm.get('api_key', 'local-mock-key'),
        help='VLM API key (local servers usually accept any non-empty string)',
    )
    parser.add_argument('--vlm-update-interval', type=float, default=vlm.get('update_interval_seconds', 5.0))
    parser.add_argument(
        '--vlm-thinking-mode',
        type=str,
        default=str(vlm.get('thinking_mode', 'off') or 'off'),
        help='VLM reasoning / thinking mode default when VLM_THINKING_MODE env is unset (off|low|auto)',
    )
    parser.add_argument(
        '--crash-attribution',
        action=argparse.BooleanOptionalAction,
        default=bool(co_opt.get('crash_attribution_enabled', True)),
        help='Assign individualized terminal penalty to collider/teleport CAVs and bypass peer baseline',
    )
    parser.add_argument(
        '--crash-terminal-penalty',
        type=float,
        default=float(co_opt.get('crash_terminal_penalty', -1.0)),
    )
    parser.add_argument(
        '--green-glide-fix',
        action=argparse.BooleanOptionalAction,
        default=bool(co_opt.get('green_glide_decouple_enabled', True)),
    )
    parser.add_argument(
        '--lagrangian-safety',
        action=argparse.BooleanOptionalAction,
        default=bool(co_opt.get('lagrangian_safety_enabled', True)),
    )
    parser.add_argument(
        '--lagrangian-safety-init',
        type=float,
        default=float(co_opt.get('lagrangian_safety_init', 0.05)),
    )
    parser.add_argument(
        '--lagrangian-safety-lr',
        type=float,
        default=float(co_opt.get('lagrangian_safety_lr', 0.02)),
    )
    parser.add_argument(
        '--lagrangian-safety-max',
        type=float,
        default=float(co_opt.get('lagrangian_safety_max', 0.50)),
    )
    parser.add_argument(
        '--target-intervention-rate',
        type=float,
        default=float(co_opt.get('target_intervention_rate', 0.05)),
    )
    parser.add_argument(
        '--in-memory-follower',
        action=argparse.BooleanOptionalAction,
        default=bool(co_opt.get('in_memory_follower_lookup', True)),
    )
    parser.add_argument(
        '--cacc-soft-platoon',
        action=argparse.BooleanOptionalAction,
        default=bool(co_opt.get('cacc_soft_platoon_enabled', True)),
    )
    parser.add_argument(
        '--cacc-full-gap-m',
        type=float,
        default=float(co_opt.get('cacc_full_gap_m', 8.0)),
    )
    parser.add_argument(
        '--cacc-free-gap-m',
        type=float,
        default=float(co_opt.get('cacc_free_gap_m', 22.0)),
    )
    parser.add_argument(
        '--cacc-rl-authority-floor',
        type=float,
        default=float(co_opt.get('cacc_rl_authority_floor', 0.25)),
        help='Minimum physical RL action authority [0,1] retained inside cacc_full_gap_m (default 0.25)',
    )
    parser.add_argument(
        '--cacc-leader-accel-gain',
        type=float,
        default=float(co_opt.get('cacc_leader_accel_gain', 0.35)),
    )
    parser.add_argument(
        '--cacc-ppo-authority-min',
        type=float,
        default=float(co_opt.get('cacc_ppo_authority_min', 0.20)),
    )
    parser.add_argument(
        '--goal-speed-cond',
        action=argparse.BooleanOptionalAction,
        default=bool(co_opt.get('goal_speed_conditioning', True)),
    )
    parser.add_argument(
        '--cross-approach-baseline',
        action=argparse.BooleanOptionalAction,
        default=bool(co_opt.get('cross_approach_baseline', True)),
    )
    parser.add_argument(
        '--freeze-team-critic-in-s',
        action=argparse.BooleanOptionalAction,
        default=bool(co_opt.get('freeze_team_critic_in_stage_s', True)),
    )
    # ---------------- v4 optimization switches (experiments/config.yaml: optimization) ----
    parser.add_argument('--queue-mode', choices=['halted', 'legacy'],
                        default=str(opt_cfg.get('queue_mode', 'halted')),
                        help='halted = halted vehicles only (v4); legacy = v3 incl. moving DBSCAN clusters')
    parser.add_argument('--include-permissive-lanes', action=argparse.BooleanOptionalAction,
                        default=bool(opt_cfg.get('include_permissive_lanes', True)))
    parser.add_argument('--green-arrival-k', type=float, default=float(opt_cfg.get('green_arrival_k', 2.0)))
    parser.add_argument('--green-arrival-window-s', type=float,
                        default=float(opt_cfg.get('green_arrival_window_s', 10.0)))
    parser.add_argument('--max-depart-delay', type=float, default=float(opt_cfg.get('max_depart_delay', -1.0)),
                        help='<0: never discard un-inserted vehicles (v3: 30 s, silently dropped)')
    parser.add_argument('--collision-check-junctions', action=argparse.BooleanOptionalAction,
                        default=bool(opt_cfg.get('collision_check_junctions', True)))
    parser.add_argument('--allow-od-rewrite', action=argparse.BooleanOptionalAction,
                        default=bool(opt_cfg.get('allow_od_rewrite', False)),
                        help='changeTarget/reroute rescues for stuck vehicles (v3: on)')
    parser.add_argument('--hdv-keep-lane-control-zone', action=argparse.BooleanOptionalAction,
                        default=bool(opt_cfg.get('hdv_keep_lane_control_zone', False)))
    parser.add_argument('--demand-randomize', action=argparse.BooleanOptionalAction,
                        default=bool(opt_cfg.get('demand_randomize', True)))
    parser.add_argument('--demand-jitter-s', type=float, default=float(opt_cfg.get('demand_jitter_s', 60.0)))
    parser.add_argument('--demand-scale-low', type=float, default=float(opt_cfg.get('demand_scale_low', 0.9)))
    parser.add_argument('--demand-scale-high', type=float, default=float(opt_cfg.get('demand_scale_high', 1.1)))
    parser.add_argument('--cav-credit-mode', choices=['coop_xapp', 'relative', 'individual'],
                        default=str(opt_cfg.get('cav_credit_mode', 'coop_xapp')))
    parser.add_argument('--coop-kappa', type=float, default=float(opt_cfg.get('coop_kappa', 0.5)))
    parser.add_argument('--dual-clip-c', type=float, default=float(opt_cfg.get('dual_clip_c', 3.0)))
    parser.add_argument('--popart', action=argparse.BooleanOptionalAction, default=bool(opt_cfg.get('popart', True)))
    parser.add_argument('--final-select', choices=['latest', 'score'],
                        default=str(opt_cfg.get('final_select', 'latest')),
                        help='latest = export the most complete stage (v4); score = v3 cross-stage pick')
    parser.add_argument('--vlm-heuristic', action=argparse.BooleanOptionalAction,
                        default=bool(opt_cfg.get('vlm_heuristic', False)),
                        help='Ablation: rule table identical to the VLM prompt, no VLM calls')
    parser.add_argument('--ablate-zero-lon-residual', action=argparse.BooleanOptionalAction,
                        default=bool(opt_cfg.get('ablate_zero_lon_residual', False)),
                        help='Ablation: force the Lon RL residual to 0 (rule stack only)')
    # ---------------- v5 batch 1 ----------------
    parser.add_argument('--signal-min-batch', type=int, default=int(opt_cfg.get('signal_min_batch', 128)),
                        help='Accumulate >= N signal decisions before a signal-actor PPO update (0 = v4 per-flush)')
    parser.add_argument('--select-score', choices=['legacy', 'tis'], default=str(opt_cfg.get('select_score', 'legacy')),
                        help='Best-checkpoint score: legacy (speed - 0.15*queue) or tis (-avg_time_in_system/60)')
    parser.add_argument('--gamma-seconds', type=float, default=opt_cfg.get('gamma_seconds', None),
                        help='Per-second discount; if set, gamma_step = gamma_seconds ** step_length')
    parser.add_argument('--eval-only', action='store_true',
                        help='Evaluate --eval-checkpoint deterministically on --eval-seeds and exit')
    parser.add_argument('--eval-checkpoint', type=str, default='')
    parser.add_argument('--eval-seeds', type=str, default='validation',
                        help='Comma-separated seeds, or "validation" / "test" (baselines/experiment_seeds.py)')
    parser.add_argument('--eval-stage', type=str, default='', help='Stage to configure (default: checkpoint stage)')
    parser.add_argument('--eval-out', type=str, default='', help='CSV for per-episode KPIs')
    parser.add_argument('--eval-demand-randomize', action=argparse.BooleanOptionalAction, default=False,
                        help='Held-out randomized demand instances seeded by the eval seed')
    # ---------------- v5.1 (smoke-test fixes) ----------------
    parser.add_argument('--smoke', action='store_true',
                        help='Tiny schedule visiting every stage: S2 / Lon2 / Lat2 + JointAll2 (pair with --control-seconds 300)')
    parser.add_argument('--torch-threads', type=int, default=int(opt_cfg.get('torch_threads', 0) or 0),
                        help='torch intra-op threads in the trainer (0 = auto: 2). Env workers always use 1.')
    parser.add_argument('--sumo-diag-dir', type=str, default='',
                        help='Write SUMO collision-output, warnings (teleport reasons) and statistics per episode here')
    # ---------------- v5.2 ----------------
    parser.add_argument('--lon-reward-version', choices=['v1', 'v2'],
                        default=str(opt_cfg.get('lon_reward_version', 'v2')),
                        help='v2 prices delay (delay rate), penalty-only safety/platoon, leader-type headway bands')
    parser.add_argument('--ablate-cav-native-idm', action=argparse.BooleanOptionalAction,
                        default=bool(opt_cfg.get('ablate_cav_native_idm', False)),
                        help='Ablation A0: in Lon/Lat/Joint, CAVs drive with SUMO native IDM (no rule stack)')
    parser.add_argument('--glosa-min-speed', type=float, default=opt_cfg.get('glosa_min_speed', None),
                        help='GLOSA speed floor in m/s for env envelope AND reward target (v1: 3.5)')
    # ---------------- v5.2.4: control-stack bisection (defaults = v5.2.3) ----------------
    parser.add_argument('--lon-no-floors', action=argparse.BooleanOptionalAction,
                        default=bool(opt_cfg.get('lon_no_floors', False)),
                        help='B2: disable the four lower-bound accel nudges (cruise/follower/junction/anti-stall)')
    parser.add_argument('--lon-handback-near-m', type=float,
                        default=float(opt_cfg.get('lon_handback_near_m', 0.0) or 0.0),
                        help='B3: hand CAVs back to SUMO within N m of the stop line AND inside the junction (0 = off)')
    parser.add_argument('--lon-handback-junction', action=argparse.BooleanOptionalAction,
                        default=bool(opt_cfg.get('lon_handback_junction', False)),
                        help='B3b: hand CAVs back to SUMO inside the junction box only')
    parser.add_argument('--lon-actuation', choices=['accel', 'speed'],
                        default=str(opt_cfg.get('lon_actuation', 'accel') or 'accel'),
                        help='B4: accel = setAcceleration (v5.2.3); speed = speed advisory via setMaxSpeed '
                             '(SUMO keeps its own car-following and junction logic)')
    parser.add_argument('--spat-synth-fix', action=argparse.BooleanOptionalAction,
                        default=bool(opt_cfg.get('spat_synth_fix', True)),
                        help='Time-to-green during synthesized yellow/all-red uses the decided next green (v5.2.4 fix)')
    parser.add_argument('--keep-lon-noop-samples', action=argparse.BooleanOptionalAction,
                        default=bool(opt_cfg.get('keep_lon_noop_samples', False)),
                        help='Keep Lon samples of CAVs handed back to SUMO in PPO (v5.2.3 behaviour; default drops them)')
    # ---------------- v6-P0 (defaults = v5.2.4 behaviour; --profile v6p0 sets them) ----------------
    parser.add_argument('--profile', choices=['v524', 'v6p0', 'v6p1', 'landable'],
                        default=str(opt_cfg.get('profile', 'v524') or 'v524'),
                        help='v6p0: P0 rule stack (Lon residual still learns unless ablated). '
                             'landable: G2 paper stack (v6p0 + zero Lon residual + Max-Pressure). '
                             'v6p1: experimental; GATE-P1 failed on 4-leg seed 7. '
                             'Any flag given explicitly on the CLI wins over the profile.')
    parser.add_argument('--lon-action-mode', choices=['residual', 'target_speed'],
                        default=str(opt_cfg.get('lon_action_mode', 'residual') or 'residual'),
                        help='residual = IDM residual (v5.2.4 / v6p0); target_speed = v6-P1')
    parser.add_argument('--individual-critic', action=argparse.BooleanOptionalAction,
                        default=bool(opt_cfg.get('individual_critic', False)),
                        help='Train V(g(s) + local CAV observation) and drop the team-advantage mix')
    parser.add_argument('--signal-commitment', action=argparse.BooleanOptionalAction,
                        default=bool(opt_cfg.get('signal_commitment', False)),
                        help='Green start commits gmin and the next phase; T is an observation only')
    parser.add_argument('--p1-obs-on-decision', action=argparse.BooleanOptionalAction,
                        default=bool(opt_cfg.get('p1_obs_on_decision', False)),
                        help='Rebuild agent observations only on CAV decision steps')
    parser.add_argument('--p1-lat-delayed', action=argparse.BooleanOptionalAction,
                        default=bool(opt_cfg.get('p1_lat_delayed', False)),
                        help='Lane-change reward from travel time measured 15 s later plus a MOBIL penalty')
    parser.add_argument('--lon-rl-max-dist-m', type=float,
                        default=float(opt_cfg.get('lon_rl_max_dist_m', 300.0) or 300.0),
                        help='Longitudinal RL corridor length before the stop line (v5.2.4: 300; spec: 200)')
    parser.add_argument('--lon-rl-min-dist-m', type=float,
                        default=float(opt_cfg.get('lon_rl_min_dist_m', 0.0) or 0.0),
                        help='No Lon RL (no obs, no sample) within this distance of the stop line (SUMO drives)')
    parser.add_argument('--lon-rl-in-junction', action=argparse.BooleanOptionalAction,
                        default=bool(opt_cfg.get('lon_rl_in_junction', True)),
                        help='Lon RL inside the junction box (v5.2.4: on)')
    parser.add_argument('--gap-policy', choices=['legacy', 'unified'],
                        default=str(opt_cfg.get('gap_policy', 'legacy') or 'legacy'),
                        help='environment/gap_policy.py: legacy = v5.2.4 thresholds; unified = one ordered set')
    parser.add_argument('--signal-reward-sat', type=float,
                        default=float(opt_cfg.get('signal_reward_sat', 1.0) or 1.0),
                        help='Saturation of the normalised signal queue/wait reward (v5.2.4: 1.0)')
    parser.add_argument('--lon-imitation-scale', type=float,
                        default=float(opt_cfg.get('lon_imitation_scale', 0.10)),
                        help='Lon soft-start imitation coef = scale*(1-beta); v5.2.4: 0.10 (its target is the '
                             'sampled action, not the executed one -> v6p0 sets 0)')
    parser.add_argument('--signal-rule', choices=['none', 'maxpressure', 'longest_queue', 'fixed'],
                        default=str(opt_cfg.get('signal_rule', 'none') or 'none'),
                        help='Replace the signal agent by a rule inside the same envelope (baseline / bisection). '
                             'fixed = keep the SUMO TLS program after warmup')
    parser.add_argument('--gate-lon-episodes', type=int, default=0,
                        help='P0 gate schedule: S2 / Lon N / Lat1, no joint stages (0 = off)')
    parser.add_argument('--lagrangian-penalty-mode', choices=['indicator', 'squared'],
                        default=str(co_opt.get('lagrangian_penalty_mode', 'indicator')))
    parser.add_argument(
        '--vlm-fail-stop',
        action=argparse.BooleanOptionalAction,
        default=bool(vlm.get('fail_stop_on_error', True)),
        help=(
            'Stop training when online/local VLM call or parse fails (default: on). '
            'Re-run with --resume after fixing the API/server. Use --no-vlm-fail-stop '
            'to keep the old retain-weights behavior.'
        ),
    )
    parser.add_argument(
        '--no-vlm',
        action='store_true',
        default=bool(vlm.get('disabled', False)),
        help=(
            'Legacy alias for --no-vision: disable VLM in all stages '
            '(fixed reward weights, no signal vision)'
        ),
    )
    parser.add_argument(
        '--no-vision',
        action='store_true',
        default=False,
        help=(
            'Baseline: no VLM in Stage-S / Lon / Lat (fixed weights, no signal vision). '
            'Prefer this over --no-vlm.'
        ),
    )
    _env_signal_vision = os.environ.get('SIGNAL_VLM_VISION_ENABLED', '').strip().lower()
    if _env_signal_vision in ('0', 'false', 'no', 'off'):
        _default_signal_vision = False
    elif _env_signal_vision in ('1', 'true', 'yes', 'on'):
        _default_signal_vision = True
    else:
        # Main algorithm default: signal vision ON (full three-stage VLM).
        _default_signal_vision = True
    parser.add_argument(
        '--signal-vlm-vision',
        action=argparse.BooleanOptionalAction,
        default=_default_signal_vision,
        help=(
            'Enable Stage-S signal vision-semantic VLM (default: on for the main '
            'algorithm). Usually omit this flag. Use --only-*-vlm-vision / '
            '--no-vision for ablations; --no-signal-vlm-vision disables Stage-S '
            'vision while keeping Lon/Lat weight VLM.'
        ),
    )
    parser.add_argument(
        '--only-signal-vlm-vision',
        action='store_true',
        default=False,
        help=(
            'Baseline ablation: VLM only in Stage-S (signal vision); '
            'Stage-Lon/Lat use fixed reward weights'
        ),
    )
    parser.add_argument(
        '--rule-signal-teacher',
        action=argparse.BooleanOptionalAction,
        default=False,
        help=(
            'Stage-S deterministic queue/wait teacher for no-signal-vision runs. '
            'Default: OFF (pure RL baseline for no_vlm / only-lon / only-lat). '
            'Pass --rule-signal-teacher to enable explicitly.'
        ),
    )
    parser.add_argument(
        "--leaders-only",
        action="store_true",
        help="Restrict longitudinal RL to DBSCAN platoon leaders only (legacy ablation; default controls all corridor CAVs).",
    )
    parser.add_argument(
        "--no-lon-residual-idm",
        action="store_true",
        help="Disable IDM-residual longitudinal action space and revert to direct absolute acceleration.",
    )
    parser.add_argument(
        '--all-cav-soft-platoon',
        action=argparse.BooleanOptionalAction,
        default=False,
        help=(
            'Scheme-1 experiment: Lon RL for all corridor CAVs (not DBSCAN-leader '
            'gated), soft platoon via Lon pack + Lat form, discrete Lat unchanged. '
            'Writes to results/train/allcav_softplatoon[/model]/ or '
            'allcav_softplatoon_no_vlm/. Do not resume Leader-only checkpoints. '
            'Also: ALL_CAV_SOFT_PLATOON=1.'
        ),
    )
    parser.add_argument(
        '--only-lon-vlm-vision',
        action='store_true',
        default=False,
        help=(
            'Baseline ablation: VLM only in Stage-Lon (W_long); '
            'no Stage-S signal vision and no Stage-Lat weight VLM'
        ),
    )
    parser.add_argument(
        '--only-lat-vlm-vision',
        action='store_true',
        default=False,
        help=(
            'Baseline ablation: VLM only in Stage-Lat (W_lat); '
            'no Stage-S signal vision and no Stage-Lon weight VLM'
        ),
    )
    parser.add_argument(
        '--fixed-weights',
        type=float,
        nargs='+',
        default=None,
        metavar='W',
        help='Fixed longitudinal weights (3 or 4: safe eff comfort [platoon]). Implies --no-vlm.',
    )
    parser.add_argument(
        '--stage-s-frac', type=float,
        default=float(training.get('stage_s_frac', training.get('stage1_frac', 200 / 1200))),
        help='Fraction of episodes for Stage-S (signal only); default 200/1200',
    )
    parser.add_argument(
        '--stage-l1-frac', type=float,
        default=float(training.get('stage_l1_frac', training.get('stage_transition_frac', 420 / 1200))),
        help='Fraction for the 2nd stage (Stage-Lon: longitudinal + VLM W_long)',
    )
    parser.add_argument(
        '--stage-l2-frac', type=float,
        default=float(training.get('stage_l2_frac', 580 / 1200)),
        help='Fraction for the 3rd stage (Stage-Lat: lateral + VLM W_lat); '
        'if unset remainder after S+Lon is used',
    )
    parser.add_argument(
        '--stage-lon-frac', type=float, default=float(training.get('stage_lon_frac', 300 / 600)),
        help='Fraction for Stage-Lon (longitudinal); overrides --stage-l1-frac',
    )
    parser.add_argument(
        '--stage-lat-frac', type=float, default=float(training.get('stage_lat_frac', 200 / 600)),
        help='Fraction for Stage-Lat (lateral); overrides --stage-l2-frac',
    )
    parser.add_argument(
        '--joint-lon-sig-episodes', type=int,
        default=int(training.get('joint_lon_sig_episodes', 500)),
        help='Absolute JointLonSig length carved from Lon block '
        '(full default 500 → Lon main 500 when Lon block=1000; '
        'LR/entropy anneal over first 200 then hold floor for 300). 0 disables.',
    )
    parser.add_argument(
        '--joint-all-episodes', type=int,
        default=int(training.get('joint_all_episodes', 500)),
        help='Absolute JointAll length carved from Lat block '
        '(full default 500 → Lat main 500 when Lat block=1000; '
        'LR/entropy anneal over first 200 then hold floor for 300). 0 disables.',
    )
    parser.add_argument(
        '--joint-lon-sig-tail-frac', type=float,
        default=float(training.get('joint_lon_sig_tail_frac', 0.0)),
        help='Fallback: fraction of Lon block for JointLonSig if '
        '--joint-lon-sig-episodes is 0.',
    )
    parser.add_argument(
        '--joint-all-tail-frac', type=float,
        default=float(training.get('joint_all_tail_frac', 0.0)),
        help='Fallback: fraction of Lat block for JointAll if '
        '--joint-all-episodes is 0.',
    )
    parser.add_argument(
        '--stage-transition-frac', type=float,
        default=float(training.get('stage_transition_frac', 420 / 1200)),
        help='Legacy alias for --stage-l1-frac',
    )
    parser.add_argument(
        '--stage-v1-frac', type=float,
        default=float(training.get('stage_v1_frac', training.get('stage2_frac', 0.0))),
        help='Deprecated (ignored); curriculum is S→Lon→Lat only',
    )
    parser.add_argument('--delta-max', type=float, default=float(training.get('delta_max', 1.5)))
    parser.add_argument(
        '--disable-lateral',
        action='store_true',
        help='Train/eval without CAV lateral agent (longitudinal-only ablation)',
    )
    parser.add_argument(
        '--disable-longitudinal',
        action='store_true',
        help='Train/eval without CAV longitudinal agent (lateral-only ablation)',
    )
    parser.add_argument('--w-coop', type=float, default=float(training.get('w_coop', 0.25)))
    parser.add_argument('--lambda-flow', type=float, default=float(training.get('lambda_flow', 0.6)))
    parser.add_argument('--lambda-plat', type=float, default=float(training.get('lambda_plat', 0.4)))
    parser.add_argument(
        '--lambda-mode',
        type=str,
        default=str(training.get('lambda_mode', 'fixed')),
        choices=['adaptive', 'fixed'],
        help='Coop λ_flow/λ_plat: density occupancy (adaptive) or constant (fixed)',
    )
    parser.add_argument(
        '--lambda-ema',
        type=float,
        default=float(training.get('lambda_ema', 0.9)),
        help='EMA for adaptive λ_flow (0=raw occupancy, ~0.9=slow)',
    )
    parser.add_argument(
        '--k-jam',
        type=float,
        default=float(training.get('k_jam', 0.0)),
        help='Jam density veh/km/lane; 0 uses zone jam count (incoming capacity)',
    )
    parser.add_argument(
        '--no-residual',
        action='store_true',
        default=bool(training.get('no_residual', False)),
        help='Deprecated no-op alias (curriculum is S→Lon→Lat; no residual head)',
    )
    parser.add_argument(
        '--no-coop',
        action='store_true',
        default=bool(training.get('no_coop', False)),
        help='Deprecated: forces w_coop=0 (legacy coop channel removed from R_lat/R_long)',
    )
    parser.add_argument('--green-k', type=float, default=float(training.get('green_duration_k', 0.85)))
    parser.add_argument('--dbscan-eps', type=float, default=float(training.get('dbscan_eps', 0.8)))
    parser.add_argument(
        '--top3-mask',
        action='store_true',
        default=bool(training.get('top3_phase_mask', True)),
        help='Congestion Top-3 phase mask during training',
    )
    parser.add_argument(
        '--no-top3-mask',
        action='store_true',
        help='Disable Top-3 phase mask',
    )
    parser.add_argument(
        '--stage1-frac', type=float,
        default=float(training.get('stage1_frac', 0.2)),
        help='Deprecated alias for --stage-s-frac',
    )
    parser.add_argument(
        '--stage2-frac', type=float,
        default=float(training.get('stage2_frac', 0.27)),
        help='Deprecated alias for --stage-v1-frac',
    )
    parser.add_argument('--seed', type=int, default=7)
    parser.add_argument(
        '--sumocfg',
        default=config.get('simulation', {}).get(
            'sumocfg',
            os.path.join('environment', 'sumo_net', 'cross', 'cross.sumocfg'),
        ),
        help='SUMO config path relative to project root or absolute',
    )
    parser.add_argument(
        '--experiment-name',
        default=config.get('experiment_name', 'VECTOR'),
        help='TensorBoard / checkpoint run name prefix',
    )
    args = parser.parse_args()
    args.schedule_overrides = (config.get('training', {}) or {}).get('schedule')
    if str(getattr(args, 'resume_from', '') or '').strip():
        args.resume = True
    if args.fixed_weights is not None:
        # Fixed W_long implies reward-weight VLM off; resolve_vision_mode maps
        # bare --no-vlm to --no-vision unless an only-* ablation is set.
        args.no_vlm = True
        if not (
            bool(getattr(args, "only_signal_vlm_vision", False))
            or bool(getattr(args, "only_lon_vlm_vision", False))
            or bool(getattr(args, "only_lat_vlm_vision", False))
        ):
            args.no_vision = True
    if getattr(args, 'no_top3_mask', False):
        args.top3_mask = False
    # Prefer explicit stage_s/v1; fall back to legacy aliases if user only set those.
    if abs(float(args.stage_s_frac) - 0.2) < 1e-9 and abs(float(args.stage1_frac) - 0.2) > 1e-9:
        args.stage_s_frac = float(args.stage1_frac)
    if abs(float(args.stage_v1_frac) - 0.27) < 1e-9 and abs(float(args.stage2_frac) - 0.27) > 1e-9:
        args.stage_v1_frac = float(args.stage2_frac)
    # Hierarchical rewards no longer use a separate coop channel; keep policy off.
    args.w_coop = 0.0
    args.coop_policy = 'off'
    if bool(getattr(args, 'no_coop', False)) or bool(getattr(args, 'no_residual', False)):
        pass  # deprecated flags accepted but do not alter S→Lon→Lat curriculum
    args.lambda_mode = str(getattr(args, 'lambda_mode', 'fixed')).strip().lower()
    apply_profile(args, sys.argv[1:])
    from baselines.episode_timing import apply_episode_timing
    # step_length may still be default here; train() re-prints after full resolve.
    apply_episode_timing(args, step_length=float(getattr(args, 'step_length', 0.2) or 0.2))
    return args


def _pack_train_checkpoint(
    args,
    agent,
    cav_actor,
    cav_residual_actor,
    signal_actor,
    critic,
    n_signal_actions,
    completed_episodes_count,
    tb_run=None,
    lat_actor=None,
    extra=None,
):
    """Pack a resumable checkpoint. ``completed_episodes_count`` is the next episode index."""
    del cav_residual_actor
    # Never persist API secrets into checkpoints.
    cfg = dict(vars(args))
    if cfg.get("vlm_api_key"):
        cfg["vlm_api_key"] = "***"
    payload = {
        'episode': int(completed_episodes_count),
        'cav_actor': cav_actor.state_dict(),
        'lon_actor': cav_actor.state_dict(),
        'lat_actor': (lat_actor or getattr(agent, 'lat_actor', None)).state_dict()
        if (lat_actor or getattr(agent, 'lat_actor', None)) is not None
        else None,
        'signal_actor': signal_actor.state_dict(),
        'critic': critic.state_dict(),
        'cav_optimizer': agent.lon_optimizer.state_dict() if agent.lon_optimizer else None,
        'lon_optimizer': agent.lon_optimizer.state_dict() if agent.lon_optimizer else None,
        'lat_optimizer': agent.lat_optimizer.state_dict() if agent.lat_optimizer else None,
        'signal_optimizer': agent.signal_optimizer.state_dict() if agent.signal_optimizer else None,
        'critic_optimizer': agent.critic_optimizer.state_dict(),
        'config': cfg,
        'n_signal_actions': int(n_signal_actions),
        'training_stage': agent.training_stage,
        'ret_rms': {
            'mean': float(getattr(agent, '_ret_rms_mean', 0.0)),
            'var': float(getattr(agent, '_ret_rms_var', 1.0)),
            'count': float(getattr(agent, '_ret_rms_count', 1e-4)),
        },
        'sig_ret_rms': {
            'mean': float(getattr(agent, '_sig_ret_rms_mean', 0.0)),
            'var': float(getattr(agent, '_sig_ret_rms_var', 1.0)),
            'count': float(getattr(agent, '_sig_ret_rms_count', 1e-4)),
        },
    }
    name = str(tb_run or '').strip()
    if name:
        payload['tb_run'] = name
    if extra:
        payload.update(extra)
    return payload


def _collect_vlm_snapshot(parallel_envs):
    try:
        snap = parallel_envs.get_vlm_weight_snapshot() or {}
    except Exception:
        return {}
    out = {}
    for k in ("W_sig", "W_lat", "W_long"):
        v = snap.get(k)
        if v:
            out[k] = [float(x) for x in v]
    return out

def _restore_vlm_snapshot(parallel_envs, ckpt):
    vw = (ckpt.get("vlm_weights") or {}) if isinstance(ckpt, dict) else {}
    meta = (ckpt.get("best_meta") or {}) if isinstance(ckpt, dict) else {}
    kwargs = {}
    for k in ("W_sig", "W_lat", "W_long"):
        v = vw.get(k, meta.get(k))
        if v:
            kwargs[k] = v
    if kwargs and hasattr(parallel_envs, "apply_macro_weights"):
        try:
            parallel_envs.apply_macro_weights(**kwargs)
            print(f"[resume] restored VLM weights {sorted(kwargs)}", flush=True)
        except Exception as exc:
            print(f"[Warn] restore VLM weights failed: {exc}", flush=True)

# Per-stage actor LR floor after VLM soft-start (relative to actor_lr).
# Lon/Lat lock the peak with a lower floor; Joint polish uses ~0.30 (no invert).
_STAGE_LR_FLOOR = {
    "S": 0.30,
    "Lon": 0.25,
    "JointLonSig": 0.30,
    "Lat": 0.25,
    "JointAll": 0.30,
}
_BEST_STAGE_FILENAMES = {
    "S": "best_stage_s.pt",
    "Lon": "best_stage_lon.pt",
    "JointLonSig": "best_joint_lon_sig.pt",
    "Lat": "best_stage_lat.pt",
    "JointAll": "best_joint_all.pt",
}
_JOINT_ENTRY_FILENAMES = {
    "JointLonSig": "pre_joint_lon_sig.pt",
    "JointAll": "pre_joint_all.pt",
}
# KPI gate for joint tails: compare to *late prior-stage mean*, not peak best.
# Calibrated for per-episode SUMO seeds (5-ep roll score std can be ~3+ points).
_JOINT_KPI_WINDOW = 8
_JOINT_SCORE_DROP = 2.50
_JOINT_HARD_DROP = 4.50
_JOINT_GRACE_EPS = 15
_JOINT_BASELINE_TAIL = 30
_JOINT_SAFE_ABORT_COUNT = 3  # need ≥3 collision-spike eps in the window
_CURRICULUM_ORDER = ("S", "Lon", "JointLonSig", "Lat", "JointAll")
# Formal Best gate on rolling-window *physical collisions* (teleports excluded).
# Stage-S stays strict 0; CAV stages allow a small mean so formal best_*.pt
# can be established under residual collision noise.
_STAGE_GATE_MAX_COLLISIONS = {
    "S": 0.0,
    "Lon": 0.4,
    "JointLonSig": 0.4,
    "Lat": 0.4,
    "JointAll": 0.4,
}


def _carve_joint_tail(main_n, joint_n=None, tail_frac=None, min_main=8):
    """Split a Lon/Lat block into (main, joint).

    Prefer absolute ``joint_n`` when >0; else carve ``tail_frac`` of the block.
    Always keep at least ``min_main`` episodes in the pure main stage.
    """
    main_n = max(0, int(main_n))
    if main_n <= 0:
        return 0, 0
    max_joint = max(0, main_n - int(min_main))
    j_abs = None
    if joint_n is not None:
        try:
            j_abs = int(joint_n)
        except (TypeError, ValueError):
            j_abs = None
    if j_abs is not None and j_abs > 0:
        joint = min(max(0, j_abs), max_joint)
        return main_n - joint, joint
    try:
        frac = float(tail_frac or 0.0)
    except (TypeError, ValueError):
        frac = 0.0
    if frac <= 0.0:
        return main_n, 0
    frac = min(0.95, max(0.0, frac))
    joint = min(int(round(main_n * frac)), max_joint)
    return main_n - joint, joint


def _resolve_stage_schedule(args):
    """Dynamic stage lengths/starts (S→Lon→JointLonSig→Lat→JointAll)."""
    if bool(getattr(args, "use_absolute_stage_schedule", False)):
        s_n, lon_n, lat_n = _resolve_stage_episodes(args)
    else:
        total = max(1, int(getattr(args, "episodes", 1) or 1))
        s_frac = float(getattr(args, "stage_s_frac", 0.0) or 0.0)
        lon_frac = float(
            getattr(args, "stage_lon_frac", None)
            or getattr(args, "stage_l1_frac", 0.0) or 0.0
        )
        lat_frac = float(
            getattr(args, "stage_lat_frac", None)
            or getattr(args, "stage_l2_frac", 0.0) or 0.0
        )
        s_n = max(0, int(round(s_frac * total)))
        lon_n = max(0, int(round(lon_frac * total)))
        if lat_frac > 0.0:
            lat_n = max(0, int(round(lat_frac * total)))
        else:
            lat_n = max(0, total - s_n - lon_n)
    # Absolute joint lengths preferred (full: Lon200+JLS150, Lat300+JA150).
    jls_eps = getattr(args, "joint_lon_sig_episodes", None)
    ja_eps = getattr(args, "joint_all_episodes", None)
    jls_frac = float(getattr(args, "joint_lon_sig_tail_frac", 0.0) or 0.0)
    ja_frac = float(getattr(args, "joint_all_tail_frac", 0.0) or 0.0)
    lon_main, jls_n = _carve_joint_tail(
        lon_n, joint_n=jls_eps, tail_frac=jls_frac,
        min_main=(1 if bool(getattr(args, "smoke", False)) else 8),
    )
    lat_main, ja_n = _carve_joint_tail(
        lat_n, joint_n=ja_eps, tail_frac=ja_frac,
        min_main=(1 if bool(getattr(args, "smoke", False)) else 8),
    )
    lengths = {
        "S": s_n,
        "Lon": lon_main,
        "JointLonSig": jls_n,
        "Lat": lat_main,
        "JointAll": ja_n,
    }
    starts = {}
    cursor = 0
    for st in _CURRICULUM_ORDER:
        starts[st] = cursor
        cursor += int(lengths[st])
    return lengths, starts


def _resolve_stage_episodes(args):
    """Per-stage absolute episode counts: (S, Lon, Lat).

    New attribute names ``stage_lon_episodes`` / ``stage_lat_episodes`` are
    preferred; legacy ``stage_l1_episodes`` / ``stage_l2_episodes`` (old slots
    2/3) are accepted as fallbacks so older configs still load.
    Joint tails are carved later in ``_resolve_stage_schedule``.
    """
    s_n = max(0, int(getattr(args, "stage_s_episodes", 0) or 0))
    lon_n = max(0, int(
        getattr(args, "stage_lon_episodes", 0)
        or getattr(args, "stage_l1_episodes", 0) or 0))
    lat_n = max(0, int(
        getattr(args, "stage_lat_episodes", 0)
        or getattr(args, "stage_l2_episodes", 0) or 0))
    return s_n, lon_n, lat_n


def _stage_at_episode(episode, lengths, starts):
    """Return (stage, stage_episode, stage_len) for a global episode index."""
    episode = int(episode)
    for stage in _CURRICULUM_ORDER:
        start = int(starts.get(stage, 0))
        length = int(lengths.get(stage, 0))
        if length <= 0:
            continue
        if episode < start + length:
            return stage, episode - start, length
    # Past the last non-empty stage: clamp to the last non-empty block.
    for stage in reversed(_CURRICULUM_ORDER):
        length = int(lengths.get(stage, 0))
        if length > 0:
            start = int(starts.get(stage, 0))
            return stage, max(0, length - 1), length
    return "S", 0, 1


def _vlm_soft_start_episodes(args, stage):
    """Soft-start length for *this* stage from resolved warmup table (no hardcodes)."""
    by_stage = getattr(args, "vlm_warmup_by_stage", None) or {}
    if isinstance(by_stage, dict) and stage in by_stage:
        return max(0, int(by_stage[stage]))
    n = getattr(args, "vlm_warmup_episodes", None)
    if n is not None:
        return max(0, int(n))
    return 0


_LR_TRANSITION_EPS = 15
# Production entropy anneal after LR hold (DIAG_* can override). Floor 1.0 = off.
_DIAG_ENTROPY_HOLD = None
_DIAG_ENTROPY_FLOOR = 0.35
# Stage-S keeps a high entropy floor so categorical signal logits do not
# collapse before Best-S KPI selection; Lon/Lat/Joint stay 0.35.
_STAGE_ENTROPY_FLOOR = {
    "S": 0.25,
    "Lon": 0.35,
    "JointLonSig": 0.35,
    "Lat": 0.35,
    "JointAll": 0.35,
}
# 3-leg nets (3 greens) — slightly higher Stage-S floor than 4/5-leg.
_STAGE_S_ENTROPY_FLOOR_3LEG = 0.30
# Hold full entropy_coef for first 80 eps of Stage-S before annealing to floor.
_STAGE_S_ENTROPY_HOLD_EPISODES = 80


def _apply_diag_train_overrides_from_env():
    """Apply DIAG_* / GRID_FORCE_CURRICULUM knobs (diagnostics only)."""
    global _LR_TRANSITION_EPS, _DIAG_ENTROPY_HOLD, _DIAG_ENTROPY_FLOOR
    hold_extra = str(os.environ.get("DIAG_LR_HOLD_EXTRA", "") or "").strip()
    if hold_extra:
        try:
            _LR_TRANSITION_EPS = max(0, int(hold_extra))
            print(f"[diag] LR hold extra → {_LR_TRANSITION_EPS}", flush=True)
        except (TypeError, ValueError):
            pass
    floors = str(os.environ.get("DIAG_LR_FLOOR", "") or "").strip()
    if floors:
        # e.g. Lon:0.32,Lat:0.32,JointLonSig:0.40,JointAll:0.40
        for part in floors.split(","):
            part = part.strip()
            if not part or ":" not in part:
                continue
            key, raw = part.split(":", 1)
            key = key.strip()
            try:
                val = float(raw.strip())
            except (TypeError, ValueError):
                continue
            if key in _STAGE_LR_FLOOR and 0.05 <= val <= 1.0:
                _STAGE_LR_FLOOR[key] = float(val)
        print(f"[diag] LR floors → {_STAGE_LR_FLOOR}", flush=True)
    ent_floor = str(os.environ.get("DIAG_ENTROPY_FLOOR", "") or "").strip()
    if ent_floor:
        try:
            _DIAG_ENTROPY_FLOOR = float(ent_floor)
        except (TypeError, ValueError):
            _DIAG_ENTROPY_FLOOR = 1.0
        _DIAG_ENTROPY_FLOOR = min(1.0, max(0.05, float(_DIAG_ENTROPY_FLOOR)))
        for _k in list(_STAGE_ENTROPY_FLOOR.keys()):
            _STAGE_ENTROPY_FLOOR[_k] = float(_DIAG_ENTROPY_FLOOR)
    ent_hold = str(os.environ.get("DIAG_ENTROPY_HOLD", "") or "").strip()
    if ent_hold:
        try:
            _DIAG_ENTROPY_HOLD = max(0, int(ent_hold))
        except (TypeError, ValueError):
            _DIAG_ENTROPY_HOLD = None
    if _DIAG_ENTROPY_FLOOR < 1.0 - 1e-9:
        print(
            f"[diag] entropy anneal hold={_DIAG_ENTROPY_HOLD} "
            f"floor={_DIAG_ENTROPY_FLOOR} stage_floors={_STAGE_ENTROPY_FLOOR}",
            flush=True,
        )


def _stage_lr_hold_episodes(stage, soft_start=None):
    """Hold = soft-start + 15. Defaults follow VLM_WARMUP_BY_STAGE."""
    if soft_start is None:
        from baselines.episode_timing import VLM_WARMUP_BY_STAGE

        soft_start = int(VLM_WARMUP_BY_STAGE.get(str(stage), 10))
    return max(0, int(soft_start)) + int(_LR_TRANSITION_EPS)


def _stage_anneal_length(stage, stage_len, quick=False):
    """Effective length for LR/entropy anneal.

    JointLonSig / JointAll anneal over profile caps (Full 60/75, Quick 30/30),
    then hold the floor for remaining joint episodes.
    """
    length = max(1, int(stage_len))
    st = str(stage)
    if st == "JointLonSig":
        try:
            from baselines.episode_timing import (
                FULL_JOINT_LON_SIG_ANNEAL_EPISODES,
                QUICK_JOINT_LON_SIG_ANNEAL_EPISODES,
            )

            anneal_cap = max(
                1,
                int(
                    QUICK_JOINT_LON_SIG_ANNEAL_EPISODES
                    if quick
                    else FULL_JOINT_LON_SIG_ANNEAL_EPISODES
                ),
            )
        except Exception:
            anneal_cap = 30 if quick else 60
        return max(1, min(length, anneal_cap))
    if st == "JointAll":
        try:
            from baselines.episode_timing import (
                FULL_JOINT_ALL_ANNEAL_EPISODES,
                QUICK_JOINT_ALL_ANNEAL_EPISODES,
            )

            anneal_cap = max(
                1,
                int(
                    QUICK_JOINT_ALL_ANNEAL_EPISODES
                    if quick
                    else FULL_JOINT_ALL_ANNEAL_EPISODES
                ),
            )
        except Exception:
            anneal_cap = 30 if quick else 75
        return max(1, min(length, anneal_cap))
    return length


def _stage_actor_lr_scale(stage, stage_episode, stage_len, soft_start=None, quick=False):
    """1.0 through soft-start+15, then hit floor by the anneal-length episode."""
    floor = float(_STAGE_LR_FLOOR.get(str(stage), 0.45))
    length = _stage_anneal_length(stage, stage_len, quick=quick)
    hold = _stage_lr_hold_episodes(stage, soft_start)
    ep = max(0, int(stage_episode))
    # Past the anneal window: stay on floor.
    if ep >= length:
        return floor
    if ep < hold or hold >= length - 1:
        return 1.0
    denom = max(1, (length - 1) - hold)
    progress = float(ep - hold) / float(denom)
    progress = min(1.0, max(0.0, progress))
    return 1.0 - (1.0 - floor) * progress


def _stage_entropy_coef_scale(stage, stage_episode, stage_len, soft_start=None, quick=False):
    """Stage-aware post-hold linear anneal of entropy_coef (Stage-S → high floor)."""
    st = str(stage or "S")
    floor = float(_STAGE_ENTROPY_FLOOR.get(st, _DIAG_ENTROPY_FLOOR))
    if floor >= 1.0 - 1e-9:
        return 1.0
    length = _stage_anneal_length(st, stage_len, quick=quick)
    ep = max(0, int(stage_episode))
    if _DIAG_ENTROPY_HOLD is None:
        hold = _stage_lr_hold_episodes(st, soft_start)
        if st == "S":
            hold = max(hold, int(_STAGE_S_ENTROPY_HOLD_EPISODES))
    else:
        hold = max(0, int(_DIAG_ENTROPY_HOLD))
    if ep >= length:
        return floor
    if ep < hold or hold >= length - 1:
        return 1.0
    denom = max(1, (length - 1) - hold)
    progress = float(ep - hold) / float(denom)
    progress = min(1.0, max(0.0, progress))
    return 1.0 - (1.0 - floor) * progress


def _best_track_enabled(stage_episode, stage_len, soft_start, stage="S"):
    """Track from soft_start-5; Lon/Lat also require action-blend β≥1.

    Stage-S: whole stage after soft_start-5 by KPI (collisions then score).
    Joint tails track from episode 0 (β already 1, no soft-start).
    """
    length = max(0, int(stage_len))
    if length <= 0:
        return False
    ep = int(stage_episode)
    st = str(stage or "S")
    if st in ("JointLonSig", "JointAll"):
        return True
    if ep < max(0, int(soft_start) - 5):
        return False
    if st in ("Lon", "Lat"):
        from baselines.episode_timing import action_blend_beta

        if float(action_blend_beta(ep, soft_start, stage=st)) < 1.0 - 1e-6:
            return False
    return True


def _archive_best_stage_checkpoint(checkpoint_dir, stage, archive_name):
    """Rename best_stage_*.pt aside (keep for forensics; do not delete)."""
    fname = _BEST_STAGE_FILENAMES.get(str(stage))
    if not fname:
        return False
    src = os.path.join(checkpoint_dir, fname)
    if not os.path.isfile(src):
        return False
    dst = os.path.join(checkpoint_dir, str(archive_name))
    try:
        if os.path.isfile(dst):
            stamp = time.strftime("%Y%m%d_%H%M%S")
            dst = os.path.join(
                checkpoint_dir, f"{archive_name}.{stamp}"
            )
        os.replace(src, dst)
        print(
            f"[best] archived {fname} → {os.path.basename(dst)}",
            flush=True,
        )
        return True
    except OSError as exc:
        print(
            f"[Warn] archive {fname} failed ({type(exc).__name__}: {exc})",
            flush=True,
        )
        return False


def _best_score(avg_speed, avg_queue_length):
    return float(avg_speed) - 0.15 * float(avg_queue_length)


def _is_better_stage_episode(
    collisions, score, best_collisions, best_score, tol=0.5
):
    """Collision-gated selection; within ``tol``, higher score wins."""
    if best_collisions is None:
        return True
    c = float(collisions)
    bc = float(best_collisions)
    if abs(c - bc) <= float(tol):
        return float(score) > float(
            best_score if best_score is not None else float("-inf")
        )
    return c < bc


# Rolling-window Best-ckpt selector (avoids single-episode SUMO-seed lottery).
_BEST_ROLL_WINDOW = 5
_BEST_ROLL_MIN = 3
_BEST_SELECTOR_NAME = "roll5_phys_coll_gate"
_SUMO_SEED_STRIDE = 10000
# v4 episode KPIs forwarded by marl_env (infos['__all__']) and logged to TB.
_V4_EXTRA_KPI_KEYS = (
    "uncensored_avg_travel_time",
    "avg_time_in_system",
    "insertion_backlog",
    "od_rewrites",
) + tuple(V524_KPI_KEYS) + tuple(V6_AUTH_KPI_KEYS)


def _empty_best_tracker(**extra):
    """Fresh per-stage best tracker (rolling windows start empty)."""
    tracker = {
        "collisions": None,
        "score": None,
        "episode": None,
        "tail_window": False,
        "kpi_tracked": False,
        "recent_scores": [],
        "recent_colls": [],
        "legacy_single_ep": False,
        "safety_gate_passed": False,
        # Score-only archive for non-gated windows (independent of formal floor).
        "ungated_score": None,
        "ungated_collisions": None,
        "ungated_episode": None,
    }
    tracker.update(extra)
    return tracker


def _sumo_per_episode_seed_enabled():
    """Default ON. Set SUMO_PER_EPISODE_SEED=0 to lock run-level SUMO seed."""
    return str(os.environ.get("SUMO_PER_EPISODE_SEED", "1")).strip().lower() not in (
        "0",
        "false",
        "no",
        "off",
    )


def _sumo_reset_seeds(base_seed, episode, num_envs):
    """Per-env SUMO seeds for one training episode reset.

    Default: ``base_seed * 10000 + episode * num_envs + i`` so train seeds
    7..11 never share the overlapping ``seed+episode`` chain. With
    ``SUMO_PER_EPISODE_SEED=0``: ``base_seed + i`` (debug / SNR ablation).
    """
    base = int(base_seed)
    ep = int(episode)
    n = max(1, int(num_envs))
    if _sumo_per_episode_seed_enabled():
        stride = int(_SUMO_SEED_STRIDE)
        return [base * stride + ep * n + i for i in range(n)]
    return [base + i for i in range(n)]


def _append_best_window(
    tracker,
    raw_score,
    ep_collisions,
    window=None,
    min_len=None,
    max_window_coll=0.0,
):
    """Append one episode KPI; return rolling snapshot (ready / gate / means)."""
    win = max(1, int(window if window is not None else _BEST_ROLL_WINDOW))
    min_n = max(1, int(min_len if min_len is not None else _BEST_ROLL_MIN))
    thr = max(0.0, float(max_window_coll or 0.0))
    scores = tracker.setdefault("recent_scores", [])
    colls = tracker.setdefault("recent_colls", [])
    scores.append(float(raw_score))
    colls.append(float(ep_collisions))
    while len(scores) > win:
        scores.pop(0)
        colls.pop(0)
    n = len(scores)
    ready = n >= min_n
    window_score = float(np.mean(scores)) if n else None
    window_coll = float(np.mean(colls)) if n else None
    ep_coll = float(colls[-1]) if n else None
    # Formal best: rolling mean and last ep within the physical-collision budget.
    ep_cap = max(thr, float(np.ceil(thr))) if thr > 0.0 else 0.0
    gated_ok = bool(
        ready
        and window_coll is not None
        and window_coll <= thr + 1e-6
        and ep_coll is not None
        and ep_coll <= ep_cap + 1e-6
    )
    return {
        "ready": ready,
        "window_size": n,
        "window_score": window_score,
        "window_coll": window_coll,
        "gated_ok": gated_ok,
        "ep_collisions": ep_coll,
        "raw_score": float(raw_score),
    }


def _load_best_stage_meta(checkpoint_dir, device, start_episode=0, stage_s_len=0):
    """Restore in-memory best trackers from existing best_stage_*.pt files.

    Resume safeguards:
      - any best whose ``episode`` is past ``start_episode`` is a leftover
        "future" snapshot → archive and clear tracker.
      - when ``stage_s_len>0`` and resume is at/after the Stage-S teacher-β=0
        tail, a pre-tail ``best_stage_s.pt`` is archived (same policy as the
        live loop). Callers must pass ``stage_s_len=0`` for no_vlm / no teacher
        so Best-S is not wiped on mid-run ``--resume``.
      Stage-S Best is KPI-tracked for the whole stage (after soft-start); legacy
      ``tail_window`` is accepted but no longer required.
      Rolling windows are never restored (empty on resume). Legacy single-ep
      metas clear the comparison baseline so roll scores are not raced against
      an old lottery peak.
      Also restores ``ungated_score`` from ``temp_ungated_best_stage_*.pt`` so a
      mid-run ``--resume`` cannot overwrite a better ungated archive with a
      worse window after the in-memory baseline resets to None.
    """
    trackers = {st: _empty_best_tracker() for st in _CURRICULUM_ORDER}
    try:
        start_ep = max(0, int(start_episode or 0))
    except (TypeError, ValueError, OverflowError):
        start_ep = 0
    for stage, fname in _BEST_STAGE_FILENAMES.items():
        path = os.path.join(checkpoint_dir, fname)
        if not os.path.isfile(path):
            continue
        try:
            ckpt = torch_load(path, device)
            meta = ckpt.get("best_meta") or {}
            try:
                meta_ep = int(meta.get("episode")) if meta.get("episode") is not None else None
            except (TypeError, ValueError, OverflowError):
                meta_ep = None
            future = meta_ep is not None and meta_ep > start_ep
            if future:
                _archive_best_stage_checkpoint(
                    checkpoint_dir,
                    stage,
                    f"superseded_best_stage_{str(stage).lower()}.pt",
                )
                print(
                    f"[best] resume invalidated {fname} (future_episode); "
                    f"tracker cleared",
                    flush=True,
                )
                continue
            s_len = max(0, int(stage_s_len or 0))
            s_tail_start = _stage_s_tail_start(s_len) if s_len > 0 else 0
            if (
                stage == "S"
                and s_tail_start > 0
                and start_ep >= s_tail_start
                and (not bool(meta.get("tail_window", False)))
                and (meta_ep is not None and meta_ep <= s_tail_start)
            ):
                _archive_best_stage_checkpoint(
                    checkpoint_dir,
                    "S",
                    "pre_tail_best_stage_s.pt",
                )
                print(
                    f"[best] resume at ep={start_ep} >= Stage-S tail_start={s_tail_start}: "
                    f"archived pre-tail best_stage_s.pt → pre_tail_best_stage_s.pt",
                    flush=True,
                )
                continue
            is_roll = (
                meta.get("roll_score") is not None
                or str(meta.get("selector") or "") == _BEST_SELECTOR_NAME
            )
            restored = _empty_best_tracker(
                episode=meta.get("episode"),
                tail_window=bool(meta.get("tail_window", False)),
                kpi_tracked=bool(
                    meta.get("kpi_tracked", meta.get("tail_window", False))
                ),
                signal_entropy=meta.get("signal_entropy"),
                teacher_beta=meta.get("teacher_beta"),
                legacy_single_ep=not is_roll,
            )
            if is_roll:
                restored["collisions"] = meta.get("collisions")
                restored["score"] = meta.get("score")
                restored["safety_gate_passed"] = bool(
                    meta.get("safety_gate_passed", False)
                )
            else:
                # Keep file on disk; re-baseline comparisons with the rolling window.
                print(
                    f"[best] resume: {fname} is legacy single-ep best; "
                    f"rolling window will re-baseline (file kept until new gated best)",
                    flush=True,
                )
            trackers[stage] = restored
        except Exception as exc:
            print(f"[Warn] could not read {fname} meta ({type(exc).__name__}: {exc})")
    # Restore ungated score floors independently of formal best_*.pt.
    for stage in _CURRICULUM_ORDER:
        u_path = os.path.join(
            checkpoint_dir, _temp_ungated_best_filename(stage)
        )
        if not os.path.isfile(u_path):
            continue
        try:
            u_ckpt = torch_load(u_path, device)
            u_meta = u_ckpt.get("best_meta") or {}
            u_ep = u_meta.get("episode")
            if u_ep is None:
                continue
            try:
                u_ep_i = int(u_ep)
            except (TypeError, ValueError, OverflowError):
                continue
            if u_ep_i > start_ep:
                sup_u = os.path.join(
                    checkpoint_dir,
                    f"superseded_{os.path.basename(u_path)}",
                )
                try:
                    if os.path.isfile(sup_u):
                        sup_u = f"{sup_u}.{time.strftime('%Y%m%d_%H%M%S')}"
                    os.replace(u_path, sup_u)
                    print(
                        f"[best] resume archived future {os.path.basename(u_path)} "
                        f"(ep={u_ep_i} > {start_ep}) → {os.path.basename(sup_u)}",
                        flush=True,
                    )
                except OSError:
                    pass
                continue
            trackers[stage]["ungated_score"] = u_meta.get("score")
            trackers[stage]["ungated_collisions"] = u_meta.get("collisions")
            trackers[stage]["ungated_episode"] = u_ep_i
            print(
                f"[best] resume: restored ungated floor from "
                f"{os.path.basename(u_path)} "
                f"(ep={u_ep_i}, score={u_meta.get('score')})",
                flush=True,
            )
        except Exception as exc:
            print(
                f"[Warn] could not read {_temp_ungated_best_filename(stage)} "
                f"({type(exc).__name__}: {exc})",
                flush=True,
            )
    return trackers


def _preferred_joint_source(checkpoint_dir, *candidates):
    """First existing checkpoint among preferred filenames."""
    for name in candidates:
        path = os.path.join(checkpoint_dir, name)
        if os.path.isfile(path):
            return path
    return None


def _preferred_checkpoint_by_score(checkpoint_dir, device, *candidates):
    """Pick the highest-scoring existing checkpoint among candidate filenames.

    Preference order:
      1) Among files with ``best_meta.safety_gate_passed`` truthy, max score
      2) Else among all readable candidates, max score
      3) Else first existing file (filename order) if loads fail
    """
    existing = []
    for name in candidates:
        path = os.path.join(checkpoint_dir, name)
        if os.path.isfile(path):
            existing.append(path)
    if not existing:
        return None, None

    gated = []
    ungated = []
    for path in existing:
        try:
            ck = torch_load(path, device)
        except Exception as exc:
            print(
                f"[curriculum] skip unreadable ckpt {os.path.basename(path)} "
                f"({type(exc).__name__}: {exc})",
                flush=True,
            )
            continue
        if not isinstance(ck, dict):
            continue
        meta = ck.get("best_meta") or {}
        try:
            score = float(meta.get("score", float("-inf")))
        except (TypeError, ValueError, OverflowError):
            score = float("-inf")
        if not np.isfinite(score):
            score = float("-inf")
        entry = (score, path, ck)
        if bool(meta.get("safety_gate_passed", False)):
            gated.append(entry)
        else:
            ungated.append(entry)

    pool = gated if gated else ungated
    if not pool:
        return existing[0], None
    pool.sort(key=lambda t: t[0], reverse=True)
    best_score, best_path, best_ck = pool[0]
    return best_path, best_ck


def _preferred_stage_s_for_lon(checkpoint_dir, device, *candidates):
    """S→Lon / joint-anchor prefer β≈0 low-entropy Best-S over Teacher pre_tail.

    Within score tolerance, refuse a higher-entropy Teacher-smoothed checkpoint
    (e.g. ``pre_tail_best_stage_s.pt``) when a β=0 tail Best exists.
    """
    existing = []
    for name in candidates:
        path = os.path.join(checkpoint_dir, name)
        if os.path.isfile(path):
            existing.append(path)
    if not existing:
        return None, None

    loaded = []
    for path in existing:
        try:
            ck = torch_load(path, device)
        except Exception as exc:
            print(
                f"[curriculum] skip unreadable ckpt {os.path.basename(path)} "
                f"({type(exc).__name__}: {exc})",
                flush=True,
            )
            continue
        if not isinstance(ck, dict):
            continue
        meta = ck.get("best_meta") or {}
        try:
            score = float(meta.get("score", float("-inf")))
        except (TypeError, ValueError, OverflowError):
            score = float("-inf")
        if not np.isfinite(score):
            score = float("-inf")
        try:
            beta = float(meta.get("teacher_beta")) if meta.get("teacher_beta") is not None else 1.0
        except (TypeError, ValueError, OverflowError):
            beta = 1.0
        try:
            ent = float(meta.get("signal_entropy")) if meta.get("signal_entropy") is not None else 9.0
        except (TypeError, ValueError, OverflowError):
            ent = 9.0
        if not np.isfinite(ent):
            ent = 9.0
        loaded.append((score, beta, ent, path, ck))

    if not loaded:
        return existing[0], None

    # Prefer β≈0 candidates; among them pick lowest entropy, then best score.
    beta0 = [e for e in loaded if float(e[1]) <= 1e-6]
    pool = beta0 if beta0 else loaded
    # Reject high-entropy Teacher ckpts that only beat β0 within a thin score tol.
    if beta0:
        best_b0 = max(beta0, key=lambda e: e[0])
        filtered = []
        for e in pool:
            if e[2] > best_b0[2] + 0.05 and e[0] <= best_b0[0] + 0.25:
                # Higher entropy and not meaningfully better score → skip.
                continue
            filtered.append(e)
        if filtered:
            pool = filtered
    # Sort: lower entropy first among near-β0, then higher score.
    pool.sort(key=lambda e: (0 if e[1] <= 1e-6 else 1, e[2], -e[0]))
    _score, _beta, _ent, best_path, best_ck = pool[0]
    return best_path, best_ck


def _apply_vlm_from_meta(parallel_envs, meta):
    if parallel_envs is None or not hasattr(parallel_envs, "apply_macro_weights"):
        return
    kwargs = {}
    for key in ("W_sig", "W_long", "W_lat"):
        val = (meta or {}).get(key)
        if val is not None:
            kwargs[key] = val
    if kwargs:
        parallel_envs.apply_macro_weights(**kwargs)


def _restore_critic_and_ret_rms(agent, critic, ckpt):
    """Restore critic + return-normalizer with a stage-best / entry snapshot."""
    restored = []
    if critic is not None and isinstance(ckpt, dict) and ckpt.get("critic") is not None:
        try:
            critic.load_state_dict(ckpt["critic"])
            restored.append("critic")
        except Exception as exc:
            print(f"[Warn] restore critic failed: {exc}", flush=True)
    if agent is None or not isinstance(ckpt, dict):
        return restored
    rms = ckpt.get("ret_rms")
    if isinstance(rms, dict):
        try:
            agent._ret_rms_mean = float(rms.get("mean", 0.0))
            agent._ret_rms_var = float(rms.get("var", 1.0))
            agent._ret_rms_count = float(rms.get("count", 1e-4))
            restored.append("ret_rms")
        except (TypeError, ValueError, OverflowError) as exc:
            print(f"[Warn] restore ret_rms failed: {exc}", flush=True)
    sig_rms = ckpt.get("sig_ret_rms")
    if isinstance(sig_rms, dict):
        try:
            agent._sig_ret_rms_mean = float(sig_rms.get("mean", 0.0))
            agent._sig_ret_rms_var = float(sig_rms.get("var", 1.0))
            agent._sig_ret_rms_count = float(sig_rms.get("count", 1e-4))
            restored.append("sig_ret_rms")
        except (TypeError, ValueError, OverflowError) as exc:
            print(f"[Warn] restore sig_ret_rms failed: {exc}", flush=True)
    return restored


def _temp_ungated_best_filename(stage):
    """Filename for safety-ungated best snapshots (never a formal best_* name)."""
    return f"temp_ungated_best_stage_{str(stage).lower()}.pt"


def _joint_seed_filename(joint_stage, safety_gate_passed):
    """Formal best_joint_*.pt only when the entry source passed the safety gate."""
    if bool(safety_gate_passed):
        return _BEST_STAGE_FILENAMES.get(str(joint_stage))
    return _temp_ungated_best_filename(joint_stage)


def _seed_joint_best_from_entry(
    joint_stage,
    source_stage,
    checkpoint_dir,
    source_ckpt,
    best_trackers,
):
    """Seed joint selection floor from the entry stage checkpoint.

    Gated entry (``safety_gate_passed=True``) → formal ``best_joint_*.pt``.
    Ungated / temp entry → ``temp_ungated_best_stage_joint*.pt`` only (never
    occupy the formal joint best name). Stale formal joint bests are archived.
    """
    if not isinstance(source_ckpt, dict):
        return False
    if str(joint_stage) not in _BEST_STAGE_FILENAMES:
        return False
    meta = dict(source_ckpt.get("best_meta") or {})
    # Missing flag → treat as ungated (defensive; do not default True).
    gated = bool(meta.get("safety_gate_passed", False))
    fname = _joint_seed_filename(joint_stage, gated)
    if not fname:
        return False
    meta["stage"] = str(joint_stage)
    meta["seeded_from"] = str(source_stage)
    meta["seeded_entry"] = True
    meta["safety_gate_passed"] = bool(gated)
    payload = dict(source_ckpt)
    payload["best_meta"] = meta
    # Keep vlm_weights aligned with best_meta when present.
    vw = payload.get("vlm_weights")
    if not isinstance(vw, dict):
        vw = {}
        for key in ("W_sig", "W_long", "W_lat"):
            if meta.get(key) is not None:
                vw[key] = list(meta[key])
        if vw:
            payload["vlm_weights"] = vw
    if not gated:
        # Avoid Lat/next stage preferring a leftover formal joint best.
        formal = _BEST_STAGE_FILENAMES.get(str(joint_stage))
        if formal and os.path.isfile(os.path.join(checkpoint_dir, formal)):
            _archive_best_stage_checkpoint(
                checkpoint_dir,
                joint_stage,
                f"ungated_entry_archived_{formal}",
            )
    out_path = os.path.join(checkpoint_dir, fname)
    try:
        _atomic_torch_save(payload, out_path)
    except Exception as exc:
        print(f"[Warn] seed {fname} failed: {exc}", flush=True)
        return False
    if isinstance(best_trackers, dict):
        if gated:
            best_trackers[joint_stage] = _empty_best_tracker(
                collisions=meta.get("collisions"),
                score=meta.get("score"),
                episode=meta.get("episode"),
                safety_gate_passed=True,
            )
        else:
            # Ungated entry seeds the temp floor only — do not occupy formal
            # score/collisions slots (those are restored from gated best_*.pt).
            best_trackers[joint_stage] = _empty_best_tracker(
                ungated_collisions=meta.get("collisions"),
                ungated_score=meta.get("score"),
                ungated_episode=meta.get("episode"),
                safety_gate_passed=False,
            )
    score = meta.get("score")
    coll = meta.get("collisions")
    kind = "gated floor" if gated else "ungated temp floor"
    print(
        f"[joint] seeded {fname} from {source_stage} entry "
        f"(score={score}, safety={coll}, gate={gated}) as {kind}",
        flush=True,
    )
    return True


def _setup_joint_entry(
    stage,
    checkpoint_dir,
    device,
    agent,
    signal_actor,
    lon_actor,
    lat_actor,
    pack_ckpt_fn,
):
    """Snapshot entry weights, load BC anchors from stage-best checkpoints."""
    entry_name = _JOINT_ENTRY_FILENAMES.get(stage)
    if entry_name:
        entry_path = os.path.join(checkpoint_dir, entry_name)
        try:
            _atomic_torch_save(pack_ckpt_fn(), entry_path)
            print(f"[joint] saved entry snapshot {entry_name}", flush=True)
        except Exception as exc:
            print(f"[Warn] joint entry snapshot failed: {exc}", flush=True)

    agent.joint_abort = False
    agent.clear_policy_anchors()
    if stage == "JointLonSig":
        # Match S→Lon: pick highest-score Stage-S snapshot for the signal BC
        # anchor (pre_tail may beat formal best_stage_s after the teacher tail).
        _, s_ck = _preferred_checkpoint_by_score(
            checkpoint_dir,
            device,
            _BEST_STAGE_FILENAMES["S"],
            "pre_tail_best_stage_s.pt",
            "temp_ungated_best_stage_s.pt",
        )
        _, lon_ck = _preferred_checkpoint_by_score(
            checkpoint_dir,
            device,
            _BEST_STAGE_FILENAMES["Lon"],
            "temp_ungated_best_stage_lon.pt",
        )
        sig_sd = s_ck.get("signal_actor") if isinstance(s_ck, dict) else None
        lon_sd = None
        if isinstance(lon_ck, dict):
            if sig_sd is None:
                sig_sd = lon_ck.get("signal_actor")
            lon_sd = lon_ck.get("lon_actor") or lon_ck.get("cav_actor")
        agent.set_policy_anchors(signal_state=sig_sd, lon_state=lon_sd)
        print(
            f"[joint] JointLonSig anchors: signal={'yes' if sig_sd else 'no'} "
            f"lon={'yes' if lon_sd else 'no'}",
            flush=True,
        )
        return
    if stage == "JointAll":
        # Score-preferential among JointLonSig / Lon / S (formal then ungated).
        _, jls_ck = _preferred_checkpoint_by_score(
            checkpoint_dir,
            device,
            _BEST_STAGE_FILENAMES["JointLonSig"],
            "temp_ungated_best_stage_jointlonsig.pt",
            _BEST_STAGE_FILENAMES["Lon"],
            "temp_ungated_best_stage_lon.pt",
            _BEST_STAGE_FILENAMES["S"],
            "pre_tail_best_stage_s.pt",
            "temp_ungated_best_stage_s.pt",
        )
        _, lat_ck = _preferred_checkpoint_by_score(
            checkpoint_dir,
            device,
            _BEST_STAGE_FILENAMES["Lat"],
            "temp_ungated_best_stage_lat.pt",
        )
        sig_sd = lon_sd = lat_sd = None
        if isinstance(jls_ck, dict):
            sig_sd = jls_ck.get("signal_actor")
            lon_sd = jls_ck.get("lon_actor") or jls_ck.get("cav_actor")
        if isinstance(lat_ck, dict):
            lat_sd = lat_ck.get("lat_actor")
            if sig_sd is None:
                sig_sd = lat_ck.get("signal_actor")
            if lon_sd is None:
                lon_sd = lat_ck.get("lon_actor") or lat_ck.get("cav_actor")
        agent.set_policy_anchors(signal_state=sig_sd, lon_state=lon_sd, lat_state=lat_sd)
        print(
            f"[joint] JointAll anchors: signal={'yes' if sig_sd else 'no'} "
            f"lon={'yes' if lon_sd else 'no'} lat={'yes' if lat_sd else 'no'}",
            flush=True,
        )


def _abort_joint_stage(
    stage,
    checkpoint_dir,
    device,
    agent,
    signal_actor,
    lon_actor,
    lat_actor,
    reason="",
    critic=None,
):
    """Reload pre-joint snapshot and freeze weak heads for the rest of the block."""
    entry_name = _JOINT_ENTRY_FILENAMES.get(stage)
    path = os.path.join(checkpoint_dir, entry_name) if entry_name else ""
    if path and os.path.isfile(path):
        try:
            ckpt = torch_load(path, device)
            if signal_actor is not None and ckpt.get("signal_actor") is not None:
                signal_actor.load_state_dict(ckpt["signal_actor"])
            lon_sd = ckpt.get("lon_actor") or ckpt.get("cav_actor")
            if lon_actor is not None and lon_sd is not None:
                lon_actor.load_state_dict(lon_sd)
            if lat_actor is not None and ckpt.get("lat_actor") is not None:
                lat_actor.load_state_dict(ckpt["lat_actor"])
            extras = _restore_critic_and_ret_rms(agent, critic, ckpt)
            print(
                f"[joint] rollback loaded {entry_name}"
                f"{(' + ' + '+'.join(extras)) if extras else ''}",
                flush=True,
            )
        except Exception as exc:
            print(f"[Warn] joint rollback load failed: {exc}", flush=True)
    agent.joint_abort = True
    agent.clear_policy_anchors()
    agent.set_training_stage(stage)
    print(
        f"[joint] ABORT {stage}: re-froze weak heads"
        f"{'' if not reason else f' ({reason})'}",
        flush=True,
    )


def _refill_stage_kpi_hists(
    metrics_history, stage_lengths, stage_starts, start_episode
):
    """Rebuild Lon/Lat score+coll hist from restored metrics for joint baselines."""
    lon_scores, lon_colls = [], []
    lat_scores, lat_colls = [], []
    speeds = metrics_history.get("avg_speed") or []
    queues = metrics_history.get("avg_queue_length") or []
    colls = metrics_history.get("avg_collisions") or []
    n = min(int(start_episode or 0), len(speeds), len(queues))
    has_coll = len(colls) >= n and n > 0
    for ep in range(n):
        st, _, _ = _stage_at_episode(ep, stage_lengths, stage_starts)
        if st not in ("Lon", "Lat"):
            continue
        try:
            spd = float(np.mean(speeds[ep]))
            q = float(np.mean(queues[ep]))
        except (TypeError, ValueError, OverflowError):
            continue
        score = float(_best_score(spd, q))
        if has_coll:
            try:
                c = float(np.mean(colls[ep]))
            except (TypeError, ValueError, OverflowError):
                c = 0.0
        else:
            c = 0.0
        if st == "Lon":
            lon_scores.append(score)
            lon_colls.append(c)
        else:
            lat_scores.append(score)
            lat_colls.append(c)
    return lon_scores, lon_colls, lat_scores, lat_colls


def _joint_baseline_from_hist(score_hist, best_tracker=None, tail=None):
    """Prefer late prior-stage mean score; fall back to discounted ungated peak."""
    tail = int(_JOINT_BASELINE_TAIL if tail is None else tail)
    hist = [float(x) for x in (score_hist or []) if x is not None and np.isfinite(float(x))]
    if hist:
        window = hist[-max(1, tail):]
        return float(np.mean(window))
    if isinstance(best_tracker, dict):
        peak = best_tracker.get("ungated_score")
        if peak is None:
            peak = best_tracker.get("score")
        if peak is not None and np.isfinite(float(peak)):
            # Discount peak so a lucky best window does not set an unreachable bar.
            return float(peak) - 1.50
    return None


def _joint_kpi_should_abort(
    scores,
    baseline_score,
    collisions_hist,
    baseline_collisions=0.0,
    grace_eps=None,
    min_window=None,
):
    """True when joint KPI regresses hard vs a realistic entry baseline.

    Grace period skips early joint noise. Safety abort needs repeated episodes
    whose physical collisions spike vs prior-stage baseline (relative margin).
    Score abort uses sustained mean drop calibrated for per-ep SUMO seeds.
    """
    if baseline_score is None or not scores:
        return False, ""
    grace = int(_JOINT_GRACE_EPS if grace_eps is None else grace_eps)
    if len(scores) < max(1, grace):
        return False, ""
    win_n = int(_JOINT_KPI_WINDOW if min_window is None else min_window)
    window = scores[-win_n:]
    mean_score = float(np.mean(window))
    recent_coll = collisions_hist[-win_n:] if collisions_hist else []
    base_c = max(0.0, float(baseline_collisions or 0.0))
    coll_thr = max(base_c * 1.35, base_c + 3.0)
    n_bad = sum(1 for c in recent_coll if float(c) > coll_thr + 1e-9)
    if n_bad >= int(_JOINT_SAFE_ABORT_COUNT) and len(recent_coll) >= win_n:
        return True, (
            f"safety collisions > {coll_thr:.1f} in {n_bad}/{len(recent_coll)} recent eps"
        )
    drop = float(baseline_score) - mean_score
    if drop >= _JOINT_HARD_DROP and len(window) >= win_n:
        return True, f"hard score drop {drop:.3f} >= {_JOINT_HARD_DROP}"
    if drop >= _JOINT_SCORE_DROP and len(window) >= win_n:
        return True, f"sustained score drop {drop:.3f}"
    return False, ""


def _rollback_stage_weights(
    prev_stage,
    new_stage,
    checkpoint_dir,
    device,
    signal_actor,
    lon_actor,
    lat_actor,
    parallel_envs=None,
    agent=None,
    critic=None,
    best_trackers=None,
):
    """Force-load previous stage best NN (+ W + critic + ret_rms) before freeze.

    Chain:
      S → Lon : best_stage_s.pt (signal + W_sig)
      Lon → JointLonSig : best_stage_lon.pt (continue lon; signal from Lon/S)
      JointLonSig → Lat : best_joint_lon_sig.pt or best_stage_lon.pt
      Lon → Lat : best_stage_lon.pt (when joint tail disabled)
      Lat → JointAll : best_stage_lat.pt

    Joint entries also seed best_joint_*.pt from the source best so selection
    never starts below the entry peak checkpoint.
    """
    def _extras(ckpt):
        bits = _restore_critic_and_ret_rms(agent, critic, ckpt)
        if agent is not None and hasattr(agent, "reset_actor_optimizer_states"):
            agent.reset_actor_optimizer_states()
        return f"{' + ' + '+'.join(bits) if bits else ''}"

    if prev_stage == "S" and new_stage == "Lon":
        # Prefer β=0 low-entropy Best-S; refuse Teacher-smoothed pre_tail override.
        path, ckpt = _preferred_stage_s_for_lon(
            checkpoint_dir,
            device,
            _BEST_STAGE_FILENAMES["S"],
            "pre_tail_best_stage_s.pt",
            "temp_ungated_best_stage_s.pt",
        )
        if path is None:
            print("[curriculum] S→Lon: no best_stage_s.pt; keep current signal weights")
            return False
        if ckpt is None:
            try:
                ckpt = torch_load(path, device)
            except Exception as exc:
                print(
                    f"[curriculum] S→Lon: failed to load {os.path.basename(path)} "
                    f"({type(exc).__name__}: {exc}); keep current signal weights",
                    flush=True,
                )
                return False
        signal_actor.load_state_dict(ckpt["signal_actor"])
        if ckpt.get("critic") is not None and critic is not None:
            critic.load_state_dict(ckpt["critic"])
        if agent is not None and hasattr(agent, "reset_team_value_head"):
            agent.reset_team_value_head()
        meta = ckpt.get("best_meta") or {}
        _apply_vlm_from_meta(parallel_envs, meta)
        # Keep GNN + signal_head from Best-S, while resetting critic.net & _ret_rms.
        ep = meta.get("episode")
        try:
            sc = float(meta.get("score", float("nan")))
        except (TypeError, ValueError, OverflowError):
            sc = float("nan")
        try:
            ent = float(meta.get("signal_entropy")) if meta.get("signal_entropy") is not None else float("nan")
        except (TypeError, ValueError, OverflowError):
            ent = float("nan")
        try:
            beta = float(meta.get("teacher_beta")) if meta.get("teacher_beta") is not None else float("nan")
        except (TypeError, ValueError, OverflowError):
            beta = float("nan")
        print(
            f"[curriculum] S→Lon: loaded {os.path.basename(path)}"
            f"{' + W_sig' if meta.get('W_sig') is not None else ''}"
            f" (signal only; critic/ret_rms fresh)"
            f" (from ep {ep if ep is not None else '?'}, "
            f"score={sc:.4f}, "
            f"tail={bool(meta.get('tail_window', False))}, "
            f"gated={bool(meta.get('safety_gate_passed', False))}, "
            f"ent={ent:.3f}, beta={beta:.2f}) before sig freeze",
            flush=True,
        )
        return True
    if prev_stage == "Lon" and new_stage == "JointLonSig":
        path, ckpt = _preferred_checkpoint_by_score(
            checkpoint_dir,
            device,
            _BEST_STAGE_FILENAMES["Lon"],
            "temp_ungated_best_stage_lon.pt",
        )
        if path is None:
            print("[curriculum] Lon→JointLonSig: no best_stage_lon.pt; keep weights")
            return False
        if ckpt is None:
            try:
                ckpt = torch_load(path, device)
            except Exception as exc:
                print(
                    f"[curriculum] Lon→JointLonSig: failed to load "
                    f"{os.path.basename(path)} ({type(exc).__name__}: {exc})",
                    flush=True,
                )
                return False
        if ckpt.get("signal_actor") is not None:
            signal_actor.load_state_dict(ckpt["signal_actor"])
        lon_sd = ckpt.get("lon_actor") or ckpt.get("cav_actor")
        if lon_sd is not None:
            lon_actor.load_state_dict(lon_sd)
        meta = ckpt.get("best_meta") or {}
        _apply_vlm_from_meta(parallel_envs, meta)
        extra = _extras(ckpt)
        _seed_joint_best_from_entry(
            "JointLonSig", "Lon", checkpoint_dir, ckpt, best_trackers
        )
        print(
            f"[curriculum] Lon→JointLonSig: loaded {os.path.basename(path)}"
            f"{extra} before weak sig unfreeze",
            flush=True,
        )
        return True
    if prev_stage in ("Lon", "JointLonSig") and new_stage == "Lat":
        path, ckpt = _preferred_checkpoint_by_score(
            checkpoint_dir,
            device,
            _BEST_STAGE_FILENAMES["JointLonSig"],
            _BEST_STAGE_FILENAMES["Lon"],
            "temp_ungated_best_stage_jointlonsig.pt",
            "temp_ungated_best_stage_lon.pt",
        )
        if path is None:
            print("[curriculum] →Lat: no lon/joint best; keep current trainable weights")
            return False
        if ckpt is None:
            try:
                ckpt = torch_load(path, device)
            except Exception as exc:
                print(
                    f"[curriculum] →Lat: failed to load {os.path.basename(path)} "
                    f"({type(exc).__name__}: {exc})",
                    flush=True,
                )
                return False
        signal_actor.load_state_dict(ckpt["signal_actor"])
        lon_sd = ckpt.get("lon_actor") or ckpt.get("cav_actor")
        if lon_sd is None:
            print("[curriculum] →Lat: checkpoint missing lon_actor; skip")
            return False
        lon_actor.load_state_dict(lon_sd)
        meta = ckpt.get("best_meta") or {}
        _apply_vlm_from_meta(parallel_envs, meta)
        # Do NOT restore Lon/JLS critic / ret_rms into Lat (reward scale mismatch).
        ep = meta.get("episode")
        print(
            f"[curriculum] {prev_stage}→Lat: loaded {os.path.basename(path)} (signal+lon"
            f"{' + W_sig' if meta.get('W_sig') is not None else ''}"
            f"{' + W_long' if meta.get('W_long') is not None else ''}"
            f"; critic/ret_rms fresh)"
            f"{'' if ep is None else f' (from ep {ep})'} before lon freeze"
        )
        return True
    if prev_stage == "Lat" and new_stage == "JointAll":
        path, ckpt = _preferred_checkpoint_by_score(
            checkpoint_dir,
            device,
            _BEST_STAGE_FILENAMES["Lat"],
            "temp_ungated_best_stage_lat.pt",
        )
        if path is None:
            print("[curriculum] Lat→JointAll: no best_stage_lat.pt; keep weights")
            return False
        if ckpt is None:
            try:
                ckpt = torch_load(path, device)
            except Exception as exc:
                print(
                    f"[curriculum] Lat→JointAll: failed to load "
                    f"{os.path.basename(path)} ({type(exc).__name__}: {exc})",
                    flush=True,
                )
                return False
        if ckpt.get("signal_actor") is not None:
            signal_actor.load_state_dict(ckpt["signal_actor"])
        lon_sd = ckpt.get("lon_actor") or ckpt.get("cav_actor")
        if lon_sd is not None:
            lon_actor.load_state_dict(lon_sd)
        if ckpt.get("lat_actor") is not None:
            lat_actor.load_state_dict(ckpt["lat_actor"])
        meta = ckpt.get("best_meta") or {}
        _apply_vlm_from_meta(parallel_envs, meta)
        extra = _extras(ckpt)
        _seed_joint_best_from_entry(
            "JointAll", "Lat", checkpoint_dir, ckpt, best_trackers
        )
        print(
            f"[curriculum] Lat→JointAll: loaded {os.path.basename(path)}"
            f"{extra} before weak three-way unfreeze",
            flush=True,
        )
        return True
    return False


def _resolve_checkpoint_dir(args, method, scenario_key, vlm_model=""):
    ckpt_override = str(getattr(args, "checkpoint_dir", "") or "").strip()
    if ckpt_override in ("", "checkpoints", "results/baselines/no_vlm/checkpoints", "results/baselines/mappo_lat_lon_fixed/checkpoints"):
        checkpoint_dir = str(
            train_ckpt_dir(
                method,
                scenario_key,
                int(args.seed),
                vlm_model=vlm_model,
            )
        )
    elif ckpt_override.rstrip("/\\").endswith(f"seed_{args.seed}"):
        checkpoint_dir = (
            ckpt_override
            if os.path.isabs(ckpt_override)
            else os.path.join(PROJECT_ROOT, ckpt_override)
        )
    else:
        base = (
            ckpt_override
            if os.path.isabs(ckpt_override)
            else os.path.join(PROJECT_ROOT, ckpt_override)
        )
        if os.path.basename(base.rstrip("/\\")) == scenario_key:
            checkpoint_dir = os.path.join(base, f"seed_{args.seed}")
        else:
            checkpoint_dir = os.path.join(base, scenario_key, f"seed_{args.seed}")
    os.makedirs(checkpoint_dir, exist_ok=True)
    return checkpoint_dir


def build_co_opt_config(args) -> dict:
    """Extract validated co-optimization config dict from parsed CLI / config.yaml args."""
    return {
        "crash_attribution_enabled": bool(getattr(args, "crash_attribution", True)),
        "crash_terminal_penalty": float(getattr(args, "crash_terminal_penalty", -1.0)),
        "green_glide_decouple_enabled": bool(getattr(args, "green_glide_fix", True)),
        "lagrangian_safety_enabled": bool(getattr(args, "lagrangian_safety", True)),
        "lagrangian_safety_init": float(getattr(args, "lagrangian_safety_init", 0.05)),
        "lagrangian_safety_lr": float(getattr(args, "lagrangian_safety_lr", 0.02)),
        "lagrangian_safety_max": float(getattr(args, "lagrangian_safety_max", 0.50)),
        "target_intervention_rate": float(getattr(args, "target_intervention_rate", 0.05)),
        "in_memory_follower_lookup": bool(getattr(args, "in_memory_follower", True)),
        "cacc_soft_platoon_enabled": bool(getattr(args, "cacc_soft_platoon", True)),
        "cacc_full_gap_m": float(getattr(args, "cacc_full_gap_m", 8.0)),
        "cacc_free_gap_m": float(getattr(args, "cacc_free_gap_m", 22.0)),
        "cacc_rl_authority_floor": float(
            np.clip(float(getattr(args, "cacc_rl_authority_floor", 0.25)), 0.0, 1.0)
        ),
        "cacc_leader_accel_gain": float(getattr(args, "cacc_leader_accel_gain", 0.35)),
        "cacc_ppo_authority_min": float(getattr(args, "cacc_ppo_authority_min", 0.20)),
        "goal_speed_conditioning": bool(getattr(args, "goal_speed_cond", True)),
        "cross_approach_baseline": bool(getattr(args, "cross_approach_baseline", True)),
        "freeze_team_critic_in_stage_s": bool(getattr(args, "freeze_team_critic_in_s", True)),
        "lagrangian_penalty_mode": str(getattr(args, "lagrangian_penalty_mode", "indicator") or "indicator"),
    }


def _archive_downstream_for_stage_lon_restart(
    checkpoint_dir: str,
    lon_entry_ep: int,
    *,
    source_s_ckpt: str = "",
    results_dir: str = "",
) -> list[str]:
    """Archive ALL post-Stage-S checkpoints unconditionally during --restart-stage-lon.

    Eliminates stale ``best_stage_lon.pt``, ``temp_ungated_best_stage_lon.pt``,
    ``best_joint_*.pt``, ``pre_joint_*.pt``, ``best_stage_lat.pt``, ``best_final.pt``,
    and ``episode_<N>.pt`` (``N > lon_entry_ep``) even when old checkpoints came from
    a shorter curriculum or lacked ``best_meta.episode`` — preventing Stage-Lat from
    ever reloading stale longitudinal weights.
    """
    import re
    import shutil
    from pathlib import Path
    ckpt_p = Path(checkpoint_dir)
    if not ckpt_p.is_dir():
        return []
    src_res = Path(source_s_ckpt).resolve() if source_s_ckpt and os.path.isfile(source_s_ckpt) else None
    stamp = time.strftime("%Y%m%d_%H%M%S")
    arch_dir = ckpt_p / f"_archive_before_lon_restart_{stamp}"
    downstream_names = (
        "best_stage_lon.pt",
        "best_joint_lon_sig.pt",
        "best_stage_lat.pt",
        "best_joint_all.pt",
        "best_final.pt",
        "pre_joint_lon_sig.pt",
        "pre_joint_all.pt",
        "temp_ungated_best_stage_lon.pt",
        "temp_ungated_best_stage_jointlonsig.pt",
        "temp_ungated_best_stage_lat.pt",
        "temp_ungated_best_stage_jointall.pt",
        "superseded_best_stage_lon.pt",
        "superseded_best_stage_jointlonsig.pt",
        "superseded_best_stage_lat.pt",
        "superseded_best_stage_jointall.pt",
    )
    to_move: list[Path] = []
    latest_p = ckpt_p / "latest.pt"
    if latest_p.is_file() and (src_res is None or latest_p.resolve() != src_res):
        to_move.append(latest_p)
    for fname in downstream_names:
        cand = ckpt_p / fname
        if cand.is_file() and (src_res is None or cand.resolve() != src_res):
            to_move.append(cand)
    ep_pat = re.compile(r"^episode_(\d+)\.pt$")
    for item in sorted(ckpt_p.iterdir()):
        if not item.is_file():
            continue
        m = ep_pat.match(item.name)
        if m and int(m.group(1)) > int(lon_entry_ep):
            if src_res is None or item.resolve() != src_res:
                to_move.append(item)

    moved_names: list[str] = []
    if to_move:
        arch_dir.mkdir(parents=True, exist_ok=True)
        for p_old in to_move:
            dst = arch_dir / p_old.name
            if dst.exists():
                dst = arch_dir / f"{p_old.name}.{stamp}"
            shutil.move(str(p_old), str(dst))
            moved_names.append(p_old.name)
    if src_res is not None and src_res.is_file():
        shutil.copy2(str(src_res), str(latest_p))
        try:
            from baselines.tb_curve_sanitize import patch_checkpoint_tb_run
            patch_checkpoint_tb_run(latest_p, tb_run="", episode=int(lon_entry_ep))
        except Exception:
            pass
    if results_dir:
        npz_p = Path(results_dir) / "episode_metrics.npz"
        if npz_p.is_file():
            try:
                with np.load(npz_p, allow_pickle=False) as d_npz:
                    arrays = {k: d_npz[k] for k in d_npz.files}
                if "episode_index" in arrays:
                    ep_idx = np.asarray(arrays["episode_index"]).reshape(-1)
                    mask = ep_idx <= int(lon_entry_ep)
                    if not bool(np.all(mask)):
                        arch_dir.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(npz_p, arch_dir / "episode_metrics.before_lon_restart.npz")
                        n_rows = len(ep_idx)
                        trimmed = {
                            k: (arr[mask] if arr.ndim >= 1 and arr.shape[0] == n_rows else arr)
                            for k, arr in arrays.items()
                        }
                        _atomic_savez_compressed(str(npz_p), **trimmed)
            except Exception as exc:
                print(f"[Warn] could not trim episode_metrics.npz on restart: {exc}", flush=True)
    if moved_names:
        print(
            f"[restart-stage-lon] archived {len(moved_names)} downstream checkpoint(s) "
            f"to {arch_dir.name}: {', '.join(moved_names)}",
            flush=True,
        )
    return moved_names


def _load_optimizer_state(optimizer, state, name):
    if not state or optimizer is None:
        return
    try:
        optimizer.load_state_dict(state)
    except Exception as exc:
        print(f"[Warn] skip optimizer '{name}' on resume ({type(exc).__name__}: {exc})")


def _build_control_kwargs(args, co_opt_config, top3):
    """Per-run env control knobs, shared by training and --eval-only (v5)."""
    control_kwargs = {
        'green_duration_k': float(args.green_k),
        'dbscan_eps': float(args.dbscan_eps),
        'top3_phase_mask': top3,
        'warmup_seconds': float(getattr(args, 'warmup_seconds', 300.0) or 300.0),
    }
    # Default controls all corridor CAVs with IDM-residual actions;
    # --leaders-only / --no-lon-residual-idm allow legacy ablations.
    if bool(getattr(args, "leaders_only", False)):
        control_kwargs["cav_rl_leaders_only"] = True
    elif getattr(args, "cav_rl_leaders_only", None) is not None:
        control_kwargs["cav_rl_leaders_only"] = bool(args.cav_rl_leaders_only)
    else:
        control_kwargs["cav_rl_leaders_only"] = False
    control_kwargs["lon_residual_idm"] = not bool(
        getattr(args, "no_lon_residual_idm", False)
    )
    control_kwargs["green_glide_decouple"] = bool(
        co_opt_config["green_glide_decouple_enabled"]
    )
    control_kwargs["in_memory_follower_lookup"] = bool(
        co_opt_config["in_memory_follower_lookup"]
    )
    control_kwargs["cacc_soft_platoon"] = bool(
        co_opt_config["cacc_soft_platoon_enabled"]
    )
    control_kwargs["cacc_full_gap_m"] = float(co_opt_config["cacc_full_gap_m"])
    control_kwargs["cacc_free_gap_m"] = float(co_opt_config["cacc_free_gap_m"])
    control_kwargs["cacc_rl_authority_floor"] = float(
        co_opt_config["cacc_rl_authority_floor"]
    )
    control_kwargs["cacc_leader_accel_gain"] = float(
        co_opt_config["cacc_leader_accel_gain"]
    )
    # v4 environment knobs (measurement validity + demand randomization).
    control_kwargs.update({
        "queue_mode": str(getattr(args, "queue_mode", "halted")),
        "include_permissive_lanes": bool(getattr(args, "include_permissive_lanes", True)),
        "green_arrival_k": float(getattr(args, "green_arrival_k", 2.0)),
        "green_arrival_window_s": float(getattr(args, "green_arrival_window_s", 10.0)),
        "max_depart_delay": float(getattr(args, "max_depart_delay", -1.0)),
        "collision_check_junctions": bool(getattr(args, "collision_check_junctions", True)),
        "allow_od_rewrite": bool(getattr(args, "allow_od_rewrite", False)),
        "control_keep_lane_hdv": bool(getattr(args, "hdv_keep_lane_control_zone", False)),
        "demand_randomize": bool(getattr(args, "demand_randomize", True)),
        "demand_jitter_s": float(getattr(args, "demand_jitter_s", 60.0)),
        "demand_scale_low": float(getattr(args, "demand_scale_low", 0.9)),
        "demand_scale_high": float(getattr(args, "demand_scale_high", 1.1)),
        "ablate_zero_lon_residual": bool(getattr(args, "ablate_zero_lon_residual", False)),
    })
    control_kwargs["sumo_diag_dir"] = str(getattr(args, "sumo_diag_dir", "") or "")  # v5.1
    return control_kwargs


def _selection_score(args, avg_speed, avg_queue_length, final_v4_kpis=None):
    """v5: best-checkpoint score. 'legacy' = v4 (speed - 0.15*queue); 'tis' =
    -avg_time_in_system/60 (minutes, higher is better). Joint-abort logic keeps
    the legacy score because its thresholds are calibrated in those units."""
    if str(getattr(args, "select_score", "legacy") or "legacy").strip().lower() == "tis":
        vals = []
        for fe in (final_v4_kpis or []):
            try:
                v = float((fe or {}).get("avg_time_in_system", 0.0) or 0.0)
            except (TypeError, ValueError):
                continue
            if np.isfinite(v) and v > 0.0:
                vals.append(v)
        if vals:
            return -float(np.mean(vals)) / 60.0
    return _best_score(avg_speed, avg_queue_length)


def _resolve_eval_seeds(spec):
    s = str(spec or "").strip().lower()
    try:
        from baselines.experiment_seeds import TEST_SEEDS, VALIDATION_SEEDS
    except Exception:
        VALIDATION_SEEDS, TEST_SEEDS = tuple(range(900001, 900011)), tuple(range(990001, 990011))
    if s in ("", "validation", "val"):
        return [int(x) for x in VALIDATION_SEEDS]
    if s == "test":
        return [int(x) for x in TEST_SEEDS]
    return [int(x) for x in s.replace(";", ",").split(",") if x.strip()]


def _run_eval_only(args, agent, parallel_envs, co_opt_config):
    """v5 (1.2): deterministic evaluation of ONE checkpoint on held-out seeds.

    Same environment construction and per-step action glue as training
    (select_actions -> hold_cav_actions -> env_actions_only), eval_mode=True
    (no OD rewrites), no learning. Writes one CSV row per episode, then
    hard-exits so the training post-processing never runs on an eval run.
    """
    import csv
    import traceback

    rc = 0
    try:
        ckpt_path = str(getattr(args, "eval_checkpoint", "") or "")
        rule_stack = (
            str(getattr(args, "profile", "") or "").strip().lower() == "landable"
            or (
                bool(getattr(args, "ablate_zero_lon_residual", False))
                and str(getattr(args, "signal_rule", "none") or "none") != "none"
            )
        )
        loaded = []
        ckpt = {}
        if ckpt_path and os.path.isfile(ckpt_path):
            ckpt = torch.load(ckpt_path, map_location=getattr(agent, "device", "cpu"), weights_only=False)
            if not isinstance(ckpt, dict):
                raise ValueError("checkpoint is not a dict")
            for key in ("signal_actor", "lon_actor", "lat_actor", "critic"):
                module = getattr(agent, key, None)
                state = ckpt.get(key)
                if module is not None and state is not None:
                    module.load_state_dict(state)
                    loaded.append(key)
        elif rule_stack:
            print(
                "[eval] no checkpoint: rule stack only "
                f"(profile={getattr(args, 'profile', '')} "
                f"zero_lon_residual={int(bool(getattr(args, 'ablate_zero_lon_residual', False)))} "
                f"signal_rule={getattr(args, 'signal_rule', 'none')})",
                flush=True,
            )
        else:
            raise FileNotFoundError(f"--eval-checkpoint not found: {ckpt_path!r}")
        default_stage = "Lon" if rule_stack else "JointAll"
        stage = str(getattr(args, "eval_stage", "") or ckpt.get("training_stage") or default_stage)
        agent.set_training_stage(stage)
        agent.action_blend_beta = 1.0
        agent.imitation_coef = 0.0
        top3 = bool(getattr(args, "top3_mask", True))
        if hasattr(parallel_envs, "configure_stage"):
            _len = 10 ** 6
            parallel_envs.configure_stage(
                stage, top3_mask=top3, coop_policy="off",
                stage_episode=_len, soft_start=0, stage_len=_len,
            )
        ckw = _build_control_kwargs(args, co_opt_config, top3)
        ckw["demand_randomize"] = bool(getattr(args, "eval_demand_randomize", False))
        ckw["eval_mode"] = True
        if hasattr(parallel_envs, "configure_control"):
            parallel_envs.configure_control(**ckw)
        seeds = _resolve_eval_seeds(getattr(args, "eval_seeds", ""))
        if not seeds:
            raise ValueError("no evaluation seeds")
        n_env = max(1, int(args.num_envs))
        cav_hold_steps = max(1, int(round(float(args.cav_action_interval) / float(args.step_length))))
        out_path = str(getattr(args, "eval_out", "") or "") or os.path.join(
            os.getcwd(), f"eval_{os.path.splitext(os.path.basename(ckpt_path))[0]}.csv"
        )
        print(
            f"[eval] ckpt={ckpt_path} loaded={loaded} stage={stage} seeds={seeds} "
            f"demand_randomize={ckw['demand_randomize']}",
            flush=True,
        )
        rows = []
        ep_index = int(getattr(args, "episodes", 0) or 0)
        for g0 in range(0, len(seeds), n_env):
            group = list(seeds[g0:g0 + n_env])
            padded = group + [group[-1]] * (n_env - len(group))
            obs_list = parallel_envs.reset(seeds=padded)
            alive = [True] * n_env
            a_cache = [{} for _ in range(n_env)]
            l_cache = [{} for _ in range(n_env)]
            collisions = [0] * n_env
            teleports = [0] * n_env
            last_info = [{} for _ in range(n_env)]
            steps_done = [0] * n_env
            for step in range(int(args.max_steps)):
                if not any(alive):
                    break
                cav_decision = (step % cav_hold_steps == 0)
                actions_list, lambdas_list = [], []
                for i in range(n_env):
                    lam = np.asarray([0.5, 0.5], dtype=np.float32)
                    if not alive[i]:
                        actions_list.append({})
                        lambdas_list.append(lam)
                        continue
                    with torch.no_grad():
                        actions, log_probs = agent.select_actions(
                            obs_list[i],
                            deterministic=True,
                            cav_decision=cav_decision,
                            cav_action_cache=a_cache[i],
                            cav_logp_cache=l_cache[i],
                        )
                    actions, log_probs, a_cache[i], l_cache[i] = hold_cav_actions(
                        actions, log_probs, a_cache[i], l_cache[i], refresh=cav_decision,
                    )
                    actions_list.append(env_actions_only(actions))
                    lambdas_list.append(lam)
                next_obs_list, _rew, dones_list, infos_list = parallel_envs.step(
                    actions_list, ep_index, step, lambdas_list, alive_mask=list(alive)
                )
                for i in range(n_env):
                    if not alive[i]:
                        continue
                    infos_i = infos_list[i] if isinstance(infos_list[i], dict) else {}
                    info = infos_i.get("__all__") or {}
                    collisions[i] += int(info.get("collisions", 0) or 0)
                    teleports[i] += int(info.get("teleports", 0) or 0)
                    last_info[i] = info
                    steps_done[i] = step + 1
                    if bool((dones_list[i] or {}).get("__all__", False)):
                        alive[i] = False
                obs_list = next_obs_list
            for i, sd in enumerate(group):
                info = last_info[i] or {}
                row = {
                    "checkpoint": os.path.basename(ckpt_path),
                    "checkpoint_path": ckpt_path,
                    "stage": stage,
                    "seed": int(sd),
                    "demand_randomized": int(bool(ckw["demand_randomize"])),
                    "steps": int(steps_done[i]),
                    "collisions_total": int(collisions[i]),
                    "teleports_total": int(teleports[i]),
                }
                for key, val in sorted(info.items()):
                    if isinstance(val, (bool, np.bool_)):
                        continue
                    if isinstance(val, (int, float, np.integer, np.floating)) and np.isfinite(float(val)):
                        row[str(key)] = float(val)
                rows.append(row)
                print(
                    f"[eval] seed={sd} avg_time_in_system={row.get('avg_time_in_system', float('nan')):.2f} "
                    f"collisions={collisions[i]} teleports={teleports[i]}",
                    flush=True,
                )
        os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)
        fields = []
        for r in rows:
            for key in r:
                if key not in fields:
                    fields.append(key)
        with open(out_path, "w", newline="", encoding="utf-8") as fh:
            writer_csv = csv.DictWriter(fh, fieldnames=fields)
            writer_csv.writeheader()
            for r in rows:
                writer_csv.writerow(r)
        print(f"[eval] wrote {len(rows)} row(s) -> {out_path}", flush=True)
    except BaseException:
        traceback.print_exc()
        rc = 1
    finally:
        try:
            parallel_envs.close()
        except Exception:
            pass
        sys.stdout.flush()
        sys.stderr.flush()
        os._exit(rc)


def train(args=None):
    args = args or parse_args()
    _validate_training_args(args)
    if bool(getattr(args, "vlm_heuristic", False)):
        # v4 ablation: same rule table as the VLM prompt, without any VLM call.
        os.environ["VLM_HEURISTIC_WEIGHTS"] = "1"
    # v5.2: runtime switches read by env workers (set BEFORE envs are created).
    os.environ["LON_REWARD_VERSION"] = str(getattr(args, "lon_reward_version", "v2") or "v2")
    if getattr(args, "glosa_min_speed", None) is not None:
        os.environ["LON_GLOSA_MIN_SPEED"] = str(float(args.glosa_min_speed))
    if bool(getattr(args, "ablate_cav_native_idm", False)):
        os.environ["VECTOR_ABLATE_CAV_NATIVE_IDM"] = "1"
    # v5.2.4: control-stack bisection switches (read by SUMOEnvironment.__init__).
    os.environ["LON_NO_FLOORS"] = "1" if bool(getattr(args, "lon_no_floors", False)) else "0"
    os.environ["LON_HANDBACK_NEAR_M"] = str(float(getattr(args, "lon_handback_near_m", 0.0) or 0.0))
    os.environ["LON_HANDBACK_JUNCTION"] = "1" if bool(getattr(args, "lon_handback_junction", False)) else "0"
    os.environ["LON_ACTUATION"] = str(getattr(args, "lon_actuation", "accel") or "accel")
    os.environ["SPAT_SYNTH_FIX"] = "1" if bool(getattr(args, "spat_synth_fix", True)) else "0"
    # v6-P0 switches (read by env workers at call time).
    os.environ["LON_RL_MAX_DIST_M"] = str(float(getattr(args, "lon_rl_max_dist_m", 300.0) or 300.0))
    os.environ["LON_RL_MIN_DIST_M"] = str(float(getattr(args, "lon_rl_min_dist_m", 0.0) or 0.0))
    os.environ["LON_RL_IN_JUNCTION"] = "1" if bool(getattr(args, "lon_rl_in_junction", True)) else "0"
    os.environ["GAP_POLICY"] = str(getattr(args, "gap_policy", "legacy") or "legacy")
    os.environ["SIGNAL_REWARD_SAT"] = str(float(getattr(args, "signal_reward_sat", 1.0) or 1.0))
    _rule = str(getattr(args, "signal_rule", "none") or "none")
    os.environ["SIGNAL_RULE"] = "" if _rule == "none" else _rule
    os.environ["VECTOR_VLM_OBS_SCALE_FIX"] = (
        "1" if str(getattr(args, "profile", "v524")) in ("v6p0", "v6p1", "landable") else "0"
    )
    os.environ["LON_ACTION_MODE"] = str(getattr(args, "lon_action_mode", "residual") or "residual")
    os.environ["SIGNAL_COMMITMENT"] = "1" if bool(getattr(args, "signal_commitment", False)) else "0"
    os.environ["P1_OBS_ON_DECISION"] = "1" if bool(getattr(args, "p1_obs_on_decision", False)) else "0"
    os.environ["P1_VALUE_ON_DECISION"] = os.environ["P1_OBS_ON_DECISION"]
    os.environ["P1_LAT_DELAYED"] = "1" if bool(getattr(args, "p1_lat_delayed", False)) else "0"
    try:
        _hold = max(1, int(round(float(args.cav_action_interval) / float(args.step_length))))
    except (TypeError, ValueError, ZeroDivisionError):
        _hold = 1
    os.environ["P1_OBS_HOLD_STEPS"] = str(_hold)
    from environment import gap_policy as _gp_mod

    print(
        f"[v6] profile={getattr(args, 'profile', 'v524')} "
        f"applied={sorted((getattr(args, '_profile_applied', {}) or {}).keys())} "
        f"lon_zone=[{os.environ['LON_RL_MIN_DIST_M']},{os.environ['LON_RL_MAX_DIST_M']}]m "
        f"in_junction={os.environ['LON_RL_IN_JUNCTION']} {_gp_mod.summary()} "
        f"signal_reward_sat={os.environ['SIGNAL_REWARD_SAT']} "
        f"imitation_scale={float(getattr(args, 'lon_imitation_scale', 0.10)):g} "
        f"authority_min={float(getattr(args, 'cacc_ppo_authority_min', 0.20)):g} "
        f"signal_rule={_rule}",
        flush=True,
    )
    print(
        f"[v5.2.4] no_floors={os.environ['LON_NO_FLOORS']} "
        f"handback_near_m={float(os.environ['LON_HANDBACK_NEAR_M']):g} "
        f"handback_junction={os.environ['LON_HANDBACK_JUNCTION']} "
        f"actuation={os.environ['LON_ACTUATION']} "
        f"spat_synth_fix={os.environ['SPAT_SYNTH_FIX']} "
        f"keep_lon_noop_samples={int(bool(getattr(args, 'keep_lon_noop_samples', False)))} "
        f"zero_lon_residual={int(bool(getattr(args, 'ablate_zero_lon_residual', False)))}",
        flush=True,
    )
    print(
        f"[v5.2] lon_reward_version={os.environ['LON_REWARD_VERSION']} "
        f"glosa_min_speed={os.environ.get('LON_GLOSA_MIN_SPEED', '3.5 (default)')} "
        f"cav_native_idm={os.environ.get('VECTOR_ABLATE_CAV_NATIVE_IDM', '0')}",
        flush=True,
    )
    if getattr(args, "gamma_seconds", None):
        _gs = float(args.gamma_seconds)
        if 0.0 < _gs < 1.0:
            args.gamma = float(_gs ** float(args.step_length))
            print(f"[v5] gamma_seconds={_gs} -> gamma per step={args.gamma:.6f}", flush=True)
    _tt = int(getattr(args, "torch_threads", 0) or 0) or int(os.environ.get("VECTOR_TORCH_THREADS", "0") or 0) or 2
    try:
        torch.set_num_threads(max(1, _tt))
    except Exception:
        pass
    print(f"[v5.1] torch threads={torch.get_num_threads()} (several runs on one CPU: keep this small)", flush=True)
    if int(getattr(args, "num_envs", 1) or 1) > 1:
        print(
            "[v5][note] num_envs>1: fixed windows (teacher hold 50, Best-S tail 60, VLM warm-up, "
            "joint grace 15) count ITERATIONS, each holding num_envs episodes; consider scaling the "
            "schedule (training.schedule) or run seeds as separate processes.",
            flush=True,
        )
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(int(args.seed))

    sumocfg_path = args.sumocfg
    if not os.path.isabs(sumocfg_path):
        sumocfg_path = os.path.abspath(os.path.join(PROJECT_ROOT, sumocfg_path))
    api_key = str(
        getattr(args, 'vlm_api_key', None) or os.environ.get('VLM_API_KEY') or 'local-mock-key'
    ).strip()
    from VLM.scene_encoder import VLMSceneEncoder

    vlm_api_base = VLMSceneEncoder._normalize_api_base(
        getattr(args, 'vlm_api_base', None)
        or os.environ.get('VLM_API_BASE')
        or 'http://127.0.0.1:8080/v1'
    )
    args.vlm_api_key = api_key
    args.vlm_api_base = vlm_api_base
    args.vlm_model = str(getattr(args, 'vlm_model', '') or '').strip()

    # Signal / Lon / Lat share one thinking preference. Default to low unless
    # the user already set VLM_THINKING_MODE / VLM_THINKING (off|low|auto).
    try:
        from VLM.vlm_call_config import env_thinking_preference

        if not str(
            os.environ.get("VLM_THINKING_MODE")
            or os.environ.get("VLM_THINKING")
            or ""
        ).strip():
            os.environ["VLM_THINKING_MODE"] = str(
                getattr(args, "vlm_thinking_mode", "off") or "off"
            ).strip()
        _think_pref = env_thinking_preference(
            api_base=vlm_api_base, model=args.vlm_model
        )
        print(
            f"[Start] VLM thinking_mode={_think_pref} "
            f"(Signal/Lon/Lat; reasoning_effort via VLM_REASONING_EFFORT, "
            f"default low)"
        )
    except Exception as _think_exc:
        print(f"[Start] VLM thinking preference setup skipped: {_think_exc}")

    vision = resolve_vision_mode(args)
    use_vlm = bool(vision["use_vlm"])
    signal_vision = bool(vision["signal_vision"])
    vlm_weight_stages = tuple(vision["weight_stages"])
    vision_mode = str(vision["mode"])
    args.vision_mode = vision_mode
    args.signal_vlm_vision = signal_vision
    args.vlm_weight_stages = vlm_weight_stages
    # Rule teacher: default OFF so no_vlm / only-lon / only-lat remain pure RL
    # baselines in Stage-S; opt-in via --rule-signal-teacher when signal_vision is off.
    _rule_cli = getattr(args, "rule_signal_teacher", False)
    rule_signal_teacher = bool(_rule_cli) and (not bool(signal_vision))
    args.rule_signal_teacher = bool(rule_signal_teacher)
    # Keep legacy flag in sync for resume/meta and baseline injectors.
    if vision_mode == VISION_MODE_NONE:
        args.no_vlm = True
        args.no_vision = True
    # Scheme-1 all-CAV soft-platoon: remap results folder + leaders_only=False.
    # Must run after vision_mode is known so VLM vs no-VLM folders split correctly.
    from baselines.allcav_softplatoon import (
        apply_allcav_soft_platoon_args,
        is_allcav_mode,
    )

    if is_allcav_mode(args):
        from baselines.allcav_softplatoon import CURRICULUM_FREEZE_NOTE

        apply_allcav_soft_platoon_args(args, use_vlm=bool(use_vlm or signal_vision))
        print(
            f"[Start] all-CAV soft-platoon ON "
            f"(cav_rl_leaders_only=False; results_method={args.results_method}); "
            f"DBSCAN labels observational only; signal formal reward unchanged; "
            f"{CURRICULUM_FREEZE_NOTE}",
            flush=True,
        )
    fixed_weights = getattr(args, 'fixed_weights', None)
    _mode_labels = {
        VISION_MODE_FULL: "full (S signal-vision + Lon W_long + Lat W_lat)",
        VISION_MODE_ONLY_SIGNAL: "only-signal (Stage-S vision; Lon/Lat fixed)",
        VISION_MODE_ONLY_LON: "only-lon (Stage-Lon W_long only)",
        VISION_MODE_ONLY_LAT: "only-lat (Stage-Lat W_lat only)",
        VISION_MODE_NONE: "none (no VLM in any stage)",
    }
    print(
        f"[Start] vision_mode={vision_mode} "
        f"({_mode_labels.get(vision_mode, vision_mode)}); "
        f"signal_vision={'ON' if signal_vision else 'OFF'}; "
        f"rule_signal_teacher={'ON' if rule_signal_teacher else 'OFF'}; "
        f"weight_VLM_stages={list(vlm_weight_stages) if vlm_weight_stages else '[]'}"
    )
    if use_vlm or signal_vision:
        print(
            f"[Start] VLM model={args.vlm_model} "
            f"base={vlm_api_base} "
            f"cadence=signal-vision 3/4/5-leg 75/112/150s; W_long 30s; W_lat 45s; "
            f"(unknown-scenario fallback {args.vlm_update_interval}s) "
            f"fail_stop={bool(getattr(args, 'vlm_fail_stop', True))}"
        )
    if not use_vlm:
        from reward.longitudinal_reward import DEFAULT_LONG_WEIGHTS

        w = fixed_weights if fixed_weights is not None else tuple(float(x) for x in DEFAULT_LONG_WEIGHTS)
        if str(os.environ.get("LON_REWARD_VERSION", "v2")).strip().lower() == "v2":
            from reward.longitudinal_reward import V2_LONG_WEIGHTS

            print(
                "[Start] reward-weight VLM off — lon reward v2 uses its own fixed weights "
                f"(safe,delay,comfort,platoon)={tuple(round(float(x), 3) for x in V2_LONG_WEIGHTS)}; "
                "W_long below/in [VLM] lines only applies to v1"
            )
        else:
            print(f"[Start] reward-weight VLM off — fixed W_long={tuple(float(x) for x in w)}")

    cav_hold_steps = max(1, int(round(float(args.cav_action_interval) / float(args.step_length))))
    print(
        f"[Start] CAV action interval={args.cav_action_interval}s "
        f"(hold {cav_hold_steps} sim steps @ step_length={args.step_length}s)"
    )
    enable_emissions = bool(getattr(args, "emissions", True))
    args.emissions = enable_emissions
    os.environ["SUMO_ENABLE_EMISSIONS"] = "1" if enable_emissions else "0"
    print(
        f"[Start] emissions={'on' if enable_emissions else 'off'} "
        f"(--emissions/--no-emissions; HBEFA fuel/CO2 for Metrics TB)",
        flush=True,
    )
    from baselines.episode_timing import apply_episode_timing, timing_summary
    apply_episode_timing(args, step_length=float(args.step_length))
    print(f"[Start] episode timing: {timing_summary(args)}")
    # Optional short Stage-S-only budgets for β grid / ablations.
    # apply_episode_timing always rewrites --episodes to the full curriculum;
    # GRID_FORCE_EPISODES restores a Stage-S-only run of N episodes.
    _grid_eps = str(os.environ.get("GRID_FORCE_EPISODES", "") or "").strip()
    if _grid_eps:
        try:
            _n = max(1, int(_grid_eps))
        except (TypeError, ValueError):
            _n = 0
        if _n > 0:
            args.stage_s_episodes = int(_n)
            args.stage_lon_episodes = 0
            args.stage_lat_episodes = 0
            args.stage_l1_episodes = 0
            args.stage_l2_episodes = 0
            args.joint_lon_sig_episodes = 0
            args.joint_all_episodes = 0
            args.episodes = int(_n)
            args.use_absolute_stage_schedule = True
            print(
                f"[Start] GRID_FORCE_EPISODES={_n}: Stage-S only "
                f"(Lon/Lat/joint tails disabled)",
                flush=True,
            )
    # Compressed multi-stage diagnostic curriculum:
    # GRID_FORCE_CURRICULUM=S,LonBlock,JLS,LatBlock,JA
    _grid_cur = str(os.environ.get("GRID_FORCE_CURRICULUM", "") or "").strip()
    if _grid_cur and not _grid_eps:
        try:
            parts = [max(0, int(x.strip())) for x in _grid_cur.split(",")]
        except (TypeError, ValueError):
            parts = []
        if len(parts) == 5:
            s_n, lon_block, jls_n, lat_block, ja_n = parts
            args.stage_s_episodes = int(s_n)
            args.stage_lon_episodes = int(lon_block)
            args.stage_lat_episodes = int(lat_block)
            args.stage_l1_episodes = int(lon_block)
            args.stage_l2_episodes = int(lat_block)
            args.joint_lon_sig_episodes = int(jls_n)
            args.joint_all_episodes = int(ja_n)
            args.episodes = int(s_n + lon_block + lat_block)
            args.use_absolute_stage_schedule = True
            print(
                f"[Start] GRID_FORCE_CURRICULUM S={s_n} LonBlock={lon_block} "
                f"JLS={jls_n} LatBlock={lat_block} JA={ja_n} "
                f"total={args.episodes}",
                flush=True,
            )
    _warm_ov = str(os.environ.get("DIAG_VLM_WARMUP", "") or "").strip()
    if _warm_ov:
        # e.g. S:3,Lon:4,Lat:4
        table = dict(getattr(args, "vlm_warmup_by_stage", None) or {})
        for part in _warm_ov.split(","):
            part = part.strip()
            if not part or ":" not in part:
                continue
            key, raw = part.split(":", 1)
            try:
                table[key.strip()] = max(0, int(raw.strip()))
            except (TypeError, ValueError):
                continue
        args.vlm_warmup_by_stage = table
        print(f"[diag] vlm_warmup_by_stage → {table}", flush=True)
    _wu = str(os.environ.get("DIAG_WARMUP_SECONDS", "") or "").strip()
    if _wu:
        try:
            wu = float(_wu)
        except (TypeError, ValueError):
            wu = -1.0
        if wu >= 0.0 and wu == wu:
            args.warmup_seconds = float(wu)
            print(f"[diag] warmup_seconds → {args.warmup_seconds}", flush=True)
    _apply_diag_train_overrides_from_env()
    # Non-quick default: absolute S200 / Lon350 / Lat450 (=1000; carve → JLS150/JA150).
    # Also accept legacy 900/970/1200/1400/1500/2300 totals by mapping onto the full absolute table.
    if not bool(getattr(args, 'use_absolute_stage_schedule', False)):
        from baselines.episode_timing import (
            FULL_STAGE_LON_EPISODES,
            FULL_STAGE_LAT_EPISODES,
            FULL_STAGE_S_EPISODES,
            FULL_TOTAL_EPISODES,
        )
        s_n, lon_n, lat_n = _resolve_stage_episodes(args)
        ep = int(args.episodes)
        if ep in (int(FULL_TOTAL_EPISODES), 900, 920, 970, 1000, 1200, 1400, 1500, 2300) or (
            s_n > 0 and lon_n > 0 and lat_n > 0 and ep == (s_n + lon_n + lat_n)
        ):
            if s_n <= 0:
                args.stage_s_episodes = int(FULL_STAGE_S_EPISODES)
                args.stage_lon_episodes = int(FULL_STAGE_LON_EPISODES)
                args.stage_lat_episodes = int(FULL_STAGE_LAT_EPISODES)
            s_n, lon_n, lat_n = _resolve_stage_episodes(args)
            args.episodes = s_n + lon_n + lat_n
            args.use_absolute_stage_schedule = True
    if bool(getattr(args, 'use_absolute_stage_schedule', False)):
        s_n, lon_n, lat_n = _resolve_stage_episodes(args)
        lon_start = s_n
        lat_start = lon_start + lon_n
        print(
            f"[Start] curriculum (absolute): "
            f"S {s_n} (ep 0–{s_n - 1}) | "
            f"Lon {lon_n} (ep {lon_start}–{lat_start - 1}) | "
            f"Lat {lat_n} (ep {lat_start}–{args.episodes - 1}); "
            f"total episodes={args.episodes}; "
            f"VLM soft-start by stage="
            f"{getattr(args, 'vlm_warmup_by_stage', {})}; "
            f"best-ckpt after soft-start + stage LR floors "
            f"S={_STAGE_LR_FLOOR['S']:.2f}/Lon={_STAGE_LR_FLOOR['Lon']:.2f}/"
            f"Lat={_STAGE_LR_FLOOR['Lat']:.2f}"
        )
    _per_ep = _sumo_per_episode_seed_enabled()
    print(
        f"[Start] Launching {args.num_envs} SUMO env(s), seed={args.seed}. "
        f"For mean±STD use independent seeds {list(EXPERIMENT_SEEDS)} "
        f"(see scripts/train/run_five_seeds.py)."
    )
    print(
        f"[Start] SUMO seed mode="
        f"{'per_episode_stride_' + str(_SUMO_SEED_STRIDE) if _per_ep else 'run_level_locked'} "
        f"(SUMO_PER_EPISODE_SEED={'1' if _per_ep else '0'}); "
        f"best_selector={_BEST_SELECTOR_NAME} "
        f"(window={_BEST_ROLL_WINDOW}, min={_BEST_ROLL_MIN})",
        flush=True,
    )

    method = resolve_results_method(
        str(getattr(args, "results_method", "") or "").strip(),
        use_vlm=use_vlm,
        vlm_model=str(getattr(args, "vlm_model", "") or ""),
        vision_mode=vision_mode,
    )
    raw_scenario = str(getattr(args, "scenario", "") or "").strip()
    if raw_scenario:
        from baselines.fixed_timing.scenarios import canonical_scenario_key

        scenario_key = canonical_scenario_key(raw_scenario)
    else:
        scenario_key = infer_scenario_key(sumocfg_path)
    args.scenario = scenario_key
    if bool(getattr(args, "eval_only", False)):
        # v5 (1.2): keep evaluation artefacts away from the training run directory.
        method = f"{method}__eval"
    args.method = method
    vlm_model = str(getattr(args, "vlm_model", "") or "")
    args.vlm_model = vlm_model
    # 3-leg / 3-phase nets: slightly higher Stage-S entropy floor (action space just
    # grew). Skip when DIAG_ENTROPY_FLOOR already forced a uniform floor.
    if (
        not str(os.environ.get("DIAG_ENTROPY_FLOOR", "") or "").strip()
        and str(scenario_key).startswith("3leg")
    ):
        _STAGE_ENTROPY_FLOOR["S"] = float(_STAGE_S_ENTROPY_FLOOR_3LEG)
    print(
        f"[Start] Stage-S entropy floor={_STAGE_ENTROPY_FLOOR['S']:.2f} "
        f"hold={_STAGE_S_ENTROPY_HOLD_EPISODES}ep "
        f"(scenario={scenario_key})",
        flush=True,
    )
    bev_dir = bev_run_dir(
        method, scenario_key, int(args.seed), vlm_model=vlm_model
    )
    ensure_dir(bev_dir)
    print(f"[paths] bev_dir={bev_dir} (every BEV_SAVE_EVERY VLM calls)")

    def _allocate_sumo_ports(n_envs):
        """Explicit independent TraCI port per env (base+i, or free sockets)."""
        n_envs = int(n_envs)
        base = int(getattr(args, "sumo_port_base", 0) or 0)
        if base > 0:
            ports = [base + i for i in range(n_envs)]
        else:
            from sumolib.miscutils import getFreeSocketPort
            ports = []
            for _ in range(n_envs):
                p = getFreeSocketPort()
                if p is None:
                    raise RuntimeError("Failed to allocate a free TraCI port")
                ports.append(int(p))
        print(f"[Start] TraCI ports per env: {ports}")
        return ports

    co_opt_config = build_co_opt_config(args)
    print(f"[Start] co_optimization={co_opt_config}", flush=True)
    processes = []
    if args.gui:
        if int(args.num_envs) != 1:
            print("[Warn] --gui forces --num-envs 1 (in-process SUMO-GUI).")
            args.num_envs = 1
        print("[Start] SUMO-GUI enabled: each episode opens GUI (auto-start, quit-on-end).")
        gui_ports = _allocate_sumo_ports(1)
        demand_profile = "quick" if bool(getattr(args, "quick", False)) else "full"
        print(f"[Start] demand_profile={demand_profile}")
        local_env = MultiAgentTrafficEnv(
            sumocfg_file=sumocfg_path,
            use_gui=True,
            step_length=args.step_length,
            vlm_api_key=api_key,
            vlm_model=args.vlm_model,
            vlm_api_base=vlm_api_base,
            vlm_update_interval_seconds=args.vlm_update_interval,
            use_vlm=use_vlm,
            fixed_reward_weights=fixed_weights,
            sumo_port=gui_ports[0],
            fail_stop_on_vlm_error=bool(getattr(args, "vlm_fail_stop", True)),
            results_method=method,
            scenario_key=scenario_key,
            run_seed=int(args.seed),
            env_index=0,
            enable_lateral=not bool(getattr(args, "disable_lateral", False)),
            enable_longitudinal=not bool(getattr(args, "disable_longitudinal", False)),
            vlm_warmup_episodes=getattr(args, "vlm_warmup_episodes", None),
            vlm_warmup_by_stage=getattr(args, "vlm_warmup_by_stage", None),
            demand_profile=demand_profile,
            signal_vlm_vision_enabled=signal_vision,
            rule_signal_teacher_enabled=bool(
                getattr(args, "rule_signal_teacher", False)
            ),
            vlm_weight_stages=vlm_weight_stages,
            enable_emissions=enable_emissions,
            co_opt_config=co_opt_config,
        )
        parallel_envs = LocalTrafficEnvs(local_env)
        if is_allcav_mode(args):
            from baselines.allcav_softplatoon import ensure_soft_platoon_rewards

            ensure_soft_platoon_rewards(getattr(local_env, "reward_fn", None))
    else:
        sumo_ports = _allocate_sumo_ports(args.num_envs)
        remotes, work_remotes = zip(*[mp.Pipe() for _ in range(args.num_envs)])
        demand_profile = "quick" if bool(getattr(args, "quick", False)) else "full"
        print(f"[Start] demand_profile={demand_profile}")
        for i in range(args.num_envs):
            use_gui_for_this_env = False
            p = mp.Process(
                target=env_worker,
                args=(
                    work_remotes[i],
                    remotes[i],
                    sumocfg_path,
                    api_key,
                    args.vlm_model,
                    args.vlm_update_interval,
                    args.seed + i,
                    args.step_length,
                    use_gui_for_this_env,
                    use_vlm,
                    fixed_weights,
                    sumo_ports[i],
                    vlm_api_base,
                    bool(getattr(args, "vlm_fail_stop", True)),
                    method,
                    scenario_key,
                    int(args.seed),
                    i,
                    not bool(getattr(args, "disable_lateral", False)),
                    not bool(getattr(args, "disable_longitudinal", False)),
                    None,
                    getattr(args, "vlm_warmup_episodes", None),
                    getattr(args, "vlm_warmup_by_stage", None),
                    demand_profile,
                    signal_vision,
                    vlm_weight_stages,
                    bool(getattr(args, "rule_signal_teacher", False)),
                    enable_emissions,
                    co_opt_config,
                ),
            )
            p.daemon = True
            p.start()
            processes.append(p)
        for w in work_remotes:
            w.close()
        parallel_envs = ParallelTrafficEnvs(remotes)

    device = resolve_torch_device(args.device)
    print(f'Using device: {device}')
    if device.type == 'cuda':
        free_b, total_b = torch.cuda.mem_get_info()
        print(
            f'  GPU free/total at start: {free_b / 1024**3:.2f}/{total_b / 1024**3:.2f} GiB '
            f'(if free < 1.5 GiB, stop local VLM on this GPU or use VLM_DEVICE=cpu)'
        )
    run_dir = train_run_dir(
        method, scenario_key, int(args.seed), vlm_model=vlm_model
    )
    ensure_dir(run_dir)
    ensure_dir(
        train_tb_dir(method, scenario_key, int(args.seed), vlm_model=vlm_model)
    )
    print(f"[paths] train_dir={run_dir}")
    from baselines.result_paths import method_uses_model_layer

    if method_uses_model_layer(method):
        print(f"[paths] method={method} vlm_model={vlm_model or 'unset'}")
    else:
        print(f"[paths] method={method} (flat; no vlm_model nest)")
    if path_looks_volatile(run_dir):
        print(
            "[warn] train_dir is under Trash/Recycle. Restore the project out of Trash "
            "and copy results/train/... there, or checkpoints/TB files can disappear mid-run.",
            flush=True,
        )
    _s_vlm = "signal-vision ON" if signal_vision else "no signal-vision"
    _lon_vlm = "VLM W_long" if "Lon" in vlm_weight_stages else "fixed W_long"
    _lat_vlm = "VLM W_lat" if "Lat" in vlm_weight_stages else "fixed W_lat"
    print(
        f"[curriculum] vision_mode={vision_mode}: "
        f"S({_s_vlm}) → Lon({_lon_vlm}) → Lat({_lat_vlm}); "
        "Lon/Lat soft-start then EMA when weight-VLM is on; "
        "W_long frozen after Stage-Lon"
    )

    use_lon_residual_idm = not bool(getattr(args, "no_lon_residual_idm", False))
    lon_actor = build_longitudinal_actor(
        MultiAgentTrafficEnv.LON_OBS_DIM,
        residual_idm=use_lon_residual_idm,
    ).to(device)
    lat_actor = build_lateral_actor(MultiAgentTrafficEnv.LAT_OBS_DIM).to(device)
    n_signal_actions = n_green_from_sumocfg(sumocfg_path)
    args.n_signal_actions = int(n_signal_actions)
    signal_obs_dim = int(MultiAgentTrafficEnv.SIGNAL_OBS_DIM)
    print(
        f"[MAPPO] signal action dim (green phases) = {n_signal_actions}; "
        f"signal_obs_dim={signal_obs_dim} "
        f"(phase_one_hot={MultiAgentTrafficEnv.SIGNAL_PHASE_FEATURE_DIM}, "
        f"vision_semantics={MultiAgentTrafficEnv.VISION_FEATURE_DIM}; "
        f"5-leg has 7 greens so obs is 33, not a truncated 31)"
    )
    print(
        "[MAPPO] signal obs map: one-hot[0:7], elapsed[7], remaining[8], "
        "queue[9:14], veh[14:19], wait[19:24], prog[24:29], "
        "vision[29:33]=blockage,spillback,incident_or_work,special_vehicle; "
        "old 31-d and W_sig checkpoints are not valid for this layout"
    )
    signal_actor = build_signal_actor(
        signal_obs_dim, action_dim=n_signal_actions
    ).to(device)
    critic = CentralizedCritic().to(device)
    cav_actor = lon_actor  # legacy name for checkpoint helpers
    cav_residual_actor = lon_actor  # placeholder so old pack helpers do not crash
    agent = MAPPOAgent(
        lon_actor=lon_actor,
        lat_actor=lat_actor,
        signal_actor=signal_actor,
        critic=critic,
        actor_lr=args.actor_lr,
        critic_lr=args.critic_lr,
        gamma=args.gamma,
        gae_lambda=args.gae_lambda,
        clip_param=args.clip_param,
        ppo_epochs=args.ppo_epochs,
        minibatch_size=args.minibatch_size,
        device=device,
    )
    agent.enable_lateral = not bool(getattr(args, "disable_lateral", False))
    agent.enable_longitudinal = not bool(getattr(args, "disable_longitudinal", False))
    agent.freeze_team_critic_in_stage_s = bool(co_opt_config["freeze_team_critic_in_stage_s"])
    agent.cross_approach_baseline = bool(co_opt_config["cross_approach_baseline"])
    agent.individual_critic = bool(getattr(args, "individual_critic", False))
    agent.cacc_soft_platoon_enabled = bool(co_opt_config["cacc_soft_platoon_enabled"])
    agent.cacc_rl_authority_floor = float(co_opt_config["cacc_rl_authority_floor"])
    agent.cacc_ppo_authority_min = float(co_opt_config["cacc_ppo_authority_min"])
    # v5.2.4: drop Lon samples of CAVs handed back to SUMO (action not executed).
    agent.keep_lon_noop_samples = bool(getattr(args, "keep_lon_noop_samples", False))
    # v4 algorithm switches (experiments/config.yaml: optimization).
    agent.cav_credit_mode = str(getattr(args, "cav_credit_mode", "coop_xapp") or "coop_xapp")
    agent.coop_kappa = float(getattr(args, "coop_kappa", 0.5))
    agent.dual_clip_c = float(getattr(args, "dual_clip_c", 3.0))
    agent.popart_enabled = bool(getattr(args, "popart", True))
    agent.signal_min_batch = int(getattr(args, "signal_min_batch", 128) or 0)
    print(
        f"[v4] credit={agent.cav_credit_mode} kappa={agent.coop_kappa} "
        f"dual_clip_c={agent.dual_clip_c} popart={agent.popart_enabled} "
        f"queue={getattr(args, 'queue_mode', 'halted')} "
        f"max_depart_delay={getattr(args, 'max_depart_delay', -1)} "
        f"od_rewrite={getattr(args, 'allow_od_rewrite', False)} "
        f"demand_randomize={getattr(args, 'demand_randomize', True)} "
        f"final_select={getattr(args, 'final_select', 'latest')}",
        flush=True,
    )

    checkpoint_dir = _resolve_checkpoint_dir(
        args, method, scenario_key, vlm_model=vlm_model
    )
    start_episode = 0
    ckpt = None
    _pre_lengths, _pre_starts = _resolve_stage_schedule(args)
    _lon_entry_ep = int(_pre_starts.get('Lon', 0) or 0)
    if bool(getattr(args, 'restart_stage_lon', False)):
        args.resume = True
        if not str(getattr(args, 'resume_from', '') or '').strip():
            _best_s_cand, _ = _preferred_stage_s_for_lon(
                checkpoint_dir,
                device,
                _BEST_STAGE_FILENAMES['S'],
                'pre_tail_best_stage_s.pt',
                'temp_ungated_best_stage_s.pt',
            )
            if _best_s_cand is not None:
                args.resume_from = str(_best_s_cand)
    if bool(getattr(args, 'resume', False)):
        resume_path = resolve_resume_file(
            checkpoint_dir, str(getattr(args, 'resume_from', '') or '')
        )
        ckpt = torch_load(resume_path, device)
        n_ckpt = int(ckpt.get('n_signal_actions') or 0)
        if n_ckpt and n_ckpt != int(n_signal_actions):
            raise ValueError(
                f"resume checkpoint n_signal_actions={n_ckpt} != current {n_signal_actions}"
            )
        signal_actor.load_state_dict(ckpt['signal_actor'])
        if bool(getattr(args, 'restart_stage_lon', False)):
            start_episode = _lon_entry_ep
            _archive_downstream_for_stage_lon_restart(
                checkpoint_dir,
                start_episode,
                source_s_ckpt=str(resume_path),
                results_dir=str(run_dir),
            )
            write_resume_meta(checkpoint_dir, start_episode)
        else:
            start_episode = completed_episodes(checkpoint_dir, ckpt=ckpt)
        # Only load lon/lat/critic weights when resuming past Stage-Lon entry;
        # when resuming at/before Stage-Lon entry (Stage-S checkpoint), keep
        # lon_actor freshly initialized at 0.0 m/s^2 for [-2.2, +1.0] bounds.
        if int(start_episode) > _lon_entry_ep and not bool(getattr(args, 'restart_stage_lon', False)):
            lon_key = 'lon_actor' if ckpt.get('lon_actor') is not None else 'cav_actor'
            if ckpt.get(lon_key) is not None:
                lon_actor.load_state_dict(ckpt[lon_key])
            if ckpt.get('lat_actor') is not None and lat_actor is not None:
                lat_actor.load_state_dict(ckpt['lat_actor'])
            if ckpt.get('critic') is not None:
                critic.load_state_dict(ckpt['critic'])
            _load_optimizer_state(
                agent.lon_optimizer, ckpt.get('lon_optimizer') or ckpt.get('cav_optimizer'), 'lon'
            )
            _load_optimizer_state(agent.lat_optimizer, ckpt.get('lat_optimizer'), 'lat')
            _load_optimizer_state(agent.critic_optimizer, ckpt.get('critic_optimizer'), 'critic')
        else:
            if ckpt.get('critic') is not None:
                critic.load_state_dict(ckpt['critic'])
            if int(start_episode) >= _lon_entry_ep or bool(getattr(args, 'restart_stage_lon', False)):
                agent.reset_team_value_head()
            lon_actor._initialize_policy()
            agent.reset_actor_optimizer_states()
            print(
                f"[resume] Stage-Lon clean entry at episode {start_episode + 1}: "
                f"loaded signal_actor + critic(gnn/signal_head) from {os.path.basename(str(resume_path))}, "
                f"reset critic.net/ret_rms & lon_actor neutral 0.0 m/s^2 in [{lon_actor.action_low}, {lon_actor.action_high}].",
                flush=True,
            )
        _load_optimizer_state(agent.signal_optimizer, ckpt.get('signal_optimizer'), 'signal')
        if ckpt.get('training_stage'):
            agent.set_training_stage(ckpt['training_stage'])
        _rms = ckpt.get('ret_rms')
        if isinstance(_rms, dict) and int(start_episode) > _lon_entry_ep and not bool(getattr(args, 'restart_stage_lon', False)):
            try:
                agent._ret_rms_mean = float(_rms.get('mean', 0.0))
                agent._ret_rms_var = float(_rms.get('var', 1.0))
                agent._ret_rms_count = float(_rms.get('count', 1e-4))
            except (TypeError, ValueError, OverflowError):
                pass
        _sig_rms = ckpt.get('sig_ret_rms')
        if isinstance(_sig_rms, dict):
            try:
                agent._sig_ret_rms_mean = float(_sig_rms.get('mean', 0.0))
                agent._sig_ret_rms_var = float(_sig_rms.get('var', 1.0))
                agent._sig_ret_rms_count = float(_sig_rms.get('count', 1e-4))
            except (TypeError, ValueError, OverflowError):
                pass
        print(
            f"[resume] loaded {resume_path} (completed episodes={start_episode}, "
            f"device={device}, next=Episode {start_episode + 1})"
        )
        if start_episode >= int(args.episodes):
            print(
                f"[resume] already finished {start_episode}/{args.episodes} episodes; nothing to do."
            )
            try:
                parallel_envs.close()
            finally:
                _join_worker_processes(processes)
            return

    # TB: fresh launch → new tb/<stamp>/; resume → reuse saved/discovered tb_run.
    tb_run = None
    if bool(getattr(args, 'resume', False)):
        tb_run = resume_tb_run_name(checkpoint_dir, ckpt=ckpt)
        if not tb_run:
            tb_run = discover_tb_run_for_resume(
                method, scenario_key, int(args.seed), vlm_model=vlm_model
            )
            if tb_run:
                print(
                    f"[paths] tensorboard reuse discovered run={tb_run} "
                    f"(no tb_run in checkpoint/meta)",
                    flush=True,
                )
    if tb_run:
        tb_log_dir = train_tb_run_dir(
            method, scenario_key, int(args.seed), tb_run, vlm_model=vlm_model
        )
        ensure_dir(tb_log_dir)
        print(f"[paths] tensorboard resume run={tb_run} dir={tb_log_dir}")
    else:
        tb_log_dir = allocate_train_tb_run_dir(
            method, scenario_key, int(args.seed), vlm_model=vlm_model
        )
        tb_run = tb_log_dir.name
        if bool(getattr(args, 'resume', False)):
            print(
                f"[paths] tensorboard new run={tb_run} (no reusable tb stamp) "
                f"dir={tb_log_dir}"
            )
        else:
            print(f"[paths] tensorboard run={tb_run} dir={tb_log_dir}")
    # On resume only: pull legacy flat tb/events into this stamp so TB shows one curve.
    if bool(getattr(args, 'resume', False)):
        tb_root = train_tb_dir(
            method, scenario_key, int(args.seed), vlm_model=vlm_model
        )
        migrated = migrate_flat_tb_events_into_run(tb_root, tb_log_dir)
        if migrated:
            print(
                f"[paths] tensorboard migrated {len(migrated)} flat event file(s) "
                f"into {tb_run} (parent tb/ + stamp now one continuous run)",
                flush=True,
            )
        # Hard guarantee: active stamp has no step >= next episode, no duplicate
        # steps, and no sibling stamps left visible under tb/ (prevents zigzag).
        if int(start_episode) > 0:
            from baselines.tb_curve_sanitize import sanitize_tb_for_resume

            tb_fix = sanitize_tb_for_resume(
                tb_root, str(tb_run), completed_episodes=int(start_episode)
            )
            reb = tb_fix.get("rebuild") or {}
            if reb.get("rewrote"):
                print(
                    f"[paths] tensorboard sanitized run={tb_run} "
                    f"keep_step<={int(start_episode)} "
                    f"dropped={reb.get('dropped')} deduped={reb.get('deduped')} "
                    f"parked_files={reb.get('files_in')}",
                    flush=True,
                )
            elif reb.get("reason") == "already_clean":
                print(
                    f"[paths] tensorboard run={tb_run} already clean "
                    f"(max_step<={reb.get('max_step')})",
                    flush=True,
                )
            quarantined = tb_fix.get("quarantined") or []
            if quarantined:
                print(
                    f"[paths] tensorboard quarantined sibling stamp(s): "
                    f"{', '.join(quarantined)}",
                    flush=True,
                )
    writer = SafeSummaryWriter(str(tb_log_dir))
    write_resume_meta(checkpoint_dir, start_episode, tb_run=tb_run)

    episode_rewards = []
    episode_rewards_per_env = []
    cav_rewards_per_env = []
    cav_lon_rewards_per_env = []
    cav_lat_rewards_per_env = []
    signal_rewards_per_env = []
    metrics_history = {
        'avg_travel_time': [],
        'avg_speed': [],
        'avg_waiting_time': [],
        'avg_queue_length': [],
        'avg_collisions': [],
        'num_stops': [],
        'num_conflicts': [],
        'fleet_avg_fuel': [],
        'fleet_avg_co2': [],
        'avg_fuel': [],  # alias of fleet_avg_fuel
        'avg_co2': [],   # alias of fleet_avg_co2
        'total_fuel_L': [],
        'total_co2_g': [],
        'veh_avg_fuel_L': [],
        'veh_avg_co2_g': [],
    }
    live_steps = []
    live_cav_rewards = []
    live_signal_rewards = []
    total_steps = 0
    vlm_abort_error = None
    results_dir = str(run_dir)
    os.makedirs(results_dir, exist_ok=True)
    history_start_episode = 0
    if bool(getattr(args, "resume", False)) and int(start_episode) > 0:
        restored_history = _restore_episode_history(
            results_dir,
            start_episode=int(start_episode),
            num_envs=int(args.num_envs),
            metrics_history=metrics_history,
        )
        if restored_history is not None:
            episode_rewards = restored_history["episode_rewards"]
            episode_rewards_per_env = restored_history["episode_rewards_per_env"]
            cav_rewards_per_env = restored_history["cav_rewards_per_env"]
            cav_lon_rewards_per_env = restored_history.get(
                "cav_lon_rewards_per_env",
                [[0.0] * int(args.num_envs) for _ in range(int(start_episode))],
            )
            cav_lat_rewards_per_env = restored_history.get(
                "cav_lat_rewards_per_env",
                [[0.0] * int(args.num_envs) for _ in range(int(start_episode))],
            )
            signal_rewards_per_env = restored_history["signal_rewards_per_env"]
            metrics_history = restored_history["metrics_history"]
        else:
            history_start_episode = int(start_episode)

    stage_lengths, stage_starts = _resolve_stage_schedule(args)
    print(
        "[curriculum] schedule "
        + ", ".join(
            f"{st}={stage_lengths[st]}(@{stage_starts[st]})"
            for st in _CURRICULUM_ORDER
            if int(stage_lengths.get(st, 0)) > 0
        ),
        flush=True,
    )
    # Match main-loop Best-S tail reset: only archive pre-tail best_stage_s on
    # resume when Stage-S actually uses a teacher (signal vision or rule teacher).
    # no_vlm keeps one continuous Best-S; do not wipe it at ep>=tail_start.
    _resume_has_s_teacher = bool(signal_vision) or bool(
        getattr(args, "rule_signal_teacher", False)
    )
    best_trackers = _load_best_stage_meta(
        checkpoint_dir,
        device,
        start_episode=int(start_episode),
        stage_s_len=(
            int(stage_lengths.get("S", 0) or 0) if _resume_has_s_teacher else 0
        ),
    )
    prev_stage = None
    # configure_stage resets the entering stage's live weights. Restore the
    # checkpoint snapshot after that first reset so Resume does not drop them.
    vlm_resume_pending = ckpt is not None
    # configure_control kwargs are run-constant (same args each episode).
    sent_control_kwargs = None
    joint_score_hist = []
    joint_coll_hist = []
    joint_baseline_score = None
    joint_baseline_collisions = 0.0
    # Rolling scores / collisions during Lon / Lat → realistic joint abort baseline.
    lon_score_hist = []
    lat_score_hist = []
    lon_coll_hist = []
    lat_coll_hist = []
    if start_episode > 0:
        # Resume mid-run: infer prior stage so we do not re-rollback on the same stage.
        prev_stage, _, _ = _stage_at_episode(
            max(0, int(start_episode) - 1), stage_lengths, stage_starts
        )
        # Refill prior-stage KPI histories so Joint baselines survive --resume.
        (
            lon_score_hist,
            lon_coll_hist,
            lat_score_hist,
            lat_coll_hist,
        ) = _refill_stage_kpi_hists(
            metrics_history, stage_lengths, stage_starts, int(start_episode)
        )
        if lon_score_hist or lat_score_hist:
            print(
                f"[resume] refilled stage KPI hist "
                f"lon={len(lon_score_hist)} lat={len(lat_score_hist)} "
                f"(coll_series={'yes' if metrics_history.get('avg_collisions') else 'no'})",
                flush=True,
            )

    if args.live_plot:
        import matplotlib.pyplot as plt
        plt.ion()
        fig, (ax_cav, ax_signal) = plt.subplots(2, 1, figsize=(10, 8))
        live_line_cav, = ax_cav.plot([], [], 'bo-', alpha=0.6, label='CAV Mean Reward')
        ax_cav.set_title('Real-time Agent Rewards (Episode Level)')
        ax_cav.set_ylabel('CAV Reward')
        ax_cav.legend(loc='upper left')
        ax_cav.grid(True)
        live_line_signal, = ax_signal.plot([], [], 'ro-', alpha=0.6, label='Signal Reward')
        ax_signal.set_xlabel('Episodes')
        ax_signal.set_ylabel('Signal Reward')
        ax_signal.legend(loc='upper left')
        ax_signal.grid(True)
        fig.tight_layout()

    try:
        skip_until_episode = int(start_episode)
        if bool(getattr(args, "eval_only", False)):
            # v5 (1.2): deterministic evaluation of one checkpoint (no updates).
            _run_eval_only(args, agent, parallel_envs, co_opt_config)
        for episode in range(start_episode, args.episodes):
            if episode < skip_until_episode:
                continue
            # S → Lon → JointLonSig → Lat → JointAll from dynamic schedule.
            stage, stage_episode, stage_len = _stage_at_episode(
                episode, stage_lengths, stage_starts
            )
            soft_start = (
                0
                if stage in ("JointLonSig", "JointAll")
                else _vlm_soft_start_episodes(args, stage)
            )

            # Cross-stage handoff: switch stage flags first (may reset ret_rms),
            # then load prior-stage best so restored ret_rms / critic survive.
            rolled_back = False
            entering_joint = (
                prev_stage is not None
                and stage != prev_stage
                and stage in ("JointLonSig", "JointAll")
            )
            agent.set_training_stage(stage)
            if prev_stage is not None and stage != prev_stage:
                rolled_back = bool(_rollback_stage_weights(
                    prev_stage,
                    stage,
                    checkpoint_dir,
                    device,
                    signal_actor,
                    lon_actor,
                    lat_actor,
                    parallel_envs=parallel_envs,
                    agent=agent,
                    critic=critic,
                    best_trackers=best_trackers,
                ))
                if stage in ("JointLonSig", "JointAll"):
                    joint_score_hist = []
                    joint_coll_hist = []
                    # Baseline = late prior-stage *mean*, not peak best_stage_*.
                    if stage == "JointLonSig":
                        joint_baseline_score = _joint_baseline_from_hist(
                            lon_score_hist, best_trackers.get("Lon")
                        )
                        _coll_src = lon_coll_hist
                    else:
                        joint_baseline_score = _joint_baseline_from_hist(
                            lat_score_hist, best_trackers.get("Lat")
                        )
                        _coll_src = lat_coll_hist
                    if _coll_src:
                        joint_baseline_collisions = float(
                            np.mean(_coll_src[-max(1, int(_JOINT_BASELINE_TAIL)):])
                        )
                    else:
                        joint_baseline_collisions = 0.0
                    print(
                        f"[joint] {stage} KPI baseline={joint_baseline_score} "
                        f"coll_baseline={joint_baseline_collisions:.2f} "
                        f"(tail mean of prior stage; not peak best)",
                        flush=True,
                    )
                elif prev_stage in ("JointLonSig", "JointAll"):
                    joint_score_hist = []
                    joint_coll_hist = []
                    joint_baseline_score = None
                    joint_baseline_collisions = 0.0
                    agent.joint_abort = False
                    if stage == "Lat":
                        lat_score_hist = []
                        lat_coll_hist = []
            if entering_joint:
                def _pack_entry():
                    return _pack_train_checkpoint(
                        args, agent, cav_actor, cav_residual_actor, signal_actor, critic,
                        n_signal_actions, completed_episodes_count=episode,
                        tb_run=tb_run, lat_actor=lat_actor,
                    )

                _setup_joint_entry(
                    stage,
                    checkpoint_dir,
                    device,
                    agent,
                    signal_actor,
                    lon_actor,
                    lat_actor,
                    _pack_entry,
                )
                # Re-apply stage so LR flags pick up anchors / abort=False.
                agent.set_training_stage(stage)
            # Stage-aware actor LR: new stage always starts at 1.0x; decay only
            # after *this* stage's soft-start using this stage's length.
            _quick = bool(getattr(args, "quick", False))
            lr_scale = _stage_actor_lr_scale(
                stage, stage_episode, stage_len, soft_start, quick=_quick
            )
            if hasattr(agent, "apply_active_actor_lr_scale"):
                agent.apply_active_actor_lr_scale(lr_scale)
            if not hasattr(agent, "_base_entropy_coef"):
                agent._base_entropy_coef = float(agent.entropy_coef)
            ent_scale = _stage_entropy_coef_scale(
                stage, stage_episode, stage_len, soft_start, quick=_quick
            )
            _has_s_teacher = bool(signal_vision) or bool(
                getattr(args, "rule_signal_teacher", False)
            )
            # No terminal entropy inflation (was 3.0× / 1.8×); floor already 0.25.
            agent.entropy_coef = float(agent._base_entropy_coef) * float(ent_scale)
            # Teacher soft-start defaults to 5; allow SIGNAL_TEACHER_SOFT_START_EPISODES
            # override for short diagnostic grids (independent of LR soft_start).
            try:
                _teacher_soft = max(
                    0,
                    int(
                        str(
                            os.environ.get("SIGNAL_TEACHER_SOFT_START_EPISODES", "5")
                        ).strip()
                        or "5"
                    ),
                )
            except (TypeError, ValueError, OverflowError):
                _teacher_soft = 5
            _beta_t = float(
                _signal_teacher_beta(
                    stage,
                    stage_episode,
                    stage_len,
                    _teacher_soft,
                    signal_vlm_vision=bool(signal_vision),
                    rule_signal_teacher=bool(
                        getattr(args, "rule_signal_teacher", False)
                    ),
                )
            )
            agent.teacher_beta = _beta_t
            agent.signal_teacher_beta = _beta_t
            if hasattr(agent, "teacher_conf_threshold"):
                agent.teacher_conf_threshold = float(TEACHER_CONFIDENCE_THRESHOLD)
            prev_stage = stage

            top3 = bool(getattr(args, 'top3_mask', True))
            coop_policy = 'off'
            # NOTE: per-episode configure_coop intentionally not sent:
            # AdaptiveReward.configure_coop is a legacy no-op (del kwargs),
            # so this was a pure IPC round-trip per env per episode.
            if hasattr(parallel_envs, 'configure_stage'):
                parallel_envs.configure_stage(
                    stage,
                    top3_mask=top3,
                    coop_policy=coop_policy,
                    stage_episode=int(stage_episode),
                    soft_start=int(soft_start),
                    stage_len=int(stage_len),
                )
            # Lon/Lat action soft-start β (IDM mix / keep-bias); agent reads this.
            from baselines.episode_timing import action_blend_beta

            _blend = float(
                action_blend_beta(int(stage_episode), int(soft_start), stage=str(stage))
            )
            agent.action_blend_beta = _blend
            # Soft-start imitation toward shield/IDM-executed accel (Lon/JLS).
            if str(stage) in ("Lon", "JointLonSig") and _blend < 1.0 - 1e-6:
                agent.imitation_coef = float(
                    float(getattr(args, "lon_imitation_scale", 0.10)) * (1.0 - _blend)
                )
            else:
                agent.imitation_coef = 0.0
            if vlm_resume_pending:
                # Stage-entry reset runs inside configure_stage. Put the
                # checkpoint weights back afterwards. A successful best-ckpt
                # handoff on this same episode already loaded W_sig / W_long;
                # do not overwrite those with latest.pt.
                if not rolled_back:
                    _restore_vlm_snapshot(parallel_envs, ckpt)
                vlm_resume_pending = False
            if hasattr(parallel_envs, 'configure_control'):
                control_kwargs = _build_control_kwargs(args, co_opt_config, top3)
                # Knobs are run-constant: resend only on change (first episode).
                if control_kwargs != sent_control_kwargs:
                    parallel_envs.configure_control(**control_kwargs)
                    sent_control_kwargs = dict(control_kwargs)
            
            # Default: per-episode SUMO seeds with *10000 stride (no cross-run overlap).
            # Debug lock: SUMO_PER_EPISODE_SEED=0 → args.seed + env_index only.
            _tr0 = time.perf_counter()
            obs_list = parallel_envs.reset(
                seeds=_sumo_reset_seeds(args.seed, episode, args.num_envs)
            )
            _t_reset = time.perf_counter() - _tr0
            rollouts = [empty_rollout() for _ in range(args.num_envs)]
            
            env_ep_rewards = [0.0 for _ in range(args.num_envs)]
            env_cav_rewards = [0.0 for _ in range(args.num_envs)]
            env_cav_lon_rewards = [0.0 for _ in range(args.num_envs)]
            env_cav_lat_rewards = [0.0 for _ in range(args.num_envs)]
            env_signal_rewards = [0.0 for _ in range(args.num_envs)]
            total_collisions = 0
            total_teleports = 0
            total_safety_incidents = 0
            final_signal_rewards = [0.0 for _ in range(args.num_envs)]
            final_sig_formal_rewards = [0.0 for _ in range(args.num_envs)]
            final_sig_residual_rewards = [0.0 for _ in range(args.num_envs)]
            final_sig_residual_nonzero_frac = [0.0 for _ in range(args.num_envs)]
            final_spill_proxy_mean = [0.0 for _ in range(args.num_envs)]
            final_lon_residual = [0.0 for _ in range(args.num_envs)]
            final_lon_residual_nz = [0.0 for _ in range(args.num_envs)]
            final_lon_exposed = [0.0 for _ in range(args.num_envs)]
            final_net_waiting_time = [0.0 for _ in range(args.num_envs)]
            final_cav_rewards = [0.0 for _ in range(args.num_envs)]
            final_cav_lon_rewards = [0.0 for _ in range(args.num_envs)]
            final_cav_lat_rewards = [0.0 for _ in range(args.num_envs)]
            final_sig_wait_inc = [0.0 for _ in range(args.num_envs)]
            final_sig_speed_term = [0.0 for _ in range(args.num_envs)]
            final_sig_wait_s = [0.0 for _ in range(args.num_envs)]
            final_sig_exposure = [0.0 for _ in range(args.num_envs)]
            final_avg_travel_time = [0.0 for _ in range(args.num_envs)]
            final_v4_kpis = [dict() for _ in range(args.num_envs)]
            sig_decisions_ep = 0
            sig_overrides_ep = 0
            _tm = {"reset": _t_reset, "env": 0.0, "policy": 0.0, "critic": 0.0, "update": 0.0}
            _ep_t0 = time.perf_counter() - _t_reset
            final_avg_speed = [0.0 for _ in range(args.num_envs)]
            final_avg_waiting_time = [0.0 for _ in range(args.num_envs)]
            final_avg_queue_length = [0.0 for _ in range(args.num_envs)]
            final_num_stops = [0.0 for _ in range(args.num_envs)]
            final_num_conflicts = [0.0 for _ in range(args.num_envs)]
            final_fleet_avg_fuel = [0.0 for _ in range(args.num_envs)]
            final_fleet_avg_co2 = [0.0 for _ in range(args.num_envs)]
            final_total_fuel_L = [0.0 for _ in range(args.num_envs)]
            final_total_co2_g = [0.0 for _ in range(args.num_envs)]
            final_veh_avg_fuel_L = [0.0 for _ in range(args.num_envs)]
            final_veh_avg_co2_g = [0.0 for _ in range(args.num_envs)]
            final_lambda_flow = [0.0 for _ in range(args.num_envs)]
            final_lambda_plat = [0.0 for _ in range(args.num_envs)]
            # Observe-only red-gap diagnosis (CAV/HDV); reward formula unchanged.
            _red_gap_keys = (
                "red_gap_cav_n",
                "red_gap_cav_mean",
                "red_gap_cav_pack_frac",
                "red_gap_cav_gt4p5_frac",
                "red_gap_cav_gt6_frac",
                "red_gap_hdv_n",
                "red_gap_hdv_mean",
                "red_gap_hdv_pack_frac",
                "red_gap_hdv_gt4p5_frac",
                "red_gap_hdv_gt6_frac",
                "red_gap_cav_both_slow_n",
                "red_gap_cav_both_slow_mean",
                "red_gap_cav_both_slow_pack_frac",
                "red_gap_cav_both_slow_gt4p5_frac",
                "red_gap_hdv_both_slow_n",
                "red_gap_hdv_both_slow_mean",
                "red_gap_hdv_both_slow_pack_frac",
                "red_gap_hdv_both_slow_gt4p5_frac",
                # v5.2.1 split: true queue gap vs head-of-queue (leader past line)
                "red_gap_cav_queue_n",
                "red_gap_cav_queue_mean",
                "red_gap_cav_queue_pack_frac",
                "red_gap_cav_queue_creep_frac",
                "red_gap_hdv_queue_n",
                "red_gap_hdv_queue_mean",
                "red_gap_hdv_queue_pack_frac",
                "red_gap_hdv_queue_creep_frac",
                "red_gap_cav_head_n",
                "red_gap_hdv_head_n",
            )
            final_red_gap = {
                k: [0.0 for _ in range(args.num_envs)] for k in _red_gap_keys
            }
            env_alive = [True for _ in range(args.num_envs)]
            update_losses = []
            # Per-env CAV accel hold caches (refreshed every cav_hold_steps).
            cav_action_cache = [{} for _ in range(args.num_envs)]
            cav_logp_cache = [{} for _ in range(args.num_envs)]
            last_critic = [None for _ in range(args.num_envs)]
            value_on_decision = str(os.environ.get("P1_VALUE_ON_DECISION", "0")).strip().lower() in (
                "1", "true", "yes", "on"
            )

            # Each parallel env must run the full control horizon. Dividing by
            # num_envs previously truncated multi-env episodes (e.g. 4 envs →
            # 1/4 length). Rollout flush still uses horizon // num_envs below.
            steps_per_env = int(args.max_steps)

            for step in range(steps_per_env):
                if not any(env_alive):
                    break

                cav_decision = (step % cav_hold_steps == 0)
                actions_list = []
                learn_actions_list = []
                log_probs_list = []
                values_list = []
                sig_values_list = []
                lambdas_list = []

                for i in range(args.num_envs):
                    if not env_alive[i]:
                        actions_list.append({})
                        learn_actions_list.append({})
                        log_probs_list.append({})
                        values_list.append(0.0)
                        sig_values_list.append(0.0)
                        lambdas_list.append(np.asarray([0.5, 0.5], dtype=np.float32))
                        cav_action_cache[i] = {}
                        cav_logp_cache[i] = {}
                        continue
                    obs = obs_list[i]
                    global_graph = graph_from_obs(obs)
                    _tc0 = time.perf_counter()
                    if value_on_decision and (not cav_decision) and last_critic[i] is not None:
                        value, sig_value = last_critic[i]
                    else:
                        value, sig_value = _evaluate_critic_values(agent, global_graph)
                        last_critic[i] = (value, sig_value)
                    _tp0 = time.perf_counter()
                    _tm['critic'] += _tp0 - _tc0
                    actions, log_probs = agent.select_actions(
                        obs,
                        cav_decision=cav_decision,
                        cav_action_cache=cav_action_cache[i],
                        cav_logp_cache=cav_logp_cache[i],
                    )
                    actions, log_probs, cav_action_cache[i], cav_logp_cache[i] = hold_cav_actions(
                        actions,
                        log_probs,
                        cav_action_cache[i],
                        cav_logp_cache[i],
                        refresh=cav_decision,
                    )
                    _tm['policy'] += time.perf_counter() - _tp0
                    lambdas = np.asarray([0.5, 0.5], dtype=np.float32)

                    values_list.append(value)
                    sig_values_list.append(sig_value)
                    actions_list.append(env_actions_only(actions))
                    learn_actions_list.append(actions)
                    log_probs_list.append(log_probs)
                    lambdas_list.append(lambdas)

                _te0 = time.perf_counter()
                next_obs_list, rewards_list, dones_list, infos_list = parallel_envs.step(
                    actions_list, episode, step, lambdas_list, alive_mask=list(env_alive)
                )
                _tm['env'] += time.perf_counter() - _te0

                env_terminals = [False for _ in range(args.num_envs)]
                for i in range(args.num_envs):
                    if not env_alive[i]:
                        continue

                    rollout = rollouts[i]
                    obs = obs_list[i]
                    actions = learn_actions_list[i]
                    log_probs = log_probs_list[i]
                    value = values_list[i]
                    rewards = rewards_list[i]
                    dones = dones_list[i]
                    infos = infos_list[i]

                    team_info = infos['__all__']
                    # Episode score: R_ep = α*mean(r_cav) + β*mean(r_signal), β≈std_cav/std_signal
                    env_ep_rewards[i] = float(
                        team_info.get('episode_total_reward', team_info['global_reward'])
                    )
                    total_collisions += int(team_info.get('collisions', 0) or 0)
                    total_teleports += int(team_info.get('teleports', 0) or 0)
                    total_safety_incidents += int(
                        team_info.get(
                            'safety_incidents',
                            int(team_info.get('collisions', 0) or 0)
                            + int(team_info.get('teleports', 0) or 0),
                        )
                    )
                    # Keep only the latest cumulative episode metrics (not a running sum of means).
                    # Signal TB/plot uses mean (same scale as CAV), not the raw sum.
                    final_signal_rewards[i] = float(
                        team_info.get(
                            'episode_reward_signal_mean',
                            team_info.get('episode_reward_signal', 0.0),
                        )
                    )
                    final_sig_formal_rewards[i] = float(
                        team_info.get('episode_reward_signal_formal_mean', 0.0)
                    )
                    final_sig_residual_rewards[i] = float(
                        team_info.get('episode_reward_signal_residual_mean', 0.0)
                    )
                    final_sig_residual_nonzero_frac[i] = float(
                        team_info.get(
                            'episode_reward_signal_residual_nonzero_frac', 0.0
                        )
                    )
                    final_spill_proxy_mean[i] = float(
                        team_info.get('episode_spill_proxy_mean', 0.0)
                    )
                    final_lon_residual[i] = float(
                        team_info.get('episode_lon_residual_mean', 0.0)
                    )
                    final_lon_residual_nz[i] = float(
                        team_info.get('episode_lon_residual_nonzero_frac', 0.0)
                    )
                    final_lon_exposed[i] = float(
                        team_info.get('episode_lon_exposed_frac', 0.0)
                    )
                    final_cav_rewards[i] = float(team_info.get('episode_reward_cav_mean', 0.0))
                    final_cav_lon_rewards[i] = float(
                        team_info.get('episode_reward_cav_lon_mean', 0.0)
                    )
                    final_cav_lat_rewards[i] = float(
                        team_info.get('episode_reward_cav_lat_mean', 0.0)
                    )
                    final_sig_wait_inc[i] = float(
                        team_info.get(
                            'signal_waiting_increment_mean',
                            final_signal_rewards[i],
                        )
                    )
                    final_sig_speed_term[i] = float(
                        team_info.get('signal_speed_term_mean', 0.0)
                    )
                    final_sig_wait_s[i] = float(
                        team_info.get('signal_waiting_seconds', 0.0)
                    )
                    final_sig_exposure[i] = float(
                        team_info.get('signal_vehicle_time_exposure', 0.0)
                    )

                    env_signal_rewards[i] = final_signal_rewards[i]
                    env_cav_rewards[i] = final_cav_rewards[i]
                    env_cav_lon_rewards[i] = final_cav_lon_rewards[i]
                    env_cav_lat_rewards[i] = final_cav_lat_rewards[i]

                    final_avg_travel_time[i] = float(team_info.get('avg_travel_time', 0.0))
                    final_v4_kpis[i] = {_k: float(team_info.get(_k, 0.0) or 0.0) for _k in _V4_EXTRA_KPI_KEYS}
                    final_avg_speed[i] = float(team_info.get('avg_speed', team_info.get('network_avg_speed', 0.0)))
                    final_avg_waiting_time[i] = float(
                        team_info.get('avg_waiting_time', team_info.get('network_avg_waiting_time', 0.0))
                    )
                    final_net_waiting_time[i] = float(
                        team_info.get(
                            'network_avg_waiting_time',
                            final_avg_waiting_time[i],
                        )
                    )
                    final_avg_queue_length[i] = float(team_info.get('avg_queue_length', 0.0))
                    final_num_stops[i] = float(team_info.get('num_stops', 0.0))
                    final_num_conflicts[i] = float(
                        team_info.get('num_conflicts', team_info.get('total_conflicts', 0.0))
                    )
                    final_fleet_avg_fuel[i] = float(
                        team_info.get('fleet_avg_fuel', team_info.get('avg_fuel', 0.0))
                    )
                    final_fleet_avg_co2[i] = float(
                        team_info.get('fleet_avg_co2', team_info.get('avg_co2', 0.0))
                    )
                    final_total_fuel_L[i] = float(team_info.get('total_fuel_L', 0.0))
                    final_total_co2_g[i] = float(team_info.get('total_co2_g', 0.0))
                    final_veh_avg_fuel_L[i] = float(team_info.get('veh_avg_fuel_L', 0.0))
                    final_veh_avg_co2_g[i] = float(team_info.get('veh_avg_co2_g', 0.0))
                    final_lambda_flow[i] = float(team_info.get('lambda_flow', 0.0))
                    final_lambda_plat[i] = float(team_info.get('lambda_plat', 0.0))
                    for _rgk in final_red_gap:
                        final_red_gap[_rgk][i] = float(team_info.get(_rgk, 0.0) or 0.0)

                    learn_actions = learning_actions_from_obs(
                        obs, actions, cav_decision=cav_decision
                    )
                    agent_done_map = {
                        agent_id: bool(dones.get(agent_id, False))
                        for agent_id in actions
                    }

                    # v5 (1.1): detect signal samples whose sampled phase was overridden.
                    _la = learn_actions if isinstance(learn_actions, dict) else {}
                    _overridden = set()
                    for _tls, _pair in (team_info.get('signal_exec') or {}).items():
                        _aid = f"signal_{_tls}"
                        try:
                            _sampled = int(_la.get(_aid, -1))
                        except (TypeError, ValueError):
                            _sampled = -1
                        if _sampled < 0:
                            continue
                        sig_decisions_ep += 1
                        try:
                            _executed = int(_pair[1])
                        except (TypeError, ValueError, IndexError):
                            continue
                        if _executed != _sampled:
                            _overridden.add(_aid)
                            sig_overrides_ep += 1
                    rollout.setdefault('signal_overridden', []).append(_overridden)
                    rollout.setdefault('lon_noop_vids', []).append(
                        frozenset(str(v) for v in (team_info.get('lon_noop_vids') or ()))
                    )
                    rollout['obs'].append(obs)
                    rollout['actions'].append(learn_actions)
                    rollout['log_probs'].append(log_probs)
                    rollout['agent_dones'].append(agent_done_map)
                    rollout['global_obs'].append(graph_from_obs(obs))
                    rollout['rewards'].append(rewards)
                    _lon_formal = team_info.get('lon_formal_by_agent') or {}
                    rollout['lon_formal_rewards'].append(
                        dict(_lon_formal) if isinstance(_lon_formal, dict) else {}
                    )
                    _term_inc = team_info.get('terminal_incident_agents') or ()
                    rollout['terminal_incidents'].append(list(_term_inc))
                    _applied = team_info.get('applied_cav_actions') or {}
                    rollout['applied_cav_actions'].append(
                        dict(_applied) if isinstance(_applied, dict) else {}
                    )
                    rollout['team_rewards'].append(float(team_info['global_reward']))
                    rollout['values'].append(value)
                    rollout['signal_values'].append(sig_values_list[i])
                    if cav_decision and bool(getattr(agent, "individual_critic", False)):
                        indiv = agent.individual_values(obs) if hasattr(agent, "individual_values") else {}
                    else:
                        indiv = {}
                    rollout.setdefault("indiv_values", []).append(indiv)
                    env_done = bool(dones.get('__all__', False))
                    rollout['dones'].append(env_done)
                    rollout['coop_terms'].append(team_info['coop_terms'])

                    if env_done:
                        env_terminals[i] = True
                        env_alive[i] = False
                        cav_action_cache[i] = {}
                        cav_logp_cache[i] = {}
                        last_critic[i] = None

                    fatal = team_info.get('vlm_fatal_error')
                    if fatal and bool(getattr(args, 'vlm_fail_stop', True)):
                        vlm_abort_error = str(fatal)

                obs_list = list(next_obs_list)
                total_steps += sum(1 for alive in env_alive if alive) + sum(1 for t in env_terminals if t)

                if vlm_abort_error:
                    # Keep latest weights; resume restarts this incomplete episode.
                    os.makedirs(checkpoint_dir, exist_ok=True)
                    emergency = _pack_train_checkpoint(
                        args, agent, cav_actor, cav_residual_actor, signal_actor, critic,
                        n_signal_actions, completed_episodes_count=episode,
                        tb_run=tb_run, lat_actor=lat_actor,
                        extra={'vlm_weights': _collect_vlm_snapshot(parallel_envs)},
                    )
                    ckpt_path = os.path.join(checkpoint_dir, 'latest.pt')
                    _atomic_torch_save(emergency, ckpt_path)
                    write_resume_meta(checkpoint_dir, episode, tb_run=tb_run)
                    print(
                        f"\n[ABORT] VLM call failed — training stopped at "
                        f"Episode {episode + 1}, step {step}.\n"
                        f"  reason: {vlm_abort_error}\n"
                        f"  checkpoint: {ckpt_path}\n"
                        f"  completed episodes kept: {episode}\n"
                        f"  After fixing the API/local VLM, continue with the same "
                        f"command plus --resume\n"
                        f"  (next run starts at Episode {episode + 1}).",
                        flush=True,
                    )
                    break

            # Modified: We no longer plot at step level. We will plot at episode level instead.
            # (Live plot code at step level removed)

                if vlm_abort_error:
                    break

                horizon_hit = any(
                    len(rollouts[i]['global_obs']) >= (args.rollout_horizon // args.num_envs)
                    for i in range(args.num_envs)
                    if env_alive[i] or env_terminals[i] or rollouts[i]['global_obs']
                )
                
                # [优化] 只有当达到 horizon 或者所有存活的环境都已经 done，才触发 update。
                # 避免仅仅因为某一个环境提前终止，就把其他环境正常运行的 rollout 强行 flush。
                all_done = not any(env_alive)
                
                if horizon_hit or all_done:
                    for i in range(args.num_envs):
                        if not rollouts[i]['global_obs']:
                            continue
                        compute_gae_for_rollout(
                            agent,
                            rollouts[i],
                            obs_list[i],
                            terminal=env_terminals[i],
                        )
                    tail_steps = sum(len(rollouts[i]['global_obs']) for i in range(args.num_envs))
                    agent._force_signal_one_epoch = bool(
                        all_done and update_losses and tail_steps < 256
                    )
                    try:
                        _tu0 = time.perf_counter()
                        losses = merge_and_update(agent, rollouts)
                        _tm['update'] += time.perf_counter() - _tu0
                    finally:
                        agent._force_signal_one_epoch = False
                    if losses is not None:
                        update_losses.append(losses)
                    rollouts = [empty_rollout() for _ in range(args.num_envs)]

                if step > 0 and step % max(3600 // args.num_envs, 1) == 0:
                    alive_n = sum(1 for a in env_alive if a)
                    print(
                        f'  [Episode {episode + 1}] Step {step}/{steps_per_env} '
                        f'completed (alive envs={alive_n}/{args.num_envs})...'
                    )
                    sys.stdout.flush()

                if any(env_terminals):
                    finished = sum(1 for t in env_terminals if t)
                    reasons = []
                    for i in range(args.num_envs):
                        if not env_terminals[i]:
                            continue
                        reason = str(
                            (infos_list[i].get("__all__") or {}).get("done_reason", "")
                            or "unknown"
                        )
                        reasons.append(reason)
                    reason_txt = ",".join(reasons) if reasons else "unknown"
                    print(
                        f"[Info] [Episode {episode + 1}] {finished} env(s) finished at step {step} "
                        f"(reason={reason_txt}; collisions do not hard-stop)."
                    )

            if vlm_abort_error:
                break

            # Flush remaining rollouts; only mark terminal for envs that already ended.
            if any(r['global_obs'] for r in rollouts):
                for i in range(args.num_envs):
                    if not rollouts[i]['global_obs']:
                        continue
                    compute_gae_for_rollout(
                        agent,
                        rollouts[i],
                        obs_list[i],
                        terminal=not env_alive[i],
                    )
                tail_steps = sum(len(rollouts[i]['global_obs']) for i in range(args.num_envs))
                # Same short-tail guard as the in-loop flush: leftover <256 after
                # this episode already updated once → signal actor trains 1 epoch.
                agent._force_signal_one_epoch = bool(
                    update_losses and tail_steps < 256
                )
                try:
                    _tu0 = time.perf_counter()
                    losses = merge_and_update(agent, rollouts)
                    _tm['update'] += time.perf_counter() - _tu0
                finally:
                    agent._force_signal_one_epoch = False
                if losses is not None:
                    update_losses.append(losses)

            loss_keys = (
                'cav_actor', 'lat_actor', 'lon_actor', 'signal_actor', 'critic',
                'teacher_valid_samples', 'teacher_loss', 'teacher_beta',
                'teacher_agreement_rate', 'teacher_severity_mean',
                'signal_entropy', 'signal_grad_norm',
            )
            mean_losses = {
                key: float(np.mean([loss.get(key, 0.0) for loss in update_losses]))
                if update_losses
                else 0.0
                for key in loss_keys
            }
            # valid_samples: sum across flushes in the episode, not mean.
            if update_losses:
                mean_losses['teacher_valid_samples'] = float(
                    np.sum([loss.get('teacher_valid_samples', 0.0) for loss in update_losses])
                )

            avg_ep_reward = float(np.mean(env_ep_rewards))
            avg_signal_reward = float(np.mean(final_signal_rewards))
            avg_sig_formal = float(np.mean(final_sig_formal_rewards))
            avg_sig_residual = float(np.mean(final_sig_residual_rewards))
            avg_sig_residual_nz = float(np.mean(final_sig_residual_nonzero_frac))
            avg_spill_proxy = float(np.mean(final_spill_proxy_mean))
            avg_lon_residual = float(np.mean(final_lon_residual))
            avg_lon_residual_nz = float(np.mean(final_lon_residual_nz))
            avg_lon_exposed = float(np.mean(final_lon_exposed))
            avg_cav_reward = float(np.mean(final_cav_rewards))
            avg_cav_lon_reward = float(np.mean(final_cav_lon_rewards))
            avg_cav_lat_reward = float(np.mean(final_cav_lat_rewards))
            avg_collisions = total_collisions / args.num_envs
            avg_teleports = total_teleports / args.num_envs
            avg_safety_incidents = total_safety_incidents / args.num_envs
            # KPI means across parallel envs (usually num_envs=1)
            avg_travel_time = float(np.mean(final_avg_travel_time))
            avg_speed = float(np.mean(final_avg_speed))
            avg_waiting_time = float(np.mean(final_avg_waiting_time))
            avg_net_waiting_time = float(np.mean(final_net_waiting_time))
            avg_queue_length = float(np.mean(final_avg_queue_length))
            avg_num_stops = float(np.mean(final_num_stops))
            avg_num_conflicts = float(np.mean(final_num_conflicts))
            fleet_avg_fuel = float(np.mean(final_fleet_avg_fuel))
            fleet_avg_co2 = float(np.mean(final_fleet_avg_co2))
            total_fuel_L = float(np.mean(final_total_fuel_L))
            total_co2_g = float(np.mean(final_total_co2_g))
            veh_avg_fuel_L = float(np.mean(final_veh_avg_fuel_L))
            veh_avg_co2_g = float(np.mean(final_veh_avg_co2_g))

            print(
                format_episode_log(
                    episode + 1,
                    args.episodes,
                    total_reward=avg_ep_reward,
                    signal_reward=avg_signal_reward,
                    cav_reward=avg_cav_reward,
                    avg_speed=avg_speed,
                    avg_travel_time=avg_travel_time,
                    avg_waiting_time=avg_waiting_time,
                    avg_queue_length=avg_queue_length,
                    num_stops=avg_num_stops,
                    num_conflicts=avg_num_conflicts,
                    fleet_avg_fuel=fleet_avg_fuel,
                    fleet_avg_co2=fleet_avg_co2,
                    avg_fuel=fleet_avg_fuel,
                    avg_co2=fleet_avg_co2,
                    total_fuel_L=total_fuel_L,
                    total_co2_g=total_co2_g,
                    veh_avg_fuel_L=veh_avg_fuel_L,
                    veh_avg_co2_g=veh_avg_co2_g,
                    stage=agent.training_stage,
                    extra=(
                        # v5.2.4: paper KPI + gridlock indicators on the console line
                        # (TravelT hides vehicles that never got inserted).
                        f"TIS: {float(np.mean([fe.get('avg_time_in_system', 0.0) for fe in final_v4_kpis])):.1f}s | "
                        f"Backlog: {float(np.mean([fe.get('insertion_backlog', 0.0) for fe in final_v4_kpis])):.0f} | "
                        f"Teleports: {float(avg_teleports):.0f} | "
                        f"Collisions: {float(avg_collisions):.0f}"
                    ),
                )
            )
            _js = {
                _k: float(np.mean([fe.get(_k, 0.0) for fe in final_v4_kpis]))
                for _k in V524_KPI_KEYS
            }
            print(
                f"[Diag-JStall] ep={episode + 1} stage={agent.training_stage} "
                f"sig_box_standstill_s ctrlCAV={_js['jstall_sig_ctrl_cav_s']:.0f} "
                f"freeCAV={_js['jstall_sig_free_cav_s']:.0f} HDV={_js['jstall_sig_hdv_s']:.0f} "
                f"| >=10s events ctrlCAV={_js['jstall_ctrl_cav_events']:.0f} "
                f"freeCAV={_js['jstall_free_cav_events']:.0f} HDV={_js['jstall_hdv_events']:.0f} "
                f"| unsig_box_s={_js['jstall_unsig_s']:.0f} "
                f"| lon_noop={_js['lon_noop_frac']:.2f} handback(idm_fol={_js['lon_handback_idm_follower']:.0f} "
                f"native={_js['lon_handback_native_idm']:.0f} near={_js['lon_handback_near_stopline']:.0f} "
                f"junc={_js['lon_handback_junction']:.0f}) "
                f"ppo_noop_dropped={int(getattr(agent, '_v524_noop_skipped', 0))}",
                flush=True,
            )
            _au = {
                _k: float(np.mean([fe.get(_k, 0.0) for fe in final_v4_kpis]))
                for _k in V6_AUTH_KPI_KEYS
            }
            print(
                f"[Diag-Auth] ep={episode + 1} stage={agent.training_stage} "
                f"n={_au['auth_n']:.0f} res(policy={_au['auth_policy_res_mean']:+.3f} "
                f"stack={_au['auth_stack_res_mean']:+.3f} realized={_au['auth_realized_res_mean']:+.3f}) "
                f"stack_cut={_au['auth_stack_cut_frac']:.2f} stack_lift={_au['auth_stack_lift_frac']:.2f} "
                f"pos_policy={_au['auth_policy_pos_frac']:.2f} pos_exec_ratio={_au['auth_pos_exec_ratio']:.2f} "
                f"sumo_cut={_au['auth_sumo_cut_frac']:.2f} sumo_lift={_au['auth_sumo_lift_frac']:.2f}",
                flush=True,
            )
            agent._v524_noop_skipped = 0
            agent._v524_lon_kept = 0
            _t_beta = float(
                mean_losses.get(
                    "teacher_beta",
                    getattr(agent, "teacher_beta", getattr(agent, "signal_teacher_beta", 0.0)),
                )
            )
            _t_valid = int(mean_losses.get("teacher_valid_samples", 0.0) or 0)
            _t_loss = float(mean_losses.get("teacher_loss", 0.0) or 0.0)
            _t_agree = float(mean_losses.get("teacher_agreement_rate", 0.0) or 0.0)
            _t_gnorm = float(mean_losses.get("signal_grad_norm", 0.0) or 0.0)
            print(
                f"[Teacher-Guided] ep={episode + 1} stage={agent.training_stage} "
                f"beta={_t_beta:.4f} valid_teacher_samples={_t_valid} "
                f"teacher_loss={_t_loss:.4f} agree={_t_agree:.2f} "
                f"grad_norm={_t_gnorm:.4f}",
                flush=True,
            )
            sys.stdout.flush()

            # TB x-axis is 1-based Episode index.
            tb_step = int(episode) + 1
            # Rewards
            writer.add_scalar('Reward/Total_Episode_Reward', avg_ep_reward, tb_step)
            # Signal: total = formal (+ 3leg speed blend) + VLM residual.
            writer.add_scalar('Reward/Signal_Reward', avg_signal_reward, tb_step)
            writer.add_scalar('Reward/Signal_Formal', avg_sig_formal, tb_step)
            writer.add_scalar('Reward/Signal_Residual', avg_sig_residual, tb_step)
            writer.add_scalar(
                'Reward/Signal_Residual_NonzeroFrac', avg_sig_residual_nz, tb_step
            )
            writer.add_scalar('VLM/spill_proxy_mean', avg_spill_proxy, tb_step)
            writer.add_scalar('Reward/Lon_Residual', avg_lon_residual, tb_step)
            writer.add_scalar(
                'Reward/Lon_Residual_NonzeroFrac', avg_lon_residual_nz, tb_step
            )
            writer.add_scalar('Reward/Lon_ExposedFrac', avg_lon_exposed, tb_step)
            writer.add_scalar(
                'Reward/Signal_Waiting_Increment',
                float(np.mean(final_sig_wait_inc)),
                tb_step,
            )
            writer.add_scalar(
                'Reward/Signal_Speed_Term',
                float(np.mean(final_sig_speed_term)),
                tb_step,
            )
            writer.add_scalar(
                'Metrics/Signal_Waiting_Seconds',
                float(np.mean(final_sig_wait_s)),
                tb_step,
            )
            writer.add_scalar(
                'Metrics/Signal_Vehicle_Time_Exposure',
                float(np.mean(final_sig_exposure)),
                tb_step,
            )
            # Per-vehicle (r_lon+r_lat) mean — aligned with team CAV part (log only).
            writer.add_scalar('Reward/CAV_Mean_Reward', avg_cav_reward, tb_step)
            # Diagnostics: lon all samples; lat = dlc_eligible samples only.
            writer.add_scalar('Reward/CAV_Lon_Mean', avg_cav_lon_reward, tb_step)
            writer.add_scalar('Reward/CAV_Lat_Mean', avg_cav_lat_reward, tb_step)
            # Traffic KPIs (mean over parallel sims)
            writer.add_scalar('Metrics/Average_Travel_Time', avg_travel_time, tb_step)
            # v4 KPIs: prefer avg_time_in_system in papers; TTC exposure in seconds.
            for _k in _V4_EXTRA_KPI_KEYS:
                writer.add_scalar(
                    f"Metrics/{_k}",
                    float(np.mean([fe.get(_k, 0.0) for fe in final_v4_kpis])),
                    tb_step,
                )
            writer.add_scalar(
                'Metrics/TTC_Exposure_s',
                float(avg_num_conflicts) * float(args.step_length),
                tb_step,
            )
            _ovr_rate = float(sig_overrides_ep) / float(max(1, sig_decisions_ep))
            writer.add_scalar('Signal/override_rate', _ovr_rate, tb_step)
            if sig_decisions_ep > 0 and _ovr_rate > 0.01:
                print(
                    f"[v5][warn] signal override rate {_ovr_rate:.1%} "
                    f"({sig_overrides_ep}/{sig_decisions_ep}); overridden samples excluded from PPO",
                    flush=True,
                )
            _bk = float(np.mean([fe.get('insertion_backlog', 0.0) for fe in final_v4_kpis]))
            if _bk > 100.0 or int(total_teleports) > 20:
                print(
                    f"[v5][warn] insertion_backlog={_bk:.0f} teleports={int(total_teleports)}: "
                    f"check for stuck vehicles (4-leg HDV_SW); diagnose with --allow-od-rewrite",
                    flush=True,
                )
            _tot = time.perf_counter() - _ep_t0
            _oth = max(0.0, _tot - sum(_tm.values()))
            print(
                f"[timing] ep={episode + 1} total={_tot:.0f}s reset={_tm['reset']:.0f}s env={_tm['env']:.0f}s "
                f"policy={_tm['policy']:.0f}s critic={_tm['critic']:.0f}s update={_tm['update']:.0f}s other={_oth:.0f}s",
                flush=True,
            )
            for _k, _v in list(_tm.items()) + [("total", _tot), ("other", _oth)]:
                writer.add_scalar(f"Timing/{_k}_s", float(_v), tb_step)
            writer.add_scalar('Metrics/Average_Speed', avg_speed, tb_step)
            writer.add_scalar('Metrics/Average_Waiting_Time', avg_waiting_time, tb_step)
            writer.add_scalar(
                'Metrics/Network_Average_Waiting_Time', avg_net_waiting_time, tb_step
            )
            writer.add_scalar('Metrics/Average_Queue_Length', avg_queue_length, tb_step)
            writer.add_scalar('Metrics/Number_of_Vehicle_Stops', avg_num_stops, tb_step)
            writer.add_scalar('Metrics/Number_of_Traffic_Conflicts', avg_num_conflicts, tb_step)
            writer.add_scalar('Metrics/Fleet_Average_Fuel_Consumption', fleet_avg_fuel, tb_step)
            writer.add_scalar('Metrics/Fleet_Average_CO2_Emission', fleet_avg_co2, tb_step)
            writer.add_scalar('Metrics/Total_Fuel_Consumption', total_fuel_L, tb_step)
            writer.add_scalar('Metrics/Total_CO2_Emission', total_co2_g, tb_step)
            writer.add_scalar('Metrics/Vehicle_Average_Fuel_Consumption', veh_avg_fuel_L, tb_step)
            writer.add_scalar('Metrics/Vehicle_Average_CO2_Emission', veh_avg_co2_g, tb_step)
            writer.add_scalar('Metrics/Collisions', avg_collisions, tb_step)
            writer.add_scalar('Metrics/Teleports', avg_teleports, tb_step)
            writer.add_scalar('Metrics/Safety_Incidents', avg_safety_incidents, tb_step)
            # Observe-only: red/slow leader_gap CAV vs HDV (no reward change).
            avg_red_gap = {
                k: float(np.mean(vals)) for k, vals in final_red_gap.items()
            }
            writer.add_scalar('Diag/RedGap_CAV_n', avg_red_gap['red_gap_cav_n'], tb_step)
            writer.add_scalar(
                'Diag/RedGap_CAV_mean', avg_red_gap['red_gap_cav_mean'], tb_step
            )
            writer.add_scalar(
                'Diag/RedGap_CAV_pack_frac',
                avg_red_gap['red_gap_cav_pack_frac'],
                tb_step,
            )
            writer.add_scalar(
                'Diag/RedGap_CAV_gt4p5_frac',
                avg_red_gap['red_gap_cav_gt4p5_frac'],
                tb_step,
            )
            writer.add_scalar(
                'Diag/RedGap_CAV_gt6_frac',
                avg_red_gap['red_gap_cav_gt6_frac'],
                tb_step,
            )
            writer.add_scalar('Diag/RedGap_HDV_n', avg_red_gap['red_gap_hdv_n'], tb_step)
            writer.add_scalar(
                'Diag/RedGap_HDV_mean', avg_red_gap['red_gap_hdv_mean'], tb_step
            )
            writer.add_scalar(
                'Diag/RedGap_HDV_pack_frac',
                avg_red_gap['red_gap_hdv_pack_frac'],
                tb_step,
            )
            writer.add_scalar(
                'Diag/RedGap_HDV_gt4p5_frac',
                avg_red_gap['red_gap_hdv_gt4p5_frac'],
                tb_step,
            )
            writer.add_scalar(
                'Diag/RedGap_HDV_gt6_frac',
                avg_red_gap['red_gap_hdv_gt6_frac'],
                tb_step,
            )
            writer.add_scalar(
                'Diag/RedGap_CAV_both_slow_n',
                avg_red_gap['red_gap_cav_both_slow_n'],
                tb_step,
            )
            writer.add_scalar(
                'Diag/RedGap_CAV_both_slow_mean',
                avg_red_gap['red_gap_cav_both_slow_mean'],
                tb_step,
            )
            writer.add_scalar(
                'Diag/RedGap_CAV_both_slow_pack_frac',
                avg_red_gap['red_gap_cav_both_slow_pack_frac'],
                tb_step,
            )
            writer.add_scalar(
                'Diag/RedGap_CAV_both_slow_gt4p5_frac',
                avg_red_gap['red_gap_cav_both_slow_gt4p5_frac'],
                tb_step,
            )
            writer.add_scalar(
                'Diag/RedGap_HDV_both_slow_n',
                avg_red_gap['red_gap_hdv_both_slow_n'],
                tb_step,
            )
            writer.add_scalar(
                'Diag/RedGap_HDV_both_slow_mean',
                avg_red_gap['red_gap_hdv_both_slow_mean'],
                tb_step,
            )
            writer.add_scalar(
                'Diag/RedGap_HDV_both_slow_pack_frac',
                avg_red_gap['red_gap_hdv_both_slow_pack_frac'],
                tb_step,
            )
            writer.add_scalar(
                'Diag/RedGap_HDV_both_slow_gt4p5_frac',
                avg_red_gap['red_gap_hdv_both_slow_gt4p5_frac'],
                tb_step,
            )
            if str(agent.training_stage) in ('Lon', 'JointLonSig'):
                print(
                    f"[Diag-RedGap] ep={episode + 1} stage={agent.training_stage} "
                    f"CAV n={avg_red_gap['red_gap_cav_n']:.0f} "
                    f"mean={avg_red_gap['red_gap_cav_mean']:.2f} "
                    f"pack={avg_red_gap['red_gap_cav_pack_frac']:.2f} "
                    f"gt4.5={avg_red_gap['red_gap_cav_gt4p5_frac']:.2f} | "
                    f"HDV n={avg_red_gap['red_gap_hdv_n']:.0f} "
                    f"mean={avg_red_gap['red_gap_hdv_mean']:.2f} "
                    f"pack={avg_red_gap['red_gap_hdv_pack_frac']:.2f} "
                    f"gt4.5={avg_red_gap['red_gap_hdv_gt4p5_frac']:.2f}",
                    flush=True,
                )
                # v5.2.1: "gt4.5" above is really > IDLE_LEADER_EXEMPT_M (2.8 m).
                print(
                    f"[Diag-RedGap2] ep={episode + 1} stage={agent.training_stage} "
                    f"QUEUE CAV n={avg_red_gap['red_gap_cav_queue_n']:.0f} "
                    f"mean={avg_red_gap['red_gap_cav_queue_mean']:.2f} "
                    f"pack={avg_red_gap['red_gap_cav_queue_pack_frac']:.2f} "
                    f"creep={avg_red_gap['red_gap_cav_queue_creep_frac']:.2f} | "
                    f"HDV n={avg_red_gap['red_gap_hdv_queue_n']:.0f} "
                    f"mean={avg_red_gap['red_gap_hdv_queue_mean']:.2f} "
                    f"pack={avg_red_gap['red_gap_hdv_queue_pack_frac']:.2f} "
                    f"creep={avg_red_gap['red_gap_hdv_queue_creep_frac']:.2f} || "
                    f"HEAD CAV n={avg_red_gap['red_gap_cav_head_n']:.0f} "
                    f"HDV n={avg_red_gap['red_gap_hdv_head_n']:.0f}",
                    flush=True,
                )
                for _k in ('cav_queue_mean', 'hdv_queue_mean', 'cav_head_n', 'hdv_head_n'):
                    writer.add_scalar(f'Diag/RedGap2_{_k}', avg_red_gap[f'red_gap_{_k}'], tb_step)
            stage_code = {
                'S': 0, 'Lon': 1, 'JointLonSig': 2,
                'Lat': 3, 'JointAll': 4,
                'Transition': 1, 'V1': 1, 'V2': 3,
            }.get(str(agent.training_stage), -1)
            writer.add_scalar('Training_Stage', stage_code, tb_step)
            writer.add_scalar(
                'Joint/abort',
                1.0 if bool(getattr(agent, "joint_abort", False)) else 0.0,
                tb_step,
            )
            writer.add_scalar('LR/actor_scale', float(lr_scale), tb_step)
            writer.add_scalar('LR/stage_episode', float(stage_episode), tb_step)
            for key in ('cav_actor', 'lat_actor', 'lon_actor', 'signal_actor', 'critic'):
                writer.add_scalar(f'Loss/{key}', float(mean_losses.get(key, 0.0)), tb_step)
            writer.add_scalar(
                'Teacher/valid_samples',
                float(mean_losses.get('teacher_valid_samples', 0.0)),
                tb_step,
            )
            writer.add_scalar(
                'Teacher/loss',
                float(mean_losses.get('teacher_loss', 0.0)),
                tb_step,
            )
            writer.add_scalar(
                'Teacher/beta',
                float(
                    mean_losses.get(
                        'teacher_beta',
                        getattr(
                            agent,
                            'teacher_beta',
                            getattr(agent, 'signal_teacher_beta', 0.0),
                        ),
                    )
                ),
                tb_step,
            )
            writer.add_scalar(
                'Teacher/agreement_rate',
                float(mean_losses.get('teacher_agreement_rate', 0.0)),
                tb_step,
            )
            writer.add_scalar(
                'Teacher/severity_mean',
                float(mean_losses.get('teacher_severity_mean', 0.0)),
                tb_step,
            )
            writer.add_scalar(
                'Policy/signal_entropy',
                float(mean_losses.get('signal_entropy', 0.0)),
                tb_step,
            )
            writer.add_scalar(
                'Policy/signal_grad_norm',
                float(mean_losses.get('signal_grad_norm', 0.0)),
                tb_step,
            )

            # Episode-level VLM update: one slow EMA from this episode's raws.
            if hasattr(parallel_envs, 'end_episode_vlm_update'):
                try:
                    parallel_envs.end_episode_vlm_update()
                except Exception:
                    pass
            # VLM weight diagnostics (EMA-applied values at episode end).
            # Single snapshot per episode end; reused by TB + both checkpoints
            # below (was: one IPC round-trip per consumer).
            vlm_snap = _collect_vlm_snapshot(parallel_envs)
            if hasattr(parallel_envs, 'get_vlm_weight_snapshot'):
                try:
                    snap = parallel_envs.get_vlm_weight_snapshot() or vlm_snap or {}
                    # W_sig/* omitted: unused by current R_sig (pressure/hybrid+residual).
                    w_lat = list(snap.get('W_lat') or [])
                    w_long = list(snap.get('W_long') or [])
                    lat_names = (
                        'lane', 'safe_lc', 'eff_lc', 'formation', 'comfort_lc'
                    )
                    long_names = ('safety', 'efficiency', 'comfort', 'platoon')
                    writer.add_scalar(
                        'VLM/sig_frozen', float(bool(snap.get('sig_frozen'))), tb_step
                    )
                    for i, name in enumerate(lat_names):
                        if i < len(w_lat):
                            writer.add_scalar(f'VLM/W_lat/{name}', float(w_lat[i]), tb_step)
                    for i, name in enumerate(long_names):
                        if i < len(w_long):
                            writer.add_scalar(f'VLM/W_long/{name}', float(w_long[i]), tb_step)
                    # Log active CoRe VLM residuals & raw semantic confidence/risk.
                    for res_k in ('lon_residual', 'lon_pos_bonus', 'lat_residual', 'lat_pos_bonus'):
                        if res_k in snap and snap.get(res_k) is not None:
                            writer.add_scalar(f'VLM/{res_k}', float(snap[res_k]), tb_step)
                    raw = snap.get('last_raw') or {}
                    for key, val in raw.items():
                        if str(key).endswith('_weight') or str(key) in ('residual_risk', 'confidence', 'valid'):
                            writer.add_scalar(f'VLM/raw/{key}', float(val), tb_step)
                    mode = snap.get('traffic_mode')
                    analysis = snap.get('semantic_analysis') or ''
                    if mode or analysis:
                        writer.add_text(
                            'VLM/last_semantic',
                            f"mode={mode}\n{analysis}",
                            tb_step,
                        )
                except Exception as exc:
                    print(f"[tensorboard] skip VLM weight snapshot: {exc}", flush=True)

            episode_rewards.append(avg_ep_reward)
            episode_rewards_per_env.append(list(env_ep_rewards))
            cav_rewards_per_env.append(list(env_cav_rewards))
            cav_lon_rewards_per_env.append(list(env_cav_lon_rewards))
            cav_lat_rewards_per_env.append(list(env_cav_lat_rewards))
            signal_rewards_per_env.append(list(env_signal_rewards))
            metrics_history['avg_travel_time'].append(list(final_avg_travel_time))
            metrics_history['avg_speed'].append(list(final_avg_speed))
            metrics_history['avg_waiting_time'].append(list(final_avg_waiting_time))
            metrics_history['avg_queue_length'].append(list(final_avg_queue_length))
            metrics_history['avg_collisions'].append(
                [float(avg_collisions)] * int(args.num_envs)
            )
            metrics_history['num_stops'].append(list(final_num_stops))
            metrics_history['num_conflicts'].append(list(final_num_conflicts))
            metrics_history['fleet_avg_fuel'].append(list(final_fleet_avg_fuel))
            metrics_history['fleet_avg_co2'].append(list(final_fleet_avg_co2))
            metrics_history['avg_fuel'].append(list(final_fleet_avg_fuel))
            metrics_history['avg_co2'].append(list(final_fleet_avg_co2))
            metrics_history['total_fuel_L'].append(list(final_total_fuel_L))
            metrics_history['total_co2_g'].append(list(final_total_co2_g))
            metrics_history['veh_avg_fuel_L'].append(list(final_veh_avg_fuel_L))
            metrics_history['veh_avg_co2_g'].append(list(final_veh_avg_co2_g))

            if args.live_plot:
                live_steps.append(episode + 1)
                live_cav_rewards.append(avg_cav_reward)
                live_signal_rewards.append(avg_signal_reward)
                
                live_line_cav.set_data(live_steps, live_cav_rewards)
                ax_cav.relim(); ax_cav.autoscale_view()
                live_line_signal.set_data(live_steps, live_signal_rewards)
                ax_signal.relim(); ax_signal.autoscale_view()
                plt.pause(0.001)

            if vlm_abort_error:
                break

            os.makedirs(checkpoint_dir, exist_ok=True)
            checkpoint = _pack_train_checkpoint(
                args, agent, cav_actor, cav_residual_actor, signal_actor, critic,
                n_signal_actions, completed_episodes_count=episode + 1,
                tb_run=tb_run, lat_actor=lat_actor,
                extra={'vlm_weights': vlm_snap},
            )
            _atomic_torch_save(checkpoint, os.path.join(checkpoint_dir, 'latest.pt'))
            write_resume_meta(checkpoint_dir, episode + 1, tb_run=tb_run)
            if (episode + 1) % max(args.checkpoint_interval, 1) == 0:
                _atomic_torch_save(checkpoint, os.path.join(checkpoint_dir, f'episode_{episode + 1:04d}.pt'))

            # Track Lon/Lat rolling scores / incidents for the next joint baseline.
            ep_score_now = _best_score(avg_speed, avg_queue_length)
            if stage == "Lon":
                lon_score_hist.append(float(ep_score_now))
                lon_coll_hist.append(float(avg_collisions))
            elif stage == "Lat":
                lat_score_hist.append(float(ep_score_now))
                lat_coll_hist.append(float(avg_collisions))

            # Joint KPI gate: abort weak unfreeze on sustained regression / collisions.
            if stage in ("JointLonSig", "JointAll") and not bool(
                getattr(agent, "joint_abort", False)
            ):
                joint_score_hist.append(float(ep_score_now))
                joint_coll_hist.append(float(avg_collisions))
                if joint_baseline_score is None:
                    # Fallback: freeze baseline after grace so early noise is ignored.
                    if len(joint_score_hist) >= int(_JOINT_GRACE_EPS):
                        joint_baseline_score = float(
                            np.mean(joint_score_hist[: int(_JOINT_GRACE_EPS)])
                        )
                        joint_baseline_collisions = float(
                            np.mean(joint_coll_hist[: int(_JOINT_GRACE_EPS)])
                        )
                do_abort, why = _joint_kpi_should_abort(
                    joint_score_hist,
                    joint_baseline_score,
                    joint_coll_hist,
                    baseline_collisions=joint_baseline_collisions,
                )
                writer.add_scalar('Joint/score', float(ep_score_now), tb_step)
                if joint_baseline_score is not None:
                    writer.add_scalar(
                        'Joint/baseline_score', float(joint_baseline_score), tb_step
                    )
                writer.add_scalar(
                    'Joint/grace_remaining',
                    float(max(0, int(_JOINT_GRACE_EPS) - len(joint_score_hist))),
                    tb_step,
                )
                if do_abort:
                    _abort_joint_stage(
                        stage,
                        checkpoint_dir,
                        device,
                        agent,
                        signal_actor,
                        lon_actor,
                        lat_actor,
                        reason=why,
                        critic=critic,
                    )
                    # If a qualified joint best already exists, end the stage early
                    # instead of burning remaining episodes at floor LR.
                    _jname = _BEST_STAGE_FILENAMES.get(stage)
                    _jpath = (
                        os.path.join(checkpoint_dir, _jname) if _jname else ""
                    )
                    if _jpath and os.path.isfile(_jpath):
                        print(
                            f"[joint] abort with qualified {_jname}; "
                            f"ending {stage} early (skip empty floor run)",
                            flush=True,
                        )
                        # stage_episode is recomputed from `episode` each loop.
                        # Skip by global episode index through the end of this block.
                        _stage_start = int(episode) - int(stage_episode)
                        skip_until_episode = _stage_start + int(stage_len)
                    else:
                        lr_scale = _stage_actor_lr_scale(
                            stage,
                            stage_episode,
                            stage_len,
                            soft_start,
                            quick=bool(getattr(args, "quick", False)),
                        )
                        if hasattr(agent, "apply_active_actor_lr_scale"):
                            agent.apply_active_actor_lr_scale(lr_scale)

            # Stage best: rolling-window physical collisions then score.
            # Formal best_stage_*.pt uses per-stage τ_coll (S=0; CAV≈1.5).
            if (
                stage == "S"
                and _has_s_teacher
                and int(stage_len) > 0
                and int(stage_episode) == _stage_s_tail_start(stage_len)
                and int(stage_episode) > 0
                and not bool(best_trackers["S"].get("tail_window", False))
                and best_trackers["S"].get("episode") is not None
            ):
                _archive_best_stage_checkpoint(
                    checkpoint_dir, "S", "pre_tail_best_stage_s.pt"
                )
                best_trackers["S"] = _empty_best_tracker(
                    tail_window=True,
                    kpi_tracked=True,
                )
                print(
                    f"[best] Stage-S entered teacher-beta=0 tail window "
                    f"(stage_ep={stage_episode}/{stage_len}); reset tracker for tail Best-S",
                    flush=True,
                )

            if _best_track_enabled(stage_episode, stage_len, soft_start, stage=stage):
                # Formal gate: teleports == 0 and physical collisions ≤ τ.
                ep_collisions = float(avg_collisions)
                ep_teleports = float(avg_teleports)
                ep_safety = float(ep_collisions + ep_teleports)
                ep_raw_score = _selection_score(args, avg_speed, avg_queue_length, final_v4_kpis)
                tracker = best_trackers[stage]
                gate_thr = float(_STAGE_GATE_MAX_COLLISIONS.get(stage, 0.0))
                # Gate window on collisions; teleports veto separately below.
                roll = _append_best_window(
                    tracker,
                    ep_raw_score,
                    ep_collisions,
                    max_window_coll=gate_thr,
                )
                writer.add_scalar(
                    f"Best/{stage}_raw_score", float(ep_raw_score), tb_step
                )
                if roll["window_score"] is not None:
                    writer.add_scalar(
                        f"Best/{stage}_roll_score",
                        float(roll["window_score"]),
                        tb_step,
                    )
                if roll["window_coll"] is not None:
                    writer.add_scalar(
                        f"Best/{stage}_roll_collisions",
                        float(roll["window_coll"]),
                        tb_step,
                    )
                    writer.add_scalar(
                        f"Best/{stage}_roll_safety_incidents",
                        float(roll["window_coll"]) + float(ep_teleports),
                        tb_step,
                    )
                if not roll["ready"]:
                    pass
                else:
                    if bool(tracker.get("legacy_single_ep")):
                        tracker["collisions"] = None
                        tracker["score"] = None
                        tracker["legacy_single_ep"] = False
                        print(
                            f"[best] {stage}: rolling window ready — "
                            f"cleared legacy single-ep baseline",
                            flush=True,
                        )
                    window_coll = float(roll["window_coll"])
                    window_score = float(roll["window_score"])
                    # Formal gate requires teleports == 0 on the candidate episode.
                    gated_ok = bool(roll["gated_ok"]) and float(ep_teleports) <= 0.0

                    def _build_best_meta(gate_passed):
                        snap = vlm_snap or {}
                        meta = {
                            "stage": stage,
                            "episode": int(episode) + 1,
                            "stage_episode": int(stage_episode),
                            "selector": _BEST_SELECTOR_NAME,
                            "window_size": int(roll["window_size"]),
                            "collisions": float(window_coll),
                            "safety_incidents": float(window_coll) + float(ep_teleports),
                            "ep_collisions": float(ep_collisions),
                            "collisions_only": float(avg_collisions),
                            "teleports_only": float(avg_teleports),
                            "score": float(window_score),
                            "roll_score": float(window_score),
                            "raw_score": float(ep_raw_score),
                            "avg_speed": float(avg_speed),
                            "avg_queue_length": float(avg_queue_length),
                            "safety_gate_passed": bool(gate_passed),
                            "W_sig": list(snap.get("W_sig") or []),
                            "W_lat": list(snap.get("W_lat") or []),
                            "W_long": list(snap.get("W_long") or []),
                        }
                        if stage == "S":
                            in_s_tail = int(stage_episode) >= _stage_s_tail_start(
                                stage_len
                            )
                            meta["kpi_tracked"] = True
                            meta["tail_window"] = bool(in_s_tail)
                            meta["signal_entropy"] = float(
                                mean_losses.get("signal_entropy", 0.0) or 0.0
                            )
                            meta["teacher_beta"] = float(
                                getattr(
                                    agent,
                                    "teacher_beta",
                                    getattr(agent, "signal_teacher_beta", 0.0),
                                )
                                or 0.0
                            )
                        if not meta["W_sig"]:
                            meta.pop("W_sig", None)
                        if not meta["W_lat"]:
                            meta.pop("W_lat", None)
                        if not meta["W_long"]:
                            meta.pop("W_long", None)
                        return meta

                    # Formal gated Best: τ_coll window then score (tol tie-break).
                    if gated_ok:
                        better_formal = _is_better_stage_episode(
                            window_coll,
                            window_score,
                            tracker.get("collisions"),
                            tracker.get("score"),
                        )
                        if better_formal:
                            best_meta = _build_best_meta(True)
                            best_ckpt = _pack_train_checkpoint(
                                args, agent, cav_actor, cav_residual_actor,
                                signal_actor, critic, n_signal_actions,
                                completed_episodes_count=episode + 1,
                                tb_run=tb_run, lat_actor=lat_actor,
                                extra={
                                    "best_meta": best_meta,
                                    "vlm_weights": vlm_snap,
                                },
                            )
                            best_path = os.path.join(
                                checkpoint_dir, _BEST_STAGE_FILENAMES[stage]
                            )
                            _atomic_torch_save(best_ckpt, best_path)
                            print(
                                f"[best] {stage}: saved {_BEST_STAGE_FILENAMES[stage]} "
                                f"(ep {episode + 1}, window_coll={window_coll:.3f}, "
                                f"τ={gate_thr:.1f}, "
                                f"roll_score={window_score:.4f}, "
                                f"raw_score={ep_raw_score:.4f})",
                                flush=True,
                            )
                            tracker["collisions"] = float(window_coll)
                            tracker["score"] = float(window_score)
                            tracker["episode"] = int(episode) + 1
                            tracker["safety_gate_passed"] = True
                            if stage == "S":
                                tracker["kpi_tracked"] = True
                                tracker["tail_window"] = bool(
                                    best_meta.get("tail_window", False)
                                )
                                tracker["signal_entropy"] = best_meta.get(
                                    "signal_entropy"
                                )
                                tracker["teacher_beta"] = best_meta.get(
                                    "teacher_beta"
                                )
                            writer.add_scalar(
                                f"Best/{stage}_score",
                                float(window_score),
                                tb_step,
                            )
                            writer.add_scalar(
                                f"Best/{stage}_safety_incidents",
                                float(window_coll),
                                tb_step,
                            )
                            writer.add_scalar(
                                f"Best/{stage}_collisions",
                                float(window_coll),
                                tb_step,
                            )

                    # Independent ungated archive: score-only, never blocked by a
                    # prior zero-incident formal floor (fixes 5leg temp deadlock).
                    if not gated_ok:
                        prev_u = tracker.get("ungated_score")
                        better_ungated = (
                            prev_u is None
                            or float(window_score) > float(prev_u)
                        )
                        if better_ungated:
                            best_meta = _build_best_meta(False)
                            best_ckpt = _pack_train_checkpoint(
                                args, agent, cav_actor, cav_residual_actor,
                                signal_actor, critic, n_signal_actions,
                                completed_episodes_count=episode + 1,
                                tb_run=tb_run, lat_actor=lat_actor,
                                extra={
                                    "best_meta": best_meta,
                                    "vlm_weights": vlm_snap,
                                },
                            )
                            temp_name = _temp_ungated_best_filename(stage)
                            best_path = os.path.join(checkpoint_dir, temp_name)
                            _atomic_torch_save(best_ckpt, best_path)
                            print(
                                f"[best] {stage}: safety gate FAIL — saved {temp_name} "
                                f"(ep {episode + 1}, window_safety={window_coll:.3f}, "
                                f"roll_score={window_score:.4f}); not a gated best",
                                flush=True,
                            )
                            tracker["ungated_score"] = float(window_score)
                            tracker["ungated_collisions"] = float(window_coll)
                            tracker["ungated_episode"] = int(episode) + 1
                            writer.add_scalar(
                                f"Best/{stage}_ungated_score",
                                float(window_score),
                                tb_step,
                            )

    finally:
        try:
            parallel_envs.close()
        finally:
            _join_worker_processes(processes)
            writer.close()

    if vlm_abort_error:
        raise SystemExit(2)

    import matplotlib.pyplot as plt
    if args.live_plot:
        plt.ioff()

    def _plot_mean_std(episodes_x, values_2d, title, ylabel, out_path, color="C0"):
        """values_2d: (episodes, n_seeds). Shade = STD across independent seeds/runs."""
        arr = np.asarray(values_2d, dtype=np.float64)
        if arr.ndim == 1:
            arr = arr[:, None]
        mean = np.mean(arr, axis=1)
        std = np.std(arr, axis=1)
        fig, ax = plt.subplots(figsize=(10, 6))
        ax.plot(episodes_x, mean, color=color, linewidth=2.0, label="Mean")
        ax.fill_between(
            episodes_x, mean - std, mean + std,
            color=color, alpha=0.25, label="+/- 1 STD",
        )
        ax.set_title(title)
        ax.set_xlabel("Episode")
        ax.set_ylabel(ylabel)
        ax.legend()
        ax.grid(True, alpha=0.3)
        fig.tight_layout()
        fig.savefig(out_path, dpi=150)
        plt.close(fig)

    if len(episode_rewards_per_env) > 0:
        ep_rewards_array = np.asarray(episode_rewards_per_env, dtype=np.float64)
        cav_rewards_array = np.asarray(cav_rewards_per_env, dtype=np.float64)
        cav_lon_rewards_array = np.asarray(cav_lon_rewards_per_env, dtype=np.float64)
        cav_lat_rewards_array = np.asarray(cav_lat_rewards_per_env, dtype=np.float64)
        signal_rewards_array = np.asarray(signal_rewards_per_env, dtype=np.float64)
        episodes_x = np.arange(
            history_start_episode + 1,
            history_start_episode + 1 + len(ep_rewards_array),
        )

        episode_indices = np.arange(
            history_start_episode + 1,
            history_start_episode + 1 + len(ep_rewards_array),
            dtype=np.int64,
        )
        save_kwargs = {
            "total_reward": ep_rewards_array,
            "cav_reward": cav_rewards_array,
            "cav_lon_reward": cav_lon_rewards_array,
            "cav_lat_reward": cav_lat_rewards_array,
            "signal_reward": signal_rewards_array,
            "episode_index": episode_indices,
            "num_envs": np.asarray([args.num_envs]),
            "seed": np.asarray([args.seed]),
        }
        for key, series in metrics_history.items():
            if series:
                save_kwargs[key] = np.asarray(series, dtype=np.float64)
        npz_path = os.path.join(results_dir, "episode_metrics.npz")
        _atomic_savez_compressed(npz_path, **save_kwargs)

        save_curve_bands(
            results_dir,
            episodes_x,
            {
                "total_reward": ep_rewards_array,
                "cav_reward": cav_rewards_array,
                "cav_lon_reward": cav_lon_rewards_array,
                "cav_lat_reward": cav_lat_rewards_array,
                "signal_reward": signal_rewards_array,
            },
            method=str(getattr(args, "method", MAIN_METHOD) or MAIN_METHOD),
            scenario=str(getattr(args, "scenario", "") or ""),
            smooth=1,
            band_mode="seed_std",
        )

        n_seeds = ep_rewards_array.shape[1]
        seed_note = (
            f"mean +/- STD over {n_seeds} envs in this run"
            if n_seeds > 1
            else f"single env (aggregate seeds {list(EXPERIMENT_SEEDS)} offline for STD)"
        )
        _plot_mean_std(
            episodes_x, ep_rewards_array,
            f"Total Episode Reward ({seed_note})",
            "Total Reward",
            os.path.join(results_dir, "reward_curve_total.png"),
            color="#1f77b4",
        )
        _plot_mean_std(
            episodes_x, cav_rewards_array,
            f"CAV Agent Reward ({seed_note})",
            "CAV Mean Reward",
            os.path.join(results_dir, "reward_curve_cav.png"),
            color="#2ca02c",
        )
        _plot_mean_std(
            episodes_x, cav_lon_rewards_array,
            f"CAV Lon Mean Reward ({seed_note})",
            "Lon Mean Reward",
            os.path.join(results_dir, "reward_curve_cav_lon.png"),
            color="#17becf",
        )
        _plot_mean_std(
            episodes_x, cav_lat_rewards_array,
            f"CAV Lat Mean Reward ({seed_note})",
            "Lat Mean Reward",
            os.path.join(results_dir, "reward_curve_cav_lat.png"),
            color="#9467bd",
        )
        _plot_mean_std(
            episodes_x, signal_rewards_array,
            f"Signal Agent Reward ({seed_note})",
            "Signal Reward",
            os.path.join(results_dir, "reward_curve_signal.png"),
            color="#d62728",
        )
        print(f"Reward curves saved under '{results_dir}'.")
        print(f"Episode metrics saved to '{npz_path}'")

        # Aggregate sibling seeds under the active scenario folder (supports VLM model layer).
        train_scenario_root = os.path.dirname(os.path.abspath(results_dir))
        run_series = []
        if os.path.isdir(train_scenario_root):
            for sub in sorted(os.listdir(train_scenario_root)):
                path = os.path.join(train_scenario_root, sub, "episode_metrics.npz")
                if not os.path.isfile(path):
                    continue
                try:
                    with np.load(path, allow_pickle=False) as data:
                        total = np.asarray(data["total_reward"], dtype=np.float64)
                        cav = np.asarray(data["cav_reward"], dtype=np.float64)
                        signal = np.asarray(data["signal_reward"], dtype=np.float64)
                        if total.ndim == 1:
                            total = total.reshape(-1, 1)
                        if cav.ndim == 1:
                            cav = cav.reshape(-1, 1)
                        if signal.ndim == 1:
                            signal = signal.reshape(-1, 1)
                        n_rows = min(len(total), len(cav), len(signal))
                        if n_rows <= 0:
                            continue
                        if "episode_index" in data.files:
                            episode_idx = np.asarray(data["episode_index"], dtype=np.int64).reshape(-1)[:n_rows]
                        else:
                            episode_idx = np.arange(1, n_rows + 1, dtype=np.int64)
                        if len(episode_idx) != n_rows:
                            continue
                        run_series.append({
                            "index": episode_idx,
                            "total": np.mean(total[:n_rows], axis=1),
                            "cav": np.mean(cav[:n_rows], axis=1),
                            "signal": np.mean(signal[:n_rows], axis=1),
                        })
                except Exception:
                    continue
        if len(run_series) >= 2:
            common_indices = set(int(x) for x in run_series[0]["index"])
            for series in run_series[1:]:
                common_indices.intersection_update(int(x) for x in series["index"])
            common_indices = sorted(common_indices)
            if not common_indices:
                print(
                    "[multi-seed] no overlapping episode indices across runs; "
                    "skipping aggregate curves.",
                    flush=True,
                )
            else:
                def _align(series, key):
                    values = {
                        int(ep): float(val)
                        for ep, val in zip(series["index"], series[key])
                    }
                    return np.asarray([values[ep] for ep in common_indices], dtype=np.float64)

                stack_total = np.stack([_align(x, "total") for x in run_series], axis=1)
                stack_cav = np.stack([_align(x, "cav") for x in run_series], axis=1)
                stack_signal = np.stack([_align(x, "signal") for x in run_series], axis=1)
                x_multi = np.asarray(common_indices, dtype=np.int64)
                multi_dir = os.path.join(train_scenario_root, "_multi_seed")
                os.makedirs(multi_dir, exist_ok=True)
                n_runs = stack_total.shape[1]
                _plot_mean_std(
                    x_multi, stack_total,
                    f"Total Reward across {n_runs} independent training runs (mean +/- STD)",
                    "Total Reward",
                    os.path.join(multi_dir, "reward_curve_total_multi.png"),
                    color="#1f77b4",
                )
                _plot_mean_std(
                    x_multi, stack_cav,
                    f"CAV Reward across {n_runs} independent training runs (mean +/- STD)",
                    "CAV Mean Reward",
                    os.path.join(multi_dir, "reward_curve_cav_multi.png"),
                    color="#2ca02c",
                )
                _plot_mean_std(
                    x_multi, stack_signal,
                    f"Signal Reward across {n_runs} independent training runs (mean +/- STD)",
                    "Signal Reward",
                    os.path.join(multi_dir, "reward_curve_signal_multi.png"),
                    color="#d62728",
                )
                print(f"Multi-run STD curves saved under '{multi_dir}' ({n_runs} runs).")
    elif episode_rewards:
        plt.figure(figsize=(10, 6))
        plt.plot(range(1, len(episode_rewards) + 1), episode_rewards, marker="o")
        plt.title("Team Reward over Episodes")
        plt.xlabel("Episode")
        plt.ylabel("Total Reward")
        plt.grid(True)
        plt.tight_layout()
        out = os.path.join(results_dir, "reward_curve.png")
        plt.savefig(out)
        plt.close()
        print(f"Reward curve saved as '{out}'")

    # Non-degradation Pareto checkpoint selector across curriculum stages:
    # Prefer the latest full-capability stage unless an earlier safety-gated stage
    # achieved a materially better KPI score (> 1.0 margin) or strictly safer floor.
    stage_candidates = []
    for st_cand in ("JointAll", "Lat", "JointLonSig", "Lon", "S"):
        cand_path = os.path.join(checkpoint_dir, _BEST_STAGE_FILENAMES[st_cand])
        if not os.path.isfile(cand_path):
            continue
        try:
            c_meta = (torch_load(cand_path, "cpu") or {}).get("best_meta") or {}
            c_score = float(c_meta.get("score")) if c_meta.get("score") is not None else float("-inf")
            c_coll = float(c_meta.get("collisions")) if c_meta.get("collisions") is not None else float("inf")
            c_gate = bool(c_meta.get("safety_gate_passed", True))
        except Exception:
            c_score, c_coll, c_gate = float("-inf"), float("inf"), True
        stage_candidates.append((st_cand, cand_path, c_score, c_coll, c_gate))

    final_best = None
    final_stage_picked = None
    if stage_candidates:
        gated_cands = [c for c in stage_candidates if c[4]] or stage_candidates
        # Start with the most complete stage (first in order), then check if any
        # earlier gated checkpoint beats it by > 1.0 KPI score without worse collisions.
        best_st, best_p, best_sc, best_co, _ = gated_cands[0]
        # v4: 'latest' (default) always exports the most complete stage. v3 could
        # export an EARLIER stage (even Stage-S, i.e. IDM-driven CAVs) by training score.
        _final_rule = str(getattr(args, "final_select", "latest") or "latest").strip().lower()
        for st_c, p_c, sc_c, co_c, _ in (gated_cands[1:] if _final_rule == "score" else []):
            if np.isfinite(sc_c) and (not np.isfinite(best_sc) or (sc_c > best_sc + 1.0 and co_c <= best_co + 0.1)):
                best_st, best_p, best_sc, best_co = st_c, p_c, sc_c, co_c
        final_best = best_p
        final_stage_picked = best_st
        # v5.1: under 'latest', never export an EARLIER stage just because the final
        # stage produced no gated best (smoke run exported Stage-S = IDM CAVs).
        _stage_order = ["S", "Lon", "JointLonSig", "Lat", "JointAll"]
        _trained = str(getattr(agent, "training_stage", "") or "")
        _latest_p = os.path.join(checkpoint_dir, "latest.pt")
        if (
            _final_rule == "latest"
            and _trained in _stage_order
            and best_st in _stage_order
            and _stage_order.index(best_st) < _stage_order.index(_trained)
            and os.path.isfile(_latest_p)
        ):
            print(
                f"[best][v5.1] no gated best for final stage {_trained} (best available: {best_st}); "
                f"exporting latest.pt instead. Select on validation seeds with scripts/evaluate_policy.py.",
                flush=True,
            )
            final_best = _latest_p
            best_p = _latest_p
            best_st = f"{_trained}(latest)"
            final_stage_picked = best_st
        try:
            import json as _json

            with open(os.path.join(checkpoint_dir, "best_final_meta.json"), "w", encoding="utf-8") as _fh:
                _json.dump(
                    {
                        "stage": best_st,
                        "path": os.path.basename(best_p),
                        "rule": _final_rule,
                        "train_window_score": float(best_sc) if np.isfinite(best_sc) else None,
                        "train_window_collisions": float(best_co) if np.isfinite(best_co) else None,
                        "note": "selected on TRAINING-episode KPIs; report results on held-out demand seeds",
                    },
                    _fh,
                    indent=2,
                )
        except Exception as _exc:
            print(f"[Warn] best_final_meta.json not written: {_exc}", flush=True)
        best_final_dst = os.path.join(checkpoint_dir, "best_final.pt")
        try:
            shutil.copy2(final_best, best_final_dst)
        except Exception as exc:
            print(f"[Warn] failed to export best_final.pt: {exc}", flush=True)
        print(
            f"[best] final eval model: {final_best} (stage={final_stage_picked}, "
            f"score={best_sc:.4f}, collisions={best_co:.3f}) -> exported best_final.pt"
        )
    else:
        _latest_p = os.path.join(checkpoint_dir, "latest.pt")
        if str(getattr(args, "final_select", "latest") or "latest").strip().lower() == "latest" and os.path.isfile(_latest_p):
            try:
                shutil.copy2(_latest_p, os.path.join(checkpoint_dir, "best_final.pt"))
                print(
                    "[best][v5.1] no gated stage checkpoints; exported latest.pt as best_final.pt "
                    "(select on validation seeds with scripts/evaluate_policy.py)",
                    flush=True,
                )
            except Exception as exc:
                print(f"[Warn] failed to export latest.pt as best_final.pt: {exc}", flush=True)
        status_txt = ", ".join(
            f"{st}={'ok' if os.path.isfile(os.path.join(checkpoint_dir, _BEST_STAGE_FILENAMES[st])) else 'missing'}"
            for st in _CURRICULUM_ORDER
        )
        print(f"[best] stage checkpoints: {status_txt}")


if __name__ == "__main__":
    try:
        mp.set_start_method("spawn", force=True)
    except RuntimeError:
        pass
    train()
