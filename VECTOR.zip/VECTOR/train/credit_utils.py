"""Per-step CAV credit assignment (pure numpy; unit-tested).

VECTOR v3 used a *relative* advantage: delta_i = r_i - b_i with
b_i = 0.75 * mean(same-approach peers incl. ego) + 0.25 * mean(all).
Same-approach peers are mostly ego's followers, whose rewards depend on ego's
actions, so ego's effective objective was ~ r_i - c * sum(follower rewards):
hurting followers raised ego's advantage (anti-cooperative, biased baseline).

v4 default ``coop_xapp``:
  * cooperative reward  r~_i = r_i + kappa * mean_{j in same approach, j != i} r_j
  * action-independent baseline b_i = mean of r~_j over CAVs on OTHER approaches
    (fallback: rollout-level constant), so the baseline cannot be moved by ego.
Same-approach peers now enter ego's objective only with weight +kappa.
"""
from __future__ import annotations

from typing import Dict, Iterable, List, Sequence, Tuple

import numpy as np

# (agent_id, approach_key, own_reward, peer_value)
CreditEntry = Tuple[str, str, float, float]
CREDIT_MODES = ("coop_xapp", "relative", "individual")


def _mean(xs) -> float:
    xs = list(xs)
    return float(np.mean(xs)) if xs else 0.0


def relative_deltas(entries: Sequence[CreditEntry], use_cross_app: bool = True,
                    min_peers: int = 2) -> Dict[str, float]:
    """Legacy v3 relative credit (kept bit-compatible for ablations)."""
    if not entries:
        return {}
    all_mean = _mean(e[3] for e in entries)
    by_app: Dict[str, List[float]] = {}
    for _aid, app, _own, peer in entries:
        if app:
            by_app.setdefault(app, []).append(float(peer))
    out: Dict[str, float] = {}
    for aid, app, own, _peer in entries:
        peers = by_app.get(app) if (use_cross_app and app) else None
        if peers and len(peers) >= int(min_peers):
            base = 0.75 * _mean(peers) + 0.25 * all_mean
        else:
            base = all_mean
        out[aid] = float(own) - float(base)
    return out


def coop_values(entries: Sequence[CreditEntry], kappa: float = 0.5):
    """Return ({aid: r~ from own reward}, {aid: r~ from peer value})."""
    by_app: Dict[str, List[Tuple[str, float]]] = {}
    for aid, app, _own, peer in entries:
        if app:
            by_app.setdefault(app, []).append((aid, float(peer)))
    coop_own: Dict[str, float] = {}
    coop_peer: Dict[str, float] = {}
    for aid, app, own, peer in entries:
        others = [p for (a, p) in by_app.get(app, ()) if a != aid] if app else []
        bonus = float(kappa) * _mean(others) if others else 0.0
        coop_own[aid] = float(own) + bonus
        coop_peer[aid] = float(peer) + bonus
    return coop_own, coop_peer


def coop_xapp_deltas(entries: Sequence[CreditEntry], kappa: float = 0.5,
                     fallback_mean: float = 0.0, min_peers: int = 2) -> Dict[str, float]:
    """Cooperative credit with a cross-approach (action-independent) baseline."""
    if not entries:
        return {}
    coop_own, coop_peer = coop_values(entries, kappa)
    out: Dict[str, float] = {}
    for aid, app, _own, _peer in entries:
        base = float(fallback_mean)
        if app:
            others = [coop_peer[a] for (a, ap, _o, _p) in entries
                      if a != aid and ap and ap != app]
            if len(others) >= int(min_peers):
                base = _mean(others)
        out[aid] = coop_own[aid] - base
    return out


def rollout_fallback_mean(all_entries: Iterable[Sequence[CreditEntry]],
                          kappa: float = 0.5) -> float:
    """Rollout-level constant baseline (mean cooperative peer value)."""
    vals: List[float] = []
    for entries in all_entries:
        if entries:
            _own, peer = coop_values(entries, kappa)
            vals.extend(peer.values())
    return _mean(vals)


def step_deltas(entries: Sequence[CreditEntry], mode: str = "coop_xapp",
                kappa: float = 0.5, use_cross_app: bool = True,
                fallback_mean: float = 0.0, min_peers: int = 2) -> Dict[str, float]:
    m = str(mode or "coop_xapp").strip().lower()
    if m == "individual":
        return {str(aid): float(own) for aid, _app, own, _peer in (entries or ())}
    if m == "relative":
        return relative_deltas(entries, use_cross_app=use_cross_app, min_peers=min_peers)
    return coop_xapp_deltas(entries, kappa=kappa, fallback_mean=fallback_mean,
                            min_peers=min_peers)


# ---------------------------------------------------------------------------
# v5.2.4: Lon samples whose sampled action was NOT executed (CAV handed back to
# SUMO by IDM_FOLLOWER / native-IDM ablation / near-stop-line handback) carry
# an advantage that does not depend on the action -> excluded from PPO.
# ---------------------------------------------------------------------------
def lon_agent_vid(agent_id: str) -> str:
    """'cav_lon_<vid>' or legacy 'cav_<vid>' -> '<vid>'."""
    s = str(agent_id)
    if s.startswith("cav_lon_"):
        return s[len("cav_lon_"):]
    if s.startswith("cav_"):
        return s[len("cav_"):]
    return s


def is_lon_noop(noop_steps, step_idx: int, agent_id: str) -> bool:
    """True when ``agent_id``'s vehicle is listed as a no-op at ``step_idx``.

    ``noop_steps`` is the rollout's per-step list of vehicle-id collections, or
    None to keep every sample (``--keep-lon-noop-samples``).
    """
    if noop_steps is None or step_idx < 0 or step_idx >= len(noop_steps):
        return False
    return lon_agent_vid(agent_id) in (noop_steps[step_idx] or ())
