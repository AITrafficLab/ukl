# CHANGELOG v5.2.1 → v5.2.2（验证后可落地版）

依据：v5.1/v5.2/v5.2.1 的消融 A0–A5、v5.2.2 短验证、`Diag-RedGap2` 和 4-leg 诊断压缩包。

## 已实现并验证

1. 控制栈：`SUMO_INTERFACE.RED_GLIDE_HEAD_ONLY` 默认开启（`LON_RED_GLIDE_HEAD_ONLY=1`）。130 m 连续滑行包络只用于排头车或已越过停车线/快速远距前车。
2. 控制栈：`SUMO_INTERFACE.IDM_FOLLOWER_ENABLED` 默认开启（`LON_IDM_FOLLOWER=1`）。红/黄灯下慢速且跟车距离 <30 m 的 CAV 交还 SUMO 原生 IDM（`setSpeedMode(31); setSpeed(-1)`），记录零残差。
3. 奖励：默认 `lon_reward_version=v2`；保留 `--lon-reward-version v1` 回归对照。日志应显示 `lon_reward_version=v2`。
4. 评估配置沿用 v4/v5 已有修正：`max_depart_delay=-1`、路口碰撞检测开启、OD 改写默认关闭。

## 验证结论

- 3-leg（隔离控制栈、v1 奖励，`logs/v522_fix_v1_3leg.log`）：Lon Ep4 `Diag-RedGap2 QUEUE CAV mean=4.37 m`，比 A1 的 12.29 m 显著下降；速度 8.80 m/s。
- 4-leg（v2 奖励 + 修复，`logs/v522c_4leg_v2.log`）：Lon Ep3 `QUEUE CAV mean=0.26 m`、`pack=0.95`、`creep=0.01`，停车间距已修复到原生 IDM 水平（A0 为 0.17 m）。但速度仍 2.09 m/s、队列 567 m、backlog 312。
- 4-leg（全量原生 IDM，`logs/v522c_4leg_nativeidm.log`）：Lon Ep3 速度 6.56 m/s、队列 195 m、无 insertion backlog 警告，`QUEUE CAV mean=0.17 m`。

## 最终判断

CAV 跟驰/红灯滑行导致的“二次排队间距”已修复。4-leg 剩余锁死来自规则栈中的其他层（GLOSA 下限、CACC/权限、信号预算/SPaT 或 HDV_SW），不再来自红灯停车间距。正式训练前只有在 4-leg 上复现“原生 IDM 连续可行”后，才应继续放开 CAV 控制；当前不要把 v5.2.2 直接用于 4-leg 正式训练。

推荐落地组合：
- 3-leg 训练/论文主实验：可使用 v5.2.2（v2 奖励 + 两个控制修复）。
- 4-leg：使用 `--ablate-cav-native-idm` 作为临时安全基线，或继续定位剩余规则层；不要宣称控制栈通行能力已完全解决。
