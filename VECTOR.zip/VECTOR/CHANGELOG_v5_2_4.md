# CHANGELOG v5.2.3 → v5.2.4（控制栈分层定位 + 两处正确性修复）

依据：v5.2.3 的 4-leg 日志与 SUMO 诊断。

- 恢复 SW 车型的战略换道后，Lon 阶段仍然锁死，需求降到 0.75 也一样：车速 2.1–2.4 m/s，而 Stage-S 为 6.7–9.6 m/s。
- 堵塞传送集中发生在信号路口内部车道：每回合 29–37 次，原生 IDM 为 0。
- 这些卡在路口内的车里，CAV 占 37–47%，高于其 30% 的车流占比。

## 1. 分层定位开关（默认全关 = v5.2.3 行为）

| 开关 | 环境变量 | 作用 |
|---|---|---|
| `--lon-no-floors` | `LON_NO_FLOORS` | B2：关闭四个加速度下限（巡航、后车、路口清空 +0.8、静止防停滞 +0.8） |
| `--lon-handback-near-m N` | `LON_HANDBACK_NEAR_M` | B3：距停车线 N m 内以及路口内，把 CAV 交还 SUMO 自身模型 |
| `--lon-handback-junction` | `LON_HANDBACK_JUNCTION` | B3b：只在路口内交还 |
| `--lon-actuation speed` | `LON_ACTUATION` | B4：控制栈输出改为速度建议，用 `setMaxSpeed` 设上限（只在控制栈要求的加速度低于 a_IDM 时才设）。SUMO 保留自己的跟驰、让行和路口占用逻辑；车辆被交还或离开时恢复原最高车速。默认 `accel`，即 `setAcceleration` |

所有交还都经过 `_note_handback`：记录为“本步未执行”，并按原因计数（`idm_follower` / `native_idm` / `near_stopline` / `junction`）。

## 2. 正确性修复（默认开启）

**2.1 交还样本不再进入 PPO（`--keep-lon-noop-samples` 可恢复旧行为）**

- **问题：** v5.2.2 的 `IDM_FOLLOWER` 和 v5.2.1 的原生 IDM 消融，都会把 CAV 交还给 SUMO，但这些样本仍以采样动作和对数概率进入纵向 PPO。它们的优势与动作无关，是纯噪声。
- **修法：**
  - 环境在 info 中返回 `lon_noop_vids`；
  - rollout 按步记录；
  - `merge_and_update` 通过 `train/credit_utils.is_lon_noop` 排除这些样本；
  - 这些车辆也不再计入拉格朗日安全约束的干预率分母。

**2.2 合成黄灯 / 全红期间的到绿时间（`--no-spat-synth-fix` 可回退）**

- **问题：** v5.2.3 在过渡期间按旧绿灯 `from_phase` 沿静态程序推算，起算时间取自临时 “online” 程序的 `getNextSwitch`，两者都不对。
- **修法：**
  - `remaining_time` 改为过渡的真实剩余时间（黄灯剩余 + 全红）；
  - `_time_to_green` 从已确定的下一绿灯 `next_green` 开始推算；
  - 影响 GLOSA、红灯滑行包络、纵向/横向观测中的到绿时间，以及信号观测中的剩余时间特征。

## 3. 只观测的诊断

**`[Diag-JStall]`（每回合一行，同时写入 TensorBoard 的 `Metrics/jstall_*` 和 `Metrics/lon_*`）：**
- 信号路口内部静止（< 0.1 m/s）的车辆·秒，分受控 CAV、未受控 CAV、HDV 三类；
- 连续静止 ≥ 10 s 的车辆数，每辆车每回合只计一次；
- 无信号子路口内部的静止车辆·秒；
- 纵向无效样本占比、各类交还次数、本回合被 PPO 排除的样本数。

**汇总行：** 末尾追加 `TIS`、`Backlog`、`Teleports`、`Collisions`。原有的 TravelT 不计未插入车辆，会掩盖锁死。

## 4. 其他

- 奖励模块默认版本改为 v2，与 `train_RL` 和配置文件一致（此前不经过 `train_RL` 的脚本会悄悄用 v1）。
- v2 下启动日志改为打印 v2 自己的固定权重，并说明 `W_long` 只对 v1 生效。
- 主进程退出（Ctrl+C 或崩溃）时，环境子进程静默退出，不再打印 `BrokenPipeError`。
- `config.yaml`：
  - 头部注释改为实际排程（Full 850）；
  - `stage_*` 字段标为遗留字段；
  - 默认 sumocfg 改为包内存在的 3-leg；
  - 新增 v5.2.4 的开关项。
- 打包：去掉截断且含语法错误的 `SUMO_interface.py.bak522`，以及 `__pycache__`、`results/`、`logs/`、空的 `bev_renders/`。

## 5. 发现但有意未改

- **模仿损失的目标不对。** `applied_cav_actions` 从未进入 `infos['__all__']`，所以软启动的模仿损失模仿的是采样动作，而不是执行后的残差。修好它会重新启用“模仿规则栈”，所以保持现状。建议之后把模仿系数设为 0。
- **权限过滤是死代码。** `cacc_ppo_authority_min = 0.20` 低于权限下限 0.25，任何样本都不会被过滤掉。
- **4-leg 的 rou 文件。** 保留 v5.2.3 的 SW 车型修改，这样 B 系列消融才能与 v5.2.3 的运行在同一场景下配对比较。

## 验证

- 新增 `tests/test_v524_bisection.py`（19 项）：
  - 默认值与 v5.2.3 一致；
  - 交还判定；
  - 两种执行方式（含恢复最高车速）；
  - 无效样本过滤；
  - 路口停滞统计（分类、≥10 s 事件、移动后重新计时）；
  - 过渡期到绿时间（包括下一绿灯为 0 号相位、非过渡期行为不变）；
  - 开关确实接入了 `step()` 和训练端。
- 全部 67 项离线测试通过，1 项按设计跳过；静态检查 0 个问题。
- 沙箱里没有 SUMO 和 torch。`setMaxSpeed` 在 libsumo 下的实际效果，请以 B4 的日志为准。
