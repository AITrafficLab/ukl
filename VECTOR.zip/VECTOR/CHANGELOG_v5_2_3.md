# CHANGELOG v5.2.2 → v5.2.3（4-leg 根因修复）

4-leg 剩余锁死与红灯停车间距无关。v5.2.2 已把 QUEUE CAV 间距修到 0.26 m，但速度仍约 2 m/s；原生 IDM 对照为 6.56 m/s。剩余证据集中在 4-leg 专用 `HDV_SW` / `CAV_SW` 车型：二者 `lcStrategic=0` 且合计占需求约四分之一，导致大量 side collision / yield teleport 和错误车道死锁。

修复：在 `environment/sumo_net/4-leg(4phases)/4-leg(4phases).rou.xml` 中给 `HDV_SW` / `CAV_SW` 恢复 SUMO 正常战略换道：
- `lcStrategic="1.0"`
- `lcKeepRight="1"`
- `lcSpeedGain="1"`

其他文件与 v5.2.2 相同；3-leg 不受影响，5-leg 没有 SW 车型，也不受此修复影响。
