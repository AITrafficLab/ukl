"""Discrete lateral policy for CAV lane selection.

Action convention: 0 = change left, 1 = keep lane, 2 = change right.
The policy consumes only the local observation vector (CTDE execution).
"""
from __future__ import annotations

import math
import os

import torch
import torch.nn as nn
from torch.distributions import Categorical

from networks.actor import DiscreteActor


class LateralActor(DiscreteActor):
    """MAPPO actor for discrete lane actions, with robust action masking
    and exact importance-sampling log_prob under soft-start keep blending."""

    KEEP_ACTION = 1
    FALLBACK_ACTION = 1

    def __init__(self, obs_dim, action_dim=3, hidden_dim=128):
        obs_dim = int(obs_dim)
        action_dim = int(action_dim)
        hidden_dim = int(hidden_dim)
        if obs_dim <= 0:
            raise ValueError(f"obs_dim must be positive; got {obs_dim}")
        if action_dim <= 0:
            raise ValueError(f"action_dim must be positive; got {action_dim}")
        if hidden_dim <= 0:
            raise ValueError(f"hidden_dim must be positive; got {hidden_dim}")

        super().__init__(obs_dim, action_dim, hidden_dim=hidden_dim)
        self.action_dim = action_dim
        self.obs_dim = obs_dim
        self._initialize_policy()

    def _initialize_policy(self):
        """Orthogonal initialization commonly used for stable PPO training."""
        linear_layers = [m for m in self.net.modules() if isinstance(m, nn.Linear)]
        for layer in linear_layers[:-1]:
            nn.init.orthogonal_(layer.weight, gain=math.sqrt(2.0))
            nn.init.zeros_(layer.bias)
        if linear_layers:
            nn.init.orthogonal_(linear_layers[-1].weight, gain=0.01)
            nn.init.zeros_(linear_layers[-1].bias)
            # v4: keep-biased initial policy replaces the soft-start mixture. The
            # mixture made behavior != target policy (PPO ratio started at 1/beta,
            # KL early-stop blocked Lat updates). P(keep) ~= 0.69 at init.
            keep_bias = float(os.environ.get("LAT_KEEP_LOGIT_BIAS_INIT", "1.5") or 1.5)
            keep_idx = int(getattr(self, "KEEP_ACTION", 1))
            if 0 <= keep_idx < int(linear_layers[-1].bias.shape[0]):
                with torch.no_grad():
                    linear_layers[-1].bias[keep_idx] = keep_bias

    def _prepare_vector(self, obs_dict):
        if not isinstance(obs_dict, dict) or "vector" not in obs_dict:
            raise KeyError("LateralActor expects obs_dict with a 'vector' field")
        reference = next(self.parameters())
        vector = obs_dict["vector"]
        if not torch.is_tensor(vector):
            vector = torch.as_tensor(vector, dtype=reference.dtype, device=reference.device)
        else:
            vector = vector.to(device=reference.device, dtype=reference.dtype)

        unbatched = vector.ndim == 1
        if unbatched:
            vector = vector.unsqueeze(0)
        elif vector.ndim != 2:
            raise ValueError(
                "obs_dict['vector'] must have shape [obs_dim] or [batch, obs_dim]; "
                f"got {tuple(vector.shape)}"
            )
        if vector.shape[-1] != self.obs_dim:
            raise ValueError(
                f"Expected observation width {self.obs_dim}, got {vector.shape[-1]}"
            )
        vector = torch.nan_to_num(vector, nan=0.0, posinf=1e6, neginf=-1e6)
        return vector, unbatched

    def _apply_action_mask(self, logits, action_mask):
        if action_mask is None:
            return logits

        mask = torch.as_tensor(action_mask, device=logits.device)
        mask = torch.nan_to_num(
            mask.to(dtype=logits.dtype), nan=0.0, posinf=1.0, neginf=0.0
        )
        if mask.ndim == 0:
            raise ValueError("action_mask must contain one entry per action")
        if mask.ndim == 1:
            mask = mask.unsqueeze(0)
        elif mask.ndim > 2:
            mask = mask.reshape(mask.shape[0], -1)

        batch_size, action_count = logits.shape
        if mask.shape[0] == 1 and batch_size > 1:
            mask = mask.expand(batch_size, -1)
        elif mask.shape[0] != batch_size:
            if mask.numel() == batch_size * mask.shape[-1]:
                mask = mask.reshape(batch_size, -1)
            else:
                raise ValueError(
                    f"action_mask batch {mask.shape[0]} does not match observation batch {batch_size}"
                )

        aligned = torch.zeros(
            (batch_size, action_count), dtype=torch.bool, device=logits.device
        )
        width = min(action_count, int(mask.shape[-1]))
        if width:
            aligned[:, :width] = mask[:, :width] > 0

        no_valid_action = ~aligned.any(dim=-1)
        if no_valid_action.any():
            fallback = min(self.KEEP_ACTION, action_count - 1)
            aligned[no_valid_action, fallback] = True

        return logits.masked_fill(~aligned, torch.finfo(logits.dtype).min)

    def forward(self, obs_dict):
        vector, unbatched = self._prepare_vector(obs_dict)
        logits = self.net(vector)
        logits = self._apply_action_mask(logits, obs_dict.get("action_mask"))
        return logits.squeeze(0) if unbatched else logits

    def get_action(self, obs_dict, deterministic=False, soft_start_beta: float = 1.0):
        """Sample action; when ``soft_start_beta < 1``, sample from exact mixture
        ``mu(a|s) = (1-beta)*I[a==KEEP] + beta*pi(a|s)`` (when KEEP is legal)
        and return ``log mu(a|s)`` so PPO importance ratios stay unbiased."""
        logits = self.forward(obs_dict)
        beta = float(max(0.0, min(1.0, float(soft_start_beta))))
        if deterministic or beta >= 1.0 - 1e-6:
            distribution = Categorical(logits=logits)
            action = torch.argmax(logits, dim=-1) if deterministic else distribution.sample()
            return action, distribution.log_prob(action)

        probs = torch.softmax(logits, dim=-1)
        keep_idx = min(self.KEEP_ACTION, probs.shape[-1] - 1)
        keep_legal = probs[..., keep_idx] > 1e-12
        mixed_probs = probs.clone()
        if bool(keep_legal.any()):
            mixed_probs = beta * probs
            mixed_probs[..., keep_idx] = mixed_probs[..., keep_idx] + (1.0 - beta)
            mixed_probs = torch.where(keep_legal.unsqueeze(-1), mixed_probs, probs)
            mixed_probs = mixed_probs / mixed_probs.sum(dim=-1, keepdim=True).clamp_min(1e-12)
        mixed_dist = Categorical(probs=mixed_probs)
        action = mixed_dist.sample()
        return action, mixed_dist.log_prob(action)

    def evaluate_actions(self, obs_dict, actions):
        """Return log probabilities and categorical entropy for PPO updates."""
        logits = self.forward(obs_dict)
        distribution = Categorical(logits=logits)
        action = torch.as_tensor(actions, dtype=torch.long, device=logits.device)
        if logits.ndim == 1:
            if action.numel() != 1:
                raise ValueError("A single observation requires exactly one action")
            action = action.reshape(())
        else:
            if action.ndim > 1 and action.shape[-1] == 1:
                action = action.squeeze(-1)
            if action.shape != logits.shape[:-1] and action.numel() == logits.shape[0]:
                action = action.reshape(logits.shape[:-1])
        return distribution.log_prob(action), distribution.entropy()
