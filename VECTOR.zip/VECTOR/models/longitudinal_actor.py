"""Continuous longitudinal policy with bounded acceleration in [low, high].

The actor uses a tanh-squashed Gaussian and returns corrected log probabilities
for the affine+tanh action transform, as required by PPO/MAPPO. Near red stop
lines and compact slow queues, exploration noise is smoothly attenuated as a
pure function of the observation vector while keeping exact ``strict=True``
checkpoint parameter compatibility.
"""
from __future__ import annotations

import math

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions import Normal

# Symmetric latent clamp so tanh->atanh round-trips stay finite in float32.
RAW_ACTION_LIMIT = math.atanh(1.0 - 1e-4)  # ~= 4.9517
LOG_STD_MIN = -2.8  # sigma >= ~= 0.06
LOG_STD_MAX = -0.35 # sigma <= ~= 0.70 (prevents wild gas/brake exploration)
# Interior margin for imitation targets so shield spikes never saturate tanh' -> 0.
IMITATION_BOX_MARGIN_FRAC = 0.03


class LongitudinalActor(nn.Module):
    """Gaussian actor for longitudinal acceleration control.

    Outputs a smooth IDM-residual acceleration delta in ``[action_low, action_high]``
    (default ``[-2.2, +1.0]`` m/s^2) initialized at exact ``0.0`` m/s^2 so initial
    policy == SUMO IDM baseline with zero stage-transition shock.
    """

    def __init__(
        self,
        obs_dim,
        action_dim=1,
        hidden_dim=128,
        action_low=-2.2,
        action_high=1.0,
    ):
        super().__init__()
        self.obs_dim = int(obs_dim)
        self.action_dim = int(action_dim)
        hidden_dim = int(hidden_dim)
        self.action_low = float(action_low)
        self.action_high = float(action_high)

        if self.obs_dim <= 0:
            raise ValueError(f"obs_dim must be positive; got {self.obs_dim}")
        if self.action_dim <= 0:
            raise ValueError(f"action_dim must be positive; got {self.action_dim}")
        if hidden_dim <= 0:
            raise ValueError(f"hidden_dim must be positive; got {hidden_dim}")
        if not math.isfinite(self.action_low) or not math.isfinite(self.action_high):
            raise ValueError("action bounds must be finite")
        if self.action_high <= self.action_low:
            raise ValueError(
                f"action_high must be greater than action_low; got "
                f"{self.action_low}, {self.action_high}"
            )

        self.action_center = 0.5 * (self.action_low + self.action_high)
        self.action_half = 0.5 * (self.action_high - self.action_low)

        # Keep exact module names/shapes so existing checkpoints load with strict=True.
        self.net = nn.Sequential(
            nn.Linear(self.obs_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
        )
        self.mean_layer = nn.Linear(hidden_dim, self.action_dim)
        self.log_std_layer = nn.Parameter(torch.full((1, self.action_dim), -1.35))
        self._initialize_policy()

    def _initialize_policy(self):
        for module in self.net.modules():
            if isinstance(module, nn.Linear):
                nn.init.orthogonal_(module.weight, gain=math.sqrt(2.0))
                nn.init.zeros_(module.bias)
        nn.init.orthogonal_(self.mean_layer.weight, gain=0.01)
        neutral_ratio = (0.0 - self.action_center) / max(self.action_half, 1e-6)
        neutral_ratio = max(-0.95, min(0.95, float(neutral_ratio)))
        nn.init.constant_(self.mean_layer.bias, math.atanh(neutral_ratio))
        with torch.no_grad():
            self.log_std_layer.fill_(-1.35)

    def load_state_dict(self, state_dict, strict: bool = True, assign: bool = False):
        """Transparently zero-pad legacy 22-dim input weights to 23-dim (beta + goal_speed)."""
        if isinstance(state_dict, dict) or hasattr(state_dict, "keys"):
            patched = dict(state_dict)
            w_key = "net.0.weight"
            if w_key in patched and torch.is_tensor(patched[w_key]):
                w_old = patched[w_key]
                if w_old.ndim == 2 and w_old.shape[1] < self.obs_dim:
                    pad_cols = self.obs_dim - int(w_old.shape[1])
                    pad = torch.zeros(
                        (w_old.shape[0], pad_cols),
                        dtype=w_old.dtype,
                        device=w_old.device,
                    )
                    patched[w_key] = torch.cat([w_old, pad], dim=1)
            state_dict = patched
        return super().load_state_dict(state_dict, strict=strict, assign=assign)

    def _prepare_vector(self, obs_dict):
        if not isinstance(obs_dict, dict) or "vector" not in obs_dict:
            raise KeyError("LongitudinalActor expects obs_dict with a 'vector' field")
        reference = next(self.parameters())
        vector = obs_dict["vector"]
        if not torch.is_tensor(vector):
            vector = torch.as_tensor(vector, dtype=reference.dtype, device=reference.device)
        else:
            vector = vector.to(device=reference.device, dtype=reference.dtype)
        if vector.ndim not in (1, 2):
            raise ValueError(
                "obs_dict['vector'] must have shape [obs_dim] or [batch, obs_dim]; "
                f"got {tuple(vector.shape)}"
            )
        if vector.shape[-1] != self.obs_dim:
            raise ValueError(
                f"Expected observation width {self.obs_dim}, got {vector.shape[-1]}"
            )
        return torch.nan_to_num(vector, nan=0.0, posinf=1e6, neginf=-1e6)

    def _state_std_scale(self, vector: torch.Tensor) -> torch.Tensor:
        """Smoothly damp exploration std near red stop lines and tight slow queues.

        Pure deterministic function of ``vector`` (detached), so rollout sampling
        and PPO ``evaluate_actions`` share the exact same distribution.
        """
        if self.obs_dim < 18:
            return torch.ones_like(vector[..., :1])
        with torch.no_grad():
            speed_norm = vector[..., 0:1].clamp(0.0, 1.5)   # speed / v_lim
            dist_norm = vector[..., 3:4].clamp(0.0, 2.5)    # dist_to_stopline / 200m
            gap_norm = vector[..., 7:8].clamp(0.0, 2.0)     # leader_gap / 100m
            tls_code = vector[..., 17:18]                   # -1.0 red, -0.5 yellow, +1.0 green

            is_red_or_yellow = (tls_code < -0.25).to(vector.dtype)
            # Ramp 0 -> 1 inside 36m of red/yellow stop line; stronger when slow (< ~6 m/s).
            red_prox = ((0.18 - dist_norm) / 0.18).clamp(0.0, 1.0) * is_red_or_yellow
            slow_fac = ((0.35 - speed_norm) / 0.35).clamp(0.0, 1.0)
            # Ramp 0 -> 1 inside 8m net gap to leader.
            lead_prox = ((0.08 - gap_norm) / 0.08).clamp(0.0, 1.0)

            prox = torch.maximum(
                red_prox * (0.40 + 0.60 * slow_fac),
                lead_prox * (0.50 + 0.50 * slow_fac),
            )
            # Moderately attenuate std down to 0.45x at standstill pocket so
            # standstill pulses are damped without freezing IDM-residual exploration.
            return (1.0 - 0.55 * prox).clamp(0.45, 1.0)

    def forward(self, obs_dict):
        vector = self._prepare_vector(obs_dict)
        features = self.net(vector)
        mean = self.mean_layer(features)
        mean = torch.nan_to_num(
            mean, nan=0.0, posinf=RAW_ACTION_LIMIT, neginf=-RAW_ACTION_LIMIT
        )
        mean = mean.clamp(-RAW_ACTION_LIMIT, RAW_ACTION_LIMIT)
        log_std = torch.clamp(self.log_std_layer, LOG_STD_MIN, LOG_STD_MAX).expand_as(mean)
        std_scale = self._state_std_scale(vector).expand_as(mean)
        std = (torch.exp(log_std) * std_scale).clamp(min=0.04)
        return mean, std

    def _squash(self, raw_action):
        return self.action_center + self.action_half * torch.tanh(raw_action)

    def _corrected_log_prob(self, distribution, raw_action):
        log_tanh_jacobian = 2.0 * (
            math.log(2.0) - raw_action - F.softplus(-2.0 * raw_action)
        )
        log_abs_det_jacobian = math.log(self.action_half) + log_tanh_jacobian
        return (distribution.log_prob(raw_action) - log_abs_det_jacobian).sum(dim=-1)

    def _align_actions(self, actions, mean):
        action = torch.as_tensor(actions, dtype=mean.dtype, device=mean.device)
        if mean.ndim == 2:
            if action.ndim == 0:
                action = action.reshape(1, 1)
            elif action.ndim == 1:
                if self.action_dim == 1 and action.shape[0] == mean.shape[0]:
                    action = action.unsqueeze(-1)
                elif mean.shape[0] == 1 and action.numel() == self.action_dim:
                    action = action.unsqueeze(0)
            if action.shape != mean.shape and action.numel() == mean.numel():
                action = action.reshape_as(mean)
        elif mean.ndim == 1 and action.shape != mean.shape:
            if action.numel() == mean.numel():
                action = action.reshape_as(mean)
        if action.shape != mean.shape:
            raise ValueError(
                f"Action shape {tuple(action.shape)} does not match policy output "
                f"{tuple(mean.shape)}"
            )
        return torch.nan_to_num(
            action, nan=self.action_center, posinf=self.action_high, neginf=self.action_low
        )

    def _action_to_raw(self, action, mean):
        del mean
        normalized = (action - self.action_center) / self.action_half
        lim = math.tanh(RAW_ACTION_LIMIT)
        normalized = normalized.clamp(-lim, lim)
        return torch.atanh(normalized)

    def get_action(self, obs_dict, deterministic=False):
        mean, std = self.forward(obs_dict)
        distribution = Normal(mean, std)
        raw_action = mean if deterministic else distribution.sample()
        raw_action = raw_action.clamp(-RAW_ACTION_LIMIT, RAW_ACTION_LIMIT)
        action = self._squash(raw_action)
        log_prob = self._corrected_log_prob(distribution, raw_action)
        return action, log_prob

    def evaluate_actions(self, obs_dict, actions):
        mean, std = self.forward(obs_dict)
        distribution = Normal(mean, std)
        action = self._align_actions(actions, mean)
        raw_action = self._action_to_raw(action, mean)
        log_prob = self._corrected_log_prob(distribution, raw_action)
        entropy = distribution.entropy().sum(dim=-1)
        return log_prob, entropy

    def anchor_loss(self, obs_dict, anchor_module):
        """Bounded Smooth-L1 (action) + latent W2 proxy toward frozen anchor mean."""
        if anchor_module is None:
            return None
        mean, std = self.forward(obs_dict)
        with torch.no_grad():
            a_mean, a_std = anchor_module.forward(obs_dict)
            a_act = anchor_module._squash(
                a_mean.clamp(-RAW_ACTION_LIMIT, RAW_ACTION_LIMIT)
            )
        my_act = self._squash(mean.clamp(-RAW_ACTION_LIMIT, RAW_ACTION_LIMIT))
        act_term = F.smooth_l1_loss(my_act, a_act, beta=0.5, reduction="mean")
        w2 = ((mean - a_mean) ** 2 + (std - a_std) ** 2).mean()
        loss = act_term + 0.1 * w2
        if not bool(torch.isfinite(loss)):
            return None
        return loss

    def imitation_loss(self, obs_dict, target_actions):
        """Pull policy mean toward interior-clamped executed accelerations."""
        mean, _ = self.forward(obs_dict)
        target = self._align_actions(target_actions, mean)
        margin = float(IMITATION_BOX_MARGIN_FRAC) * self.action_half
        lo = self.action_low + margin
        hi = self.action_high - margin
        target = target.clamp(lo, hi)
        pred = self._squash(mean.clamp(-RAW_ACTION_LIMIT, RAW_ACTION_LIMIT))
        loss = F.smooth_l1_loss(pred, target, beta=0.5, reduction="mean")
        if not bool(torch.isfinite(loss)):
            return None
        return loss
