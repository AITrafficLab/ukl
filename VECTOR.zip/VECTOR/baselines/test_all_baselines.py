#!/usr/bin/env python3
"""
Test all baseline methods for import errors, basic logic, and interface compatibility.

Usage:
  python baselines/test_all_baselines.py
"""
from __future__ import annotations

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

print("=" * 80)
print("BASELINE COMPATIBILITY TEST")
print("=" * 80)

# Test 1: SOTL
print("\n[1/7] Testing SOTL...")
try:
    from baselines.sotl.controller import SOTLController
    from environment.SUMO_interface import SUMOEnvironment
    
    controller = SOTLController(phi_min=10.0, theta=50.0, queue_extend=3, step_length=0.2)
    print("  [OK] SOTLController instantiated")
    print(f"  [OK] params: {controller.params_dict()}")
    print("  [OK] SOTL: PASS")
except Exception as e:
    print(f"  [FAIL] SOTL: FAIL - {e}")

# Test 2: Max-Pressure
print("\n[2/7] Testing Max-Pressure...")
try:
    from baselines.max_pressure.controller import MaxPressureController
    
    controller = MaxPressureController(use_density=False)
    print("  [OK] MaxPressureController instantiated")
    print(f"  [OK] params: {controller.params_dict()}")
    print("  [OK] Max-Pressure: PASS")
except Exception as e:
    print(f"  [FAIL] Max-Pressure: FAIL - {e}")

# Test 3: PressLight
print("\n[3/7] Testing PressLight...")
try:
    from baselines.presslight.dqn_agent import PressLightDQN
    from baselines.presslight.pressure import PressLightEnvAdapter
    import torch
    
    agent = PressLightDQN(
        obs_dim=100,
        n_actions=8,
        lr=1e-3,
        gamma=0.95,
        device="cpu"
    )
    print("  [OK] PressLightDQN instantiated")
    print(f"  [OK] device: {agent.device}")
    
    # Test forward pass
    dummy_obs = torch.randn(1, 100)
    q_values = agent.q_network(dummy_obs)
    print(f"  [OK] Q-network forward: {q_values.shape}")
    print("  [OK] PressLight: PASS")
except Exception as e:
    print(f"  [FAIL] PressLight: FAIL - {e}")

# Test 4: DDPG CAV
print("\n[4/7] Testing DDPG CAV...")
try:
    from baselines.ddpg_cav.ddpg_agent import DDPGAgent
    from baselines.ddpg_cav.features import build_obs, compute_reward
    
    agent = DDPGAgent(
        obs_dim=20,
        action_dim=1,
        action_min=-3.0,
        action_max=3.0,
        lr_actor=1e-4,
        lr_critic=1e-4,
        gamma=0.9,
        tau=0.005,
        device="cpu"
    )
    print("  [OK] DDPGAgent instantiated")
    print(f"  [OK] replay buffer size: {agent.replay_buffer.max_size}")
    
    # Test action selection
    import numpy as np
    dummy_obs = np.random.randn(20)
    action = agent.select_action(dummy_obs, noise=0.1)
    print(f"  [OK] action selection: {action}")
    print("  [OK] DDPG CAV: PASS")
except Exception as e:
    print(f"  [FAIL] DDPG CAV: FAIL - {e}")

# Test 5: CoTV
print("\n[5/7] Testing CoTV...")
try:
    from baselines.cotv.adapter import CoTVAdapter, TL_OBS_DIM, CAV_OBS_DIM
    from baselines.cotv.ppo import DiscretePPO, ContinuousPPO
    
    tl_agent = DiscretePPO(
        obs_dim=TL_OBS_DIM,
        n_actions=2,
        lr=3e-4,
        gamma=0.99,
        gae_lambda=0.95,
        clip=0.2,
        device="cpu"
    )
    print("  [OK] TL DiscretePPO instantiated")
    
    cav_agent = ContinuousPPO(
        obs_dim=CAV_OBS_DIM,
        action_dim=1,
        action_min=-3.0,
        action_max=3.0,
        lr=3e-4,
        gamma=0.99,
        gae_lambda=0.95,
        clip=0.2,
        device="cpu"
    )
    print("  [OK] CAV ContinuousPPO instantiated")
    print(f"  [OK] TL obs_dim={TL_OBS_DIM}, CAV obs_dim={CAV_OBS_DIM}")
    print("  [OK] CoTV: PASS")
except Exception as e:
    print(f"  [FAIL] CoTV: FAIL - {e}")

# Test 6: ViRL-TSC
print("\n[6/7] Testing ViRL-TSC...")
try:
    from baselines.virl_tsc.ppo_agent import VirlPPO
    from baselines.virl_tsc.obs import VirlObsBuilder, waiting_time_reward
    
    agent = VirlPPO(
        n_phases=5,
        lr=3e-4,
        gamma=0.99,
        device="cpu"
    )
    print("  [OK] VirlPPO instantiated")
    print(f"  [OK] n_phases: {agent.n_phases}")
    print(f"  [OK] obs_shape: {agent.obs_builder.obs_shape()}")
    print("  [OK] ViRL-TSC: PASS")
except Exception as e:
    print(f"  [FAIL] ViRL-TSC: FAIL - {e}")

# Test 7: LLM-Assisted Light
print("\n[7/7] Testing LLM-Assisted Light...")
try:
    from baselines.llm_assisted_light.controller import LALightController
    from baselines.llm_assisted_light.react_agent import ReActAgent
    
    controller = LALightController(
        model="gpt-4-turbo",
        api_key="dummy_key",
        api_base="https://api.openai.com/v1",
        action_interval=10.0,
        step_length=0.2,
        temperature=0.0,
        max_iterations=10,
        offline=True  # Don't actually call API
    )
    print("  [OK] LALightController instantiated")
    print(f"  [OK] offline mode: {controller.offline}")
    print(f"  [OK] action_interval: {controller.action_interval}s")
    print("  [OK] LLM-Assisted Light: PASS")
except Exception as e:
    print(f"  [FAIL] LLM-Assisted Light: FAIL - {e}")

print("\n" + "=" * 80)
print("SUMMARY")
print("=" * 80)
print("All baseline imports and basic instantiation tests completed.")
print("Run individual training scripts to test full pipelines.")
print("=" * 80)
