"""Keep TensorBoard curves continuous and non-overlapping across resumes.

Root failure modes:
1. Resume appends a new ``events.out.tfevents.*`` into a stamp that still holds
   steps >= next episode (or sibling stamps remain visible under ``tb/``) →
   duplicate x values → zigzag.
2. Parked history under a **visible** quarantine folder (``_tb_quarantine``) gets
   recursively discovered when TensorBoard ``--logdir`` points at ``seed_N`` (or
   above). Dirty 1..N and the active truncated curve then overlay → interleaved.

Call ``sanitize_tb_for_resume`` on every training resume (and from prepare_resume)
so the active stamp is rewritten to a single deduped event file with
``step < completed+1``, and every other stamp is quarantined under
``.tb_quarantine/`` (leading dot → TensorBoard ignores it).

History safety: never ``move`` the only copy of 1..N out of the active stamp until a
verified replacement file is on disk; if the stamp lost early steps, recover from
``.tb_quarantine``.
"""
from __future__ import annotations

import shutil
import time
from pathlib import Path
from typing import Any, Optional

from tensorboard.backend.event_processing.event_file_loader import RawEventFileLoader
from tensorboard.compat.proto import event_pb2
from tensorboard.summary.writer.record_writer import RecordWriter

# TensorBoard recursively walks logdir and skips directories whose names start
# with '.'. Underscore prefixes are NOT skipped — never park events there.
TB_QUARANTINE_DIRNAME = ".tb_quarantine"
_LEGACY_QUARANTINE_DIRNAMES = ("_tb_quarantine",)


def quarantine_root(run_or_tb_parent: Path) -> Path:
    """``seed_N/.tb_quarantine`` — invisible to TensorBoard recursive discovery."""
    return Path(run_or_tb_parent) / TB_QUARANTINE_DIRNAME


def migrate_legacy_quarantine_dirs(run_dir: Path) -> list[str]:
    """Rename legacy ``_tb_quarantine`` → ``.tb_quarantine`` so TB cannot see it."""
    run_dir = Path(run_dir)
    moved: list[str] = []
    dest_root = quarantine_root(run_dir)
    for legacy_name in _LEGACY_QUARANTINE_DIRNAMES:
        legacy = run_dir / legacy_name
        if not legacy.is_dir():
            continue
        dest_root.mkdir(parents=True, exist_ok=True)
        for child in sorted(legacy.iterdir()):
            target = dest_root / child.name
            if target.exists():
                target = dest_root / f"{child.name}_{int(time.time())}"
            try:
                shutil.move(str(child), str(target))
                moved.append(f"{legacy_name}/{child.name}")
            except OSError:
                continue
        try:
            # Remove empty legacy dir (ignore if something remained).
            legacy.rmdir()
        except OSError:
            pass
    return moved


def _is_header(what: Optional[str]) -> bool:
    return what in (
        "file_version",
        "session_log",
        "meta_graph_def",
        "tagged_run_metadata",
        None,
    )


def _summary_tags(event: event_pb2.Event) -> tuple[str, ...]:
    try:
        return tuple(sorted(str(v.tag) for v in event.summary.value))
    except Exception:
        return ()


def _dedupe_key(event: event_pb2.Event, what: str) -> tuple:
    step = int(event.step)
    if what == "summary":
        return ("summary", _summary_tags(event), step)
    return (what, step)


def _reward_step_span(event_dir: Path) -> tuple[int, int, int] | None:
    """Return (n, min_step, max_step) for Reward/Total_Episode_Reward, else None."""
    try:
        from tensorboard.backend.event_processing.event_accumulator import (
            EventAccumulator,
        )

        ea = EventAccumulator(str(event_dir))
        ea.Reload()
        tags = ea.Tags().get("scalars", [])
        if "Reward/Total_Episode_Reward" not in tags:
            return None
        steps = [int(e.step) for e in ea.Scalars("Reward/Total_Episode_Reward")]
        if not steps:
            return None
        return len(steps), min(steps), max(steps)
    except Exception:
        return None


def _max_step_in_files(files: list[Path]) -> int:
    max_step = -1
    for src in files:
        try:
            for raw in RawEventFileLoader(str(src)).Load():
                ev = event_pb2.Event.FromString(raw)
                what = ev.WhichOneof("what")
                if _is_header(what):
                    continue
                max_step = max(max_step, int(ev.step))
        except Exception:
            continue
    return max_step


def _merge_event_files(
    sources: list[Path],
    keep_before: int,
) -> tuple[list[bytes], dict[tuple, tuple[float, bytes]], dict[str, int]]:
    headers: list[bytes] = []
    saw_file_version = False
    stepped: dict[tuple, tuple[float, bytes]] = {}
    kept = dropped = deduped = 0
    for src in sources:
        if not src.is_file():
            continue
        try:
            iterator = RawEventFileLoader(str(src)).Load()
        except Exception:
            continue
        for raw in iterator:
            ev = event_pb2.Event.FromString(raw)
            what = ev.WhichOneof("what")
            if _is_header(what):
                if what == "file_version":
                    if saw_file_version:
                        continue
                    saw_file_version = True
                headers.append(raw)
                continue
            step = int(ev.step)
            if step >= keep_before:
                dropped += 1
                continue
            key = _dedupe_key(ev, str(what or "unknown"))
            if key in stepped:
                deduped += 1
            stepped[key] = (float(getattr(ev, "wall_time", 0.0) or 0.0), raw)
            kept += 1
    return headers, stepped, {"kept": kept, "dropped": dropped, "deduped": deduped}


def _write_merged_stamp(
    stamp_dir: Path,
    headers: list[bytes],
    stepped: dict[tuple, tuple[float, bytes]],
) -> Optional[Path]:
    stamp_dir.mkdir(parents=True, exist_ok=True)
    out = stamp_dir / f"events.out.tfevents.{int(time.time())}.sanitized.0"
    tmp = out.with_suffix(out.suffix + ".tmp")
    with open(tmp, "wb") as fout:
        writer = RecordWriter(fout)
        for raw in headers:
            writer.write(raw)
        # Sort by step first (then wall_time / key). Wall-time-only order
        # interleaves resume segments and makes TensorBoard zigzag on reload.
        for _key, (_wt, raw) in sorted(
            stepped.items(),
            key=lambda item: (int(item[0][-1]), float(item[1][0]), item[0]),
        ):
            writer.write(raw)
        writer.flush()
    if tmp.stat().st_size == 0:
        tmp.unlink(missing_ok=True)
        return None
    tmp.replace(out)
    return out


def rebuild_tb_stamp(
    stamp_dir: Path,
    keep_before: int,
    *,
    force: bool = False,
    extra_sources: Optional[list[Path]] = None,
) -> dict[str, Any]:
    """Rewrite ``stamp_dir`` to one event file: step < keep_before, last-write wins.

    Copies existing event files to quarantine for backup, writes the merged file
    first, then deletes the old active files — so a crash cannot leave the stamp
    empty with history only in quarantine.
    """
    stamp_dir = Path(stamp_dir)
    stamp_dir.mkdir(parents=True, exist_ok=True)
    keep_before = int(keep_before)
    files = sorted(
        (p for p in stamp_dir.glob("events.out.tfevents.*") if p.is_file()),
        key=lambda p: (p.stat().st_mtime_ns, p.name),
    )
    extra = [Path(p) for p in (extra_sources or []) if Path(p).is_file()]
    if not files and not extra:
        return {
            "rewrote": False,
            "kept": 0,
            "dropped": 0,
            "deduped": 0,
            "files_in": 0,
            "reason": "empty",
        }

    # Fast path: one file, no extras, already within keep window, no dups.
    if not force and not extra and len(files) == 1:
        max_step = -1
        seen: set[tuple] = set()
        dup = False
        over = False
        for raw in RawEventFileLoader(str(files[0])).Load():
            ev = event_pb2.Event.FromString(raw)
            what = ev.WhichOneof("what")
            if _is_header(what):
                continue
            step = int(ev.step)
            max_step = max(max_step, step)
            if step >= keep_before:
                over = True
                break
            if what == "summary":
                key = _dedupe_key(ev, what)
                if key in seen:
                    dup = True
                    break
                seen.add(key)
        if not over and not dup:
            return {
                "rewrote": False,
                "kept": 0,
                "dropped": 0,
                "deduped": 0,
                "files_in": 1,
                "max_step": max_step,
                "reason": "already_clean",
            }

    tb_root = stamp_dir.parent
    qroot = quarantine_root(tb_root.parent)
    park = qroot / f"sanitize_parked_{stamp_dir.name}_{time.strftime('%Y%m%d_%H%M%S')}"
    park.mkdir(parents=True, exist_ok=True)

    # Backup copies (do not empty the stamp yet).
    for src in files:
        dst = park / src.name
        if dst.exists():
            dst = park / f"{src.name}.bak_{int(time.time())}"
        try:
            shutil.copy2(str(src), str(dst))
        except OSError:
            pass

    sources = list(files) + list(extra)
    headers, stepped, stats = _merge_event_files(sources, keep_before)
    out = _write_merged_stamp(stamp_dir, headers, stepped)
    if out is None:
        return {
            "rewrote": False,
            "kept": stats["kept"],
            "dropped": stats["dropped"],
            "deduped": stats["deduped"],
            "files_in": len(sources),
            "park": park.name,
            "out": None,
            "keep_before": keep_before,
            "reason": "empty_merge",
        }

    # Remove previous active event files only after the replacement exists.
    for src in files:
        if src.resolve() == out.resolve():
            continue
        try:
            src.unlink(missing_ok=True)
        except OSError:
            pass

    return {
        "rewrote": True,
        "kept": stats["kept"],
        "dropped": stats["dropped"],
        "deduped": stats["deduped"],
        "files_in": len(sources),
        "park": park.name,
        "out": out.name,
        "keep_before": keep_before,
        "max_step": _max_step_in_files([out]),
    }


def quarantine_other_tb_stamps(tb_root: Path, keep_stamp: str) -> list[str]:
    """Move every non-keep stamp **outside** ``tb/`` so TensorBoard cannot see them."""
    tb_root = Path(tb_root)
    keep = str(keep_stamp or "").strip()
    if not tb_root.is_dir() or not keep:
        return []
    moved: list[str] = []
    siblings = []
    for child in sorted(tb_root.iterdir()):
        if not child.is_dir():
            continue
        name = child.name
        if name == keep:
            continue
        # Hidden dirs (incl. .tb_quarantine) are already TB-invisible — leave them.
        if name.startswith("."):
            continue
        siblings.append(child)
    if not siblings:
        return []
    qroot = (
        quarantine_root(tb_root.parent)
        / f"before_resume_{keep}_{time.strftime('%Y%m%d_%H%M%S')}"
    )
    qroot.mkdir(parents=True, exist_ok=True)
    for child in siblings:
        dest = qroot / child.name
        if dest.exists():
            dest = qroot / f"{child.name}_{int(time.time())}"
        shutil.move(str(child), str(dest))
        moved.append(child.name)
    return moved


def _iter_quarantine_roots(run_dir: Path) -> list[Path]:
    """Current + legacy quarantine roots under ``seed_N/``."""
    run_dir = Path(run_dir)
    roots: list[Path] = []
    for name in (TB_QUARANTINE_DIRNAME, *_LEGACY_QUARANTINE_DIRNAMES):
        p = run_dir / name
        if p.is_dir():
            roots.append(p)
    return roots


def _find_quarantine_history(
    tb_root: Path,
    *,
    need_max: int,
) -> list[Path]:
    """Pick quarantine event files that cover early episodes up to need_max."""
    scored: list[tuple[int, int, int, Path]] = []
    seen_dirs: set[Path] = set()
    for qroot in _iter_quarantine_roots(Path(tb_root).parent):
        for ev in qroot.rglob("events.out.tfevents.*"):
            if not ev.is_file() or ev.stat().st_size < 1000:
                continue
            parent = ev.parent
            if parent in seen_dirs:
                continue
            seen_dirs.add(parent)
            span = _reward_step_span(parent)
            if span is None:
                continue
            n, mn, mx = span
            if mn > 1:
                continue
            # Prefer files that reach (or nearly reach) the needed max, then denser.
            scored.append((min(mx, need_max), n, mx, ev))
    if not scored:
        return []
    scored.sort(key=lambda t: (t[0], t[1], t[2]), reverse=True)
    best_dir = scored[0][3].parent
    return sorted(
        (p for p in best_dir.glob("events.out.tfevents.*") if p.is_file()),
        key=lambda p: (p.stat().st_mtime_ns, p.name),
    )


def sanitize_tb_for_resume(
    tb_root: Path,
    tb_run: str,
    completed_episodes: int,
) -> dict[str, Any]:
    """Make ``tb/<tb_run>/`` the sole visible continuous curve through episode N."""
    tb_root = Path(tb_root)
    stamp = str(tb_run or "").strip()
    completed = max(0, int(completed_episodes))
    keep_before = completed + 1  # keep steps 1..N
    if not stamp:
        return {"ok": False, "reason": "empty_tb_run"}
    active = tb_root / stamp
    active.mkdir(parents=True, exist_ok=True)

    # Hide any legacy underscore quarantine before TB can recursively discover it.
    migrated_legacy = migrate_legacy_quarantine_dirs(tb_root.parent)

    rebuild = rebuild_tb_stamp(active, keep_before)

    # If early history is missing (only 121+ left), pull 1..N from quarantine and remesh.
    recovered = False
    span = _reward_step_span(active)
    need_recover = completed >= 2 and (
        span is None or span[1] > 1 or span[2] < max(1, completed - 1)
    )
    if need_recover:
        hist = _find_quarantine_history(tb_root, need_max=completed)
        if hist:
            rebuild = rebuild_tb_stamp(
                active, keep_before, force=True, extra_sources=hist
            )
            recovered = True
            span = _reward_step_span(active)

    quarantined = quarantine_other_tb_stamps(tb_root, stamp)
    return {
        "ok": True,
        "tb_run": stamp,
        "completed": completed,
        "keep_before": keep_before,
        "rebuild": rebuild,
        "quarantined": quarantined,
        "recovered_history": recovered,
        "span": span,
        "migrated_legacy_quarantine": migrated_legacy,
    }


def patch_checkpoint_tb_run(
    ckpt_path: Path,
    *,
    tb_run: str,
    episode: Optional[int] = None,
) -> None:
    """Embed ``tb_run`` (and optional episode) into a .pt so resume cannot drift."""
    import torch

    path = Path(ckpt_path)
    if not path.is_file():
        raise FileNotFoundError(path)
    try:
        ckpt = torch.load(str(path), map_location="cpu", weights_only=False)
    except TypeError:
        ckpt = torch.load(str(path), map_location="cpu")
    if not isinstance(ckpt, dict):
        raise TypeError(f"checkpoint is not a dict: {path}")
    name = str(tb_run or "").strip()
    if name:
        ckpt["tb_run"] = name
    if episode is not None:
        ckpt["episode"] = int(episode)
    torch.save(ckpt, str(path))
