"""
Export reward-curve shade bands for later replotting.

Band modes
----------
- rolling_std: single-run curve → smooth ± rolling STD  (PressLight / CoTV / DDPG)
- seed_std:    (T, S) array    → mean ± STD across independent seed runs
                              (aggregate 5 single-env runs; not parallel envs)

Files written under out_dir
---------------------------
  reward_curve_band.csv   long-form: episode, metric, raw, smooth, std, lower, upper, ...
  reward_curve_band.npz   same arrays keyed as ``{metric}__{field}`` plus meta
"""
from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Dict, Mapping, Optional, Sequence, Union

import numpy as np

ArrayLike = Union[Sequence[float], np.ndarray]

DEFAULT_SMOOTH = 5


def smooth_series(y: np.ndarray, window: int) -> np.ndarray:
    if window <= 1 or y.size == 0:
        return y.astype(np.float64, copy=True)
    w = min(int(window), int(y.size))
    kernel = np.ones(w, dtype=np.float64) / w
    pad = w // 2
    yp = np.pad(y.astype(np.float64), (pad, w - 1 - pad), mode="edge")
    return np.convolve(yp, kernel, mode="valid")[: y.size]


def rolling_std(y: np.ndarray, window: int) -> np.ndarray:
    if window <= 1 or y.size == 0:
        return np.zeros_like(y, dtype=np.float64)
    w = min(int(window), int(y.size))
    out = np.zeros(y.size, dtype=np.float64)
    for i in range(y.size):
        lo = max(0, i - w + 1)
        out[i] = float(np.std(y[lo : i + 1]))
    return out


def band_from_1d(
    y: ArrayLike,
    *,
    smooth: int = DEFAULT_SMOOTH,
) -> Dict[str, np.ndarray]:
    """Single-run curve → smooth center line and rolling-STD shade."""
    raw = np.asarray(y, dtype=np.float64).reshape(-1)
    center = smooth_series(raw, smooth)
    std = rolling_std(raw, max(int(smooth), 5))
    return {
        "raw": raw,
        "smooth": center,
        "std": std,
        "lower": center - std,
        "upper": center + std,
    }


def band_from_2d(
    values_2d: ArrayLike,
    *,
    smooth: int = 1,
) -> Dict[str, np.ndarray]:
    """(T, S) seed matrix → mean ± STD across seeds (optional smooth on mean/std)."""
    arr = np.asarray(values_2d, dtype=np.float64)
    if arr.ndim == 1:
        arr = arr[:, None]
    mean = np.mean(arr, axis=1)
    std = np.std(arr, axis=1)
    if smooth and int(smooth) > 1:
        mean = smooth_series(mean, smooth)
        std = smooth_series(std, smooth)
    return {
        "raw": mean,  # plot center without extra smooth when smooth=1
        "smooth": mean,
        "std": std,
        "lower": mean - std,
        "upper": mean + std,
    }


def save_curve_bands(
    out_dir: Union[str, Path],
    episodes: ArrayLike,
    metrics: Mapping[str, ArrayLike],
    *,
    method: str = "",
    scenario: str = "",
    smooth: int = DEFAULT_SMOOTH,
    band_mode: str = "rolling_std",
    stem: str = "reward_curve_band",
) -> Path:
    """
    Save shade-band tables for one or more metrics.

    ``metrics`` values are 1D (rolling_std) or 2D (seed_std).
    Returns path to the CSV.
    """
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    episodes_arr = np.asarray(episodes, dtype=np.float64).reshape(-1)

    rows = []
    npz_payload: Dict[str, np.ndarray] = {
        "episode": episodes_arr,
        "smooth_window": np.asarray([int(smooth)], dtype=np.int64),
    }

    for name, values in metrics.items():
        arr = np.asarray(values, dtype=np.float64)
        if arr.size == 0:
            continue
        if band_mode == "seed_std" or arr.ndim == 2:
            band = band_from_2d(arr, smooth=smooth if band_mode == "rolling_std" else 1)
            mode_used = "seed_std"
        else:
            band = band_from_1d(arr, smooth=smooth)
            mode_used = "rolling_std"

        n = min(episodes_arr.size, band["smooth"].size)
        for i in range(n):
            rows.append(
                {
                    "method": method,
                    "scenario": scenario,
                    "episode": int(episodes_arr[i]),
                    "metric": name,
                    "raw": float(band["raw"][i]),
                    "smooth": float(band["smooth"][i]),
                    "std": float(band["std"][i]),
                    "lower": float(band["lower"][i]),
                    "upper": float(band["upper"][i]),
                    "band_mode": mode_used,
                    "smooth_window": int(smooth),
                }
            )
        for field, series in band.items():
            npz_payload[f"{name}__{field}"] = np.asarray(series[:n], dtype=np.float64)

    csv_path = out_dir / f"{stem}.csv"
    if rows:
        with csv_path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)

    npz_path = out_dir / f"{stem}.npz"
    np.savez_compressed(npz_path, **npz_payload)

    meta = {
        "method": method,
        "scenario": scenario,
        "band_mode": band_mode,
        "smooth_window": int(smooth),
        "metrics": list(metrics.keys()),
        "n_episodes": int(episodes_arr.size),
        "csv": str(csv_path),
        "npz": str(npz_path),
        "columns": {
            "smooth": "center line used for plotting (moving average or seed mean)",
            "lower": "smooth - std  (fill_between lower)",
            "upper": "smooth + std  (fill_between upper)",
            "std": "shade half-width",
            "raw": "unsmoothed series (1D) or seed-mean (2D)",
        },
    }
    (out_dir / f"{stem}_meta.json").write_text(
        json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(f"[curve_band] wrote {csv_path}")
    print(f"[curve_band] wrote {npz_path}")
    return csv_path


def save_bands_from_episode_rows(
    out_dir: Union[str, Path],
    rows: Sequence[Mapping],
    *,
    method: str,
    scenario: str = "",
    reward_keys: Optional[Sequence[str]] = None,
    smooth: int = DEFAULT_SMOOTH,
) -> Optional[Path]:
    """Convenience for baseline train scripts that accumulate dict rows."""
    if not rows:
        return None
    keys = list(rows[0].keys())
    ep_key = "episode" if "episode" in keys else ("ep" if "ep" in keys else None)
    if ep_key is None:
        episodes = np.arange(1, len(rows) + 1)
    else:
        episodes = np.asarray([float(r[ep_key]) for r in rows], dtype=np.float64)

    if reward_keys is None:
        candidates = (
            "ep_reward",
            "total_reward",
            "tl_reward",
            "cav_reward",
            "signal_reward",
        )
        reward_keys = [k for k in candidates if k in keys]
        # CoTV: also export combined TL+CAV as total_reward for overlay plots
        if "tl_reward" in keys and "cav_reward" in keys and "total_reward" not in reward_keys:
            reward_keys = list(reward_keys) + ["total_reward"]

    metrics: Dict[str, np.ndarray] = {}
    for k in reward_keys:
        if k == "total_reward" and k not in keys and "tl_reward" in keys and "cav_reward" in keys:
            metrics[k] = np.asarray(
                [float(r["tl_reward"]) + float(r["cav_reward"]) for r in rows],
                dtype=np.float64,
            )
        elif k in keys:
            metrics[k] = np.asarray([float(r[k]) for r in rows], dtype=np.float64)

    if not metrics:
        return None
    return save_curve_bands(
        out_dir,
        episodes,
        metrics,
        method=method,
        scenario=scenario,
        smooth=smooth,
        band_mode="rolling_std",
    )
