"""
Score rule-based baselines with the LEGACY BaseReward formula. NOTE (v4): MAPPO
trains on AdaptiveReward, so only SIGNAL-reward curves are comparable across
methods; compare CAV/total performance with physical KPIs only,
and stream episode scalars to TensorBoard (same tag names as train_RL.py).

Macro weights default to 1.0 each (user request: 权重都取1).
Coop lambdas default to [1,1,1] (normalized inside BaseReward to 1/3 each).
Episode total uses α=β=1: R_ep = mean(r_cav) + mean(r_signal).
"""
from __future__ import annotations

import time
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

import numpy as np
from torch.utils.tensorboard import SummaryWriter

from reward.base_reward import BaseReward


class SafeSummaryWriter:
    """SummaryWriter that recreates the event file if the tb/ dir was deleted."""

    def __init__(self, log_dir: str):
        self.log_dir = str(log_dir)
        self._writer: Optional[SummaryWriter] = None
        self._open()

    def _open(self) -> None:
        Path(self.log_dir).mkdir(parents=True, exist_ok=True)
        self._writer = SummaryWriter(log_dir=self.log_dir)

    def _reopen(self, err: BaseException) -> None:
        print(f"[tensorboard] recreate logdir after {type(err).__name__}: {err}", flush=True)
        try:
            if self._writer is not None:
                self._writer.close()
        except Exception:
            pass
        self._writer = None
        self._open()

    def add_scalar(self, *args, **kwargs) -> None:
        try:
            self._writer.add_scalar(*args, **kwargs)
        except (FileNotFoundError, OSError) as exc:
            self._reopen(exc)
            try:
                self._writer.add_scalar(*args, **kwargs)
            except Exception as exc2:
                print(f"[tensorboard] skip add_scalar: {exc2}", flush=True)

    def add_text(self, *args, **kwargs) -> None:
        try:
            self._writer.add_text(*args, **kwargs)
        except (FileNotFoundError, OSError) as exc:
            self._reopen(exc)
            try:
                self._writer.add_text(*args, **kwargs)
            except Exception as exc2:
                print(f"[tensorboard] skip add_text: {exc2}", flush=True)

    def flush(self) -> None:
        try:
            if self._writer is not None:
                self._writer.flush()
        except (FileNotFoundError, OSError) as exc:
            self._reopen(exc)

    def close(self) -> None:
        try:
            if self._writer is not None:
                self._writer.flush()
                self._writer.close()
        except (FileNotFoundError, OSError) as exc:
            print(f"[tensorboard] close ignored: {exc}", flush=True)
        self._writer = None

# Match train/train_RL.py scalar names
TB_TOTAL = "Reward/Total_Episode_Reward"
TB_SIGNAL = "Reward/Signal_Reward"  # formal + residual
TB_SIGNAL_FORMAL = "Reward/Signal_Formal"
TB_SIGNAL_PRESSURE = TB_SIGNAL_FORMAL  # legacy alias
TB_SIGNAL_RESIDUAL = "Reward/Signal_Residual"
TB_CAV = "Reward/CAV_Mean_Reward"  # per-vehicle (r_lon+r_lat); aligns with team
TB_CAV_LON = "Reward/CAV_Lon_Mean"
TB_CAV_LAT = "Reward/CAV_Lat_Mean"  # dlc_eligible only
TB_WAIT = "Metrics/Average_Waiting_Time"
TB_SPEED = "Metrics/Average_Speed"
TB_TRAVEL = "Metrics/Average_Travel_Time"
TB_QUEUE = "Metrics/Average_Queue_Length"
TB_STOPS = "Metrics/Number_of_Vehicle_Stops"
TB_CONFLICTS = "Metrics/Number_of_Traffic_Conflicts"
TB_FUEL = "Metrics/Fleet_Average_Fuel_Consumption"  # L/100km
TB_CO2 = "Metrics/Fleet_Average_CO2_Emission"        # g/km
TB_TOTAL_FUEL = "Metrics/Total_Fuel_Consumption"     # L
TB_TOTAL_CO2 = "Metrics/Total_CO2_Emission"          # g
TB_VEH_FUEL = "Metrics/Vehicle_Average_Fuel_Consumption"  # L/100km (mean of per-vehicle)
TB_VEH_CO2 = "Metrics/Vehicle_Average_CO2_Emission"       # g/km (mean of per-vehicle)
TB_COLLISIONS = "Metrics/Collisions"


def accumulate_step_kpis(acc: dict, stats: dict) -> None:
    """Accumulate per-step conflict counts; emissions are read from stats at finalize."""
    stats = stats or {}
    acc["conflicts"] = int(acc.get("conflicts", 0)) + int(stats.get("danger_event_number", 0))


def emission_log_kwargs(row: Optional[dict] = None) -> dict:
    """Kwargs for format_episode_log / TB from a metrics row."""
    row = row or {}
    fleet_fuel = float(row.get("fleet_avg_fuel", row.get("avg_fuel", 0.0)))
    fleet_co2 = float(row.get("fleet_avg_co2", row.get("avg_co2", 0.0)))
    return {
        "avg_fuel": fleet_fuel,
        "avg_co2": fleet_co2,
        "fleet_avg_fuel": fleet_fuel,
        "fleet_avg_co2": fleet_co2,
        "total_fuel_L": float(row.get("total_fuel_L", 0.0)),
        "total_co2_g": float(row.get("total_co2_g", 0.0)),
        "veh_avg_fuel_L": float(row.get("veh_avg_fuel_L", 0.0)),
        "veh_avg_co2_g": float(row.get("veh_avg_co2_g", 0.0)),
    }


def emission_fields_from_stats(last_stats: Optional[dict] = None) -> dict:
    """Normalize emission KPI names from SUMO / marl_env stats."""
    last_stats = last_stats or {}
    fleet_fuel = float(last_stats.get("fleet_avg_fuel", last_stats.get("avg_fuel", 0.0)))
    fleet_co2 = float(last_stats.get("fleet_avg_co2", last_stats.get("avg_co2", 0.0)))
    return {
        "fleet_avg_fuel": fleet_fuel,
        "fleet_avg_co2": fleet_co2,
        "avg_fuel": fleet_fuel,  # alias → fleet average
        "avg_co2": fleet_co2,    # alias → fleet average
        "total_fuel_L": float(last_stats.get("total_fuel_L", 0.0)),
        "total_co2_g": float(last_stats.get("total_co2_g", 0.0)),
        "veh_avg_fuel_L": float(last_stats.get("veh_avg_fuel_L", 0.0)),
        "veh_avg_co2_g": float(last_stats.get("veh_avg_co2_g", 0.0)),
        "emission_vehicle_count": int(last_stats.get("emission_vehicle_count", 0)),
    }


def finalize_step_kpis(acc: dict, last_stats: Optional[dict] = None) -> dict:
    """
    Convert episode accumulators to TensorBoard / CSV fields.
    Fleet fuel/CO2: distance-normalized L/100km and g/km.
    Also expose episode totals and per-vehicle mean intensities (same units).
    """
    out = {
        "num_conflicts": int(acc.get("conflicts", 0)),
    }
    out.update(emission_fields_from_stats(last_stats))
    return out


def format_episode_log(
    episode: int,
    n_episodes: int,
    *,
    total_reward: float = 0.0,
    signal_reward: Optional[float] = None,
    cav_reward: Optional[float] = None,
    avg_speed: float = 0.0,
    avg_travel_time: float = 0.0,
    avg_waiting_time: float = 0.0,
    avg_queue_length: float = 0.0,
    num_stops: float = 0.0,
    num_conflicts: float = 0.0,
    avg_fuel: float = 0.0,
    avg_co2: float = 0.0,
    fleet_avg_fuel: Optional[float] = None,
    fleet_avg_co2: Optional[float] = None,
    total_fuel_L: float = 0.0,
    total_co2_g: float = 0.0,
    veh_avg_fuel_L: float = 0.0,
    veh_avg_co2_g: float = 0.0,
    stage: Optional[int] = None,
    extra: str = "",
) -> str:
    """
    Shared per-episode console line (same fields as train/train_RL.py).

    Methods without a signal/CAV reward pass None → printed as 0.000.
    ``extra`` appends method-specific tags (e.g. Pressure=, eps=, noise=).
    """
    sig = 0.0 if signal_reward is None else float(signal_reward)
    cav = 0.0 if cav_reward is None else float(cav_reward)
    fleet_fuel = float(avg_fuel if fleet_avg_fuel is None else fleet_avg_fuel)
    fleet_co2 = float(avg_co2 if fleet_avg_co2 is None else fleet_avg_co2)
    prefix = f"Stage {stage} | " if stage is not None else ""
    line = (
        f"{prefix}Episode {episode}/{n_episodes} - "
        f"Total Reward: {float(total_reward):.3f} | "
        f"Signal Reward: {sig:.3f} | "
        f"CAV Reward: {cav:.3f} | "
        f"Speed: {float(avg_speed):.2f} m/s | "
        f"TravelT: {float(avg_travel_time):.1f}s | "
        f"WaitT: {float(avg_waiting_time):.2f}s | "
        f"Avg_queue_length: {float(avg_queue_length):.2f} | "
        f"Stops: {float(num_stops):.1f} | "
        f"Conflicts: {float(num_conflicts):.1f} | "
        f"FleetFuel: {fleet_fuel:.2f} L/100km | "
        f"FleetCO2: {fleet_co2:.1f} g/km | "
        f"TotalFuel: {float(total_fuel_L):.2f} L | "
        f"TotalCO2: {float(total_co2_g):.1f} g | "
        f"VehFuel: {float(veh_avg_fuel_L):.2f} L/100km | "
        f"VehCO2: {float(veh_avg_co2_g):.1f} g/km"
    )
    if extra:
        line = f"{line} | {extra}"
    return line


class MetricsTensorBoard:
    """
    Lightweight episode metrics logger for learning baselines
    (PressLight / CoTV / DDPG-CAV) — same Metrics/* tags as train_RL.py.
    """

    def __init__(
        self,
        method: str,
        scenario: str,
        runs_root: Optional[Path] = None,
        log_dir: Optional[Path] = None,
    ):
        self.method = method
        self.scenario = scenario
        if log_dir is not None:
            self.log_dir = Path(log_dir)
        else:
            runs_root = Path(runs_root) if runs_root else Path("runs")
            run_name = f"{method}_{scenario}_{int(time.time())}"
            self.log_dir = runs_root / run_name
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.writer = SafeSummaryWriter(str(self.log_dir))
        print(
            f"[{method}] TensorBoard: tensorboard --logdir {self.log_dir} --port 6006"
        )

    def log_episode(self, episode_idx: int, metrics: dict) -> None:
        """episode_idx is 0-based loop index; TensorBoard x-axis uses Episode = idx+1."""
        tb_step = int(episode_idx) + 1
        # Rewards (method-specific keys mapped to shared tags when present)
        if "ep_reward" in metrics:
            self.writer.add_scalar(TB_TOTAL, float(metrics["ep_reward"]), tb_step)
        if "total_reward" in metrics:
            self.writer.add_scalar(TB_TOTAL, float(metrics["total_reward"]), tb_step)
        if "tl_reward" in metrics:
            self.writer.add_scalar(TB_SIGNAL, float(metrics["tl_reward"]), tb_step)
        if "signal_reward" in metrics:
            self.writer.add_scalar(TB_SIGNAL, float(metrics["signal_reward"]), tb_step)
        if "cav_reward" in metrics:
            self.writer.add_scalar(TB_CAV, float(metrics["cav_reward"]), tb_step)

        self.writer.add_scalar(TB_WAIT, float(metrics.get("avg_waiting_time", 0.0)), tb_step)
        self.writer.add_scalar(TB_SPEED, float(metrics.get("avg_speed", 0.0)), tb_step)
        self.writer.add_scalar(TB_TRAVEL, float(metrics.get("avg_travel_time", 0.0)), tb_step)
        self.writer.add_scalar(TB_QUEUE, float(metrics.get("avg_queue_length", 0.0)), tb_step)
        self.writer.add_scalar(TB_STOPS, float(metrics.get("num_stops", 0.0)), tb_step)
        self.writer.add_scalar(TB_CONFLICTS, float(metrics.get("num_conflicts", 0.0)), tb_step)
        fleet_fuel = float(metrics.get("fleet_avg_fuel", metrics.get("avg_fuel", 0.0)))
        fleet_co2 = float(metrics.get("fleet_avg_co2", metrics.get("avg_co2", 0.0)))
        self.writer.add_scalar(TB_FUEL, fleet_fuel, tb_step)
        self.writer.add_scalar(TB_CO2, fleet_co2, tb_step)
        self.writer.add_scalar(TB_TOTAL_FUEL, float(metrics.get("total_fuel_L", 0.0)), tb_step)
        self.writer.add_scalar(TB_TOTAL_CO2, float(metrics.get("total_co2_g", 0.0)), tb_step)
        self.writer.add_scalar(TB_VEH_FUEL, float(metrics.get("veh_avg_fuel_L", 0.0)), tb_step)
        self.writer.add_scalar(TB_VEH_CO2, float(metrics.get("veh_avg_co2_g", 0.0)), tb_step)
        self.writer.add_scalar(TB_COLLISIONS, float(metrics.get("collisions", 0.0)), tb_step)

        if "avg_loss" in metrics:
            self.writer.add_scalar("Loss/avg", float(metrics["avg_loss"]), tb_step)
        if "epsilon" in metrics:
            self.writer.add_scalar("Train/epsilon", float(metrics["epsilon"]), tb_step)
        if "noise_std" in metrics:
            self.writer.add_scalar("Train/noise_std", float(metrics["noise_std"]), tb_step)
        if "avg_pressure" in metrics:
            self.writer.add_scalar("Train/avg_pressure", float(metrics["avg_pressure"]), tb_step)
        self.writer.flush()

    def close(self) -> None:
        self.writer.flush()
        self.writer.close()


class UnitWeightReward(BaseReward):
    """BaseReward with safe/eff/comfort macro weights fixed at 1.0 (not renormalized)."""

    def __init__(self):
        super().__init__()
        self._w_safe = 1.0
        self._w_eff = 1.0
        self._w_comfort = 1.0
        self._w_coop = 0.0


class EpisodeRewardTracker:
    """Accumulate per-step CAV/signal rewards and write TB at episode end."""

    def __init__(
        self,
        method: str,
        scenario: str,
        runs_root: Optional[Path] = None,
        lambdas: Optional[np.ndarray] = None,
        log_dir: Optional[Path] = None,
    ):
        self.method = method
        self.scenario = scenario
        self.reward_fn = UnitWeightReward()
        # All-ones → BaseReward normalizes to equal thirds
        self.lambdas = (
            np.asarray(lambdas, dtype=np.float32)
            if lambdas is not None
            else np.asarray([1.0, 1.0, 1.0], dtype=np.float32)
        )
        if log_dir is not None:
            self.log_dir = Path(log_dir)
        else:
            runs_root = Path(runs_root) if runs_root else Path("runs")
            run_name = f"{method}_{scenario}_{int(time.time())}"
            self.log_dir = runs_root / run_name
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.writer = SafeSummaryWriter(str(self.log_dir))
        self.prev_state: Optional[dict] = None
        self._reset_episode_acc()
        print(
            f"[{method}] TensorBoard: tensorboard --logdir {self.log_dir} --port 6006"
        )
        print(
            f"[{method}] reward weights: w_safe=w_eff=w_comfort=1.0 "
            f"(coop channel removed)"
        )

    def _reset_episode_acc(self) -> None:
        self.prev_state = None
        self.cav_sum = 0.0
        self.cav_n = 0
        self.signal_sum = 0.0
        self.signal_n = 0

    @staticmethod
    def _build_actions(state: dict) -> Dict[str, Any]:
        """Placeholder actions so BaseReward scores every CAV / TLS in zone."""
        actions: Dict[str, Any] = {}
        for vid in (state.get("cavs") or {}):
            actions[f"cav_{vid}"] = 0.0
        for tls_id in (state.get("signals") or {}):
            actions[f"signal_{tls_id}"] = 0
        return actions

    def sync_signal_edges_from_env(self, env) -> None:
        """Align UnitWeightReward pressure edges with a live SUMOEnvironment."""
        incoming = getattr(env, "incoming_edges", None) or []
        outgoing = getattr(env, "outgoing_edges", None) or []
        self.reward_fn.set_signal_edges(incoming, outgoing)
        cap = getattr(env, "max_road_capacity", None)
        if cap is not None:
            self.reward_fn.max_road_capacity = float(cap)

    def observe_step(self, state: dict) -> Tuple[float, float, float]:
        """
        Score one SUMO raw state. Returns (step_global, mean_cav_step, mean_sig_step).
        """
        actions = self._build_actions(state)
        _, _, agent_rewards = self.reward_fn.compute_agent_rewards(
            state,
            self.prev_state,
            actions=actions,
            lambdas=self.lambdas,
        )
        self.prev_state = state

        cav_vals = [
            float(v) for k, v in agent_rewards.items() if k.startswith("cav_")
        ]
        sig_vals = [
            float(v) for k, v in agent_rewards.items() if k.startswith("signal_")
        ]
        for v in cav_vals:
            self.cav_sum += v
            self.cav_n += 1
        for v in sig_vals:
            self.signal_sum += v
            self.signal_n += 1

        mean_cav = float(np.mean(cav_vals)) if cav_vals else 0.0
        mean_sig = float(np.mean(sig_vals)) if sig_vals else 0.0
        step_global = float(np.mean(list(agent_rewards.values()))) if agent_rewards else 0.0
        return step_global, mean_cav, mean_sig

    def end_episode(self, episode_idx: int, metrics: dict) -> dict:
        """
        Finalize episode returns, write TB scalars, reset accumulators.
        episode_idx is 0-based; TensorBoard x-axis uses Episode = idx+1.
        """
        mean_cav = self.cav_sum / self.cav_n if self.cav_n > 0 else 0.0
        mean_sig = self.signal_sum / self.signal_n if self.signal_n > 0 else 0.0
        # α=β=1
        total = float(mean_cav + mean_sig)
        tb_step = int(episode_idx) + 1

        self.writer.add_scalar(TB_TOTAL, total, tb_step)
        self.writer.add_scalar(TB_SIGNAL, mean_sig, tb_step)
        self.writer.add_scalar(TB_CAV, mean_cav, tb_step)
        self.writer.add_scalar(TB_WAIT, float(metrics.get("avg_waiting_time", 0.0)), tb_step)
        self.writer.add_scalar(TB_SPEED, float(metrics.get("avg_speed", 0.0)), tb_step)
        self.writer.add_scalar(TB_TRAVEL, float(metrics.get("avg_travel_time", 0.0)), tb_step)
        self.writer.add_scalar(TB_QUEUE, float(metrics.get("avg_queue_length", 0.0)), tb_step)
        self.writer.add_scalar(TB_STOPS, float(metrics.get("num_stops", 0.0)), tb_step)
        self.writer.add_scalar(TB_CONFLICTS, float(metrics.get("num_conflicts", 0.0)), tb_step)
        fleet_fuel = float(metrics.get("fleet_avg_fuel", metrics.get("avg_fuel", 0.0)))
        fleet_co2 = float(metrics.get("fleet_avg_co2", metrics.get("avg_co2", 0.0)))
        self.writer.add_scalar(TB_FUEL, fleet_fuel, tb_step)
        self.writer.add_scalar(TB_CO2, fleet_co2, tb_step)
        self.writer.add_scalar(TB_TOTAL_FUEL, float(metrics.get("total_fuel_L", 0.0)), tb_step)
        self.writer.add_scalar(TB_TOTAL_CO2, float(metrics.get("total_co2_g", 0.0)), tb_step)
        self.writer.add_scalar(TB_VEH_FUEL, float(metrics.get("veh_avg_fuel_L", 0.0)), tb_step)
        self.writer.add_scalar(TB_VEH_CO2, float(metrics.get("veh_avg_co2_g", 0.0)), tb_step)
        self.writer.add_scalar(TB_COLLISIONS, float(metrics.get("collisions", 0.0)), tb_step)
        self.writer.flush()

        out = {
            "total_reward": total,
            "cav_reward": float(mean_cav),
            "signal_reward": float(mean_sig),
            "n_cav_reward_steps": int(self.cav_n),
            "n_signal_reward_steps": int(self.signal_n),
        }
        self._reset_episode_acc()
        return out

    def close(self) -> None:
        self.writer.flush()
        self.writer.close()
