"""Resume helpers: load checkpoints on CPU or GPU via map_location."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Optional, Union

import torch

PathLike = Union[str, Path]
DeviceLike = Union[str, torch.device, None]


def _as_device(device: DeviceLike) -> torch.device:
    if isinstance(device, torch.device):
        return device
    name = str(device or "cpu").strip() or "cpu"
    if name.lower() in ("auto", "gpu"):
        name = "cuda" if torch.cuda.is_available() else "cpu"
    return torch.device(name)


def torch_load(path: PathLike, device: DeviceLike = "cpu") -> Any:
    """Load a .pt file onto `device` (GPU ckpt → CPU and the reverse)."""
    dev = _as_device(device)
    kwargs = {"map_location": dev}
    try:
        return torch.load(str(path), weights_only=False, **kwargs)
    except TypeError:
        return torch.load(str(path), **kwargs)


def write_resume_meta(
    ckpt_dir: PathLike,
    episode: int,
    *,
    tb_run: Optional[str] = None,
) -> None:
    Path(ckpt_dir).mkdir(parents=True, exist_ok=True)
    payload: dict = {"episode": int(episode)}
    name = str(tb_run or "").strip()
    if name:
        payload["tb_run"] = name
    else:
        # Preserve prior tb_run when caller only updates episode.
        prev = read_resume_meta(ckpt_dir)
        if prev.get("tb_run"):
            payload["tb_run"] = str(prev["tb_run"])
    (Path(ckpt_dir) / "resume.json").write_text(
        json.dumps(payload, indent=2),
        encoding="utf-8",
    )


def read_resume_meta(ckpt_dir: PathLike) -> dict:
    meta = Path(ckpt_dir) / "resume.json"
    if not meta.is_file():
        return {}
    try:
        data = json.loads(meta.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def resume_tb_run_name(
    ckpt_dir: PathLike,
    ckpt: Optional[dict] = None,
) -> Optional[str]:
    """Folder name under tb/ used by this training chain (for continuous TB curves).

    Prefer ``resume.json`` over the embedded checkpoint field: prepare_resume
    rewrites meta intentionally, while ``episode_NNNN.pt`` may still carry a
    stale ``tb_run`` from an older stamp (that mismatch re-opens a dirty curve).
    """
    name = str(read_resume_meta(ckpt_dir).get("tb_run") or "").strip()
    if name:
        return name
    if isinstance(ckpt, dict):
        name = str(ckpt.get("tb_run") or "").strip()
        if name:
            return name
    return None


def completed_episodes(
    ckpt_dir: PathLike,
    ckpt: Optional[dict] = None,
    latest_names: tuple = ("latest.pt",),
) -> int:
    """How many episodes finished (1-based). Next train index is this value.

    Prefer ``resume.json`` over the embedded checkpoint field — same authority as
    ``resume_tb_run_name``. ``prepare_resume_from_episode`` rewrites meta to the
    pin point; trusting a stale ``latest.pt`` episode (e.g. 94 after pin-to-20)
    would re-pull dirty quarantine history and re-interleave TB curves.
    """
    del latest_names  # reserved for callers; episode_*.pt scan is the fallback
    meta = read_resume_meta(ckpt_dir)
    if meta.get("episode") is not None:
        try:
            return int(meta["episode"])
        except (TypeError, ValueError):
            pass
    if isinstance(ckpt, dict) and ckpt.get("episode") is not None:
        try:
            return int(ckpt["episode"])
        except (TypeError, ValueError):
            pass
    best = 0
    root = Path(ckpt_dir)
    for f in root.glob("episode_*.pt"):
        parts = f.stem.split("_")
        if len(parts) >= 2:
            try:
                best = max(best, int(parts[-1]))
            except ValueError:
                continue
    return best


def _newest_episode_ckpt(ckpt_dir: PathLike) -> Optional[Path]:
    best: Optional[Path] = None
    best_n = -1
    root = Path(ckpt_dir)
    if not root.is_dir():
        return None
    for f in root.glob("episode_*.pt"):
        parts = f.stem.split("_")
        if len(parts) < 2:
            continue
        try:
            n = int(parts[-1])
        except ValueError:
            continue
        if n > best_n:
            best_n = n
            best = f
    return best


def resolve_resume_file(
    ckpt_dir: PathLike,
    resume_from: str = "",
    default_name: str = "latest.pt",
    *,
    required: bool = True,
) -> Optional[Path]:
    if resume_from:
        p = Path(resume_from)
        if not p.is_file():
            raise FileNotFoundError(f"resume checkpoint not found: {p}")
        return p
    p = Path(ckpt_dir) / default_name
    if p.is_file():
        return p
    fallback = _newest_episode_ckpt(ckpt_dir)
    if fallback is not None:
        return fallback
    if not required:
        return None
    raise FileNotFoundError(
        f"resume requested but {p} is missing. Train once without --resume, "
        f"or pass --resume-from PATH"
    )
