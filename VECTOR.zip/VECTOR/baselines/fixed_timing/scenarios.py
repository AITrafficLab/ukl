"""Shared scenario registry for the three target junctions (+ cross)."""
from __future__ import annotations

import os

from baselines.result_paths import PROJECT_ROOT

# Logical name -> sumocfg relative to project root
#   3-leg(3phases)  — Dublin T @ 32471791
#   4-leg(4phases)  — Dublin cluster @ GS_cluster_...
#   5-leg(5phases)  — Xuancheng @ 34180200000479
_XUAN_CFG = os.path.join(
    "environment", "sumo_net", "5-leg(5phases)", "5-leg(5phases).sumocfg"
)
_DUBLIN4_CFG = os.path.join(
    "environment", "sumo_net", "4-leg(4phases)", "4-leg(4phases).sumocfg"
)
_DUBLIN3_CFG = os.path.join(
    "environment", "sumo_net", "3-leg(3phases)", "3-leg(3phases).sumocfg"
)
SCENARIOS = {
    "cross": os.path.join(
        "environment", "sumo_net", "cross", "cross.sumocfg"
    ),
    "3leg_3phases": _DUBLIN3_CFG,
    "3leg_2phases": _DUBLIN3_CFG,  # back-compat alias (pre-rename 2-green key)
    "4leg_4phases": _DUBLIN4_CFG,
    "4leg_3phases": _DUBLIN4_CFG,  # back-compat alias (pre-widening 3-green key)
    "5leg_5phases": _XUAN_CFG,
    # Back-compat aliases (same Xuancheng files)
    "5leg_4phases": _XUAN_CFG,
    "xuancheng_4phases": _XUAN_CFG,
    "xuancheng_5phases": _XUAN_CFG,
}

# Prefer these keys when several aliases share the same sumocfg.
_CANONICAL_SCENARIO_ORDER = (
    "3leg_3phases",
    "4leg_4phases",
    "5leg_5phases",
    "cross",
)
_DIR_ALIASES = {
    "3-leg(3phases)": "3leg_3phases",
    "3-leg(2phases)": "3leg_3phases",  # legacy folder name
    "4-leg(4phases)": "4leg_4phases",
    "4-leg(3phases)": "4leg_4phases",
    "5-leg(5phases)": "5leg_5phases",
    "5-leg(4phases)": "5leg_5phases",
    "cross": "cross",
}


def canonical_scenario_key(name_or_path: str) -> str:
    """Map CLI aliases / folder names onto the stable results-folder key."""
    raw = str(name_or_path or "").strip()
    if not raw:
        return "custom"
    if raw in SCENARIOS:
        cfg = SCENARIOS[raw]
        for key in _CANONICAL_SCENARIO_ORDER:
            if SCENARIOS.get(key) == cfg:
                return key
        return raw
    from pathlib import Path

    p = Path(raw)
    for token in (p.parent.name, p.stem, p.name):
        if token in _DIR_ALIASES:
            return _DIR_ALIASES[token]
        if token in SCENARIOS:
            return canonical_scenario_key(token)
    return raw


def resolve_scenario(name_or_path: str) -> tuple[str, str]:
    """Return (canonical_scenario_key, absolute_sumocfg)."""
    path = resolve_sumocfg(name_or_path)
    key = canonical_scenario_key(name_or_path)
    if key not in _CANONICAL_SCENARIO_ORDER and key not in SCENARIOS:
        key = canonical_scenario_key(path)
    return key, path


def resolve_sumocfg(name_or_path: str) -> str:
    """Return absolute sumocfg path from a scenario key or filesystem path."""
    raw = str(name_or_path or "").strip()
    if raw in SCENARIOS:
        path = os.path.join(PROJECT_ROOT, SCENARIOS[raw])
    elif raw in _DIR_ALIASES:
        # Folder-style tokens: "3-leg(3phases)" → canonical key → sumocfg.
        path = os.path.join(PROJECT_ROOT, SCENARIOS[_DIR_ALIASES[raw]])
    elif os.path.isabs(raw):
        path = raw
    else:
        cand = os.path.join(PROJECT_ROOT, raw)
        path = cand if os.path.isfile(cand) else os.path.abspath(raw)
    if not os.path.isfile(path):
        raise FileNotFoundError(f"sumocfg not found: {path}")
    return path


def resolve_primary_tls(env, preferred: str | None = None) -> str:
    """
    Pick the target junction TLS.

    Prefer scenario.py TLS_ID (stored on env as scenario_tls_id), then an
    explicit preferred id, then the first TraCI TLS. Never silently control a
    secondary corridor light when the scenario names a primary.
    """
    candidates = []
    scen = getattr(env, "scenario_tls_id", None)
    if scen:
        candidates.append(str(scen))
    if preferred:
        candidates.append(str(preferred))
    tls_ids = list(getattr(env, "tls_ids", None) or [])
    for cid in candidates:
        if cid in tls_ids:
            return cid
    if tls_ids:
        return tls_ids[0]
    return ""
