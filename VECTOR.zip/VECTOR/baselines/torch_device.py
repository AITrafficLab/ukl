"""Pick a torch device; fall back to CPU if CUDA is advertised but unusable."""
from __future__ import annotations

from typing import Union

import torch

DeviceLike = Union[str, torch.device, None]


def cuda_usable() -> bool:
    if not torch.cuda.is_available():
        return False
    try:
        torch.zeros(1, device="cuda")
        return True
    except Exception:
        return False


def resolve_torch_device(requested: DeviceLike = "cuda") -> torch.device:
    if isinstance(requested, torch.device):
        name = requested.type
    elif requested is None:
        name = "auto"
    else:
        name = str(requested).strip().lower() or "auto"

    if name == "cpu":
        return torch.device("cpu")
    if name not in ("cuda", "gpu", "auto"):
        return torch.device(name)

    if cuda_usable():
        return torch.device("cuda")
    if name == "cuda" or name == "gpu":
        print("[Warn] --device cuda requested but CUDA is unusable; falling back to cpu")
    return torch.device("cpu")
