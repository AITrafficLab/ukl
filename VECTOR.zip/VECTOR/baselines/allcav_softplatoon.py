"""Scheme-1 pragmatic overhaul: all-CAV Lon + soft platoon + discrete Lat.

New experimental line (does not resume old Leader-only runs):
  - Lon RL for every corridor CAV (not DBSCAN-leader gated)
  - Lat remains discrete LC in ZONE_PLATOON for all RL_DLC CAVs
  - Soft platoon via existing Lon pack / Lat form rewards
  - Signal formal reward unchanged
  - VLM line keeps VLM; no-vision line uses a separate results folder
"""
from __future__ import annotations

from typing import Any, Mapping, MutableMapping, Optional

# On-disk results/train|eval/<method>/...
ALLCAV_METHOD = "allcav_softplatoon"
ALLCAV_NO_VLM_METHOD = "allcav_softplatoon_no_vlm"


def is_allcav_mode(args: Any = None, *, env: Optional[Mapping[str, Any]] = None) -> bool:
    """True when CLI/env requests the all-CAV soft-platoon experiment."""
    if args is not None and bool(getattr(args, "all_cav_soft_platoon", False)):
        return True
    if env is not None:
        raw = env.get("ALL_CAV_SOFT_PLATOON") or env.get("VLM_RL_ALL_CAV")
        if raw is not None:
            return str(raw).strip().lower() in ("1", "true", "yes", "on")
    import os

    raw = os.environ.get("ALL_CAV_SOFT_PLATOON") or os.environ.get("VLM_RL_ALL_CAV")
    if raw is None:
        return False
    return str(raw).strip().lower() in ("1", "true", "yes", "on")


def resolve_allcav_results_method(*, use_vlm: bool) -> str:
    """Folder name for the all-CAV line (VLM nests under model; no-VLM is flat)."""
    return ALLCAV_METHOD if use_vlm else ALLCAV_NO_VLM_METHOD


def apply_allcav_soft_platoon_args(args: Any, *, use_vlm: Optional[bool] = None) -> Any:
    """Mutate parsed train/eval args for the all-CAV soft-platoon line.

    - Forces ``cav_rl_leaders_only=False`` (Lon for all corridor CAVs).
    - Remaps ``results_method`` onto the isolated allcav folders.
    - Leaves vision/VLM flags alone (VECTOR-style VLM still required when not --no-vision).
    """
    if not is_allcav_mode(args):
        return args

    setattr(args, "cav_rl_leaders_only", False)
    setattr(args, "all_cav_soft_platoon", True)

    if use_vlm is None:
        # Prefer explicit vision resolution if already applied.
        mode = str(getattr(args, "vision_mode", "") or "").strip().lower()
        if mode:
            use_vlm = mode not in ("none",)
        else:
            use_vlm = not (
                bool(getattr(args, "no_vlm", False))
                or bool(getattr(args, "no_vision", False))
            )

    method = resolve_allcav_results_method(use_vlm=bool(use_vlm))
    # Only override bare / default VECTOR / no_vlm so explicit user methods stay.
    current = str(getattr(args, "results_method", "") or "").strip()
    from baselines.result_paths import MAIN_METHOD, NO_VLM_METHOD, canonical_method

    cur_canon = canonical_method(current) if current else MAIN_METHOD
    if (not current) or cur_canon in (MAIN_METHOD, NO_VLM_METHOD, ALLCAV_METHOD, ALLCAV_NO_VLM_METHOD):
        args.results_method = method
    return args


def control_kwargs_for_allcav(base: Optional[MutableMapping[str, Any]] = None) -> dict:
    """Merge SUMO configure_control knobs for all-CAV Lon."""
    out = dict(base or {})
    out["cav_rl_leaders_only"] = False
    return out


def ensure_soft_platoon_rewards(reward_fn: Any) -> None:
    """Keep Lon pack + Lat form soft-platoon terms on for every controlled CAV.

    Scheme-1 does not replace DBSCAN with hard platoons; packing is reward-shaped
    via ``r_platoon_maintain`` (queue band 1–3.5 m) and Lat ``r_form``.
    """
    if reward_fn is None:
        return
    lon = getattr(reward_fn, "longitudinal", None)
    if lon is not None and hasattr(lon, "set_platoon_enabled"):
        lon.set_platoon_enabled(True)
    lat = getattr(reward_fn, "lateral", None)
    if lat is not None and hasattr(lat, "set_form_enabled"):
        lat.set_form_enabled(True)


CURRICULUM_FREEZE_NOTE = (
    "phased freeze unchanged: S→Lon (sig freeze) → JointLonSig → Lat (lon freeze) "
    "→ JointAll; start from scratch (do not resume Leader-only ckpts)"
)
