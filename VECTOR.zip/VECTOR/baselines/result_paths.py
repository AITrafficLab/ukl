"""
Canonical on-disk layout for training / evaluation artifacts.

results/
  train/{method}/{vlm_model}/{scenario}/seed_{N}/   # VLM methods (model layer)
  train/{method}/{scenario}/seed_{N}/               # no-VLM / other baselines
  eval/  — same shape as train/
  comparison/                             # summarize_baselines plots/tables
  batch_logs/                             # shell tee logs

With VLM model nest (method → VLM name → intersection → seed):
  VECTOR, only_signal_vlm, only_lon_vlm, only_lat_vlm, allcav_softplatoon

Without model nest (method → intersection → seed):
  no_vlm (alias: mappo_lat_lon_fixed), allcav_softplatoon_no_vlm,
  mappo_lon_only, mappo_lat_only, presslight, cotv, ddpg_cav, …
"""
from __future__ import annotations

import os
import re
import time
from pathlib import Path
from typing import Optional, Union

PathLike = Union[str, Path]


def path_looks_volatile(path: PathLike) -> bool:
    """Trash / Recycle Bin — files can vanish while a process still has them open."""
    s = str(Path(path)).replace("\\", "/").lower()
    return any(
        token in s
        for token in (
            "/trash/",
            "/.local/share/trash",
            "$recycle.bin",
            "/recycle.bin/",
        )
    )


def _looks_like_repo(path: Path) -> bool:
    return (path / "train" / "train_RL.py").is_file() and (path / "environment").is_dir()


def discover_project_root(hint: Optional[PathLike] = None) -> Path:
    """Repo root for results/sumocfg. Prefer a non-Trash copy (cwd / VLM_RL_ROOT)."""
    env = os.environ.get("VLM_RL_ROOT", "").strip()
    candidates: list[Path] = []
    if env:
        candidates.append(Path(env).expanduser().absolute())
    if hint:
        h = Path(hint)
        candidates.append(h.absolute().parent if h.is_file() else h.absolute())
        try:
            rh = h.resolve()
            candidates.append(rh.parent if rh.is_file() else rh)
        except Exception:
            pass
    try:
        candidates.append(Path.cwd().absolute())
    except Exception:
        pass
    here = Path(__file__).absolute().parents[1]
    candidates.append(here)
    try:
        candidates.append(Path(__file__).resolve().parents[1])
    except Exception:
        pass

    seen = set()
    ordered: list[Path] = []
    for c in candidates:
        try:
            c = c.absolute()
        except Exception:
            continue
        # Walk up a few levels from a file/dir hint
        probe = c
        for _ in range(4):
            key = str(probe)
            if key not in seen:
                seen.add(key)
                ordered.append(probe)
            if probe.parent == probe:
                break
            probe = probe.parent

    valid = [p for p in ordered if _looks_like_repo(p)]
    if not valid:
        return here
    stable = [p for p in valid if not path_looks_volatile(p)]
    chosen = stable[0] if stable else valid[0]
    if path_looks_volatile(chosen):
        print(
            "[warn] project root is under Trash/Recycle. Restore the folder "
            f"(or set VLM_RL_ROOT) before long training: {chosen}",
            flush=True,
        )
    return chosen


PROJECT_ROOT = discover_project_root(Path(__file__).absolute().parents[1])
RESULTS_ROOT = PROJECT_ROOT / "results"

# Main algorithm folder name.
MAIN_METHOD = "VECTOR"
# Fixed-weight / no-vision ablation folder (CLI: no_vlm).
NO_VLM_METHOD = "no_vlm"
_METHOD_ALIASES = {
    "mappo": MAIN_METHOD,
    "covlm": MAIN_METHOD,
    "vector": MAIN_METHOD,
    # Historical folder name → canonical no_vlm
    "mappo_lat_lon_fixed": NO_VLM_METHOD,
}

# Methods that nest: {method}/{vlm_model}/{scenario}/seed_N
# no_vlm / presslight / … stay flat: {method}/{scenario}/seed_N
MODEL_LAYER_METHODS = frozenset(
    {
        MAIN_METHOD,
        "only_signal_vlm",
        "only_lon_vlm",
        "only_lat_vlm",
        # Scheme-1 all-CAV soft-platoon line (VLM retained under model nest).
        "allcav_softplatoon",
    }
)


def canonical_method(method: str) -> str:
    """Map historical/alias method ids onto the on-disk folder name."""
    raw = str(method or "").strip()
    if not raw:
        return raw
    # Bare VECTOR / CoVLM / mappo / covlm → VECTOR; tagged names left unchanged.
    return _METHOD_ALIASES.get(raw.lower(), raw)


def method_uses_model_layer(method: str) -> bool:
    """True if results path inserts a VLM-model folder under the method."""
    return canonical_method(method) in MODEL_LAYER_METHODS


def vlm_model_slug(model: str) -> str:
    """Filesystem-safe folder fragment from a VLM model id."""
    s = str(model or "").strip()
    if not s:
        return "no_vlm"
    s = s.replace(":", "_").replace("/", "_").replace("\\", "_")
    s = re.sub(r"[^\w.\-+]+", "_", s, flags=re.UNICODE)
    s = re.sub(r"_+", "_", s).strip("._")
    return s or "no_vlm"


# Vision / VLM participation modes (train_RL.resolve_vision_mode).
VISION_MODE_FULL = "full"
VISION_MODE_ONLY_SIGNAL = "only_signal"
VISION_MODE_ONLY_LON = "only_lon"
VISION_MODE_ONLY_LAT = "only_lat"
VISION_MODE_NONE = "none"


def resolve_results_method(
    results_method: str = "",
    *,
    use_vlm: bool = True,
    vlm_model: str = "",
    vision_mode: str = "",
) -> str:
    """
    Resolve the results/train|eval/<method>/ folder name.

    - vision_mode=none / --no-vision with bare VECTOR → no_vlm
    - vision_mode=full + bare VECTOR → VECTOR
    - only_signal / only_lon / only_lat → only_signal_vlm / only_lon_vlm / only_lat_vlm
    - Explicit methods (mappo_lon_only, presslight, no_vlm, …) kept as-is

    VLM model is a *child* folder only under MODEL_LAYER_METHODS.
    """
    del vlm_model  # model slug is a nested path segment, not the method name
    raw = str(results_method or "").strip()
    mode = str(vision_mode or "").strip().lower()

    bare_or_main = (not raw) or (canonical_method(raw) == MAIN_METHOD)
    if mode == VISION_MODE_NONE or (not use_vlm and mode in ("", VISION_MODE_NONE)):
        if bare_or_main:
            return NO_VLM_METHOD
        return canonical_method(raw)
    if mode == VISION_MODE_ONLY_SIGNAL and bare_or_main:
        return "only_signal_vlm"
    if mode == VISION_MODE_ONLY_LON and bare_or_main:
        return "only_lon_vlm"
    if mode == VISION_MODE_ONLY_LAT and bare_or_main:
        return "only_lat_vlm"

    if not use_vlm and mode not in (
        VISION_MODE_ONLY_SIGNAL,
        VISION_MODE_ONLY_LON,
        VISION_MODE_ONLY_LAT,
    ):
        if bare_or_main:
            return NO_VLM_METHOD
        return canonical_method(raw)

    method = canonical_method(raw) if raw else MAIN_METHOD
    if not method:
        method = MAIN_METHOD
    return method


def method_dir_candidates(method: str) -> tuple[str, ...]:
    """Preferred folder first, then legacy aliases (for loading old checkpoints)."""
    name = canonical_method(method) or MAIN_METHOD
    if name == MAIN_METHOD:
        return (MAIN_METHOD, "CoVLM", "mappo")
    if name == NO_VLM_METHOD:
        return (NO_VLM_METHOD, "mappo_lat_lon_fixed")
    if name.startswith(f"{MAIN_METHOD}_") or name.startswith("CoVLM_"):
        return (name, MAIN_METHOD, "CoVLM", "mappo")
    return (name,)


def _path_under_method(
    method: str,
    scenario: str,
    seed: int,
    *,
    vlm_model: str = "",
    root: Optional[PathLike] = None,
    kind: str = "train",
) -> Path:
    """Build results/{kind}/{method}/[model/]{scenario}/seed_N."""
    m = canonical_method(method)
    base = results_root(root) / kind / m
    if method_uses_model_layer(m):
        base = base / vlm_model_slug(vlm_model)
    return base / str(scenario) / seed_dirname(seed)

# Folder-name aliases → stable scenario keys used in results paths
_SCENARIO_DIR_ALIASES = {
    "3-leg(3phases)": "3leg_3phases",
    "3-leg(2phases)": "3leg_3phases",  # legacy folder name
    "4-leg(4phases)": "4leg_4phases",
    "4-leg(3phases)": "4leg_4phases",
    "5-leg(5phases)": "5leg_5phases",
    "5-leg(4phases)": "5leg_5phases",
    "cross": "cross",
}


def results_root(root: Optional[PathLike] = None) -> Path:
    return Path(root) if root else RESULTS_ROOT


def seed_dirname(seed: int) -> str:
    return f"seed_{int(seed)}"


def train_run_dir(
    method: str,
    scenario: str,
    seed: int,
    *,
    vlm_model: str = "",
    root: Optional[PathLike] = None,
) -> Path:
    """results/train/{method}/[vlm_model/]{scenario}/seed_{N}/"""
    return _path_under_method(
        method, scenario, seed, vlm_model=vlm_model, root=root, kind="train"
    )


def train_ckpt_dir(
    method: str,
    scenario: str,
    seed: int,
    *,
    vlm_model: str = "",
    root: Optional[PathLike] = None,
) -> Path:
    """results/train/{method}/[vlm_model/]{scenario}/seed_{N}/checkpoints/"""
    return train_run_dir(
        method, scenario, seed, vlm_model=vlm_model, root=root
    ) / "checkpoints"


def train_tb_dir(
    method: str,
    scenario: str,
    seed: int,
    *,
    vlm_model: str = "",
    root: Optional[PathLike] = None,
) -> Path:
    """results/train/{method}/[vlm_model/]{scenario}/seed_{N}/tb/"""
    return train_run_dir(
        method, scenario, seed, vlm_model=vlm_model, root=root
    ) / "tb"


def train_tb_run_dir(
    method: str,
    scenario: str,
    seed: int,
    run_name: str,
    *,
    vlm_model: str = "",
    root: Optional[PathLike] = None,
) -> Path:
    """results/train/{method}/[vlm_model/]{scenario}/seed_{N}/tb/{run_name}/"""
    name = str(run_name or "").strip()
    if not name or name in (".", "..") or "/" in name or "\\" in name:
        raise ValueError(f"invalid tb run name: {run_name!r}")
    return train_tb_dir(
        method, scenario, seed, vlm_model=vlm_model, root=root
    ) / name


def new_train_tb_run_name() -> str:
    """Filesystem-safe stamp for one TensorBoard run folder under tb/."""
    return time.strftime("%Y%m%d_%H%M%S")


def allocate_train_tb_run_dir(
    method: str,
    scenario: str,
    seed: int,
    *,
    vlm_model: str = "",
    root: Optional[PathLike] = None,
    run_name: Optional[str] = None,
) -> Path:
    """
    Create a fresh tb/<stamp>/ directory for one training launch.

    Resume should reuse an existing run via ``train_tb_run_dir`` + meta ``tb_run``,
    so TensorBoard keeps one continuous curve. A brand-new launch always gets a
    new stamp so abandoned event files are not mixed into the same TB run.
    """
    base = train_tb_dir(
        method, scenario, seed, vlm_model=vlm_model, root=root
    )
    base.mkdir(parents=True, exist_ok=True)
    stamp = str(run_name or "").strip() or new_train_tb_run_name()
    run_dir = base / stamp
    if run_dir.exists():
        # Same-second relaunch: make the name unique.
        for i in range(1, 1000):
            cand = base / f"{stamp}_{i}"
            if not cand.exists():
                run_dir = cand
                break
        else:
            run_dir = base / f"{stamp}_{os.getpid()}"
    run_dir.mkdir(parents=True, exist_ok=True)
    return run_dir


def discover_tb_run_for_resume(
    method: str,
    scenario: str,
    seed: int,
    *,
    vlm_model: str = "",
    root: Optional[PathLike] = None,
) -> Optional[str]:
    """
    Pick an existing non-backup ``tb/<stamp>/`` to continue on resume.

    Used when ``resume.json`` / checkpoint lack ``tb_run`` so a brand-new stamp
    is not created (which would split the TensorBoard curve). Prefers the stamp
    with the most recent event-file mtime.
    """
    tb = train_tb_dir(
        method, scenario, seed, vlm_model=vlm_model, root=root
    )
    if not tb.is_dir():
        return None
    best_name: Optional[str] = None
    best_mtime = -1.0
    for child in tb.iterdir():
        if not child.is_dir():
            continue
        name = child.name
        if name.startswith("_") or name.startswith("."):
            continue
        events = list(child.glob("events.out.tfevents.*"))
        if not events:
            continue
        mtime = max(f.stat().st_mtime for f in events)
        if mtime >= best_mtime:
            best_mtime = mtime
            best_name = name
    return best_name


def migrate_flat_tb_events_into_run(
    tb_root: PathLike,
    run_dir: PathLike,
) -> list:
    """
    Move loose ``events.out.tfevents.*`` files from ``tb/`` into ``tb/<run>/``.

    TensorBoard stitches all event files in the *same* run directory into one
    curve. Legacy launches wrote directly under ``tb/``; after adopting stamp
    subdirs, resume should pull those flat files into the active run once so
    old and new episodes appear continuous. Does not touch other stamp folders.
    Fresh (non-resume) training should not call this.
    """
    root = Path(tb_root)
    dest = Path(run_dir)
    if not root.is_dir():
        return []
    dest.mkdir(parents=True, exist_ok=True)
    moved: list = []
    for src in sorted(root.glob("events.out.tfevents.*")):
        if not src.is_file():
            continue
        target = dest / src.name
        if target.exists():
            # Already migrated (or name clash): keep a unique name.
            target = dest / f"{src.name}.migrated"
            n = 1
            while target.exists():
                target = dest / f"{src.name}.migrated{n}"
                n += 1
        try:
            src.replace(target)
            moved.append(target.name)
        except OSError:
            try:
                import shutil

                shutil.move(str(src), str(target))
                moved.append(target.name)
            except OSError as exc:
                print(
                    f"[tensorboard] skip migrate {src.name}: {exc}",
                    flush=True,
                )
    return moved


def bev_run_dir(
    method: str,
    scenario: str,
    seed: int,
    *,
    vlm_model: str = "",
    root: Optional[PathLike] = None,
) -> Path:
    """bev_renders/{method}/[vlm_model/]{scenario}/seed_{N}/ — VLM BEV snapshots."""
    base = Path(root) if root else PROJECT_ROOT / "bev_renders"
    m = canonical_method(method)
    out = base / m
    if method_uses_model_layer(m):
        out = out / vlm_model_slug(vlm_model)
    return out / str(scenario) / seed_dirname(seed)


def eval_run_dir(
    method: str,
    scenario: str,
    train_seed: int,
    *,
    vlm_model: str = "",
    root: Optional[PathLike] = None,
) -> Path:
    """results/eval/{method}/[vlm_model/]{scenario}/seed_{train_seed}/"""
    return _path_under_method(
        method,
        scenario,
        train_seed,
        vlm_model=vlm_model,
        root=root,
        kind="eval",
    )


def eval_scenario_dir(
    method: str,
    scenario: str,
    *,
    vlm_model: str = "",
    root: Optional[PathLike] = None,
) -> Path:
    """results/eval/{method}/[vlm_model/]{scenario}/"""
    m = canonical_method(method)
    base = results_root(root) / "eval" / m
    if method_uses_model_layer(m):
        base = base / vlm_model_slug(vlm_model)
    return base / str(scenario)


def comparison_dir(*, root: Optional[PathLike] = None) -> Path:
    return results_root(root) / "comparison"


def batch_logs_dir(*, root: Optional[PathLike] = None) -> Path:
    return results_root(root) / "batch_logs"


def infer_scenario_key(sumocfg: PathLike) -> str:
    """Map a sumocfg path to a short scenario key for results folders."""
    path = Path(sumocfg)
    try:
        from baselines.fixed_timing.scenarios import SCENARIOS

        abs_cfg = path if path.is_absolute() else (PROJECT_ROOT / path)
        abs_cfg = abs_cfg.resolve()
        for key, rel in SCENARIOS.items():
            cand = (PROJECT_ROOT / rel).resolve()
            if cand == abs_cfg:
                # Prefer canonical names over aliases
                if key in ("3leg_3phases", "4leg_4phases", "5leg_5phases"):
                    return key
        # Second pass: any alias match
        for key, rel in SCENARIOS.items():
            if (PROJECT_ROOT / rel).resolve() == abs_cfg:
                return key
    except Exception:
        pass

    parent = path.parent.name
    if parent in _SCENARIO_DIR_ALIASES:
        return _SCENARIO_DIR_ALIASES[parent]
    stem = path.stem
    # "3-leg(3phases)" → "3leg_3phases"
    cleaned = re.sub(r"[^\w]+", "_", stem).strip("_").lower()
    return cleaned or "custom"


def ensure_dir(path: PathLike) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def _is_legacy_ckpt_root(checkpoint_dir: PathLike) -> bool:
    s = str(checkpoint_dir).replace("\\", "/").strip().rstrip("/")
    if not s or s == "checkpoints":
        return True
    if s.startswith("results/baselines/") and s.endswith("/checkpoints"):
        return True
    if s.endswith("results/baselines") or "/results/baselines/" in f"/{s}/":
        # bare legacy roots without explicit override intent
        if s.rstrip("/").endswith("/checkpoints"):
            return True
    return False


def resolve_ckpt_dir(
    method: str,
    scenario: str,
    seed: int,
    checkpoint_dir: Optional[PathLike] = None,
    *,
    vlm_model: str = "",
    root: Optional[PathLike] = None,
) -> Path:
    """
    Default: results/train/.../checkpoints.
    Legacy ``results/baselines/.../checkpoints`` defaults map to the new layout.
    Any other explicit path keeps parent/scenario/seed_N semantics.
    """
    if checkpoint_dir is None or _is_legacy_ckpt_root(checkpoint_dir):
        return train_ckpt_dir(
            method, scenario, seed, vlm_model=vlm_model, root=root
        )
    p = Path(checkpoint_dir)
    if not p.is_absolute():
        p = PROJECT_ROOT / p
    if p.name == seed_dirname(seed):
        return p
    if p.name == "checkpoints" or (p / scenario / seed_dirname(seed)).exists():
        return p / scenario / seed_dirname(seed)
    return p / scenario / seed_dirname(seed)
