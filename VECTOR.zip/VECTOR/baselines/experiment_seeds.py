"""Reproducibility protocol for train / independent eval episodes.

Default experiment (report these in papers / README of a run):

- ``step_length`` = 0.2 s
- warmup = 300 s (fixed timing; **not** in reward / RL / KPIs)
- control = 4500 steps = 900 s = 15 min (train and eval); warmup = 300 s
- demand: explicit trips on [0, 1500) s, volume ~ hourly * 1500/3600,
  profile 25/50/25 inside the horizon; generated with ``DEMAND_SEED``
- **train (report mean±STD):** 5 independent runs with ``EXPERIMENT_SEEDS``
  (default 7–11), ``num_envs=1``; artifacts under
  ``results/train|eval/<method>/<scenario>/seed_<N>/``
- **train SUMO seeds (default):** per-episode
  ``train_seed * 10000 + episode`` (see ``SUMO_SEED_STRIDE``) so runs 7..11
  do not share overlapping RNG chains; set ``SUMO_PER_EPISODE_SEED=0`` only
  for debug lock-to-run-seed ablations
- **best ckpt selector:** rolling window mean score with zero window-mean
  safety incidents (``roll5_phys_coll_gate`` in ``train_RL``)
- eval: **separate** episodes (not mid-episode 20/10 split), same horizon;
  report mean±STD over ``EVAL_SEEDS`` (default 7–11). Trip file is fixed
  unless you regenerate rou with another demand seed. Train SUMO stride
  seeds and eval 7–11 may be disjoint (held-out micro-realizations).

Do **not** use ``num_envs>1`` for seed statistics; use independent runs
(``scripts/train/run_five_seeds.py`` or ``scripts/train/run_four_methods_three_scenarios.sh``).
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, Optional, Sequence

# Demand generation (scripts/generate_peak_trips.py)
DEMAND_SEED = 7
DEMAND_HORIZON_S = 1200.0  # v4: shipped trip files span [0, 1200) s (doc said 1500)

# Simulation timing
STEP_LENGTH_S = 0.2
WARMUP_S = 300.0
CONTROL_STEPS = 4500
CONTROL_S = CONTROL_STEPS * STEP_LENGTH_S  # 900.0

# Independent full runs (train or eval) — mean±STD over these seeds
TRAIN_SEED_DEFAULT = 7
EVAL_SEEDS = (7, 8, 9, 10, 11)
EXPERIMENT_SEEDS = EVAL_SEEDS  # train multi-seed + eval defaults

DEFAULT_NUM_ENVS = 1
# Train per-episode SUMO seed stride (train_RL._sumo_reset_seeds default).
SUMO_SEED_STRIDE = 10000
BEST_SELECTOR_DEFAULT = "roll5_phys_coll_gate"


def protocol_dict(
    *,
    train_seed: Optional[int] = None,
    eval_seeds: Optional[Sequence[int]] = None,
    demand_seed: int = DEMAND_SEED,
    extra: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Metadata block to embed in train/eval summary JSON."""
    d: Dict[str, Any] = {
        "eval_mode": "independent_episodes_same_horizon",
        "train_mode": "independent_seeds_mean_std",
        "step_length_s": STEP_LENGTH_S,
        "warmup_s": WARMUP_S,
        "warmup_excluded_from_reward_and_metrics": True,
        "control_steps": CONTROL_STEPS,
        "control_s": CONTROL_S,
        "demand_horizon_s": DEMAND_HORIZON_S,
        "demand_seed": int(demand_seed),
        "demand_volume_scale": DEMAND_HORIZON_S / 3600.0,
        "train_seed_default": TRAIN_SEED_DEFAULT,
        "experiment_seeds": list(EXPERIMENT_SEEDS),
        "eval_seeds_default": list(EVAL_SEEDS),
        "train_sumo_seed_mode": "per_episode_stride_10000",
        "sumo_seed_stride": int(SUMO_SEED_STRIDE),
        "best_selector": BEST_SELECTOR_DEFAULT,
    }
    if train_seed is not None:
        d["train_seed"] = int(train_seed)
    if eval_seeds is not None:
        d["eval_seeds"] = [int(s) for s in eval_seeds]
    if extra:
        d.update(extra)
    return d


def seeds_for_episodes(base_seed: int, n_episodes: int) -> list[int]:
    """Per-episode SUMO seeds: base, base+1, ... (matches existing run_eval loops)."""
    return [int(base_seed) + i for i in range(int(n_episodes))]


def load_demand_meta(rou_or_sumocfg: Path) -> Dict[str, Any]:
    """Load demand_meta.json next to a rou/sumocfg if present."""
    p = Path(rou_or_sumocfg)
    candidates = [
        p.with_name("demand_meta.json"),
        p.parent / "demand_meta.json",
    ]
    if p.suffix == ".sumocfg":
        stem = p.stem
        candidates.insert(0, p.parent / f"{stem}.demand_meta.json")
    for c in candidates:
        if c.is_file():
            import json

            return json.loads(c.read_text(encoding="utf-8"))
    return {}


# v5 (1.2): held-out evaluation seeds. Training SUMO/demand seeds are
# seed * 10000 + episode (train_RL._sumo_reset_seeds), so these ranges are
# disjoint for any run seed < 90. Select models on VALIDATION, report on TEST.
VALIDATION_SEEDS = tuple(range(900001, 900011))
TEST_SEEDS = tuple(range(990001, 990011))
