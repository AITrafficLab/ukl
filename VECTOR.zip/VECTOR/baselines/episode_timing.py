"""Episode timing and curriculum schedule for hierarchical VLM + MAPPO.

Clean 4-Stage Curriculum (Full 1000 / Quick 480):
    Stage-S        : signal policy (250 Full / 120 Quick)
    Stage-Lon      : IDM-residual longitudinal CAV across all corridor CAVs (300 Full / 150 Quick)
    Stage-Lat      : lateral lane-balancing & gated formation CAV (300 Full / 140 Quick)
    Stage-JointAll : anchored cooperative fine-tune (150 Full / 70 Quick)
    (Optional Stage-JointLonSig stays 0 by default; enabled via --joint-lon-sig-episodes)

    Both profiles use 300 s fixed-timing warm-up + 900 s control
(complete peak/trough cycle). Explicit CLI ``--episodes`` scales stage
blocks when it differs from the profile default; YAML alone does not.
"""
from __future__ import annotations

import os
from typing import Any, Dict, Optional


# ---------------------------------------------------------------------------
# Episode budgets
# ---------------------------------------------------------------------------

# Quick: S120 + Lon150 + Lat210 = 480
# With joint_lon_sig=0 / joint_all=70 → S120 / Lon150 / Lat140 + JA70
QUICK_STAGE_S_EPISODES = 120
QUICK_STAGE_LON_EPISODES = 150
QUICK_STAGE_LAT_EPISODES = 210
QUICK_TOTAL_EPISODES = (
    QUICK_STAGE_S_EPISODES
    + QUICK_STAGE_LON_EPISODES
    + QUICK_STAGE_LAT_EPISODES
)
QUICK_JOINT_LON_SIG_EPISODES = 0
QUICK_JOINT_ALL_EPISODES = 70
# Quick joint anneal caps (JLS cap kept at 30 when explicitly enabled on CLI).
QUICK_JOINT_LON_SIG_ANNEAL_EPISODES = 30
QUICK_JOINT_ALL_ANNEAL_EPISODES = 50

# Full: S250 + Lon300 + Lat450 = 1000
# With joint_lon_sig=0 / joint_all=150 → S250 / Lon300 / Lat300 + JA150
FULL_STAGE_S_EPISODES = 250
FULL_STAGE_LON_EPISODES = 180  # v5: was 300 (data-rich stage)
FULL_STAGE_LAT_EPISODES = 420  # v5: Lat main 250 + JointAll 170 (was 300 + 150)
FULL_TOTAL_EPISODES = (
    FULL_STAGE_S_EPISODES
    + FULL_STAGE_LON_EPISODES
    + FULL_STAGE_LAT_EPISODES
)
FULL_JOINT_LON_SIG_EPISODES = 0
FULL_JOINT_LON_SIG_ANNEAL_EPISODES = 60
FULL_JOINT_ALL_EPISODES = 170  # v5: was 150 (co-adaptation budget)
FULL_JOINT_ALL_ANNEAL_EPISODES = 120  # v5: was 110

# Legacy alias used by older call sites.
VLM_WARMUP_EPISODES = 10

# Soft-start: Lon/Lat residual VLM from stage-local ep 10+; blend 15 eps.
VLM_WARMUP_BY_STAGE: Dict[str, int] = {
    "S": 5,
    "Lon": 10,
    "Lat": 10,
}

QUICK_VLM_WARMUP_BY_STAGE: Dict[str, int] = {
    "S": 5,
    "Lon": 10,
    "Lat": 10,
}


def action_blend_episodes(soft_start: int, stage: str = "Lon") -> int:
    """Lon/Lat action soft-start length (15 eps when soft≥10)."""
    soft = int(soft_start or 0)
    if soft <= 0:
        return 0
    if str(stage or "") == "Lat":
        if soft >= 10:
            return 15
        return int(max(10, soft))
    if soft >= 10:
        return 15
    return int(max(8, min(15, soft + 5)))


def action_blend_beta(stage_episode: int, soft_start: int, stage: str = "Lon") -> float:
    """Policy mix weight β: env uses (1-β)·prior + β·π."""
    st = str(stage or "")
    if st not in ("Lon", "Lat"):
        return 1.0
    if st == "Lat" and str(os.environ.get("LAT_SOFT_START_MIXTURE", "0")).strip().lower() not in (
        "1", "true", "yes", "on"
    ):
        # v4: no behavior/target mixture for Lat (keep-biased init instead).
        return 1.0
    n = action_blend_episodes(soft_start, stage=st)
    if n <= 0:
        return 1.0
    ep = max(0, int(stage_episode or 0))
    if ep >= n:
        return 1.0
    span = max(1, n - 1)
    beta0 = 0.20 if st == "Lon" else 0.35
    return float(beta0 + (1.0 - beta0) * min(1.0, float(ep) / float(span)))


def add_episode_timing_args(parser, sim: Optional[dict] = None) -> None:
    """Register episode-timing CLI arguments."""
    sim = sim or {}
    parser.add_argument(
        "--warmup-seconds",
        type=float,
        default=float(sim.get("warmup_seconds", 300.0)),
        help="Fixed-timing warm-up before RL/metrics (default: 300 seconds).",
    )
    parser.add_argument(
        "--control-seconds",
        type=float,
        default=None,
        help=(
            "Controlled horizon in seconds; overrides --max-steps "
            "(e.g. 900 seconds = 15 minutes = 4500 steps at dt=0.2 s)."
        ),
    )
    parser.add_argument(
        "--quick",
        action="store_true",
        help=(
            "Quick profile: 300 s warm-up + 900 s control; curriculum "
            f"S{QUICK_STAGE_S_EPISODES}/Lon{QUICK_STAGE_LON_EPISODES}/"
            f"Lat{QUICK_STAGE_LAT_EPISODES} "
            f"({QUICK_TOTAL_EPISODES} episodes total; "
            f"JLS{QUICK_JOINT_LON_SIG_EPISODES}/JA{QUICK_JOINT_ALL_EPISODES})."
        ),
    )
    parser.add_argument(
        "--vlm-warmup-episodes",
        type=int,
        default=None,
        help=(
            "Override the episode warm-up/soft-start count for all training "
            "stages. This does not control the simulation-time schedule for "
            "Stage-S visual-semantic refreshes."
        ),
    )


def _nonnegative_int(value: Any, default: int = 0) -> int:
    try:
        result = int(value)
    except (TypeError, ValueError, OverflowError):
        result = int(default)
    return max(0, result)


def _positive_float(value: Any, default: float) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError):
        result = float(default)
    if result <= 0 or result != result or result in (float("inf"), float("-inf")):
        result = float(default)
    return result


def _episodes_explicitly_on_cli(argv: Optional[Any] = None) -> bool:
    """True only when ``--episodes`` appears on argv (YAML defaults do not count)."""
    import sys

    args_list = list(sys.argv[1:] if argv is None else argv)
    for a in args_list:
        if a == "--episodes" or str(a).startswith("--episodes="):
            return True
    return False


_SCHEDULE_KEYS = {
    "stage_s": "STAGE_S_EPISODES",
    "stage_lon": "STAGE_LON_EPISODES",
    "stage_lat": "STAGE_LAT_EPISODES",
    "joint_lon_sig": "JOINT_LON_SIG_EPISODES",
    "joint_all": "JOINT_ALL_EPISODES",
    "joint_lon_sig_anneal": "JOINT_LON_SIG_ANNEAL_EPISODES",
    "joint_all_anneal": "JOINT_ALL_ANNEAL_EPISODES",
}


def apply_schedule_overrides(overrides: Optional[Dict[str, Any]]) -> bool:
    """v5 (1.4): validated per-profile schedule overrides from config.yaml.

    ``training.schedule: {full: {...}, quick: {...}}`` with keys stage_s,
    stage_lon (incl. JointLonSig), stage_lat (incl. JointAll), joint_lon_sig,
    joint_all, joint_lon_sig_anneal, joint_all_anneal. Updates the module
    constants (read at call time by apply_episode_timing and train_RL).
    """
    if not isinstance(overrides, dict):
        return False
    g = globals()
    changed = False
    for profile, prefix in (("full", "FULL_"), ("quick", "QUICK_")):
        spec = overrides.get(profile)
        if not isinstance(spec, dict) or not spec:
            continue
        unknown = set(spec) - set(_SCHEDULE_KEYS)
        if unknown:
            raise ValueError(f"training.schedule.{profile}: unknown keys {sorted(unknown)}")
        merged = {prefix + suf: int(g[prefix + suf]) for suf in _SCHEDULE_KEYS.values()}
        for key, suf in _SCHEDULE_KEYS.items():
            if spec.get(key) is not None:
                val = int(spec[key])
                if val < 0:
                    raise ValueError(f"training.schedule.{profile}.{key} must be >= 0")
                merged[prefix + suf] = val
        s_, lon, lat = (merged[prefix + "STAGE_S_EPISODES"], merged[prefix + "STAGE_LON_EPISODES"],
                        merged[prefix + "STAGE_LAT_EPISODES"])
        jls, ja = merged[prefix + "JOINT_LON_SIG_EPISODES"], merged[prefix + "JOINT_ALL_EPISODES"]
        if min(s_, lon, lat) < 1:
            raise ValueError(f"training.schedule.{profile}: stage lengths must be >= 1")
        if jls > 0 and jls >= lon:
            raise ValueError(f"training.schedule.{profile}: joint_lon_sig ({jls}) is carved from stage_lon ({lon})")
        if ja > 0 and ja >= lat:
            raise ValueError(f"training.schedule.{profile}: joint_all ({ja}) is carved from stage_lat ({lat})")
        if merged[prefix + "JOINT_ALL_ANNEAL_EPISODES"] > max(ja, 1):
            raise ValueError(f"training.schedule.{profile}: joint_all_anneal exceeds joint_all")
        g.update(merged)
        g[prefix + "TOTAL_EPISODES"] = int(s_ + lon + lat)
        changed = True
        print(
            f"[schedule] {profile}: S={s_} Lon={lon} (JLS={jls}) Lat={lat} (JA={ja}) "
            f"total={s_ + lon + lat}",
            flush=True,
        )
    return changed


def _flag_on_cli(flag: str, argv: Optional[Any] = None) -> bool:
    import sys

    args_list = list(sys.argv[1:] if argv is None else argv)
    return any(a == flag or str(a).startswith(flag + "=") for a in args_list)


def apply_episode_timing(args: Any, step_length: Optional[float] = None) -> Any:
    """Resolve the episode curriculum and simulation horizon on ``args``.

    Default Full/Quick budgets are authoritative. Explicit CLI ``--episodes``
    (when not equal to the profile default) scales stage blocks proportionally.
    YAML ``training.episodes`` alone must NOT scale ``--quick`` (would turn
    400→800). Boolean lock: env ``GRID_LOCK_CURRICULUM=1`` (preferred) or
    ``GRID_FORCE_CURRICULUM`` in {1,true,yes,on}. Comma-form
    ``GRID_FORCE_CURRICULUM=S,Lon,JLS,Lat,JA`` is handled only by train_RL.
    """
    import os

    dt_source = step_length
    if dt_source is None:
        dt_source = getattr(args, "step_length", 0.2)
    dt = _positive_float(dt_source, 0.2)

    quick = bool(getattr(args, "quick", False))
    apply_schedule_overrides(getattr(args, "schedule_overrides", None))  # v5 (1.4)
    _cli_jls = getattr(args, "joint_lon_sig_episodes", None)
    _cli_ja = getattr(args, "joint_all_episodes", None)
    _lock_env = str(
        os.environ.get("GRID_LOCK_CURRICULUM")
        or os.environ.get("GRID_FORCE_CURRICULUM", "")
        or ""
    ).strip().lower()
    # Boolean lock only — ignore comma-separated curriculum schedules.
    force_lock = _lock_env in ("1", "true", "yes", "on")

    if quick:
        args.warmup_seconds = 300.0
        if getattr(args, "control_seconds", None) is None:
            args.control_seconds = 900.0  # full peak/trough even in Quick

        stage_s = QUICK_STAGE_S_EPISODES
        stage_lon = QUICK_STAGE_LON_EPISODES
        stage_lat = QUICK_STAGE_LAT_EPISODES
        warmups = dict(QUICK_VLM_WARMUP_BY_STAGE)
        args.joint_lon_sig_episodes = int(QUICK_JOINT_LON_SIG_EPISODES)
        args.joint_all_episodes = int(QUICK_JOINT_ALL_EPISODES)
        default_total = int(QUICK_TOTAL_EPISODES)
    else:
        stage_s = FULL_STAGE_S_EPISODES
        stage_lon = FULL_STAGE_LON_EPISODES
        stage_lat = FULL_STAGE_LAT_EPISODES
        warmups = dict(VLM_WARMUP_BY_STAGE)
        args.joint_lon_sig_episodes = int(FULL_JOINT_LON_SIG_EPISODES)
        args.joint_all_episodes = int(FULL_JOINT_ALL_EPISODES)
        default_total = int(FULL_TOTAL_EPISODES)

    # v4: honour explicit CLI joint-tail lengths (v3 silently overwrote them).
    if _flag_on_cli("--joint-lon-sig-episodes") and _cli_jls is not None:
        args.joint_lon_sig_episodes = max(0, int(_cli_jls))
    if _flag_on_cli("--joint-all-episodes") and _cli_ja is not None:
        args.joint_all_episodes = max(0, int(_cli_ja))

    # Scale only when the user passed --episodes on the CLI (not YAML default).
    user_eps = getattr(args, "episodes", None)
    try:
        user_eps_i = int(user_eps) if user_eps is not None else None
    except (TypeError, ValueError):
        user_eps_i = None
    explicit_eps = _episodes_explicitly_on_cli()
    if (
        not force_lock
        and explicit_eps
        and user_eps_i is not None
        and user_eps_i > 0
        and user_eps_i != default_total
    ):
        scale = float(user_eps_i) / float(default_total)
        stage_s = max(1, int(round(stage_s * scale)))
        stage_lon = max(1, int(round(stage_lon * scale)))
        stage_lat = max(1, int(round(stage_lat * scale)))
        # Fix rounding so sum matches requested total.
        drift = int(user_eps_i) - (stage_s + stage_lon + stage_lat)
        stage_lat = max(1, stage_lat + drift)
        raw_jls = int(args.joint_lon_sig_episodes)
        raw_ja = int(args.joint_all_episodes)
        jls = max(1, int(round(raw_jls * scale))) if raw_jls > 0 else 0
        ja = max(1, int(round(raw_ja * scale))) if raw_ja > 0 else 0
        args.joint_lon_sig_episodes = min(jls, max(0, stage_lon - 1)) if jls > 0 else 0
        args.joint_all_episodes = min(ja, max(0, stage_lat - 1)) if ja > 0 else 0

    if bool(getattr(args, "smoke", False)):
        # v5.1: tiny schedule that still visits every stage (S, Lon, Lat, JointAll).
        stage_s, stage_lon, stage_lat = 2, 2, 4
        args.joint_lon_sig_episodes = 0
        args.joint_all_episodes = 2
    try:
        gate_lon = int(getattr(args, "gate_lon_episodes", 0) or 0)
    except (TypeError, ValueError):
        gate_lon = 0
    if gate_lon > 0:
        # v6-P0 gate: enough Lon episodes to read the control stack, one Lat
        # episode to close the run cleanly, no joint stages.
        stage_s, stage_lon, stage_lat = 2, int(gate_lon), 1
        args.joint_lon_sig_episodes = 0
        args.joint_all_episodes = 0
    args.stage_s_episodes = int(stage_s)
    args.stage_lon_episodes = int(stage_lon)
    args.stage_lat_episodes = int(stage_lat)
    args.stage_l1_episodes = int(stage_lon)
    args.stage_l2_episodes = int(stage_lat)
    args.episodes = int(stage_s + stage_lon + stage_lat)
    args.use_absolute_stage_schedule = True

    override = getattr(args, "vlm_warmup_episodes", None)
    if override is not None:
        n = _nonnegative_int(override)
        warmups = {"S": n, "Lon": n, "Lat": n}
    args.vlm_warmup_by_stage = warmups

    warmup_seconds = getattr(args, "warmup_seconds", 300.0)
    try:
        warmup_seconds = float(warmup_seconds)
    except (TypeError, ValueError, OverflowError):
        warmup_seconds = 300.0
    if warmup_seconds != warmup_seconds or warmup_seconds in (
        float("inf"), float("-inf")
    ):
        warmup_seconds = 300.0
    args.warmup_seconds = max(0.0, warmup_seconds)

    control_seconds = getattr(args, "control_seconds", None)
    if control_seconds is not None:
        try:
            control_seconds = float(control_seconds)
        except (TypeError, ValueError, OverflowError):
            raise ValueError("--control-seconds must be a finite non-negative number.")
        if (
            control_seconds != control_seconds
            or control_seconds in (float("inf"), float("-inf"))
            or control_seconds < 0
        ):
            raise ValueError("--control-seconds must be a finite non-negative number.")
        args.control_seconds = control_seconds
        args.max_steps = max(1, int(round(control_seconds / dt)))
    else:
        # Default 900 s control (4500 steps @ 0.2 s) for both Full and Quick.
        max_steps = _nonnegative_int(getattr(args, "max_steps", 4500), 4500)
        args.max_steps = max(1, max_steps)
        args.control_seconds = float(args.max_steps) * dt

    return args


def timing_summary(args: Any) -> str:
    """Return a compact, log-friendly summary of the resolved timing."""
    warmup = getattr(args, "warmup_seconds", 0)
    control = getattr(args, "control_seconds", 0)
    max_steps = getattr(args, "max_steps", 0)
    stages = (
        f"S={getattr(args, 'stage_s_episodes', QUICK_STAGE_S_EPISODES)}"
        f"/Lon={getattr(args, 'stage_lon_episodes', QUICK_STAGE_LON_EPISODES)}"
        f"/Lat={getattr(args, 'stage_lat_episodes', QUICK_STAGE_LAT_EPISODES)}"
    )
    return (
        f"warmup={warmup}s control={control}s max_steps={max_steps} "
        f"episodes=[{stages}] total={getattr(args, 'episodes', 0)}"
    )


assert QUICK_TOTAL_EPISODES == 480
assert FULL_TOTAL_EPISODES == 850  # v5 default (overridable via training.schedule)
assert QUICK_STAGE_S_EPISODES + QUICK_STAGE_LON_EPISODES + QUICK_STAGE_LAT_EPISODES == QUICK_TOTAL_EPISODES
assert FULL_STAGE_S_EPISODES + FULL_STAGE_LON_EPISODES + FULL_STAGE_LAT_EPISODES == FULL_TOTAL_EPISODES
assert FULL_JOINT_LON_SIG_EPISODES + FULL_JOINT_ALL_EPISODES <= (
    FULL_STAGE_LON_EPISODES + FULL_STAGE_LAT_EPISODES
)
assert FULL_STAGE_LON_EPISODES - FULL_JOINT_LON_SIG_EPISODES == 180
assert FULL_STAGE_LAT_EPISODES - FULL_JOINT_ALL_EPISODES == 250
assert FULL_JOINT_LON_SIG_EPISODES == 0
assert FULL_JOINT_ALL_ANNEAL_EPISODES == 120
assert FULL_JOINT_ALL_EPISODES - FULL_JOINT_ALL_ANNEAL_EPISODES == 50
assert QUICK_STAGE_LON_EPISODES - QUICK_JOINT_LON_SIG_EPISODES == 150
assert QUICK_STAGE_LAT_EPISODES - QUICK_JOINT_ALL_EPISODES == 140
assert QUICK_JOINT_LON_SIG_EPISODES == 0
assert QUICK_JOINT_ALL_ANNEAL_EPISODES == 50
assert QUICK_JOINT_ALL_EPISODES - QUICK_JOINT_ALL_ANNEAL_EPISODES == 20
