# CHANGELOG v5 → v5.1（冒烟测试修复）

依据：用户在 CPU 笔记本上跑的冒烟测试（3-leg 12 回合；4-leg 和 5-leg 各 3 回合；评估 2 个回合）。

## 修复
| 问题（冒烟中观察到） | 修复 |
|---|---|
| 导出 `best_final.pt` 时报 `name 'shutil' is not defined`（v3 就有的问题） | `train_RL.py` 顶层导入 `shutil` |
| 后续阶段没有正式最佳检查点时，`best_final.pt` 退回到 Stage-S 模型（即 IDM 驾驶的 CAV） | 在 `latest` 规则下，改为导出 `latest.pt` 并打印说明；一个最佳检查点都没有时也导出 `latest.pt` |
| 信号覆盖率 1–15%：掩码在饥饿时放开一组相位，钳位却强制其中一个；跨越 T 时智能体合法选择的"保持"被改成强制切换 | **掩码即契约**：只要动作在智能体看到的那份掩码中合法（且相位相同），就照原样执行；最短绿灯仍优先检查。设置 `SIGNAL_MASK_CONTRACT=0` 可恢复 v4 行为 |
| 场景目录缺少 `gui_viewsettings.xml`，libsumo 启动失败 | 三个场景各补一个最小的视图设置文件 |
| `--quick --episodes 12` 的实际排程是 S3/Lon4/Lat5/JA0（主阶段至少要 8 回合，切不出 JointAll） | 新增 `--smoke`：S2 / Lon2 / Lat2 + JointAll2，覆盖全部阶段；建议配合 `--control-seconds 300` 缩短回合 |
| 评估比训练还慢（多半是多个进程同时运行，每个 torch 进程默认占满全部 14 个核） | 新增 `--torch-threads`（默认 2）；环境子进程固定 1 线程 |

## 诊断工具
- 每回合打印 `[timing] total/reset/env/policy/critic/update/other`，并写入 TensorBoard 的 `Timing/*`。用于判断时间花在仿真上，还是花在网络计算和更新上。
- `--sumo-diag-dir DIR`：每回合输出 SUMO 的 `collisions_<seed>.xml`（碰撞明细，含所在车道，可判断是否发生在路口内）、`sumo_warnings_<seed>.log`（传送原因：jam / yield / wrong lane）和 `statistics_<seed>.xml`。
- 运行时传入的 SUMO 参数统一覆盖基础命令中的同名参数。

## 验证
- 42 项离线测试全部通过：新增"掩码即契约"6 项、诊断参数 1 项、冒烟排程 2 项。
- `tools/static_check.py` 报告 0 个问题。
