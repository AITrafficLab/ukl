# CHANGELOG v3 → v4

完整说明见 `docs/OPTIMIZATION_PLAN.md`；逐行差异见 `docs/v3_to_v4.diff`。

## 新增文件
- `agents/gae_utils.py`：SMDP（选项级）GAE，纯 numpy。
- `train/credit_utils.py`：CAV 信用分配（`coop_xapp` / `relative`），纯 numpy。
- `environment/demand_randomizer.py`：按种子的回合级需求随机化；解析计划出发时刻。
- `tools/static_check.py`：编译检查 + "局部变量先读后赋值"检查。
- `tests/test_v4_optimizations.py`、`tests/test_sumo_interface_offline.py`、`tests/test_credit_integration.py`。
- `docs/OPTIMIZATION_PLAN.md`、`docs/v3_to_v4.diff`。

## 修改文件
- `environment/marl_env.py`：`env_done_bool` 修复；拉格朗日阶段名与惩罚统计量；视觉语义年龄检查；新增 KPI 透传。
- `environment/SUMO_interface.py`：停驶排队；许可车道；按到达车辆的绿灯预算；每步车道索引；每回合 SUMO 运行参数（max-depart-delay、路口碰撞、需求文件）；在系统内时间/插入积压/OD 改写 KPI；默认禁止 OD 改写；HDV 控制区换道；`configure_control` 新参数与 `eval_mode`；Δa≡0 消融；删除残留的掩码构建行。
- `environment/zone_lc.py`：`control_keep_lane_hdv`（默认 False）。
- `agents/mappo.py`：actor 不再构图；PopArt；dual-clip c=3；`compute_gae` 改用 SMDP-GAE。
- `models/lateral_actor.py`：keep logit 偏置初始化。
- `baselines/episode_timing.py`：Lat 不再使用混合软启动；尊重 CLI 的联合阶段回合数。
- `train/train_RL.py`：`coop_xapp` 信用分配与 λ 位置修正；v4 命令行开关与环境参数；新 KPI 记录；最终模型选择规则与元数据；`--vlm-heuristic`；`--ablate-zero-lon-residual`。
- `VLM/signal_vision.py`：教师样本权重只依据可验证证据。
- `VLM/scene_encoder.py`：缺失置信度/有效性时关闭残差；记录实际应答的模型。
- `reward/adaptive_weight.py`：同上（语义解析默认值）。
- `VLM/prompt.py`：残差系数文字与代码一致（0.05）。
- `VLM/*_vlm_server.py`（4 个）：返回实际模型 ID，请求模型不一致时报警。
- `baselines/experiment_seeds.py`：选择器名与需求时窗修正。
- `baselines/reward_tb.py`：文件头说明修正。
- `experiments/config.yaml`：`co_optimization`（碰撞惩罚 −5、惩罚模式）与新增 `optimization` 段。
