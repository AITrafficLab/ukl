"""Multi-agent wrapper: Signal + CAV Lateral + CAV Longitudinal (hierarchical)."""
from __future__ import annotations

import json
import math
import os
from collections.abc import Mapping

import numpy as np

from environment.cav_state_builder import (
    LAT_OBS_DIM,
    LON_OBS_DIM,
    build_lateral_obs,
    build_longitudinal_obs,
    compute_lon_rl_authority,
    lat_dof_mode,
    lon_rl_eligible,
)
# v5.2.4 observe-only KPIs forwarded from SUMOEnvironment.jstall_stats().
V524_KPI_KEYS = (
    "jstall_sig_ctrl_cav_s",
    "jstall_sig_free_cav_s",
    "jstall_sig_hdv_s",
    "jstall_unsig_s",
    "jstall_ctrl_cav_events",
    "jstall_free_cav_events",
    "jstall_hdv_events",
    "lon_noop_frac",
    "lon_handback_idm_follower",
    "lon_handback_native_idm",
    "lon_handback_near_stopline",
    "lon_handback_junction",
)
# v6-P0 observe-only: longitudinal execution-authority audit (SUMOEnvironment.auth_stats()).
V6_AUTH_KPI_KEYS = (
    "auth_n",
    "auth_policy_res_mean",
    "auth_stack_res_mean",
    "auth_stack_cut_frac",
    "auth_stack_lift_frac",
    "auth_policy_pos_frac",
    "auth_pos_exec_ratio",
    "auth_realized_res_mean",
    "auth_requested_res_mean",
    "auth_sumo_cut_frac",
    "auth_sumo_lift_frac",
)

from environment.red_gap_diag import (
    SAMPLE_EVERY as RED_GAP_SAMPLE_EVERY,
    accumulate_from_state as accumulate_red_gap,
    new_accumulator as new_red_gap_accumulator,
    summarize_accumulator as summarize_red_gap,
)
from environment.SUMO_interface import SUMOEnvironment
from environment.zone_manager import ZONE_PLATOON
from reward.adaptive_weight import AdaptiveReward
from reward.lateral_reward import DEFAULT_LAT_WEIGHTS
from reward.longitudinal_reward import DEFAULT_LONG_WEIGHTS
from reward.signal_reward import (
    SPILL_PROXY_DEFAULT_LANE_M,
    compute_spill_proxy_from_state,
)


def _finite_float(value, default=0.0) -> float:
    """Convert optional simulator/model values to finite floats."""
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError):
        return float(default)
    return result if math.isfinite(result) else float(default)


class MultiAgentTrafficEnv:
    """Hierarchical CAV + TLS multi-agent environment."""

    # Legacy alias kept for older scripts; prefer LAT/LON dims.
    CAV_OBS_DIM = LON_OBS_DIM
    LAT_OBS_DIM = LAT_OBS_DIM
    LON_OBS_DIM = LON_OBS_DIM

    # Keep the 5-leg phase encoding complete: some 5-leg scenarios expose
    # seven green phases. Vision slots remain present even in the no-vision
    # ablation (zeros), so the signal actor input shape is stable.
    SIGNAL_QUEUE_DIRS = ("N", "S", "E", "W", "FZ")
    SIGNAL_PHASE_FEATURE_DIM = 7
    VISION_FEATURE_DIM = 4
    SIGNAL_OBS_DIM = (
        SIGNAL_PHASE_FEATURE_DIM
        + 2  # elapsed and remaining green time
        + 4 * len(SIGNAL_QUEUE_DIRS)  # queues, vehicle counts, waits, progression
        + VISION_FEATURE_DIM
    )
    SIGNAL_OBS_DIM_BASELINE = SIGNAL_OBS_DIM
    MAX_SIGNAL_ACTIONS = 7
    SIGNAL_VISION_KEYS = (
        "lane_blockage",
        "spillback",
        "incident_obstruction",
        "roadwork",
        "special_vehicle",
        "unseen_scene",
        "confidence",
        "valid",
    )
    GRAPH_NODE_DIM = 10
    MAX_SPEED = 16.67
    GRAPH_RANGE = 200.0
    LAT_ACTIONS = 3

    def __init__(
        self,
        sumocfg_file,
        use_gui=False,
        step_length=0.2,
        vlm_api_key=None,
        vlm_model="qwen3-vl-flash",
        vlm_api_base=None,
        vlm_update_interval_seconds=5.0,
        use_vlm=True,
        fixed_reward_weights=None,
        fixed_lat_weights=None,
        terminate_on_gridlock=False,
        sumo_port=None,
        fail_stop_on_vlm_error=None,
        results_method=None,
        scenario_key=None,
        run_seed=None,
        env_index=0,
        enable_lateral=True,
        enable_longitudinal=True,
        vlm_warmup_episodes=None,
        vlm_warmup_by_stage=None,
        demand_profile="full",
        enable_meta_reward=False,
        signal_vlm_vision_enabled=False,
        rule_signal_teacher_enabled=False,
        enable_emissions=None,
        vlm_weight_stages=None,
        co_opt_config=None,
    ):
        self.signal_vlm_vision_enabled = bool(signal_vlm_vision_enabled)
        # Rule teacher is the no_vlm Stage-S CE source; ignored when VLM vision is on.
        self.rule_signal_teacher_enabled = bool(rule_signal_teacher_enabled) and (
            not self.signal_vlm_vision_enabled
        )
        self._signal_vision_semantics = (
            self._invalid_signal_semantics()
            if self.signal_vlm_vision_enabled
            else None
        )
        self._signal_vision = None
        self._signal_vision_last_sim_time = None
        self.sumo_env = SUMOEnvironment(
            sumocfg_file,
            use_gui,
            step_length,
            terminate_on_gridlock=terminate_on_gridlock,
            sumo_port=sumo_port,
            demand_profile=demand_profile,
            enable_emissions=enable_emissions,
        )
        dublin = getattr(self.sumo_env, "_dublin_mode", False)
        self.MAX_SPEED = float(getattr(self.sumo_env, "MAX_SPEED", self.MAX_SPEED))
        self.GRAPH_RANGE = float(
            getattr(self.sumo_env, "CONTROL_ZONE_DISTANCE", self.GRAPH_RANGE)
        )
        self.use_vlm = bool(use_vlm)
        self.enable_lateral = bool(enable_lateral)
        self.enable_longitudinal = bool(enable_longitudinal)
        self._last_obs_ids = frozenset()
        # Diagnostic-only meta term (loops all vehicles each step); off by
        # default since no training/eval consumer reads infos meta_reward.
        self.enable_meta_reward = bool(enable_meta_reward)
        self.reward_fn = AdaptiveReward(
            update_interval=max(1, int(vlm_update_interval_seconds / step_length)),
            vlm_api_key=vlm_api_key,
            vlm_model=vlm_model,
            vlm_api_base=vlm_api_base,
            bev_layout="dublin" if dublin else "cross",
            use_vlm=self.use_vlm,
            fixed_weights=fixed_reward_weights,
            fixed_lat_weights=fixed_lat_weights,
            fail_stop_on_vlm_error=fail_stop_on_vlm_error,
            desired_speed=self.MAX_SPEED,
            vlm_weight_stages=vlm_weight_stages,
        )
        self.reward_fn._sim_step_length = float(step_length)
        self.co_opt_config = dict(co_opt_config or {})
        self.apply_co_opt_config(self.co_opt_config)
        if vlm_warmup_by_stage is not None and hasattr(
            self.reward_fn, "set_vlm_warmup_by_stage"
        ):
            self.reward_fn.set_vlm_warmup_by_stage(vlm_warmup_by_stage)
        elif vlm_warmup_episodes is not None:
            n = max(0, int(vlm_warmup_episodes))
            # Uniform override across stages when a single int is passed.
            if hasattr(self.reward_fn, "set_vlm_warmup_by_stage"):
                self.reward_fn.set_vlm_warmup_by_stage({"S": n, "Lat": n, "Lon": n})
            else:
                self.reward_fn.vlm_warmup_episodes = n
        try:
            from baselines.fixed_timing.scenarios import canonical_scenario_key

            jname = canonical_scenario_key(sumocfg_file)
        except Exception:
            jname = os.path.splitext(os.path.basename(sumocfg_file))[0]
        self.reward_fn.vlm.junction_name = jname
        self.reward_fn.vlm.renderer.junction_name = jname
        net_xml = None
        try:
            net_xml = self.sumo_env.resolve_net_xml_path()
        except Exception:
            net_xml = getattr(self.sumo_env, "net_xml_path", None)
        jcenter = getattr(self.sumo_env, "scenario_junction_center", None)
        approach_edges = getattr(self.sumo_env, "scenario_approach_edges", None)
        if jcenter is not None and len(jcenter) >= 2:
            self._graph_origin = (float(jcenter[0]), float(jcenter[1]))
        else:
            self._graph_origin = (1000.0, 1000.0)
        self.reward_fn.vlm.configure_scenario(
            net_xml_path=net_xml,
            junction_center=jcenter,
            approach_edges=approach_edges,
        )
        sc_key = str(scenario_key or jname or "").strip() or jname
        self.scenario_key = sc_key
        # Stage-S uses 2.5× the junction base; Lon=30s and Lat=45s are
        # fixed in AdaptiveReward. This fallback applies only if the
        # scenario key is unknown.
        if hasattr(self.reward_fn, "set_scenario"):
            try:
                self.reward_fn.set_scenario(sc_key)
            except Exception:
                pass
        method_key = str(results_method or "").strip() or (
            "VECTOR" if self.use_vlm else "no_vlm"
        )
        seed_key = run_seed if run_seed is not None else 0
        if hasattr(self.reward_fn.vlm, "configure_output_dir"):
            self.reward_fn.vlm.configure_output_dir(
                method=method_key,
                scenario=sc_key,
                seed=seed_key,
                env_index=int(env_index or 0),
                vlm_model=str(vlm_model or ""),
            )
        if self.signal_vlm_vision_enabled:
            try:
                from VLM.signal_vision import SignalVisionScheduler
            except ImportError as exc:
                raise RuntimeError(
                    "signal_vlm_vision_enabled=True, but VLM.signal_vision "
                    "could not be imported. Install/restore the signal-vision "
                    "scheduler module before running Mode B."
                ) from exc

            self._signal_vision = SignalVisionScheduler(
                encoder=self.reward_fn.vlm,
                scenario=sc_key,
                enabled=True,
                on_update=self._on_signal_vision_update,
                fail_stop_on_vlm_error=bool(
                    getattr(self.reward_fn, "fail_stop_on_vlm_error", False)
                ),
            )
        self.reward_fn.max_road_capacity = self.sumo_env.max_road_capacity
        self.reward_fn.control_zone_length = float(
            getattr(self.sumo_env, "CONTROL_ZONE_DISTANCE", self.GRAPH_RANGE)
        )
        self.reward_fn.default_green_duration = float(
            getattr(self.sumo_env, "MIN_GREEN_DURATION", 10.0)
        )
        self.raw_state = None
        self.episode_reward_signal = 0.0
        self.episode_reward_sig_formal_total = 0.0
        self.episode_reward_sig_residual_total = 0.0
        self.episode_reward_cav_total = 0.0
        self.episode_reward_cav_lon_total = 0.0
        self.episode_reward_cav_lat_total = 0.0
        self.episode_cav_count = 0
        self.step_cav_count = 0
        self.step_cav_lon_count = 0
        self.step_cav_lat_count = 0
        self.episode_steps = 0
        self._ep_shield_rate_sum = 0.0
        self._ep_shield_rate_n = 0
        self.cav_return_sums = {}
        self.ep_total_reward_alpha = 0.8
        self.ep_total_reward_beta = 0.2
        self._ep_cav_sumsq = 0.0
        self._ep_signal_sumsq = 0.0
        self._ep_sig_residual_nonzero = 0
        self._ep_spill_proxy_sum = 0.0
        self._ep_spill_proxy_n = 0
        self._last_spill_proxy = 0.0
        self._ep_lon_res_sum = 0.0
        self._ep_lon_res_nz = 0
        self._ep_lon_exposed_sum = 0.0
        self._ep_lon_step_n = 0
        self._ep_signal_count = 0
        self._ep_scale_eps = 1e-6
        self._ep_sig_waiting_seconds = 0.0
        self._ep_sig_vehicle_time_exposure = 0.0
        self._ep_sig_waiting_increment_sum = 0.0
        self._ep_sig_speed_term_sum = 0.0
        self._training_stage = "S"
        self._stage_episode = 0
        self._lat_meta = {}
        self._prev_accel = {}
        self.dt = float(step_length)
        # KPI running means (also reset() each episode).
        self.ep_fuel = 0.0
        self.ep_co2 = 0.0
        self._ep_speed_sum = 0.0
        self._ep_queue_sum = 0.0
        self._ep_net_wait_sum = 0.0
        self._ep_kpi_n = 0
        self.ep_conflicts = 0
        self.ep_arrived = 0
        self.ep_stops = 0
        self.ep_avg_travel_time = 0.0
        self.ep_avg_waiting_time = 0.0
        self.ep_completed_trips = 0
        # Observe-only: red/slow CAV vs HDV leader_gap (does not affect reward).
        self._ep_red_gap_acc = new_red_gap_accumulator()

    @classmethod
    def _invalid_signal_semantics(cls):
        """Conservative placeholder: no event is asserted when vision is invalid."""
        return {
            "lane_blockage": 0.0,
            "spillback": 0.0,
            "incident_obstruction": 0.0,
            "roadwork": 0.0,
            "special_vehicle": 0.0,
            "unseen_scene": 1.0,
            "confidence": 0.0,
            "valid": 0.0,
        }

    @classmethod
    def _normalize_signal_semantics(cls, semantics):
        """Validate the eight-field signal-vision schema before it reaches MAPPO."""
        if isinstance(semantics, str):
            try:
                semantics = json.loads(semantics)
            except (TypeError, ValueError, json.JSONDecodeError):
                return cls._invalid_signal_semantics()

        if not isinstance(semantics, Mapping):
            return cls._invalid_signal_semantics()

        if any(key not in semantics for key in cls.SIGNAL_VISION_KEYS):
            return cls._invalid_signal_semantics()

        normalized = {}
        for key in cls.SIGNAL_VISION_KEYS:
            value = semantics.get(key)
            if value is None:
                return cls._invalid_signal_semantics()
            # JSON VLM responses often encode event labels as true/false.
            # Treat booleans as valid 1/0 values rather than discarding the frame.
            if isinstance(value, bool):
                value = 1.0 if value else 0.0
            try:
                value = float(value)
            except (TypeError, ValueError, OverflowError):
                return cls._invalid_signal_semantics()
            if not math.isfinite(value) or value < 0.0 or value > 1.0:
                return cls._invalid_signal_semantics()
            normalized[key] = float(value)

        normalized["valid"] = 1.0 if normalized["valid"] >= 0.5 else 0.0
        if normalized["valid"] < 0.5:
            for key in (
                "lane_blockage",
                "spillback",
                "incident_obstruction",
                "roadwork",
                "special_vehicle",
            ):
                normalized[key] = 0.0
            normalized["unseen_scene"] = max(normalized["unseen_scene"], 0.8)
            normalized["confidence"] = min(normalized["confidence"], 0.3)

        return normalized

    def _on_signal_vision_update(self, semantics):
        """Callback from the scheduler; reject malformed results conservatively."""
        self._signal_vision_semantics = self._normalize_signal_semantics(semantics)

    def _lane_lengths_for_spill_proxy(self, lane_ids) -> dict:
        """Lookup approach corridor lengths (>=300m) so short split edges don't saturate."""
        out = {}
        env = getattr(self, "sumo_env", None)
        corridor_getter = (
            getattr(env, "_corridor_length_for_lane", None) if env is not None else None
        )
        lane_getter = getattr(env, "_lane_length", None) if env is not None else None
        floor_L = float(SPILL_PROXY_DEFAULT_LANE_M)
        for lid in lane_ids or ():
            key = str(lid)
            L = floor_L
            if callable(corridor_getter):
                try:
                    cand = float(corridor_getter(key))
                    if math.isfinite(cand) and cand > 1.0:
                        L = max(cand, floor_L)
                except Exception:
                    pass
            elif callable(lane_getter):
                try:
                    cand = float(lane_getter(key))
                    if math.isfinite(cand) and cand > 1.0:
                        L = max(cand, floor_L)
                except Exception:
                    pass
            out[key] = L
        return out

    def _spill_proxy_for_state(self, state) -> float:
        """Geometric spill proxy from lane queues vs approach lengths."""
        if not isinstance(state, Mapping):
            return 0.0
        stats = state.get("stats") if isinstance(state.get("stats"), Mapping) else {}
        lane_q = stats.get("lane_queue_lengths_m") if isinstance(stats, Mapping) else None
        lengths = None
        if isinstance(lane_q, Mapping) and lane_q:
            lengths = self._lane_lengths_for_spill_proxy(lane_q.keys())
        return float(
            compute_spill_proxy_from_state(
                state,
                lane_lengths_m=lengths,
                default_length_m=float(SPILL_PROXY_DEFAULT_LANE_M),
            )
        )

    def _signal_vision_feature_vector(self):
        """Last four signal-obs dims: live vision semantics when VLM is on.

        Layout: [lane_blockage, spillback_merged, incident_or_work,
        confidence * valid]. ``no_vlm`` / disabled vision → all zeros.
        """
        out = np.zeros(self.VISION_FEATURE_DIM, dtype=np.float32)
        if not bool(getattr(self, "signal_vlm_vision_enabled", False)):
            return out
        scheduler = getattr(self, "_signal_vision", None)
        if scheduler is not None and hasattr(scheduler, "features"):
            # v4: age-checked semantics (expire after cache_max_age_s).
            try:
                _raw = getattr(self, "raw_state", None) or {}
                _t_now = float(
                    (_raw.get("stats") or {}).get(
                        "time", getattr(self.sumo_env, "_sim_time", 0.0)
                    )
                    or 0.0
                )
                sem = dict(scheduler.features(_t_now) or {})
            except Exception:
                sem = {}
        else:
            sem = getattr(self, "_signal_vision_semantics", None) or {}
        if not isinstance(sem, Mapping):
            return out
        try:
            lane_b = float(sem.get("lane_blockage", 0.0) or 0.0)
            spill = float(sem.get("spillback", sem.get("spillback_merged", 0.0)) or 0.0)
            incident = float(sem.get("incident_obstruction", 0.0) or 0.0)
            roadwork = float(sem.get("roadwork", 0.0) or 0.0)
            conf = float(sem.get("confidence", 0.0) or 0.0)
            valid = float(sem.get("valid", 0.0) or 0.0)
            out[0] = float(np.clip(lane_b, 0.0, 1.0))
            out[1] = float(np.clip(spill, 0.0, 1.0))
            out[2] = float(np.clip(max(incident, roadwork), 0.0, 1.0))
            out[3] = float(np.clip(conf * valid, 0.0, 1.0))
        except (TypeError, ValueError):
            return np.zeros(self.VISION_FEATURE_DIM, dtype=np.float32)
        return out

    def configure_stage(
        self,
        stage,
        top3_mask=None,
        coop_policy=None,
        stage_episode=0,
        soft_start=None,
        stage_len=None,
    ):
        del coop_policy
        from agents.mappo import MAPPOAgent
        from baselines.episode_timing import action_blend_beta

        stage = MAPPOAgent._normalize_stage(stage)
        self._training_stage = stage
        env_stage = MAPPOAgent.cav_env_stage(stage)
        self._stage_episode = int(stage_episode or 0)
        self._stage_len = (
            max(0, int(stage_len)) if stage_len is not None else int(getattr(self, "_stage_len", 0) or 0)
        )
        # soft_start=None → pure policy (eval / scripts). Training always passes
        # the stage VLM warmup so Lon/Lat action blend can stagger correctly.
        # Joint tails always use β=1 (past Lon/Lat soft-start).
        if soft_start is None or MAPPOAgent.is_joint_stage(stage):
            self._soft_start = 0
            self._action_blend_beta = 1.0
        else:
            self._soft_start = int(soft_start)
            self._action_blend_beta = float(
                action_blend_beta(
                    int(self._stage_episode),
                    int(self._soft_start),
                    stage=str(env_stage),
                )
            )
        if self._signal_vision is not None and hasattr(self._signal_vision, "set_stage_context"):
            self._signal_vision.set_stage_context(
                stage=str(stage),
                stage_episode=int(self._stage_episode),
            )
        sumo = self.sumo_env
        cav_rl = env_stage != "S"
        if hasattr(self.reward_fn, "set_training_stage"):
            self.reward_fn.set_training_stage(
                stage,
                stage_episode=int(stage_episode or 0),
                stage_len=int(self._stage_len) if stage_len is not None else None,
            )
        elif hasattr(self.reward_fn, "set_stage_episode"):
            self.reward_fn.set_stage_episode(
                int(stage_episode or 0),
                stage_len=int(self._stage_len) if stage_len is not None else None,
            )
        if hasattr(sumo, "configure_control"):
            # Lon: IDM accel mix with staggered β (bound to VLM soft_start).
            # Lat: lon is frozen pure RL (β=1); keep-bias is applied in MAPPO.
            # JointLonSig follows Lon env mode; JointAll follows Lat.
            lon_beta = (
                float(self._action_blend_beta) if env_stage == "Lon" else 1.0
            )
            kwargs = {
                "cav_rl_enabled": cav_rl,
                # Universal 0..200 m keep-lane for all types (zone_lc).
                # Lat / JointAll: leader CAV LC owned by lat_actor in 200..700 m.
                "lateral_rl_enabled": env_stage == "Lat",
                "control_keep_lane": True,
                "lon_idm_mix_beta": float(lon_beta),
            }
            if top3_mask is not None:
                kwargs["top3_phase_mask"] = bool(top3_mask)
            sumo.configure_control(**kwargs)

    def _sync_reward_signal_edges(self):
        incoming = getattr(self.sumo_env, "incoming_edges", None) or []
        outgoing = getattr(self.sumo_env, "outgoing_edges", None) or []
        setter = getattr(self.reward_fn, "set_signal_edges", None)
        if callable(setter):
            setter(incoming, outgoing)
        updater = getattr(self.sumo_env, "_update_signal_pressure_capacity", None)
        if callable(updater):
            updater()
            self.reward_fn.max_road_capacity = self.sumo_env.max_road_capacity

    def reset(self, seed=None):
        self._p1_obs_cache = None
        self.raw_state = self.sumo_env.reset(seed=seed)
        self._sync_reward_signal_edges()
        if hasattr(self.reward_fn, "reset"):
            self.reward_fn.reset()
        self.episode_reward_signal = 0.0
        self.episode_reward_sig_formal_total = 0.0
        self.episode_reward_sig_residual_total = 0.0
        self.episode_reward_cav_total = 0.0
        self.episode_reward_cav_lon_total = 0.0
        self.episode_reward_cav_lat_total = 0.0
        self.episode_cav_count = 0
        self.step_cav_count = 0
        self.step_cav_lon_count = 0
        self.step_cav_lat_count = 0
        self.episode_steps = 0
        self.cav_return_sums = {}
        self._ep_cav_sumsq = 0.0
        self._ep_signal_sumsq = 0.0
        self._ep_signal_count = 0
        self._ep_sig_waiting_seconds = 0.0
        self._ep_sig_vehicle_time_exposure = 0.0
        self._ep_sig_waiting_increment_sum = 0.0
        self._ep_sig_speed_term_sum = 0.0
        self._ep_sig_residual_nonzero = 0
        self._ep_spill_proxy_sum = 0.0
        self._ep_spill_proxy_n = 0
        self._last_spill_proxy = 0.0
        self._ep_lon_res_sum = 0.0
        self._ep_lon_res_nz = 0
        self._ep_lon_exposed_sum = 0.0
        self._ep_lon_step_n = 0
        self._signal_vision_semantics = (
            self._invalid_signal_semantics()
            if bool(getattr(self, "signal_vlm_vision_enabled", False))
            else None
        )
        self._signal_vision_last_sim_time = None
        if self._signal_vision is not None:
            self._signal_vision.reset()
        self._lat_meta = {}
        self._prev_accel = {}
        self.ep_fuel = 0.0
        self.ep_co2 = 0.0
        self._ep_speed_sum = 0.0
        self._ep_queue_sum = 0.0
        self._ep_net_wait_sum = 0.0
        self._ep_kpi_n = 0
        self.ep_conflicts = 0
        self.ep_arrived = 0
        self.ep_stops = 0
        self.ep_avg_travel_time = 0.0
        self.ep_avg_waiting_time = 0.0
        self.ep_completed_trips = 0
        self._ep_red_gap_acc = new_red_gap_accumulator()
        obs = self._get_obs()
        self._last_obs_ids = frozenset(
            k for k in obs.keys() if k != "__graph__"
        )
        return obs

    def _episode_reward_parts(self):
        """Episode aggregates for logging (fixed α=0.8/β=0.2 weighting).

        Logging only — does not change per-agent PPO rewards.

        mean_cav: per-vehicle (r_lon + r_lat) over controlled CAV vehicle-steps
            (aligned with team mean_cav); Lat entry no longer dilutes via extra
            zero lat agent samples.
        mean_cav_lon: mean over cav_lon_* step rewards.
        mean_cav_lat: mean over dlc_eligible cav_lat_* step rewards only.
        """
        mean_cav = 0.0
        mean_cav_lon = 0.0
        mean_cav_lat = 0.0
        mean_signal = 0.0
        mean_sig_formal = 0.0
        mean_sig_residual = 0.0
        if self.step_cav_count > 0:
            mean_cav = float(self.episode_reward_cav_total) / float(self.step_cav_count)
        if self.step_cav_lon_count > 0:
            mean_cav_lon = (
                float(self.episode_reward_cav_lon_total) / float(self.step_cav_lon_count)
            )
        if self.step_cav_lat_count > 0:
            mean_cav_lat = (
                float(self.episode_reward_cav_lat_total) / float(self.step_cav_lat_count)
            )
        if self._ep_signal_count > 0:
            n_sig = float(self._ep_signal_count)
            mean_signal = float(self.episode_reward_signal) / n_sig
            mean_sig_formal = float(self.episode_reward_sig_formal_total) / n_sig
            mean_sig_residual = float(self.episode_reward_sig_residual_total) / n_sig

        def _std(sum_, sumsq, n, eps):
            if n < 2:
                return 0.0
            mean = sum_ / n
            var = max(sumsq / n - mean * mean, 0.0)
            return float(np.sqrt(var + eps))

        std_cav = _std(
            self.episode_reward_cav_total, self._ep_cav_sumsq, self.step_cav_count, self._ep_scale_eps
        )
        std_signal = _std(
            self.episode_reward_signal, self._ep_signal_sumsq, self._ep_signal_count, self._ep_scale_eps
        )
        beta = float(self.ep_total_reward_beta)
        r_ep = float(self.ep_total_reward_alpha) * mean_cav + beta * mean_signal
        return (
            float(r_ep),
            float(mean_cav),
            float(mean_signal),
            float(std_cav),
            float(std_signal),
            float(beta),
            float(mean_cav_lon),
            float(mean_cav_lat),
            float(mean_sig_formal),
            float(mean_sig_residual),
        )

    def _filter_escape_lateral(self, cav_lat):
        """(Unused in S -> Lon -> Lat) keeps only routing-escape lateral actions.

        Stage-Lon leaves lateral fully to SUMO defaults, so this helper is no
        longer on the control path; retained for reference/tests.
        """
        if not cav_lat or self.raw_state is None:
            return {}
        cavs = (self.raw_state.get("cavs") or {})
        keep = {}
        for vid, a in cav_lat.items():
            vinfo = cavs.get(vid)
            if not vinfo:
                continue
            if not bool(vinfo.get("in_control_zone", False)):
                continue
            lane = str(vinfo.get("lane", "") or "")
            try:
                idx = int(lane.rsplit("_", 1)[-1])
            except (TypeError, ValueError):
                continue
            edge = str(vinfo.get("edge", "") or "")
            nxt = vinfo.get("route_next_edge")
            lane_map = vinfo.get("lane_to_edges")
            if not edge or not nxt or not lane_map:
                continue
            raw = lane_map.get(idx, lane_map.get(str(idx)))
            dests = {str(x) for x in (raw if not isinstance(raw, (str, bytes)) else [raw])} if raw is not None else set()
            if str(nxt) not in dests:
                keep[vid] = a
        return keep

    def step(self, actions, ep=0, step_num=0, lambdas=None):
        del lambdas
        cav_lon = {}
        cav_lat = {}
        signal_actions = {}
        for agent_id, action in actions.items():
            if agent_id.startswith("cav_lon_"):
                cav_lon[agent_id[len("cav_lon_") :]] = action
            elif agent_id.startswith("cav_lat_"):
                # Discrete 0/1/2 → driver-left / keep / driver-right (-1/0/+1).
                # Index delta depends on net lefthand (see driver_lane_offset).
                a = int(np.asarray(action).reshape(-1)[0]) if not isinstance(action, (int, np.integer)) else int(action)
                if a in (0, 1, 2):
                    a = [-1, 0, 1][a]
                cav_lat[agent_id[len("cav_lat_") :]] = a
            elif agent_id.startswith("cav_"):
                # Legacy: treat as longitudinal
                cav_lon[agent_id[4:]] = action
            elif agent_id.startswith("signal_"):
                signal_actions[agent_id[7:]] = action

        # Stage gates (curriculum S -> Lon -> Lat):
        #   S   : both IDM / SUMO default.
        #   Lon / JointLonSig : RL longitudinal only; lateral stays SUMO default.
        #   Lat / JointAll : RL lateral on top of RL longitudinal (lon kept).
        from agents.mappo import MAPPOAgent

        stage = self._training_stage
        env_stage = MAPPOAgent.cav_env_stage(stage)
        if env_stage == "S":
            cav_lon, cav_lat = {}, {}
        elif env_stage == "Lon":
            cav_lat = {}  # default safe lane-selection; no untrained lat_actor
        elif env_stage == "Lat":
            # Longitudinal kept (frozen trained lon_actor). DoF gate: LOCKED_0DOF
            # forced keep; RULE_MLC left to routing mask; only RL_DLC keeps RL action.
            try:
                _cavs = (self.raw_state.get("cavs") or {}) if self.raw_state else {}
                for _vid in list(cav_lat.keys()):
                    _vi = _cavs.get(_vid)
                    if not _vi:
                        continue
                    _m = (self._lat_meta.get(_vid) or {}).get("dof_mode")
                    if _m is None:
                        try:
                            _m, _ = lat_dof_mode(_vi, max(int(_vi.get("n_lanes", 1) or 1), 1))
                        except Exception:
                            _m = "RL_DLC"
                    if str(_m) == "LOCKED_0DOF":
                        cav_lat[_vid] = 0  # keep-lane (-1/0/1 convention)
                    elif str(_m) == "RULE_MLC":
                        # Mandatory route lane change: never let stochastic RL override
                        # strategic routing; step deterministically toward nearest legal lane.
                        from environment.cav_state_builder import deterministic_mlc_action
                        cav_lat[_vid] = int(
                            deterministic_mlc_action(
                                _vi,
                                n_lanes=max(int(_vi.get("n_lanes", 1) or 1), 1),
                            )
                        )
            except Exception:
                pass
        if not self.enable_lateral:
            cav_lat = {}
        if not self.enable_longitudinal:
            cav_lon = {}

        previous_state = self.raw_state
        next_raw_state, _, env_done, env_info = self.sumo_env.step(
            cav_lon, signal_actions, cav_lat_actions=cav_lat
        )
        # v4 fix (P0): define env_done_bool BEFORE its first use below
        # (v3 read it ~50 lines before assignment -> UnboundLocalError every step).
        env_done_bool = bool(env_done)

        # Stage-S only: Lon/Lat must not keep injecting stale Stage-S semantics
        # into signal reward residual (see reward.signal_reward._vlm_signal_residual).
        stage_now = str(getattr(self, "_training_stage", "S") or "S")
        sem = None
        if stage_now in ("S", "JointLonSig", "JointAll"):
            sem = getattr(self, "_signal_vision_semantics", None)
            sched = getattr(self, "_signal_vision", None)
            if sched is not None:
                # v4: age-checked read via scheduler.features() (enforces
                # cache_max_age_s); v3 read the raw cache, so a stale result
                # could stay in the reward residual for the rest of the episode.
                sem = None
                try:
                    _t_now = float(
                        ((next_raw_state or {}).get("stats") or {}).get(
                            "time", getattr(self.sumo_env, "_sim_time", 0.0)
                        )
                        or 0.0
                    )
                    live = dict(sched.features(_t_now) or {})
                except Exception:
                    live = None
                if isinstance(live, Mapping) and float(live.get("valid", 0.0) or 0.0) >= 0.5:
                    sem = live
        elif getattr(self, "_signal_vision_semantics", None) is not None:
            # Drop env-side cache when leaving Stage-S.
            self._signal_vision_semantics = self._invalid_signal_semantics()
        if isinstance(sem, Mapping) and isinstance(next_raw_state, dict):
            stats = next_raw_state.get("stats")
            if not isinstance(stats, dict):
                stats = {}
                next_raw_state["stats"] = stats
            try:
                spill = float(sem.get("spillback_risk", sem.get("spillback", 0.0)) or 0.0)
                incident = float(sem.get("incident_obstruction", 0.0) or 0.0)
                blockage = float(sem.get("lane_blockage", 0.0) or 0.0)
                conf = float(sem.get("confidence", 0.0) or 0.0)
                valid = float(sem.get("valid", 0.0) or 0.0)
            except (TypeError, ValueError, OverflowError):
                spill = incident = blockage = conf = valid = 0.0
            if "junction_blocked" in sem:
                blocked = bool(sem.get("junction_blocked"))
            else:
                blocked = bool(incident >= 0.5 or blockage >= 0.7)
            # Geometric spill beyond formal L_ref; merged into residual risk.
            spill_proxy = self._spill_proxy_for_state(next_raw_state)
            self._last_spill_proxy = float(spill_proxy)
            self._ep_spill_proxy_sum += float(spill_proxy)
            self._ep_spill_proxy_n += 1
            spill_merged = float(np.clip(max(spill, spill_proxy), 0.0, 1.0))
            stats["vlm_signal_semantic"] = {
                "spillback_risk": spill_merged,
                "junction_blocked": blocked,
                "confidence": float(np.clip(conf, 0.0, 1.0)),
                "valid": valid,
                "spill_proxy": float(spill_proxy),
                "visual_event": str(sem.get("visual_event") or "none"),
            }
        elif isinstance(next_raw_state, dict):
            stats = next_raw_state.get("stats")
            if isinstance(stats, dict):
                stats.pop("vlm_signal_semantic", None)
            self._last_spill_proxy = 0.0

        # Escape credit uses agents alive before the transition. Reuse last
        # returned obs ids instead of rebuilding _get_obs on the pre-step state
        # (same keys; avoids a duplicate full obs build every step).
        global_reward, global_r_dict, agent_rewards = self.reward_fn.compute_agent_rewards(
            next_raw_state,
            previous_state,
            actions,
            ep=ep,
            step=step_num,
            lat_actions=cav_lat,
            lat_meta=self._lat_meta,
            dt=float(self.dt),
            active_agent_ids=set(getattr(self, "_last_obs_ids", ()) or ()),
        )

        # Meta reward optional (must use live reward_fn weights/edges).
        # Gated: full-vehicle scan each step, consumed by no training path.
        meta_reward = 0.0
        if bool(getattr(self, "enable_meta_reward", False)) and hasattr(
            self.reward_fn, "compute_meta_reward"
        ):
            try:
                meta_reward = self.reward_fn.compute_meta_reward(
                    next_raw_state, previous_state
                )
            except Exception:
                meta_reward = 0.0

        # Individualized physical safety-shield penalty ONLY (decoupled from CACC & soft-start!).
        applied = env_info.get("applied_cav_actions") or {}
        shield_deltas = env_info.get("shield_clip_deltas")
        eta_shield = float(getattr(self, "eta_shield", 0.05) or 0.05)
        n_intervened = 0
        # v5.2.4: CAVs handed back to SUMO this step did not execute their
        # sampled action -> excluded from PPO and from the intervention rate.
        lon_noop = set(str(v) for v in (env_info.get("lon_noop_vids") or ()))
        n_lon_exec = 0
        for vid, a_pi in (cav_lon or {}).items():
            if str(vid) in lon_noop:
                continue
            n_lon_exec += 1
            if shield_deltas is not None:
                try:
                    s_delta = max(0.0, float(shield_deltas.get(vid, 0.0) or 0.0))
                except (TypeError, ValueError):
                    s_delta = 0.0
                err2 = s_delta * s_delta
                is_real_clip = s_delta > 0.05
            else:
                if vid not in applied:
                    continue
                try:
                    a_exec = float(applied[vid])
                    a_req = float(np.asarray(a_pi).reshape(-1)[0])
                except (TypeError, ValueError):
                    continue
                s_delta = max(0.0, a_req - a_exec)
                err2 = s_delta * s_delta
                is_real_clip = s_delta > 0.05
            if err2 <= 1e-6:
                continue
            if is_real_clip:
                n_intervened += 1
            # v4: penalty statistic matches the dual constraint (intervention RATE);
            # v3 penalized delta^2 while the multiplier tracked the indicator rate.
            if str(getattr(self, "lagrangian_penalty_mode", "indicator")) == "squared":
                pen = -eta_shield * err2
            else:
                pen = -eta_shield * (1.0 if is_real_clip else 0.0)
            reward_key = f"cav_lon_{vid}"
            if reward_key not in agent_rewards and f"cav_{vid}" in agent_rewards:
                reward_key = f"cav_{vid}"
            if reward_key in agent_rewards:
                agent_rewards[reward_key] = float(agent_rewards[reward_key]) + pen
            global_r_dict["safe"] = float(global_r_dict.get("safe", 0.0)) + pen
        intervention_rate = (
            float(n_intervened) / float(n_lon_exec) if n_lon_exec else 0.0
        )
        self._ep_shield_rate_sum = float(getattr(self, "_ep_shield_rate_sum", 0.0)) + intervention_rate
        self._ep_shield_rate_n = int(getattr(self, "_ep_shield_rate_n", 0)) + (1 if n_lon_exec else 0)
        if env_done_bool and bool(getattr(self, "lagrangian_safety_enabled", True)):
            # v4 fix: v3 read "training_stage" (never set) -> dual update never ran.
            st_cur = str(getattr(self, "_training_stage", "S") or "S")
            if st_cur != "S" and int(getattr(self, "_ep_shield_rate_n", 0)) > 0:
                ep_int_rate = float(self._ep_shield_rate_sum) / float(self._ep_shield_rate_n)
                tgt = float(getattr(self, "target_intervention_rate", 0.05))
                lr_dual = float(getattr(self, "lagrangian_safety_lr", 0.02))
                eta_max = float(getattr(self, "lagrangian_safety_max", 0.50))
                self.eta_shield = float(
                    np.clip(eta_shield + lr_dual * (ep_int_rate - tgt), 0.02, eta_max)
                )

        global_r_dict["safety_intervention_rate"] = intervention_rate
        global_r_dict["applied_cav_actions"] = dict(applied)
        global_r_dict["collisions"] = next_raw_state.get("collisions", 0)
        global_r_dict["teleports"] = next_raw_state.get("teleports", 0)
        global_r_dict["safety_incidents"] = next_raw_state.get(
            "safety_incidents",
            int(global_r_dict["collisions"]) + int(global_r_dict["teleports"]),
        )
        self.last_r_dict = global_r_dict
        self.raw_state = next_raw_state
        # Mark pending teacher refresh on interval/event; consume only in
        # _get_obs when the current step is a true multi-legal decision.
        if self._signal_vision is not None:
            try:
                sim_t = float(
                    (next_raw_state.get("stats") or {}).get(
                        "time", getattr(self.sumo_env, "_sim_time", 0.0)
                    )
                    or 0.0
                )
                if "junction_name" not in next_raw_state:
                    next_raw_state = dict(next_raw_state)
                    next_raw_state["junction_name"] = getattr(
                        self, "scenario_key", None
                    )
                    self.raw_state = next_raw_state
                self._signal_vision.tick(
                    sim_t,
                    next_raw_state,
                    action_mask=next_raw_state.get("action_mask"),
                    ep=int(ep),
                    step=int(step_num),
                    training_stage=str(getattr(self, "_training_stage", "S")),
                    stage_episode=int(getattr(self, "_stage_episode", 0) or 0),
                )
            except Exception as exc:
                print(f"[SignalVision] tick skipped: {exc}", flush=True)
        obs = self._p1_obs(step_num)
        self._last_obs_ids = frozenset(
            k for k in obs.keys() if k != "__graph__"
        )

        env_done_bool = bool(env_done)
        done_reason = str(env_info.get("done_reason", "") or "")
        if env_done_bool and not done_reason:
            done_reason = getattr(self.sumo_env, "_done_reason", "") or "unknown"

        # Only penalize pathological early stops (gridlock). Normal horizon /
        # traffic_exhausted must not get -10 (hardcoded 2250 broke --quick).
        if env_done_bool and done_reason == "gridlock":
            global_reward = -10.0
            for aid in list(agent_rewards.keys()):
                agent_rewards[aid] = -10.0

        self.episode_steps += 1
        lon_by_vid = {}
        lat_by_vid = {}
        for aid, rew in agent_rewards.items():
            rew_f = float(rew)
            if aid.startswith("cav_lon_"):
                vid = aid[len("cav_lon_") :]
                lon_by_vid[vid] = rew_f
                self.episode_reward_cav_lon_total += rew_f
                self.step_cav_lon_count += 1
                self.cav_return_sums[aid] = self.cav_return_sums.get(aid, 0.0) + rew_f
            elif aid.startswith("cav_lat_"):
                vid = aid[len("cav_lat_") :]
                lat_by_vid[vid] = rew_f
                self.cav_return_sums[aid] = self.cav_return_sums.get(aid, 0.0) + rew_f
                # Lat TB mean: only DLC-eligible decision samples (not keep-forced zeros).
                meta = (self._lat_meta or {}).get(vid) or {}
                if bool(meta.get("dlc_eligible", False)):
                    self.episode_reward_cav_lat_total += rew_f
                    self.step_cav_lat_count += 1
            elif aid.startswith("cav_"):
                vid = aid[4:]
                lon_by_vid[vid] = rew_f
                self.episode_reward_cav_lon_total += rew_f
                self.step_cav_lon_count += 1
                self.cav_return_sums[aid] = self.cav_return_sums.get(aid, 0.0) + rew_f
            elif aid.startswith("signal_"):
                self.episode_reward_signal += rew_f
                self._ep_signal_sumsq += rew_f * rew_f
                self._ep_signal_count += 1
                self.episode_reward_sig_formal_total += float(
                    global_r_dict.get("sig_formal", rew_f)
                )
                _sig_res = float(global_r_dict.get("sig_residual", 0.0) or 0.0)
                self.episode_reward_sig_residual_total += _sig_res
                if abs(_sig_res) > 1e-12:
                    self._ep_sig_residual_nonzero += 1
                self._ep_sig_waiting_increment_sum += float(
                    global_r_dict.get("sig_waiting_increment", rew_f)
                )
                self._ep_sig_speed_term_sum += float(
                    global_r_dict.get("sig_speed_term", 0.0)
                )
                self._ep_sig_waiting_seconds += float(
                    global_r_dict.get("sig_waiting_seconds", 0.0)
                )
                self._ep_sig_vehicle_time_exposure += float(
                    global_r_dict.get("sig_vehicle_time_exposure", 0.0)
                )

        # Lon residual / exposure episode diagnostics (steps with lon comps only).
        if "lon_residual" in global_r_dict or "lon_formal" in global_r_dict:
            self._ep_lon_step_n = int(getattr(self, "_ep_lon_step_n", 0)) + 1
            _lon_res = float(global_r_dict.get("lon_residual", 0.0) or 0.0)
            self._ep_lon_res_sum = float(getattr(self, "_ep_lon_res_sum", 0.0)) + _lon_res
            if abs(_lon_res) > 1e-12:
                self._ep_lon_res_nz = int(getattr(self, "_ep_lon_res_nz", 0)) + 1
            self._ep_lon_exposed_sum = float(
                getattr(self, "_ep_lon_exposed_sum", 0.0)
            ) + float(global_r_dict.get("lon_exposed_frac", 0.0) or 0.0)

        # CAV_Mean_Reward: one sample per actively controlled vehicle per step =
        # r_lon + r_lat (missing head → 0), matching team mean_cav. Exclude
        # non-DLC lat-only followers so zeros do not dilute Stage-Lat / JointAll.
        eligible_lat_vids = {
            vid
            for vid in lat_by_vid
            if bool(((self._lat_meta or {}).get(vid) or {}).get("dlc_eligible", False))
        }
        for vid in set(lon_by_vid) | eligible_lat_vids:
            combined = float(lon_by_vid.get(vid, 0.0)) + float(lat_by_vid.get(vid, 0.0))
            self.episode_reward_cav_total += combined
            self._ep_cav_sumsq += combined * combined
            self.step_cav_count += 1

        (
            episode_total_reward,
            mean_cav,
            mean_signal,
            std_cav,
            std_signal,
            beta_used,
            mean_cav_lon,
            mean_cav_lat,
            mean_sig_formal,
            mean_sig_residual,
        ) = self._episode_reward_parts()

        dones = {}
        infos = {}
        for agent_id in actions:
            left = agent_id.startswith("cav_") and agent_id not in obs
            dones[agent_id] = bool(env_done_bool or left)
            vid = None
            if agent_id.startswith("cav_lon_"):
                vid = agent_id[len("cav_lon_") :]
            elif agent_id.startswith("cav_lat_"):
                vid = agent_id[len("cav_lat_") :]
            elif agent_id.startswith("cav_"):
                vid = agent_id[4:]
            vinfo = (next_raw_state.get("cavs") or {}).get(vid, {}) if vid else {}
            infos[agent_id] = {
                "collisions": next_raw_state.get("collisions", 0),
                "global_reward": global_reward,
                "individual_reward": agent_rewards.get(agent_id, 0.0),
                "safety_intervention_rate": intervention_rate,
                "triggered_escape": bool(vinfo.get("triggered_escape")),
            }
        dones["__all__"] = env_done_bool

        stats = next_raw_state.get("stats", {})
        self.ep_fuel += float(stats.get("step_fuel_mg", stats.get("step_fuel", 0.0)))
        self.ep_co2 += float(stats.get("step_co2_mg", stats.get("step_co2", 0.0)))
        speed_i = float(stats.get("average_speed", stats.get("network_avg_speed", 0.0)))
        queue_i = float(stats.get("queue_length", stats.get("step_waiting_vehicles", 0.0)))
        net_wait_i = float(stats.get("network_avg_waiting_time", 0.0))
        self._ep_speed_sum += speed_i
        self._ep_queue_sum += queue_i
        self._ep_net_wait_sum = float(getattr(self, "_ep_net_wait_sum", 0.0)) + net_wait_i
        self._ep_kpi_n += 1
        # Observe-only red-gap sampling (no reward / control side effects).
        if int(self.episode_steps) % max(1, int(RED_GAP_SAMPLE_EVERY)) == 0:
            accumulate_red_gap(self._ep_red_gap_acc, next_raw_state)
        self.ep_conflicts += int(stats.get("danger_event_number", 0))
        self.ep_arrived += int(stats.get("arrived_vehicles", 0))
        self.ep_stops = int(stats.get("num_stops", 0))
        self.ep_avg_travel_time = float(stats.get("avg_travel_time", 0.0))
        self.ep_avg_waiting_time = float(stats.get("avg_waiting_time", 0.0))
        self.ep_completed_trips = int(stats.get("completed_trips", 0))

        avg_speed = (
            float(self._ep_speed_sum / self._ep_kpi_n) if self._ep_kpi_n else 0.0
        )
        avg_waiting = float(self.ep_avg_waiting_time)
        avg_queue_length = (
            float(self._ep_queue_sum / self._ep_kpi_n) if self._ep_kpi_n else 0.0
        )
        avg_net_waiting = (
            float(self._ep_net_wait_sum / self._ep_kpi_n) if self._ep_kpi_n else 0.0
        )

        infos["__all__"] = {
            "global_reward": global_reward,
            "episode_total_reward": float(episode_total_reward),
            "meta_reward": float(meta_reward),
            "avg_travel_time": self.ep_avg_travel_time,
            # v4 KPIs (prefer these in papers): censoring- and insertion-aware
            # travel time, insertion backlog and number of OD rewrites.
            "uncensored_avg_travel_time": float(stats.get("uncensored_avg_travel_time", 0.0)),
            "avg_time_in_system": float(stats.get("avg_time_in_system", 0.0)),
            "insertion_backlog": float(stats.get("insertion_backlog", 0.0)),
            "od_rewrites": float(stats.get("od_rewrites", 0.0)),
            # v5.2.4 observe-only diagnostics (junction-box standstill, Lon no-ops).
            **{k: float(stats.get(k, 0.0)) for k in V524_KPI_KEYS},
            **{k: float(stats.get(k, 0.0)) for k in V6_AUTH_KPI_KEYS},
            # v5.2.4: per-step CAVs whose sampled Lon action was not executed.
            "lon_noop_vids": list(env_info.get("lon_noop_vids") or ()),
            "signal_exec": self._pop_signal_exec(),
            "avg_speed": avg_speed,
            "avg_waiting_time": avg_waiting,
            "avg_queue_length": avg_queue_length,
            "num_stops": self.ep_stops,
            "num_conflicts": self.ep_conflicts,
            "fleet_avg_fuel": float(stats.get("fleet_avg_fuel", 0.0)),
            "fleet_avg_co2": float(stats.get("fleet_avg_co2", 0.0)),
            "avg_fuel": float(stats.get("fleet_avg_fuel", 0.0)),
            "avg_co2": float(stats.get("fleet_avg_co2", 0.0)),
            # Episode emission totals / per-vehicle means (must reach train_RL logs).
            "total_fuel_L": float(stats.get("total_fuel_L", 0.0)),
            "total_co2_g": float(stats.get("total_co2_g", 0.0)),
            "veh_avg_fuel_L": float(stats.get("veh_avg_fuel_L", 0.0)),
            "veh_avg_co2_g": float(stats.get("veh_avg_co2_g", 0.0)),
            "emission_vehicle_count": int(stats.get("emission_vehicle_count", 0)),
            "completed_trips": self.ep_completed_trips,
            "network_avg_speed": avg_speed,
            "network_avg_waiting_time": avg_net_waiting,
            "arrived_vehicles": self.ep_arrived,
            "reward_components": {
                "safe": float(global_r_dict.get("safe", 0.0)),
                "eff": float(global_r_dict.get("eff", 0.0)),
                "comfort": float(global_r_dict.get("comfort", 0.0)),
                "platoon": float(global_r_dict.get("platoon", 0.0)),
                "lat": float(global_r_dict.get("lat", 0.0)),
                "long": float(global_r_dict.get("long", 0.0)),
                "coop": 0.0,
                "sig_waiting_increment": float(
                    global_r_dict.get("sig_waiting_increment", 0.0)
                ),
                "sig_waiting_seconds": float(
                    global_r_dict.get("sig_waiting_seconds", 0.0)
                ),
                "sig_vehicle_time_exposure": float(
                    global_r_dict.get("sig_vehicle_time_exposure", 0.0)
                ),
            },
            "coop_terms": np.zeros(2, dtype=np.float32),
            "lambda_flow": 0.0,
            "lambda_plat": 0.0,
            "collisions": next_raw_state.get("collisions", 0),
            "teleports": next_raw_state.get("teleports", 0),
            "safety_incidents": next_raw_state.get(
                "safety_incidents",
                int(next_raw_state.get("collisions", 0) or 0)
                + int(next_raw_state.get("teleports", 0) or 0),
            ),
            "done_reason": done_reason if env_done_bool else "",
            "safety_intervention_rate": intervention_rate,
            "episode_reward_signal": self.episode_reward_signal,
            "episode_reward_cav_mean": mean_cav,
            "episode_reward_cav_lon_mean": mean_cav_lon,
            "episode_reward_cav_lat_mean": mean_cav_lat,
            "episode_reward_signal_mean": mean_signal,
            "episode_reward_signal_formal_mean": mean_sig_formal,
            "episode_reward_signal_residual_mean": mean_sig_residual,
            "episode_reward_signal_residual_nonzero_frac": (
                float(self._ep_sig_residual_nonzero)
                / float(max(1, self._ep_signal_count))
            ),
            "episode_spill_proxy_mean": (
                float(self._ep_spill_proxy_sum)
                / float(max(1, self._ep_spill_proxy_n))
            ),
            "episode_lon_residual_mean": (
                float(getattr(self, "_ep_lon_res_sum", 0.0))
                / float(max(1, int(getattr(self, "_ep_lon_step_n", 0))))
            ),
            "episode_lon_residual_nonzero_frac": (
                float(getattr(self, "_ep_lon_res_nz", 0))
                / float(max(1, int(getattr(self, "_ep_lon_step_n", 0))))
            ),
            "episode_lon_exposed_frac": (
                float(getattr(self, "_ep_lon_exposed_sum", 0.0))
                / float(max(1, int(getattr(self, "_ep_lon_step_n", 0))))
            ),
            # Per-agent formal Lon rewards for GAE peer baseline (excludes residual).
            "lon_formal_by_agent": dict(
                global_r_dict.get("lon_formal_by_agent") or {}
            ),
            "terminal_incident_agents": list(
                global_r_dict.get("terminal_incident_agents") or ()
            ),
            "eta_shield": float(getattr(self, "eta_shield", 0.05)),
            "episode_reward_cav_std": std_cav,
            "episode_reward_signal_std": std_signal,
            "episode_reward_beta": beta_used,
            "episode_steps": int(self.episode_steps),
            "signal_waiting_increment_mean": (
                float(self._ep_sig_waiting_increment_sum)
                / float(max(1, self._ep_signal_count))
            ),
            "signal_speed_term_mean": (
                float(self._ep_sig_speed_term_sum)
                / float(max(1, self._ep_signal_count))
            ),
            "signal_waiting_seconds": float(self._ep_sig_waiting_seconds),
            "signal_vehicle_time_exposure": float(self._ep_sig_vehicle_time_exposure),
            "vlm_fatal_error": (
                getattr(self.reward_fn, "_vlm_fatal_error", None)
                or getattr(getattr(self, "_signal_vision", None), "_vlm_fatal_error", None)
            ),
            # Observe-only red/slow leader_gap (CAV vs HDV); reward formula unchanged.
            **summarize_red_gap(
                getattr(self, "_ep_red_gap_acc", None) or new_red_gap_accumulator()
            ),
        }
        return obs, agent_rewards, dones, infos

    def apply_co_opt_config(self, cfg=None) -> None:
        """Propagate co_optimization settings across marl_env, sumo_env, and reward_fn."""
        c = dict(cfg or {})
        self.co_opt_config = c
        self.lagrangian_safety_enabled = bool(c.get("lagrangian_safety_enabled", True))
        if not hasattr(self, "eta_shield") or not self.lagrangian_safety_enabled:
            self.eta_shield = float(c.get("lagrangian_safety_init", 0.05))
        self.lagrangian_safety_lr = float(c.get("lagrangian_safety_lr", 0.02))
        self.lagrangian_safety_max = float(c.get("lagrangian_safety_max", 0.50))
        self.lagrangian_penalty_mode = str(c.get("lagrangian_penalty_mode", "indicator") or "indicator")
        self.target_intervention_rate = float(c.get("target_intervention_rate", 0.05))
        self.goal_speed_conditioning = bool(c.get("goal_speed_conditioning", True))
        self.cacc_soft_platoon_enabled = bool(c.get("cacc_soft_platoon_enabled", True))
        self.cacc_full_gap_m = float(c.get("cacc_full_gap_m", 8.0))
        self.cacc_free_gap_m = float(c.get("cacc_free_gap_m", 22.0))
        self.cacc_rl_authority_floor = float(c.get("cacc_rl_authority_floor", 0.25))
        self.cacc_leader_accel_gain = float(c.get("cacc_leader_accel_gain", 0.35))
        if getattr(self, "reward_fn", None) is not None:
            self.reward_fn.crash_attribution_enabled = bool(
                c.get("crash_attribution_enabled", True)
            )
            self.reward_fn.crash_terminal_penalty = float(
                c.get("crash_terminal_penalty", -1.0)
            )
        if getattr(self, "sumo_env", None) is not None and hasattr(
            self.sumo_env, "configure_control"
        ):
            self.sumo_env.configure_control(
                green_glide_decouple=bool(c.get("green_glide_decouple_enabled", True)),
                in_memory_follower_lookup=bool(c.get("in_memory_follower_lookup", True)),
                cacc_soft_platoon=self.cacc_soft_platoon_enabled,
                cacc_full_gap_m=self.cacc_full_gap_m,
                cacc_free_gap_m=self.cacc_free_gap_m,
                cacc_rl_authority_floor=self.cacc_rl_authority_floor,
                cacc_leader_accel_gain=self.cacc_leader_accel_gain,
            )

    @staticmethod
    def _signal_code(state):
        state = str(state or "").lower()
        if state == "g":
            return 1.0
        if state == "r":
            return -1.0
        if state == "y":
            return -0.5
        return 0.0

    def _pop_signal_exec(self):
        """v5 (1.1): {tls_id: [requested, executed]} for this step, then clear."""
        log = getattr(self.sumo_env, "_signal_exec_log", None) or {}
        out = {}
        for k, v in dict(log).items():
            try:
                out[str(k)] = [int(v[0]), int(v[1])]
            except (TypeError, ValueError, IndexError):
                continue
        try:
            self.sumo_env._signal_exec_log = {}
        except Exception:
            pass
        return out

    def _phase_feature(self, sinfo):
        n = max(int(_finite_float(sinfo.get("n_green", 1), 1.0)), 1)
        idx = _finite_float(sinfo.get("green_index", 0), 0.0)
        return float(np.clip(idx / float(n), 0.0, 1.0))

    def _build_graph(self):
        """Build a bounded, bidirectional k-nearest-neighbour traffic graph.

        Every node receives edges, including vehicles beyond the first 32 nodes.
        Node feature width and the public graph schema remain unchanged.
        """
        node_features = []
        node_positions = []
        ox, oy = self._graph_origin
        vehicles = []
        for vid, vinfo in (self.raw_state.get("cavs") or {}).items():
            vehicles.append((vid, vinfo, 1.0))
        for vid, vinfo in (self.raw_state.get("hdvs") or {}).items():
            if vinfo.get("in_platoon_zone") or vinfo.get("in_control_zone"):
                vehicles.append((vid, vinfo, 0.0))

        for _, vinfo, is_cav in vehicles:
            pos = vinfo.get("position", (ox, oy))
            try:
                x = _finite_float(pos[0], ox)
                y = _finite_float(pos[1], oy)
            except (TypeError, IndexError, KeyError):
                x, y = ox, oy
            nx = (x - ox) / 500.0
            ny = (y - oy) / 500.0
            speed = _finite_float(vinfo.get("speed", 0.0), 0.0)
            acceleration = _finite_float(vinfo.get("acceleration", 0.0), 0.0)
            dist = _finite_float(vinfo.get("dist_to_stopline", 0.0), 0.0)
            leader_gap = _finite_float(vinfo.get("leader_gap", 100.0), 100.0)
            ttc_raw = vinfo.get("ttc")
            ttc = 10.0 if ttc_raw is None else _finite_float(ttc_raw, 10.0)
            wait_t = _finite_float(vinfo.get("waiting_time", 0.0), 0.0)
            node_features.append(
                [
                    nx,
                    ny,
                    float(np.clip(speed / max(self.MAX_SPEED, 1e-3), 0.0, 1.5)),
                    float(np.clip(acceleration / 5.0, -1.0, 1.0)),
                    float(np.clip(dist / 700.0, 0.0, 2.0)),
                    self._signal_code(vinfo.get("tls_state", "n")),
                    float(is_cav),
                    1.0 if vinfo.get("is_leader") else 0.0,
                    float(np.clip(leader_gap / 100.0, 0.0, 5.0)),
                    # Was raw TTC; recycle as normalized accum wait for critic.
                    float(np.clip(wait_t / 105.0, 0.0, 2.0)),
                ]
            )
            node_positions.append((nx, ny))

        # Peak starve across approaches for signal-node hunger feature.
        stats = self.raw_state.get("stats") or {}
        max_starve = 0.0
        for d in self.SIGNAL_QUEUE_DIRS:
            max_starve = max(
                max_starve, _finite_float(stats.get(f"max_wait_{d}", 0.0), 0.0)
            )
        for _, sinfo in (self.raw_state.get("signals") or {}).items():
            elapsed = _finite_float(sinfo.get("elapsed_time", 0.0), 0.0)
            target_t = max(
                _finite_float(sinfo.get("planned_green", sinfo.get("target_T", 30.0)), 30.0),
                1.0,
            )
            node_features.append(
                [
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    float(np.clip(elapsed / target_t, 0.0, 2.0)),
                    float(np.clip(max_starve / 105.0, 0.0, 2.0)),
                    -1.0,  # Distinct node-type tag for TLS (vehicles use 0.0=HDV, 1.0=CAV)
                    0.0,
                    1.0,   # Neutral gap (avoids 0m crash collision alias)
                    1.0,   # Neutral TTC (avoids 0s crash collision alias)
                ]
            )
            node_positions.append((0.0, 0.0))

        n = len(node_features)
        if n == 0:
            node_features = [[0.0] * self.GRAPH_NODE_DIM]
            node_positions = [(0.0, 0.0)]
            n = 1

        # Sparse graph: each node connects to up to 8 nearest nodes, with
        # undirected links represented as two directed edges for GNN compatibility.
        edge_set = set()
        if n > 1:
            positions = np.asarray(node_positions, dtype=np.float64)
            max_neighbors = min(8, n - 1)
            for i in range(n):
                delta = positions - positions[i]
                distances_sq = np.einsum("ij,ij->i", delta, delta)
                distances_sq[i] = np.inf
                neighbors = np.argsort(distances_sq, kind="stable")[:max_neighbors]
                for j in neighbors.tolist():
                    if i == j:
                        continue
                    edge_set.add((i, j))
                    edge_set.add((j, i))

        if edge_set:
            edges = sorted(edge_set)
            edge_src = [src for src, _ in edges]
            edge_dst = [dst for _, dst in edges]
        else:
            # Keep a valid [2, E] edge_index even for a one-node graph.
            edge_src, edge_dst = [0], [0]

        features = np.asarray(node_features, dtype=np.float32)
        features = np.nan_to_num(features, nan=0.0, posinf=2.5, neginf=-2.5)
        return {
            "node_features": features,
            "edge_index": np.asarray([edge_src, edge_dst], dtype=np.int64),
        }

    def _p1_obs(self, step_num):
        """Reuse the last observation between CAV decisions when P1 asks for it.

        Rewards are still computed every sim step. Only the graph and agent
        vectors, which the policy holds constant, are cached.
        """
        from environment.p1_control import _on, decision_step

        hold = 1
        try:
            hold = max(1, int(os.environ.get("P1_OBS_HOLD_STEPS", "1") or 1))
        except (TypeError, ValueError):
            hold = 1
        cached = getattr(self, "_p1_obs_cache", None)
        if _on("P1_OBS_ON_DECISION") and cached is not None and not decision_step(step_num, hold):
            return cached
        obs = self._get_obs()
        self._p1_obs_cache = obs
        return obs

    def _get_obs(self):
        obs = {}
        if self.raw_state is None:
            return obs
        graph = self._build_graph()
        long_w = list(getattr(self.reward_fn, "macro_weights", DEFAULT_LONG_WEIGHTS)[:4])
        if len(long_w) < 4:
            long_w = [float(x) for x in list(DEFAULT_LONG_WEIGHTS[:4])]
        s = float(sum(long_w))
        if s <= 1e-8:
            long_w = [float(x) for x in list(DEFAULT_LONG_WEIGHTS[:4])]
        else:
            long_w = [float(x) / s for x in long_w]
        lat_w = list(getattr(self.reward_fn.lateral, "weights", DEFAULT_LAT_WEIGHTS))
        self._lat_meta = {}

        # Stage × enable_*: S skips CAV obs; Lon/JointLonSig skip lateral;
        # Lat/JointAll build both (joint stages must not drop CAV heads).
        from agents.mappo import MAPPOAgent

        stage = str(getattr(self, "_training_stage", "S") or "S")
        env_stage = MAPPOAgent.cav_env_stage(stage)
        build_lon = bool(self.enable_longitudinal) and env_stage in ("Lon", "Lat")
        build_lat = bool(self.enable_lateral) and env_stage == "Lat"

        peers_snapshot = None
        if build_lat:
            peers_snapshot = {}
            for group in ("cavs", "hdvs"):
                for oid, o in (self.raw_state.get(group) or {}).items():
                    peers_snapshot[oid] = dict(o)
                    peers_snapshot[oid]["_id"] = oid

        # Match SUMO_interface._cav_action_applies:
        # - leaders-only (default): Lon for DBSCAN/solo leaders in corridor
        # - all-CAV: Lon for every corridor CAV; DBSCAN labels are observational
        # Lat: formation-zone RL_DLC CAVs (unchanged; already not leaders-only).
        sumo = getattr(self, "sumo_env", None)
        leaders_only = bool(
            getattr(sumo, "CAV_CONTROL_LEADERS_ONLY", False) if sumo is not None else False
        )

        for vid, vinfo in (self.raw_state.get("cavs") or {}).items():
            prev_a = float(self._prev_accel.get(vid, vinfo.get("acceleration", 0.0)))
            self._prev_accel[vid] = _finite_float(vinfo.get("acceleration", 0.0), 0.0)
            if build_lon:
                if not lon_rl_eligible(vinfo, require_leader=bool(leaders_only)):
                    pass
                else:
                    vlm_d = 0.0
                    try:
                        sem = getattr(self.reward_fn, "_vlm_lon_semantic", None) or {}
                        # v6-P0 fix (VECTOR_VLM_OBS_SCALE_FIX=1, set by --profile v6p0):
                        # obs normalises by 0.05 (= VLM_CAV_RESIDUAL_SCALE) but the
                        # feature was built with 0.02, so it never exceeded 0.4.
                        _vlm_scale = 0.05 if str(
                            os.environ.get("VECTOR_VLM_OBS_SCALE_FIX", "0")
                        ).strip().lower() in ("1", "true", "yes", "on") else 0.02
                        vlm_d = float(sem.get("residual_risk", 0.0) or 0.0) * _vlm_scale
                    except (TypeError, ValueError, AttributeError):
                        vlm_d = 0.0
                    lon = build_longitudinal_obs(
                        vid,
                        vinfo,
                        self.raw_state,
                        long_w,
                        prev_accel=prev_a,
                        dt=self.dt,
                        a_idm=vinfo.get("a_idm"),
                        vlm_lon_delta=vlm_d,
                        action_blend_beta=float(
                            getattr(self, "_action_blend_beta", 1.0) or 1.0
                        ),
                        goal_speed_conditioning=bool(
                            getattr(self, "goal_speed_conditioning", True)
                        ),
                    )
                    _app_edges = vinfo.get("approach_edges") or ()
                    _app_key = (
                        str(_app_edges[0])
                        if _app_edges
                        else str(vinfo.get("edge", "") or "")
                    )
                    _lon_auth = compute_lon_rl_authority(
                        vinfo.get("leader_gap", 100.0),
                        has_leader=bool(vinfo.get("leader_id") is not None),
                        enabled=bool(getattr(self, "cacc_soft_platoon_enabled", True)),
                        full_gap_m=float(getattr(self, "cacc_full_gap_m", 8.0)),
                        free_gap_m=float(getattr(self, "cacc_free_gap_m", 22.0)),
                        min_authority=float(getattr(self, "cacc_rl_authority_floor", 0.25)),
                    )
                    obs[f"cav_lon_{vid}"] = {
                        "vector": lon["vector"],
                        "graph": graph,
                        "approach_key": _app_key,
                        "lon_authority": float(_lon_auth),
                    }
            if build_lat:
                # Lat RL: all platoon-zone CAVs that pass RL_DLC (not leaders-only).
                # Soft-platoon form reward applies to every eligible Lat agent.
                lat = build_lateral_obs(
                    vid,
                    vinfo,
                    self.raw_state,
                    lat_w,
                    prev_accel=prev_a,
                    dt=self.dt,
                    peers=peers_snapshot,
                )
                self._lat_meta[vid] = lat.get("meta", {})
                # DoF gate: only RL_DLC (multi-lane legal through) joins Lat RL.
                try:
                    _n = max(int(vinfo.get("n_lanes", 1) or 1), 1)
                    _mode, _ = lat_dof_mode(vinfo, _n)
                except Exception:
                    _mode = "LOCKED_0DOF"
                # Only formation-zone RL_DLC samples train the lat head.
                # Control/elsewhere keep-only would otherwise flood the buffer.
                _in_form = str(vinfo.get("zone_type") or "") == ZONE_PLATOON
                _dlc_ok = bool(_mode == "RL_DLC") and _in_form
                self._lat_meta[vid]["dof_mode"] = str(_mode)
                self._lat_meta[vid]["dlc_eligible"] = _dlc_ok
                _lat_app_edges = vinfo.get("approach_edges") or ()
                _lat_app_key = (
                    str(_lat_app_edges[0])
                    if _lat_app_edges
                    else str(vinfo.get("edge", "") or "")
                )
                obs[f"cav_lat_{vid}"] = {
                    "vector": lat["vector"],
                    "graph": graph,
                    "action_mask": lat["action_mask"],
                    "dlc_eligible": _dlc_ok,
                    "dof_mode": str(_mode),
                    "approach_key": _lat_app_key,
                }

        stats = self.raw_state.get("stats", {})
        g_max = 60.0
        # Per-decision-green features (≤5 × 4 = 20) replace N/S/E/W/FZ aggregates.
        n_phase_slots = 5
        phase_feats = []
        phase_queues = stats.get("phase_queue_lengths_m") or stats.get("phase_queues_m") or []
        phase_waits = stats.get("phase_max_waits_s") or stats.get("phase_avg_waits_s") or []
        phase_vehs = stats.get("phase_near_counts") or []
        has_phase_queues = isinstance(phase_queues, (list, tuple)) and len(phase_queues) > 0
        served = set()
        try:
            cyc = getattr(getattr(self, "sumo_env", None), "_cycle_served", None) or {}
            for _tls, sset in cyc.items():
                served |= {int(x) for x in (sset or set())}
        except Exception:
            served = set()
        for p in range(n_phase_slots):
            lq = 0.0
            if isinstance(phase_queues, (list, tuple)) and p < len(phase_queues):
                lq = _finite_float(phase_queues[p], 0.0)
            n_near = 0.0
            if isinstance(phase_vehs, (list, tuple)) and p < len(phase_vehs):
                n_near = _finite_float(phase_vehs[p], 0.0)
            wmax = 0.0
            if isinstance(phase_waits, (list, tuple)) and p < len(phase_waits):
                wmax = _finite_float(phase_waits[p], 0.0)
            if (not has_phase_queues) and p < len(self.SIGNAL_QUEUE_DIRS):
                d = self.SIGNAL_QUEUE_DIRS[p]
                lq = _finite_float(stats.get(f"queue_{d}", 0), 0.0)
                n_near = _finite_float(stats.get(f"veh_count_{d}", 0), 0.0)
                wmax = _finite_float(stats.get(f"max_wait_{d}", 0), 0.0)
            phase_feats.extend(
                [
                    float(np.clip(lq / 150.0, 0.0, 2.5)),
                    float(np.clip(n_near / 20.0, 0.0, 2.5)),
                    float(np.clip(wmax / 120.0, 0.0, 2.0)),
                    1.0 if p in served else 0.0,
                ]
            )
        vision4 = self._signal_vision_feature_vector()
        for sig_id, sinfo in (self.raw_state.get("signals") or {}).items():
            g_idx = int(_finite_float(sinfo.get("green_index", 0), 0.0))
            one_hot = [0.0] * self.SIGNAL_PHASE_FEATURE_DIM
            if 0 <= g_idx < self.SIGNAL_PHASE_FEATURE_DIM:
                one_hot[g_idx] = 1.0
            if sum(one_hot) <= 0.0:
                one_hot[0] = float(self._phase_feature(sinfo))
            vector = np.asarray(
                [
                    *one_hot,
                    np.clip(_finite_float(sinfo.get("committed_gmin_remaining", sinfo.get("elapsed_time", 0.0)), 0.0) / g_max, 0.0, 1.5),
                    np.clip(_finite_float(sinfo.get("p1_planned_T", sinfo.get("remaining_time", 0.0)), 0.0) / g_max, 0.0, 1.5),
                    *phase_feats,
                    *vision4,
                ],
                dtype=np.float32,
            )
            expected = int(self.SIGNAL_OBS_DIM)
            if int(vector.shape[0]) != expected:
                raise RuntimeError(
                    f"signal obs length {vector.shape[0]} != expected {expected} "
                    f"(vision={bool(getattr(self, 'signal_vlm_vision_enabled', False))})"
                )
            action_masks = self.raw_state.get("action_masks")
            if not isinstance(action_masks, Mapping):
                action_masks = {}
            raw_mask = action_masks.get(sig_id)
            if raw_mask is None:
                raw_mask = self.raw_state.get("action_mask")
            if raw_mask is None:
                signal_mask = np.ones(self.MAX_SIGNAL_ACTIONS, dtype=np.float32)
            else:
                try:
                    source_mask = np.asarray(raw_mask, dtype=np.float32).reshape(-1)
                except (TypeError, ValueError):
                    source_mask = np.ones(self.MAX_SIGNAL_ACTIONS, dtype=np.float32)
                if source_mask.size == 0 or not np.all(np.isfinite(source_mask)):
                    source_mask = np.ones(self.MAX_SIGNAL_ACTIONS, dtype=np.float32)
                signal_mask = np.zeros(self.MAX_SIGNAL_ACTIONS, dtype=np.float32)
                n_copy = min(self.MAX_SIGNAL_ACTIONS, int(source_mask.size))
                signal_mask[:n_copy] = (source_mask[:n_copy] > 0.0).astype(np.float32)
                if not np.any(signal_mask):
                    # Never pass an all-zero categorical mask to MAPPO. Keep the
                    # current phase as the only safe fallback action.
                    current_phase = int(_finite_float(sinfo.get("green_index", 0), 0.0))
                    current_phase = min(max(current_phase, 0), self.MAX_SIGNAL_ACTIONS - 1)
                    signal_mask[current_phase] = 1.0

            teacher_action = -1
            teacher_confidence = 0.0
            teacher_severity = 0.0
            n_green = int(sinfo.get("n_green", 1) or 1)
            n_green = max(1, min(n_green, int(signal_mask.size)))
            legal_phases = [
                i for i in range(n_green) if float(signal_mask[i]) > 0.0
            ]
            scheduler = getattr(self, "_signal_vision", None)
            vision_on = bool(getattr(self, "signal_vlm_vision_enabled", False))
            rule_on = bool(getattr(self, "rule_signal_teacher_enabled", False))
            stage_ok = str(getattr(self, "_training_stage", "S")) == "S"
            stage_ep = int(getattr(self, "_stage_episode", 0) or 0)
            # Align with VLM.signal_vision.SIGNAL_TEACHER_SOFT_START_EPISODES (default 5).
            # Do not use ``x or 5``: explicit 0 (diagnostic soft-start off) must stay 0.
            soft_start_eps = 5
            if scheduler is not None:
                try:
                    soft_start_eps = max(
                        0, int(getattr(scheduler, "_soft_start_episodes", 5))
                    )
                except (TypeError, ValueError, OverflowError):
                    soft_start_eps = 5
            if (
                vision_on
                and stage_ok
                and stage_ep >= soft_start_eps
                and scheduler is not None
                and hasattr(scheduler, "consume_teacher_if_ready")
                and bool(getattr(scheduler, "pending_teacher_trigger", lambda: False)())
                and len(legal_phases) >= 2
            ):
                try:
                    sim_t = float(
                        (stats or {}).get(
                            "time", getattr(self.sumo_env, "_sim_time", 0.0)
                        )
                        or 0.0
                    )
                except (TypeError, ValueError, OverflowError):
                    sim_t = 0.0
                advice = scheduler.consume_teacher_if_ready(
                    self.raw_state if isinstance(self.raw_state, Mapping) else {},
                    legal_phases,
                    tls_id=str(sig_id),
                    sim_time=sim_t,
                ) or {}
                try:
                    teacher_action = int(advice.get("recommended_phase", -1))
                except (TypeError, ValueError, OverflowError):
                    teacher_action = -1
                try:
                    teacher_confidence = float(advice.get("confidence", 0.0) or 0.0)
                except (TypeError, ValueError, OverflowError):
                    teacher_confidence = 0.0
                conf_thr = float(getattr(scheduler, "_conf_threshold", 0.60) or 0.60)
                cycle_now = f"{sig_id}:{int(sinfo.get('phase', -1))}"
                same_cycle = str(advice.get("green_cycle") or "") == cycle_now and cycle_now.endswith(str(int(sinfo.get('phase', -1))))
                phase_known = 0 <= int(teacher_action) < n_green
                if (
                    (teacher_action not in legal_phases and not (same_cycle and phase_known))
                    or teacher_confidence < 0.0
                    or teacher_confidence > 1.0
                    or float(advice.get("valid", 0.0) or 0.0) < 0.5
                    or teacher_confidence < conf_thr
                ):
                    teacher_action = -1
                    teacher_confidence = 0.0
                else:
                    try:
                        from VLM.signal_vision import teacher_sample_severity

                        spill_now = float(
                            getattr(self, "_last_spill_proxy", 0.0) or 0.0
                        )
                        if spill_now <= 0.0 and isinstance(self.raw_state, Mapping):
                            spill_now = float(
                                self._spill_proxy_for_state(self.raw_state)
                            )
                        teacher_severity = float(
                            teacher_sample_severity(
                                advice.get("visual_event", "none"),
                                spill_proxy=spill_now,
                            )
                        )
                    except Exception:
                        teacher_severity = 0.30
            elif (
                rule_on
                and (not vision_on)
                and stage_ok
                and stage_ep >= soft_start_eps
                and len(legal_phases) >= 2
            ):
                try:
                    from environment.rule_signal_teacher import rule_recommend_phase

                    advice = (
                        rule_recommend_phase(
                            self.raw_state
                            if isinstance(self.raw_state, Mapping)
                            else {},
                            legal_phases,
                            tls_id=str(sig_id),
                        )
                        or {}
                    )
                except Exception:
                    advice = {}
                try:
                    teacher_action = int(advice.get("recommended_phase", -1))
                except (TypeError, ValueError, OverflowError):
                    teacher_action = -1
                try:
                    teacher_confidence = float(advice.get("confidence", 0.0) or 0.0)
                except (TypeError, ValueError, OverflowError):
                    teacher_confidence = 0.0
                if (
                    teacher_action not in legal_phases
                    or teacher_confidence < 0.60
                    or float(advice.get("valid", 0.0) or 0.0) < 0.5
                ):
                    teacher_action = -1
                    teacher_confidence = 0.0
                else:
                    teacher_severity = 0.30

            obs[f"signal_{sig_id}"] = {
                "vector": vector,
                "graph": graph,
                "action_mask": signal_mask,
                "teacher_action": int(teacher_action),
                "teacher_confidence": float(teacher_confidence),
                "teacher_severity": float(teacher_severity),
            }
        # Single shared graph handle for IPC packers / graph_from_obs.
        obs["__graph__"] = graph
        return obs

    def close(self):
        self.sumo_env.close()
