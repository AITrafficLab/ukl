"""Deterministic Stage-S signal teacher for no_vlm / no-signal-vision runs.

Picks the legal green with the largest approach queue (m), breaking ties by
max wait (s). Cheap substitute for VLM signal vision so MAPPO still gets a
CE teacher signal and β schedule during Stage-S.
"""

from __future__ import annotations

from typing import Mapping, Optional, Sequence


def rule_recommend_phase(
    state: Optional[Mapping],
    legal_phases: Sequence[int],
    *,
    tls_id=None,
    conf_floor: float = 0.65,
) -> Optional[dict]:
    """Return teacher advice dict or None when there is no multi-phase choice."""
    del tls_id  # reserved for multi-TLS nets; state already scoped by caller
    try:
        phases = [int(p) for p in (legal_phases or [])]
    except (TypeError, ValueError):
        return None
    phases = sorted({p for p in phases if p >= 0})
    if len(phases) < 2:
        return None

    stats = {}
    if isinstance(state, Mapping):
        raw = state.get("stats")
        if isinstance(raw, Mapping):
            stats = raw

    scored = []
    for ph in phases:
        try:
            q = float(stats.get(f"queue_phase_{ph}", 0.0) or 0.0)
        except (TypeError, ValueError):
            q = 0.0
        try:
            w = float(stats.get(f"max_wait_phase_{ph}", 0.0) or 0.0)
        except (TypeError, ValueError):
            w = 0.0
        if not (q == q):  # NaN
            q = 0.0
        if not (w == w):
            w = 0.0
        scored.append((q, w, -ph, ph))

    scored.sort(reverse=True)
    best_q, best_w, _, best_ph = scored[0]
    second_q = scored[1][0] if len(scored) > 1 else best_q
    # Dominant queue → high confidence; near-tie stays above typical CE threshold.
    if best_q > second_q + 5.0:
        conf = 0.85
    elif best_q > second_q + 1e-6 or best_w > float(scored[1][1] if len(scored) > 1 else 0.0):
        conf = 0.75
    else:
        conf = float(conf_floor)

    return {
        "recommended_phase": int(best_ph),
        "confidence": float(conf),
        "valid": 1.0,
        "visual_event": "rule_queue",
        "reason": "max_queue_then_wait",
        "queue_m": float(best_q),
        "max_wait_s": float(best_w),
    }
