"""Formation vs maintain helpers on top of PlatoonTracker labels."""
from __future__ import annotations

from typing import Any, Dict, Mapping, Optional
import re

import numpy as np

from environment.peer_index import get_peer_index
from environment import gap_policy as _gap_policy


def _finite_float(value: Any, default: float = 0.0) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError):
        return float(default)
    return result if np.isfinite(result) else float(default)

# Gap bands in TraCI net leader_gap coordinates (bumper_gap - minGap, where CAV minGap = 1.0 m).
# Standstill floor 0.15 m net (= 1.15 m bumper gap) and 0.45 s dynamic net headway stay
# safely below native CAV tau = 0.60 s so compact cooperative following scores +1.0.
def safe_gap(v: float) -> float:
    # v6-P0: delegated to environment.gap_policy (legacy mode == v5.2.4 bit-for-bit).
    return _gap_policy.safe_gap(_finite_float(v, 0.0))


def platoon_gap(v: float) -> float:
    return _gap_policy.platoon_gap(_finite_float(v, 0.0))


def platoon_type_code(ego_is_cav: bool, partner_is_cav: Optional[bool]) -> int:
    """0=none, 1=CAV-CAV, 2=CAV-HDV."""
    if partner_is_cav is None:
        return 0
    if ego_is_cav and partner_is_cav:
        return 1
    if ego_is_cav and not partner_is_cav:
        return 2
    return 0


def formation_weight(ptype: int) -> float:
    if ptype == 1:
        return 1.0
    if ptype == 2:
        return 0.8
    return 0.0


def gap_band_reward(d: float, v: float) -> float:
    """R_form / R_p distance term with continuous attraction when d >= dp."""
    ds = safe_gap(v)
    dp = platoon_gap(v)
    d = _finite_float(d, float('inf'))
    if d < ds:
        return -1.0
    if d <= dp:
        return 1.0
    # Attraction band decays +1 → 0. Falling behind 25 m stays 0, not a cliff
    # back up from a negative score.
    if d < 25.0:
        return float(
            max(0.0, 1.0 - (d - dp) / max(25.0 - dp, 1e-3))
        )
    return 0.0


def enrich_formation_state(
    ego: Mapping[str, Any],
    peers: Mapping[str, Mapping[str, Any]],
) -> Dict[str, float]:
    """Build lateral platoon-formation features for one ego vehicle."""
    ego_lane = str(ego.get("lane", "") or "")
    ego_edge = str(ego.get("edge", "") or "")
    raw_ego = ego.get("dist_to_stopline", -1.0)
    ego_d = -1.0 if raw_ego is None else _finite_float(raw_ego, -1.0)
    ego_v = _finite_float(ego.get("speed", 0.0), 0.0)
    ego_lane_idx = _lane_index(ego_lane)

    nearest_cav = 100.0
    nearest_hdv = 100.0
    best_partner: Optional[Mapping[str, Any]] = None
    best_dist = 1e9
    rel_speed = 0.0
    rel_lane = 0.0
    cand_type = 0.0  # 0 HDV, 1 CAV
    # Driver-relative lane offset: + = partner toward driver-left.
    # Raw index delta flips meaning between LHT and RHT.
    try:
        from environment.cav_state_builder import lane_index_sign

        _lane_sign = int(lane_index_sign(ego))
    except Exception:
        _lane_sign = 1

    # v5.2: only same-approach (or edge-less) candidates, in global order.
    _pidx = get_peer_index(peers)
    _cand = () if _pidx is None else _pidx.for_approach(ego_edge)
    for _ci in _cand:
        oid, o = _pidx.items[_ci]
        if oid == ego.get("_id"):
            continue
        raw_o = o.get("dist_to_stopline", -1.0)
        od = -1.0 if raw_o is None else _finite_float(raw_o, -1.0)
        if od < 0.0 or ego_d < 0.0:
            continue
        # Same approach corridor heuristic: same edge prefix or same stop-line side
        o_edge = str(o.get("edge", "") or "")
        if ego_edge and o_edge and not _same_approach(ego_edge, o_edge):
            continue
        gap = abs(od - ego_d)
        is_cav = bool(o.get("is_cav", False))
        if is_cav:
            nearest_cav = min(nearest_cav, gap)
        else:
            nearest_hdv = min(nearest_hdv, gap)
        if gap < best_dist and gap < 80.0:
            best_dist = gap
            best_partner = o
            rel_speed = ego_v - _finite_float(o.get("speed", 0.0), 0.0)
            rel_lane = float(
                (_lane_index(str(o.get("lane", "") or "")) - ego_lane_idx) * _lane_sign
            )
            cand_type = 1.0 if is_cav else 0.0

    in_plat = bool(ego.get("is_in_platoon") or ego.get("cluster_id"))
    cluster = str(ego.get("cluster_id") or "")
    quality = 0.0
    if in_plat and cluster and not cluster.startswith("solo"):
        quality = 1.0
    elif best_partner is not None:
        rd = gap_band_reward(best_dist, ego_v)
        quality = max(0.0, rd)

    # Soft probability of joining: close gap + similar speed + quality
    form_p = 0.0
    if best_partner is not None:
        ds, dp = safe_gap(ego_v), platoon_gap(ego_v)
        gap_term = float(np.clip(1.0 - abs(best_dist - 0.5 * (ds + dp)) / max(dp, 1e-3), 0.0, 1.0))
        spd_term = float(np.clip(1.0 - abs(rel_speed) / 5.0, 0.0, 1.0))
        form_p = 0.5 * gap_term + 0.5 * spd_term

    return {
        "nearest_cav_distance": float(nearest_cav),
        "nearest_hdv_distance": float(nearest_hdv),
        "relative_speed": float(rel_speed),
        "relative_lane": float(rel_lane),
        "candidate_vehicle_type": float(cand_type),
        "platoon_quality": float(quality),
        "formation_probability": float(form_p),
    }


def _lane_index(lane_id: str) -> int:
    if not lane_id or "_" not in lane_id:
        return 0
    try:
        return int(lane_id.rsplit("_", 1)[-1])
    except ValueError:
        return 0


def _same_approach(e1: str, e2: str) -> bool:
    """Compare edge identities while preserving direction.

    SUMO reverse-direction edges commonly begin with ``-``. Removing that
    prefix incorrectly treats opposing traffic as formation partners. Only
    strip known trailing duplicate/extension suffixes.
    """
    e1 = str(e1 or "").strip()
    e2 = str(e2 or "").strip()
    if e1 == e2:
        return True

    def stem(edge: str) -> str:
        value = edge
        while True:
            cleaned = re.sub(r"(?:#\d+|\.ext)$", "", value)
            if cleaned == value:
                return value
            value = cleaned

    return stem(e1) == stem(e2)
