"""Seeded per-episode demand randomization for SUMO trip files.

v3 trained and evaluated every episode on ONE fixed trip file (only the SUMO
seed changed), so the signal policy could memorize the arrival sequence.
This module writes a perturbed copy of the route file per episode:
  * global demand scale  s ~ U[scale_low, scale_high]  (thinning / duplication)
  * departure jitter     depart += U[-jitter_s, +jitter_s], clipped to the
    original demand window
Output is deterministic for a given (base file, seed). Use disjoint seeds for
held-out evaluation demand.
"""
from __future__ import annotations

import copy
import glob
import os
import tempfile
import xml.etree.ElementTree as ET
from typing import Dict, Optional

import numpy as np

_VEHICLE_TAGS = ("trip", "vehicle")


def _is_number(value) -> bool:
    try:
        float(value)
        return True
    except (TypeError, ValueError):
        return False


def read_trip_departs(route_file: Optional[str]) -> Dict[str, float]:
    """Map vehicle id -> scheduled depart time (s) for trip/vehicle elements."""
    out: Dict[str, float] = {}
    if not route_file or not os.path.isfile(route_file):
        return out
    try:
        for _event, el in ET.iterparse(route_file, events=("end",)):
            if el.tag in _VEHICLE_TAGS:
                vid = el.get("id")
                dep = el.get("depart")
                if vid is not None and _is_number(dep):
                    out[str(vid)] = float(dep)
    except ET.ParseError:
        return out
    return out


class DemandRandomizer:
    def __init__(self, enabled: bool = True, jitter_s: float = 60.0,
                 scale_low: float = 0.9, scale_high: float = 1.1,
                 out_dir: Optional[str] = None, keep_last: int = 4):
        self.enabled = bool(enabled)
        self.jitter_s = max(0.0, float(jitter_s))
        lo, hi = float(scale_low), float(scale_high)
        if hi < lo:
            lo, hi = hi, lo
        self.scale_low = max(0.05, lo)
        self.scale_high = max(self.scale_low, hi)
        self.keep_last = max(1, int(keep_last))
        self.out_dir = out_dir or tempfile.mkdtemp(prefix=f"vector_demand_{os.getpid()}_")
        os.makedirs(self.out_dir, exist_ok=True)
        self.last_meta: Dict[str, float] = {}

    def generate(self, base_route_file: Optional[str], seed: int) -> Optional[str]:
        """Write a randomized copy of ``base_route_file``; return its path (or None)."""
        if not self.enabled or not base_route_file or not os.path.isfile(base_route_file):
            return None
        rng = np.random.default_rng(int(seed) & 0xFFFFFFFF)
        tree = ET.parse(base_route_file)
        root = tree.getroot()
        children = list(root)
        vehicles = [c for c in children if c.tag in _VEHICLE_TAGS and _is_number(c.get("depart"))]
        if not vehicles:
            return None
        veh_ids = set(id(c) for c in vehicles)
        others = [c for c in children if id(c) not in veh_ids]
        departs = np.asarray([float(c.get("depart")) for c in vehicles], dtype=np.float64)
        t_min, t_max = float(departs.min()), float(departs.max())
        if self.scale_high > self.scale_low:
            scale = float(rng.uniform(self.scale_low, self.scale_high))
        else:
            scale = float(self.scale_low)
        keep_p = min(1.0, scale)
        out_veh = [c for c in vehicles if float(rng.random()) < keep_p]
        extra = max(0.0, scale - 1.0)
        if extra > 0.0:
            n_extra = int(rng.binomial(len(vehicles), min(1.0, extra)))
            if n_extra > 0:
                picks = rng.choice(len(vehicles), size=n_extra, replace=False)
                for k, i in enumerate(sorted(int(x) for x in picks)):
                    dup = copy.deepcopy(vehicles[i])
                    dup.set("id", f"{vehicles[i].get('id')}__dup{k}")
                    out_veh.append(dup)
        for c in out_veh:
            dep = float(c.get("depart"))
            if self.jitter_s > 0.0:
                dep += float(rng.uniform(-self.jitter_s, self.jitter_s))
            c.set("depart", f"{float(np.clip(dep, t_min, t_max)):.2f}")
        out_veh.sort(key=lambda c: (float(c.get("depart")), str(c.get("id"))))
        for c in children:
            root.remove(c)
        for c in others:
            root.append(c)
        for c in out_veh:
            root.append(c)
        path = os.path.join(self.out_dir, f"demand_seed{int(seed)}.rou.xml")
        tree.write(path, encoding="utf-8", xml_declaration=True)
        self.last_meta = {
            "seed": float(int(seed)),
            "scale": float(scale),
            "n_base": float(len(vehicles)),
            "n_out": float(len(out_veh)),
            "jitter_s": float(self.jitter_s),
        }
        self._cleanup()
        return path

    def _cleanup(self) -> None:
        files = sorted(glob.glob(os.path.join(self.out_dir, "demand_seed*.rou.xml")),
                       key=os.path.getmtime)
        for old in files[:-self.keep_last]:
            try:
                os.remove(old)
            except OSError:
                pass
