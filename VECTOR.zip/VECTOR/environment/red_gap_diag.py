"""Red-light leader_gap diagnostics (observe only; never changes rewards).

Samples slow vehicles on red/yellow that have a valid leader, separately for
CAV and HDV. Used online by marl_env (TB) and offline by scripts/metrics.
"""
from __future__ import annotations

from typing import Any, Dict, List, Mapping, MutableMapping, Optional, Sequence

import numpy as np

from reward.longitudinal_reward import (
    IDLE_LEADER_EXEMPT_M,
    QUEUE_PACK_HI_M,
    QUEUE_PACK_LO_M,
)

SLOW_V_MS = 1.5
SAMPLE_EVERY = 5
GAP_BINS = [-0.5, 0.0, 0.3, 0.8, 1.2, 1.8, 2.8, 4.5, 6.0, 12.0, 18.0, 50.0]
_ACC_KEYS = ("cav", "hdv", "cav_both_slow", "hdv_both_slow")
# v5.2.1 split (observe only). The legacy "cav"/"hdv" buckets mix three things:
#   queue : ego and leader both slow, leader still upstream of the stop line
#           -> the true standing queue gap (what costs storage);
#   head  : leader has already crossed the stop line (ego is first in queue)
#           -> "gap" is distance to a car on the far side of the junction;
#   creep : queue samples with ego still rolling (>= CREEP_V_MS) and gap > 2.8 m.
_SPLIT_KEYS = ("cav_queue", "hdv_queue", "cav_head", "hdv_head")
CREEP_V_MS = 0.1
HEAD_TOL_M = 0.5


def _finite(x: Any, default: float = 0.0) -> float:
    try:
        v = float(x)
    except (TypeError, ValueError, OverflowError):
        return float(default)
    return v if np.isfinite(v) else float(default)


def new_accumulator() -> Dict[str, Dict[str, float]]:
    """Running sums for online episode aggregation (no gap list storage)."""
    return {
        key: {
            "n": 0.0,
            "sum": 0.0,
            "n_pack": 0.0,
            "n_gt4p5": 0.0,
            "n_gt6": 0.0,
            "n_creep": 0.0,
        }
        for key in _ACC_KEYS + _SPLIT_KEYS
    }


def _split_bucket(vinfo: Mapping[str, Any], *, group: str, both_slow: bool) -> Optional[str]:
    """v5.2.1: queue vs head-of-queue (leader past the stop line)."""
    d = _finite(vinfo.get("dist_to_stopline", -1.0), -1.0)
    if d < 0.0:
        return None
    gap = _finite(vinfo.get("leader_gap", 100.0), 100.0)
    if gap >= d - HEAD_TOL_M:
        return f"{group}_head"
    if both_slow:
        return f"{group}_queue"
    return None


def _bucket_for(vinfo: Mapping[str, Any], *, group: str) -> Optional[str]:
    if not bool(vinfo.get("in_control_zone", False)):
        return None
    speed = _finite(vinfo.get("speed", 0.0), 0.0)
    if speed >= SLOW_V_MS:
        return None
    tls = str(vinfo.get("tls_state", "n") or "n").lower()
    if tls not in ("r", "y"):
        return None
    if vinfo.get("leader_id") is None:
        return None
    gap = _finite(vinfo.get("leader_gap", 100.0), 100.0)
    if gap >= 99.0:
        return None
    leader_speed = vinfo.get("leader_speed")
    ls = _finite(leader_speed, 10.0) if leader_speed is not None else 10.0
    both_slow = bool(speed < SLOW_V_MS and ls < SLOW_V_MS)
    if both_slow:
        return f"{group}_both_slow"
    return group


def _observe_gap(acc: MutableMapping[str, Dict[str, float]], key: str, gap: float) -> None:
    row = acc[key]
    row["n"] += 1.0
    row["sum"] += float(gap)
    if QUEUE_PACK_LO_M <= gap <= QUEUE_PACK_HI_M:
        row["n_pack"] += 1.0
    if gap > float(IDLE_LEADER_EXEMPT_M):
        row["n_gt4p5"] += 1.0
    if gap > 6.0:
        row["n_gt6"] += 1.0


def accumulate_from_state(
    acc: MutableMapping[str, Dict[str, float]],
    state: Mapping[str, Any],
) -> None:
    """Add one frame of red/slow leader gaps into the accumulator."""
    for group, bucket in (("cav", "cavs"), ("hdv", "hdvs")):
        vehicles = state.get(bucket) or {}
        if not isinstance(vehicles, Mapping):
            continue
        for vinfo in vehicles.values():
            if not isinstance(vinfo, Mapping):
                continue
            key = _bucket_for(vinfo, group=group)
            if key is None:
                continue
            gap = _finite(vinfo.get("leader_gap", 100.0), 100.0)
            _observe_gap(acc, key, gap)
            # both_slow rows are exclusive; also count them in the all-slow bucket
            if key.endswith("_both_slow"):
                _observe_gap(acc, group, gap)
            if any(k not in acc for k in _SPLIT_KEYS):
                continue  # accumulator from an older version
            skey = _split_bucket(
                vinfo, group=group, both_slow=key.endswith("_both_slow")
            )
            if skey is not None:
                _observe_gap(acc, skey, gap)
                if (
                    skey.endswith("_queue")
                    and _finite(vinfo.get("speed", 0.0), 0.0) >= CREEP_V_MS
                    and gap > float(IDLE_LEADER_EXEMPT_M)
                ):
                    acc[skey]["n_creep"] = acc[skey].get("n_creep", 0.0) + 1.0


def summarize_accumulator(acc: Mapping[str, Mapping[str, float]]) -> Dict[str, float]:
    """Flatten episode accumulator into TB-friendly scalars."""
    out: Dict[str, float] = {}
    for key in _ACC_KEYS + _SPLIT_KEYS:
        row = acc.get(key) or {}
        n = float(row.get("n", 0.0) or 0.0)
        gap_sum = float(row.get("sum", 0.0) or 0.0)
        n_pack = float(row.get("n_pack", 0.0) or 0.0)
        n_gt4p5 = float(row.get("n_gt4p5", 0.0) or 0.0)
        n_gt6 = float(row.get("n_gt6", 0.0) or 0.0)
        prefix = f"red_gap_{key}"
        out[f"{prefix}_n"] = n
        out[f"{prefix}_mean"] = (gap_sum / n) if n > 0.0 else 0.0
        out[f"{prefix}_pack_frac"] = (n_pack / n) if n > 0.0 else 0.0
        out[f"{prefix}_gt4p5_frac"] = (n_gt4p5 / n) if n > 0.0 else 0.0
        out[f"{prefix}_gt6_frac"] = (n_gt6 / n) if n > 0.0 else 0.0
        if key in _SPLIT_KEYS:
            n_creep = float(row.get("n_creep", 0.0) or 0.0)
            out[f"{prefix}_creep_frac"] = (n_creep / n) if n > 0.0 else 0.0
    return out


def sample_gap_rows(state: Mapping[str, Any]) -> List[Dict[str, Any]]:
    """Per-vehicle rows for offline scripts (includes CAV + HDV)."""
    rows: List[Dict[str, Any]] = []
    for group, bucket in (("cav", "cavs"), ("hdv", "hdvs")):
        vehicles = state.get(bucket) or {}
        if not isinstance(vehicles, Mapping):
            continue
        for vid, vinfo in vehicles.items():
            if not isinstance(vinfo, Mapping):
                continue
            key = _bucket_for(vinfo, group=group)
            if key is None:
                continue
            speed = _finite(vinfo.get("speed", 0.0), 0.0)
            gap = _finite(vinfo.get("leader_gap", 100.0), 100.0)
            leader_speed = vinfo.get("leader_speed")
            ls = (
                _finite(leader_speed, 10.0)
                if leader_speed is not None
                else 10.0
            )
            rows.append(
                {
                    "vid": str(vid),
                    "group": group,
                    "is_leader": bool(vinfo.get("is_leader", False)),
                    "leader_gap": float(gap),
                    "speed": float(speed),
                    "leader_speed": float(ls),
                    "dist_to_stopline": _finite(
                        vinfo.get("dist_to_stopline", -1.0), -1.0
                    ),
                    "both_slow": bool(speed < SLOW_V_MS and ls < SLOW_V_MS),
                }
            )
    return rows


def summarize_gaps(gaps: Sequence[float]) -> Dict[str, Any]:
    if not gaps:
        return {"n": 0}
    arr = np.asarray(list(gaps), dtype=np.float64)
    hist, _ = np.histogram(arr, bins=GAP_BINS)
    bands = {
        "lt_1": float(np.mean(arr < 1.0)),
        "in_1_3p5": float(
            np.mean((arr >= QUEUE_PACK_LO_M) & (arr <= QUEUE_PACK_HI_M))
        ),
        "in_3p5_4p5": float(
            np.mean((arr > QUEUE_PACK_HI_M) & (arr <= float(IDLE_LEADER_EXEMPT_M)))
        ),
        "in_4p5_6": float(
            np.mean((arr > float(IDLE_LEADER_EXEMPT_M)) & (arr <= 6.0))
        ),
        "gt_6": float(np.mean(arr > 6.0)),
    }
    return {
        "n": int(arr.size),
        "mean": float(np.mean(arr)),
        "median": float(np.median(arr)),
        "p25": float(np.percentile(arr, 25)),
        "p75": float(np.percentile(arr, 75)),
        "p90": float(np.percentile(arr, 90)),
        "bands": bands,
        "hist_counts": [int(x) for x in hist.tolist()],
        "hist_bins": list(GAP_BINS),
    }
