"""Hierarchical CAV zones: lon control (200 m) + LC band to outer 700 m."""
from __future__ import annotations

from typing import Any, Dict, Mapping, Union
import math

# Stopline origin: 0..200 control; 200..700 platoon/LC; >700 free.
DEFAULT_CONTROL_ZONE_M = 200.0
DEFAULT_PLATOON_ZONE_M = 700.0

ZONE_NONE = "none"
ZONE_PLATOON = "platoon"
ZONE_CONTROL = "control"


def _finite_float(value: Any, default: float) -> float:
    """Parse distances safely; malformed or non-finite data cannot enter a zone."""
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError):
        return float(default)
    return result if math.isfinite(result) else float(default)


def get_vehicle_zone(
    vehicle: Union[Mapping[str, Any], float, None],
    *,
    control_zone_m: float = DEFAULT_CONTROL_ZONE_M,
    platoon_zone_m: float = DEFAULT_PLATOON_ZONE_M,
) -> Dict[str, str]:
    """Return ``{"zone": "platoon"|"control"|"none"}`` from stop-line distance.

    Accepts a vehicle dict with ``dist_to_stopline`` / ``is_in_junction``, or a
    raw distance float (meters to stop-line; negative → none).
    """
    Lc = max(_finite_float(control_zone_m, DEFAULT_CONTROL_ZONE_M), 1e-3)
    Lp = max(_finite_float(platoon_zone_m, DEFAULT_PLATOON_ZONE_M), Lc)

    if isinstance(vehicle, Mapping):
        if vehicle.get("is_in_junction", False):
            return {"zone": ZONE_CONTROL}
        raw = vehicle.get("dist_to_stopline", -1.0)
        # 0.0 is a valid stopline distance — never coerce via `or -1.0`.
        dist = -1.0 if raw is None else _finite_float(raw, -1.0)
    elif vehicle is None:
        dist = -1.0
    else:
        dist = _finite_float(vehicle, -1.0)

    if dist < 0.0:
        return {"zone": ZONE_NONE}
    if dist <= Lc:
        return {"zone": ZONE_CONTROL}
    if dist <= Lp:
        return {"zone": ZONE_PLATOON}
    return {"zone": ZONE_NONE}


def zone_flags(
    dist_to_stopline: float,
    is_in_junction: bool = False,
    *,
    control_zone_m: float = DEFAULT_CONTROL_ZONE_M,
    platoon_zone_m: float = DEFAULT_PLATOON_ZONE_M,
) -> Dict[str, Any]:
    """Convenience flags for SUMO state packing."""
    z = get_vehicle_zone(
        {"dist_to_stopline": dist_to_stopline, "is_in_junction": is_in_junction},
        control_zone_m=control_zone_m,
        platoon_zone_m=platoon_zone_m,
    )["zone"]
    return {
        "zone_type": z,
        # Inner band only (≤ control distance), plus vehicles already in the junction.
        "in_control_zone": z == ZONE_CONTROL or bool(is_in_junction),
        "in_platoon_zone": z in (ZONE_CONTROL, ZONE_PLATOON) or bool(is_in_junction),
        # Formation LC only. Control-zone escape LC is gated separately by routing mask.
        "lateral_allowed": z == ZONE_PLATOON,
    }
