"""Xuancheng junction 34180200000479 — signal green bounds & approach map."""

JUNCTION_ID = "34180200000479"
TLS_ID = "34180200000479"
TLS_PROGRAM_ID = "rl"
JUNCTION_CENTER = (1130.16, 905.15)

USE_DUBLIN_LAYOUT = True

# Stopline origin: 0..-200 m lon (no LC); -200..-700 m LC band; beyond -700 free.
CONTROL_ZONE_DISTANCE = 200.0
PLATOON_FORMATION_LENGTH = 500.0
PLATOON_ZONE_DISTANCE = 700.0  # outer radius = control + formation
SPEED_LIMIT_MS = 16.67  # 60 km/h

# Corrected N/S labels: northbound approach is south of junction (edge 34180201815),
# southbound approach is north of junction (edge 34180200252).
APPROACH_EDGES = {
    "N": ("34180200252",),   # north side, southbound into junction (~820m)
    "S": ("34180201815",),   # south side, northbound into junction (~812m)
    "E": ("34180201814",),   # ~852m
    "W": ("34180201817",),   # ~843m
    "FZ": ("34180201816",),  # Fazhi single-lane (~831m)
}

# Pure 5 decision greens (2s lowercase-g overlaps are not agent actions).
#   G0 NS thru (14,15,25,26)
#   G1 NS protected left + U-turn (16,17,27,28,29)
#   G2 EW thru (7,8,9,19,20)
#   G3 EW protected left + U-turn (10,21,22)
#   G4 Fazhi full release (0..4)
N_GREEN_PHASES = 5
MIN_GREEN_DURATION = 8.0
MIN_GREEN_BY_PHASE = (14.0, 10.0, 14.0, 10.0, 8.0)
GREEN_DECISION_INTERVAL = 5.0
YELLOW_DURATION = 3.0
ALL_RED_DURATION = 2.0
MAX_GREEN_BY_PHASE = (46.0, 28.0, 44.0, 28.0, 24.0)
MAX_GREEN_DURATION = 46.0
CYCLE_FAIRNESS_ENABLED = True
STARVE_IDLE_CLOCK = False
