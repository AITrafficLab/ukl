"""Dublin cluster 4-leg (cluster_1417055450_...) — signal green bounds & approach map."""

JUNCTION_ID = "cluster_1417055450_2663809951_5238330325_5238330332"
TLS_ID = "GS_cluster_1417055450_2663809951_5238330325_5238330332"
TLS_PROGRAM_ID = "rl"
JUNCTION_CENTER = (9446.71, 4073.57)

USE_DUBLIN_LAYOUT = True

# Stopline origin: 0..-200 m lon (no LC); -200..-700 m LC band; beyond -700 free.
CONTROL_ZONE_DISTANCE = 200.0
PLATOON_FORMATION_LENGTH = 500.0
PLATOON_ZONE_DISTANCE = 700.0  # outer radius = control + formation
SPEED_LIMIT_MS = 16.67  # 60 km/h

# Cardinal keys follow geographic approach direction into the cluster.
# Tuples are near-junction first, then upstream (user-extended in place).
APPROACH_EDGES = {
    "N": ("610330470#0", "190858946#3.14"),   # ~899m
    "S": ("768402570#0", "768402570#0.ext"),  # ~885m
    "E": ("610330469#0", "E6"),               # ~867m
    "W": ("3819238#1", "E2"),                 # ~868m
}

# 4 decision greens aligned to 12 controlled connections (0..11).
#   G0 rrrGGrrrrGGr  NS thru (3,4,9,10)
#   G1 rrrrrGrrrrrG  NS protected rights (5,11)
#   G2 GGrrrrGGrrrr  EW thru (0,1,6,7)
#   G3 rrGrrrrrGrrr  EW protected rights (2,8)
N_GREEN_PHASES = 4
MIN_GREEN_DURATION = 6.0
MIN_GREEN_BY_PHASE = (12.0, 6.0, 12.0, 6.0)
GREEN_DECISION_INTERVAL = 5.0
YELLOW_DURATION = 3.0
ALL_RED_DURATION = 3.0  # large internal clearing (~56 m)
MAX_GREEN_BY_PHASE = (44.0, 24.0, 44.0, 24.0)
MAX_GREEN_DURATION = 44.0
CYCLE_FAIRNESS_ENABLED = True
STARVE_IDLE_CLOCK = False
# Removed CYCLE_THRU_GREENS / CYCLE_PROTECTED_GREENS hard-lock (right-turn starve).
