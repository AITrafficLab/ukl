"""3-leg T-junction (32471791, Haddington x Cranmer) — signal green bounds & approach map."""

JUNCTION_ID = "32471791"
TLS_ID = "32471791"
TLS_PROGRAM_ID = "rl"
JUNCTION_CENTER = (6277.93, 1853.84)

USE_DUBLIN_LAYOUT = True

# Stopline origin: 0..200 m keep-lane (all); 200..700 m LC/lon band; >700 free.
CONTROL_ZONE_DISTANCE = 200.0
PLATOON_FORMATION_LENGTH = 500.0
PLATOON_ZONE_DISTANCE = 700.0  # outer radius = control + formation
SPEED_LIMIT_MS = 16.67  # 60 km/h

APPROACH_EDGES = {
    "E": ("-4934446#6",),          # Haddington from J1 (~840m)
    "W": ("4934446#2",),           # Haddington west corridor (~867m)
    # Cranmer branch is NW of the T; BEV cardinal key is North (was mislabeled "S").
    "N": ("10575471#2",),
}

# --- Signal agent green bounds ---
# Conflict-free EW thru + E-right overlap (G0↔G1 keep E thru continuous).
# Baseline C=90s: 34 / 16 / 25 (+3y+2ar).
# Gmax cap 34/16/25 did not beat original G2 (TIS 175 vs 173). Next one-change:
# raise gmin to the static greens so MP cannot cut earlier than the net program.
N_GREEN_PHASES = 3
MIN_GREEN_DURATION = 16.0
MIN_GREEN_BY_PHASE = (34.0, 16.0, 25.0)
GREEN_DECISION_INTERVAL = 5.0
YELLOW_DURATION = 3.0
ALL_RED_DURATION = 2.0
MAX_GREEN_BY_PHASE = (46.0, 24.0, 28.0)
MAX_GREEN_DURATION = 46.0
CYCLE_FAIRNESS_ENABLED = True
STARVE_IDLE_CLOCK = False
