"""Build hierarchical CAV observation vectors (lateral / longitudinal)."""
from __future__ import annotations

import math
import os
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

import numpy as np

from environment.peer_index import get_peer_index

from environment.platoon_manager import (
    enrich_formation_state,
    platoon_gap,
    platoon_type_code,
    safe_gap,
)
from environment.zone_manager import ZONE_CONTROL, ZONE_PLATOON

# Lateral: ego(6) + leader(4) + safety(2) + lane queues(3) + formation(7)
#          + signal(phase,tg,tr,tls_code)(4) + neighbor gaps(5) = 31
LAT_OBS_DIM = 31
# Longitudinal: ego(5) + leader(4) + safety(2) + maintain(3)
#               + signal(phase,tg,tr,tls_code)(4) + dyn context(4: a_idm, lead_acc, vlm_d, beta)
#               + green-wave / glide goal speed error(1) = 23
LON_OBS_DIM = 23
RED_GLIDE_GOAL_DECEL_MS2 = 1.25
RED_GLIDE_STOP_BUFFER_M = 0.35
GLOSA_GOAL_MIN_DIST_M = 16.0
GLOSA_GOAL_MAX_DIST_M = 220.0
GLOSA_GOAL_MAX_TTG_S = 28.0
GLOSA_GOAL_ARRIVAL_BUF_S = 1.2
LAT_ACTIONS = 3  # indices 0,1,2 → driver-left, keep, driver-right
# Stage-Lat DLC safety gate in physical bumper-to-bumper meters (mask unsafe LC → keep).
LC_SAFE_MIN_GAP_M = 4.5
LC_SAFE_MIN_TTC_S = 2.0
# After a discretionary LC request, lock keep for this many seconds to stop
# left/right ping-pong (override with LAT_LC_COOLDOWN_S). Escape LC exempt.
LAT_LC_COOLDOWN_S = 4.5
# Lon RL train/control band: leaders (including solo) within this stopline
# distance; junction always eligible.
LON_RL_MAX_DIST_M = 300.0


def lc_cooldown_seconds() -> float:
    """Discretionary lane-change keep-lock duration (seconds)."""
    raw = os.environ.get("LAT_LC_COOLDOWN_S")
    if raw is None or not str(raw).strip():
        return float(LAT_LC_COOLDOWN_S)
    try:
        val = float(str(raw).strip())
    except (TypeError, ValueError, OverflowError):
        return float(LAT_LC_COOLDOWN_S)
    if not np.isfinite(val) or val < 0.0:
        return float(LAT_LC_COOLDOWN_S)
    return float(val)


def _finite_float(value: Any, default: float = 0.0) -> float:
    """Convert state values to finite floats without leaking NaN/Inf into observations."""
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError):
        return float(default)
    return result if np.isfinite(result) else float(default)


def tls_code(tls_state: Any) -> float:
    """Match marl_env._signal_code: g=+1, y=-0.5, r=-1, else 0."""
    tls = str(tls_state or "n").lower()
    if tls == "g":
        return 1.0
    if tls == "y":
        return -0.5
    if tls == "r":
        return -1.0
    return 0.0


def _signal_time_features(
    vinfo: Mapping[str, Any],
    state: Mapping[str, Any],
) -> Tuple[float, float, float, float]:
    """Return (phase, tg, tr, tls_code).

    ``time_to_green < 0`` (unknown / no link) falls back to phase ``remaining_time``
    instead of clipping ``-1`` into a fake zero wait. Color is carried by tls_code so
    (tg,tr)=(0,0) no longer collapses green-expire / red-expire / no-TLS.
    """
    tls = str(vinfo.get("tls_state", "n") or "n").lower()
    code = tls_code(tls)
    tg = 0.0
    tr = 0.0
    phase = 0.0
    tls_id = vinfo.get("tls_id")
    signals = state.get("signals") or {}
    if tls_id and tls_id in signals:
        sinfo = signals[tls_id] or {}
        rem = max(_finite_float(sinfo.get("remaining_time", 0.0), 0.0), 0.0)
        n_g = max(int(sinfo.get("n_green", 1) or 1), 1)
        phase = _finite_float(sinfo.get("green_index", 0), 0.0) / float(n_g)
        if tls == "g":
            tg = rem
        else:
            raw_ttg = _finite_float(vinfo.get("time_to_green", -1.0), -1.0)
            tr = raw_ttg if raw_ttg >= 0.0 else rem
    return phase, tg, tr, code


_LON_GATE_CACHE: Dict[tuple, tuple] = {}


def lon_rl_gate() -> tuple:
    """v6-P0: (max_dist_m, min_dist_m, in_junction) for the Lon RL zone.

    Read from the environment at call time (memoised on the raw strings) so
    forked env workers see the trainer's CLI choice. Defaults reproduce v5.2.4:
    300 m corridor, no near-stop-line exclusion, junction box included.
    ``--profile v6p0`` sets 200 m / 20 m / junction excluded (the specification's
    200 m control zone; the last 20 m and the box stay with SUMO's own model).
    """
    raw = (
        os.environ.get("LON_RL_MAX_DIST_M"),
        os.environ.get("LON_RL_MIN_DIST_M"),
        os.environ.get("LON_RL_IN_JUNCTION"),
    )
    hit = _LON_GATE_CACHE.get(raw)
    if hit is not None:
        return hit
    max_d = _finite_float(raw[0], LON_RL_MAX_DIST_M) if raw[0] not in (None, "") else LON_RL_MAX_DIST_M
    min_d = _finite_float(raw[1], 0.0) if raw[1] not in (None, "") else 0.0
    in_j = str(raw[2] if raw[2] is not None else "1").strip().lower() not in ("0", "false", "no", "off")
    out = (float(max(max_d, 0.0)), float(max(min_d, 0.0)), bool(in_j))
    _LON_GATE_CACHE[raw] = out
    return out


def lon_rl_eligible(
    vinfo: Optional[Mapping[str, Any]] = None,
    *,
    is_leader: bool = False,
    is_in_junction: bool = False,
    dist_to_stopline: Optional[float] = None,
    cluster_id: Any = None,
    max_dist_m: Optional[float] = None,
    require_leader: bool = True,
) -> bool:
    """True for corridor CAVs eligible for longitudinal RL.

    Default (``require_leader=True``): active leaders including solo DBSCAN ids.
    All-CAV soft-platoon mode passes ``require_leader=False`` so every CAV within
    ``max_dist_m`` (or in-junction) is eligible; DBSCAN no longer gates Lon RL.
    ``cluster_id`` is accepted for call-site compatibility only.
    """
    del cluster_id  # observational; not an RL gate
    if vinfo is not None:
        is_leader = bool(vinfo.get("is_leader", is_leader))
        is_in_junction = bool(vinfo.get("is_in_junction", is_in_junction))
        if dist_to_stopline is None:
            raw = vinfo.get("dist_to_stopline", -1.0)
            dist_to_stopline = -1.0 if raw is None else _finite_float(raw, -1.0)
    if require_leader and not is_leader:
        return False
    gate_max, gate_min, gate_in_junction = lon_rl_gate()
    if max_dist_m is None:
        max_dist_m = gate_max
    if is_in_junction:
        return bool(gate_in_junction)
    dist = (
        _finite_float(dist_to_stopline, -1.0)
        if dist_to_stopline is not None
        else -1.0
    )
    if not np.isfinite(dist):
        dist = -1.0
    # Corridor distance gate; unknown dist < 0 out. v6-P0: optional near-line cut.
    return bool(float(gate_min) <= dist <= float(max_dist_m)) if gate_min > 0.0 else bool(
        0.0 <= dist <= float(max_dist_m)
    )


def lane_index_sign(vinfo: Optional[Mapping[str, Any]] = None, lefthand: Optional[bool] = None) -> int:
    """Map driver-left to lane-index delta.

    RHT (5-leg): lane 0 = rightmost → driver left = +1 index.
    LHT (3/4-leg): lane 0 = leftmost → driver left = -1 index.
    """
    if lefthand is None and vinfo is not None:
        # Prefer explicit ±1 if provided (not bool — True==1 in Python).
        raw_sign = vinfo.get("lane_index_sign")
        if raw_sign is not None and not isinstance(raw_sign, bool):
            try:
                s = int(raw_sign)
            except (TypeError, ValueError):
                s = None
            if s in (-1, 1):
                return int(s)
        raw = vinfo.get("lefthand")
        if isinstance(raw, str):
            lefthand = raw.strip().lower() in ("1", "true", "yes", "on")
        elif raw is None:
            lefthand = False
        else:
            lefthand = bool(raw)
    return -1 if lefthand else 1


def driver_lane_offset(signed_action: int, vinfo: Optional[Mapping[str, Any]] = None) -> int:
    """Signed lat action (-1 left / 0 keep / +1 right) → lane-index delta."""
    act = int(signed_action)
    if act == 0:
        return 0
    # act=-1 (driver left) → +sign; act=+1 (driver right) → -sign
    return int(lane_index_sign(vinfo)) * (-act)


def _lane_index(lane_id: str) -> int:
    if not lane_id or "_" not in lane_id:
        return 0
    try:
        return int(str(lane_id).rsplit("_", 1)[-1])
    except ValueError:
        return 0


def _edge_of_lane(lane_id: str) -> str:
    if not lane_id:
        return ""
    if "_" in lane_id:
        return lane_id.rsplit("_", 1)[0]
    return lane_id


def lane_queue_counts(
    edge_id: str,
    vehicles: Mapping[str, Mapping[str, Any]],
    n_lanes: int = 3,
    approach_edges: Optional[Sequence[str]] = None,
    *,
    include_rolling: bool = False,
) -> List[float]:
    """Count lane load per lane index along one approach chain.

    When ``include_rolling=False`` (default for legacy callers), counts strictly
    halted vehicles (``speed < 0.5 m/s``) as integers.
    When ``include_rolling=True`` (used by ``build_lane_features`` for Stage-Lat),
    combines halted vehicles (weight 1.0) with slow/rolling approach platoons
    (``0.5 <= speed < 8.0 m/s`` within 450 m of the stop line, linearly weighted up
    to 0.55) so lateral RL proactively balances moving congestion waves before
    they come to a dead stop.

    v5.2: visits only vehicles on the chain edges (per-step PeerIndex), in the
    original order -> bit-identical sums.
    """
    edges = {str(edge_id or "")}
    if approach_edges:
        edges.update(str(e) for e in approach_edges if e)
    edges.discard("")
    pidx = get_peer_index(vehicles)
    cand = [] if pidx is None else [pidx.items[i][1] for i in pidx.for_edges(edges)]
    if not include_rolling:
        counts_int = [0] * max(int(n_lanes), 1)
        for v in cand:
            if str(v.get("edge", "") or "") not in edges:
                continue
            if _finite_float(v.get("speed", 0.0), 0.0) >= 0.5:
                continue
            idx = _lane_index(str(v.get("lane", "") or ""))
            if 0 <= idx < len(counts_int):
                counts_int[idx] += 1
        return counts_int
    loads = [0.0] * max(int(n_lanes), 1)
    for v in cand:
        if str(v.get("edge", "") or "") not in edges:
            continue
        spd = _finite_float(v.get("speed", 0.0), 0.0)
        idx = _lane_index(str(v.get("lane", "") or ""))
        if not (0 <= idx < len(loads)):
            continue
        if spd < 0.5:
            loads[idx] += 1.0
        elif spd < 8.0:
            raw_d = v.get("dist_to_stopline", -1.0)
            dist = -1.0 if raw_d is None else _finite_float(raw_d, -1.0)
            if dist < 0.0 or dist <= 450.0:
                w_roll = 0.55 * max(0.0, 1.0 - (spd - 0.5) / 7.5)
                loads[idx] += float(w_roll)
    return [round(float(x), 4) for x in loads]

def build_lane_features(
    vinfo: Mapping[str, Any],
    all_vehicles: Mapping[str, Mapping[str, Any]],
    target_lane_offset: int = 0,
) -> Tuple[float, float, float, List[int]]:
    edge = str(vinfo.get("edge", "") or "")
    cur_idx = _lane_index(str(vinfo.get("lane", "") or ""))
    # Legal-through-lane-aware queues: DLC vehicles compare only within
    # legal_lanes_for_route so a turn-only pocket never drags R_lane.
    try:
        _nlanes = max(int(vinfo.get("n_lanes", 0) or 0), cur_idx + 2, 3)
    except (TypeError, ValueError):
        _nlanes = max(cur_idx + 2, 3)
    queues = lane_queue_counts(
        edge,
        all_vehicles,
        n_lanes=_nlanes,
        approach_edges=vinfo.get("approach_edges"),
        include_rolling=True,
    )
    try:
        legal = [int(x) for x in legal_lanes_for_route(vinfo, _nlanes)]
    except Exception:
        legal = []
    if legal:
        legal_q = [float(queues[i]) for i in legal if 0 <= i < len(queues)]
        l_min = float(min(legal_q)) if legal_q else (float(min(queues)) if queues else 0.0)
    else:
        l_min = float(min(queues)) if queues else 0.0
    tgt = int(np.clip(cur_idx + int(target_lane_offset), 0, len(queues) - 1))
    l_cur = float(queues[cur_idx]) if 0 <= cur_idx < len(queues) else 0.0
    if int(target_lane_offset) == 0:
        # No commanded offset: meta target unused for LC; keep l_tgt for display.
        l_tgt = l_cur
    else:
        l_tgt = float(queues[tgt]) if 0 <= tgt < len(queues) else l_cur
        if legal and not (0 <= tgt < len(queues) and tgt in [int(x) for x in legal]):
            # Commanded target outside legal set → fall back to best legal lane.
            try:
                best = min(legal, key=lambda i: float(queues[i]) if 0 <= i < len(queues) else 1e9)
                l_tgt = float(queues[best]) if 0 <= best < len(queues) else l_cur
            except (TypeError, ValueError):
                pass
    return l_cur, l_tgt, l_min, queues


def _lane_reaches_next(
    lane_idx: int,
    route_next_edge: Optional[str],
    lane_to_edges: Optional[Mapping[Any, Any]],
) -> bool:
    """True if ``lane_idx`` has a connection onto the vehicle's next route edge.

    - No next-edge / no topology map → feasible (do not over-mask).
    - Edge map present but this lane missing → no outbound links → infeasible.
    - Empty dest list for the lane → infeasible.
    """
    next_e = str(route_next_edge or "").strip()
    if not next_e:
        return True
    if lane_to_edges is None:
        return True
    if len(lane_to_edges) == 0:
        return True
    raw = lane_to_edges.get(lane_idx, lane_to_edges.get(str(lane_idx)))
    if raw is None:
        return False
    dests = {str(x) for x in (raw if not isinstance(raw, (str, bytes)) else [raw])}
    if not dests:
        return False
    return next_e in dests


def _apply_routing_to_mask(
    mask: np.ndarray,
    idx: int,
    next_e: Any,
    lane_to_edges: Any,
    n_lanes: int = 1,
    index_sign: int = 1,
) -> np.ndarray:
    """Block LC onto / stay on route-illegal lanes; force escape when possible.

    If the current lane is illegal and every neighbor is also route-illegal
    (topology trap / map hole), fail-open to physical neighbors so the agent
    is not permanently keep-only under RL LC mode.
    """
    if not next_e or lane_to_edges is None or len(lane_to_edges) == 0:
        return mask
    sign = 1 if int(index_sign) >= 0 else -1
    left_idx = idx + sign
    right_idx = idx - sign
    if mask[0] > 0.0 and not _lane_reaches_next(left_idx, next_e, lane_to_edges):
        mask[0] = 0.0
    if mask[2] > 0.0 and not _lane_reaches_next(right_idx, next_e, lane_to_edges):
        mask[2] = 0.0
    cur_ok = _lane_reaches_next(idx, next_e, lane_to_edges)
    if not cur_ok:
        if float(mask[0]) > 0.0 or float(mask[2]) > 0.0:
            mask[1] = 0.0
        else:
            n = max(int(n_lanes), 1)
            if 0 <= left_idx < n:
                mask[0] = 1.0
            if 0 <= right_idx < n:
                mask[2] = 1.0
            if float(mask[0]) > 0.0 or float(mask[2]) > 0.0:
                mask[1] = 0.0
            else:
                mask[1] = 1.0
    return mask


def legal_lanes_for_route(vinfo: Mapping[str, Any], n_lanes: int = 1) -> list:
    """All lane indices on the current edge that can reach route_next_edge.

    Generic across 3/4/5-leg: uses lane_to_edges topology map, never hard-coded ids.
    """
    next_e = str((vinfo or {}).get("route_next_edge") or "").strip()
    lane_to_edges = (vinfo or {}).get("lane_to_edges")
    n = max(int(n_lanes or 1), 1)
    if not next_e or lane_to_edges is None or len(lane_to_edges) == 0:
        try:
            cur = str((vinfo or {}).get("lane") or "")
            idx = int(cur.rsplit("_", 1)[-1])
            return [int(idx)]
        except (TypeError, ValueError):
            return list(range(n))
    out = []
    for i in range(n):
        if _lane_reaches_next(i, next_e, lane_to_edges):
            out.append(int(i))
    return out


def lat_dof_mode(vinfo: Mapping[str, Any], n_lanes: int = 1) -> tuple:
    """Topology-aware lateral DoF gate (MLC/DLC decoupling).

    Returns (mode, legal_lanes):
      'RULE_MLC'    — current lane not in legal set (must route back)
      'LOCKED_0DOF' — in legal set but len<=1 (turn-only / single-lane进口)
      'RL_DLC'      — in legal set and len>=2 (multi-lane through, real game)
    """
    try:
        cur = str((vinfo or {}).get("lane") or "")
        idx = int(cur.rsplit("_", 1)[-1])
    except (TypeError, ValueError):
        return "LOCKED_0DOF", legal_lanes_for_route(vinfo, n_lanes)
    legal = legal_lanes_for_route(vinfo, n_lanes)
    if not legal:
        return "LOCKED_0DOF", [int(idx)]
    if int(idx) not in [int(x) for x in legal]:
        return "RULE_MLC", [int(x) for x in legal]
    if len(legal) <= 1:
        return "LOCKED_0DOF", [int(x) for x in legal]
    return "RL_DLC", [int(x) for x in legal]


def deterministic_mlc_action(
    vinfo: Mapping[str, Any],
    legal_lanes: Optional[Sequence[int]] = None,
    n_lanes: int = 1,
) -> int:
    """Deterministic signed action (-1 driver-left / 0 keep / +1 driver-right)
    steering a ``RULE_MLC`` vehicle one step toward its nearest route-legal lane."""
    try:
        cur = _lane_index(str((vinfo or {}).get("lane") or ""))
    except Exception:
        return 0
    legal = (
        [int(x) for x in legal_lanes]
        if legal_lanes is not None
        else [int(x) for x in legal_lanes_for_route(vinfo, max(int(n_lanes or 1), 1))]
    )
    if not legal or cur in legal:
        return 0
    best = min(legal, key=lambda i: abs(int(i) - int(cur)))
    want_delta = 1 if int(best) > int(cur) else -1
    sign = int(lane_index_sign(vinfo))
    # driver_lane_offset(act) = sign * (-act) == want_delta  =>  act = -sign * want_delta
    return int(-sign * want_delta)


def _nearest_gap_on_lane(
    ego: Mapping[str, Any],
    peers: Mapping[str, Mapping[str, Any]],
    target_lane: int,
    ahead: bool,
) -> tuple:
    """Nearest physical bumper-to-bumper gap (m) and closing speed (m/s) on target lane.

    Supports multi-edge approach chains (e.g. 4-leg 850 m upstream + 29 m junction
    edge) via continuous ``dist_to_stopline`` coordinates when peers are on adjacent
    segments of the same ``approach_edges`` corridor.

    v5.2: candidates from the per-step PeerIndex (same edges, global order).
    """
    edge = str(ego.get("edge") or "")
    app_edges = {edge} if edge else set()
    raw_chain = ego.get("approach_edges")
    if raw_chain:
        app_edges.update(str(e) for e in raw_chain if e)
    app_edges.discard("")
    ego_id = str(ego.get("_id") or "")
    ego_pos = _finite_float(ego.get("lane_position", 0.0), 0.0)
    ego_v = _finite_float(ego.get("speed", 0.0), 0.0)
    ego_len = _finite_float(ego.get("length", 5.0), 5.0)
    raw_ed = ego.get("dist_to_stopline", -1.0)
    ego_d = -1.0 if raw_ed is None else _finite_float(raw_ed, -1.0)
    best_gap = None
    best_closing = None
    pidx = get_peer_index(peers)
    if pidx is None:
        return best_gap, best_closing
    tl = int(target_lane)
    cand_edges = set(app_edges)
    cand_edges.add(edge)
    for i in pidx.for_edges(cand_edges):
        if pidx.lanes[i] != tl:
            continue
        oid, o = pidx.items[i]
        if ego_id and str(oid) == ego_id:
            continue
        o_edge = str(o.get("edge") or "")
        same_edge = (o_edge == edge)
        if not same_edge and (not app_edges or o_edge not in app_edges):
            continue
        ov = _finite_float(o.get("speed", 0.0), 0.0)
        o_len = _finite_float(o.get("length", 5.0), 5.0)
        if same_edge:
            opos = _finite_float(o.get("lane_position", 0.0), 0.0)
            delta_front = opos - ego_pos  # >0 means o is ahead of ego
        else:
            raw_od = o.get("dist_to_stopline", -1.0)
            od = -1.0 if raw_od is None else _finite_float(raw_od, -1.0)
            if ego_d < 0.0 or od < 0.0:
                continue
            delta_front = ego_d - od
        if ahead:
            if delta_front <= 0.0:
                continue
            gap = max(0.05, delta_front - o_len) if delta_front > 0.2 else 0.0
            if gap <= 0.0:
                continue
            closing = ego_v - ov
        else:
            delta_rear = -delta_front
            if delta_rear <= 0.0:
                continue
            gap = max(0.05, delta_rear - ego_len) if delta_rear > 0.2 else 0.0
            if gap <= 0.0:
                continue
            closing = ov - ego_v
        if best_gap is None or gap < best_gap:
            best_gap = float(gap)
            best_closing = float(closing)
    return best_gap, best_closing

def nearest_target_lane_partner(
    ego: Mapping[str, Any],
    peers: Mapping[str, Mapping[str, Any]],
    target_lane: int,
    approach_edges: Optional[Sequence[str]] = None,
) -> tuple:
    """Longitudinal gap (m) and CAV flag of the nearest front/rear vehicle.

    Only vehicles on ``target_lane`` of this approach count. A vehicle sitting
    beside the ego on another lane index is not a partner, so side-by-side
    driving is not scored as a rear-end. v5.2: PeerIndex candidates.
    """
    edges = {str(ego.get("edge") or "")}
    if approach_edges:
        edges.update(str(e) for e in approach_edges if e)
    edges.discard("")
    ego_id = str(ego.get("_id") or "")
    raw_ego = ego.get("dist_to_stopline", -1.0)
    ego_d = -1.0 if raw_ego is None else _finite_float(raw_ego, -1.0)
    best_gap = None
    best_cav = None
    pidx = get_peer_index(peers)
    cand = [] if pidx is None else (pidx.for_edges(edges) if edges else range(pidx.n))
    tl = int(target_lane)
    for i in cand:
        if pidx.lanes[i] != tl:
            continue
        oid, o = pidx.items[i]
        if ego_id and str(oid) == ego_id:
            continue
        o_edge = str(o.get("edge") or "")
        if edges and o_edge not in edges:
            continue
        raw_o = o.get("dist_to_stopline", -1.0)
        od = -1.0 if raw_o is None else _finite_float(raw_o, -1.0)
        if od < 0.0 or ego_d < 0.0:
            continue
        o_len = max(_finite_float(o.get("length", 5.0), 5.0), 0.0)
        gap = max(0.0, abs(ego_d - od) - o_len)
        if best_gap is None or gap < best_gap:
            best_gap = float(gap)
            best_cav = bool(o.get("is_cav", False))
    if best_gap is None:
        return 100.0, None
    return float(best_gap), best_cav

def _target_lane_lc_safe(
    ego: Mapping[str, Any],
    peers: Optional[Mapping[str, Mapping[str, Any]]],
    target_lane: int,
    min_gap_m: float = LC_SAFE_MIN_GAP_M,
    min_ttc_s: float = LC_SAFE_MIN_TTC_S,
) -> bool:
    """False if target-lane leader/follower gap or TTC is unsafe."""
    if not peers:
        return True
    for ahead in (True, False):
        gap, closing = _nearest_gap_on_lane(ego, peers, int(target_lane), ahead=ahead)
        if gap is None:
            continue
        if gap < float(min_gap_m):
            return False
        if closing is not None and closing > 0.1 and (gap / closing) < float(min_ttc_s):
            return False
    return True


def lateral_action_mask(
    vinfo: Mapping[str, Any],
    n_lanes_on_edge: Optional[int] = None,
    peers: Optional[Mapping[str, Mapping[str, Any]]] = None,
) -> np.ndarray:
    """Mask for actions [left, keep, right].

    - Formation (platoon) zone: physical bounds + routing mask + gap/TTC safety.
    - Control zone: keep-only **if** current lane is route-legal; if illegal,
      still allow LC toward a legal neighbor (escape; safety gate skipped).
    - Elsewhere: keep only.
    """
    mask = np.ones(LAT_ACTIONS, dtype=np.float32)
    zone = str(vinfo.get("zone_type", "") or "")
    idx = _lane_index(str(vinfo.get("lane", "") or ""))
    n = int(n_lanes_on_edge if n_lanes_on_edge is not None else vinfo.get("n_lanes", 3) or 3)
    n = max(n, 1)
    next_e = vinfo.get("route_next_edge")
    lane_to_edges = vinfo.get("lane_to_edges")
    sign = lane_index_sign(vinfo)
    left_idx = idx + sign
    right_idx = idx - sign

    if zone == ZONE_PLATOON:
        if not (0 <= left_idx < n):
            mask[0] = 0.0
        if not (0 <= right_idx < n):
            mask[2] = 0.0
        mask = _apply_routing_to_mask(
            mask, idx, next_e, lane_to_edges, n_lanes=n, index_sign=sign
        )
    elif zone == ZONE_CONTROL:
        # Default: freeze lateral. Exception: escape from a route-illegal lane.
        mask[:] = 0.0
        mask[1] = 1.0
        cur_ok = _lane_reaches_next(idx, next_e, lane_to_edges)
        if not cur_ok and next_e and lane_to_edges:
            mask[:] = 1.0
            if not (0 <= left_idx < n):
                mask[0] = 0.0
            if not (0 <= right_idx < n):
                mask[2] = 0.0
            mask = _apply_routing_to_mask(
                mask, idx, next_e, lane_to_edges, n_lanes=n, index_sign=sign
            )
    else:
        mask[:] = 0.0
        mask[1] = 1.0

    # Safety gap/TTC mask for discretionary DLC (not forced escape).
    # When keep is forbidden, vehicle must escape — do not trap it.
    if peers and float(mask[1]) > 0.0:
        if float(mask[0]) > 0.0 and not _target_lane_lc_safe(vinfo, peers, left_idx):
            mask[0] = 0.0
        if float(mask[2]) > 0.0 and not _target_lane_lc_safe(vinfo, peers, right_idx):
            mask[2] = 0.0

    # Post-LC cooldown: lock keep for discretionary DLC. Escape (keep already
    # forbidden / illegal lane) must remain able to change lanes.
    if bool(vinfo.get("lc_cooldown_active", False)) and float(mask[1]) > 0.0:
        mask[:] = 0.0
        mask[1] = 1.0

    if float(mask.sum()) <= 0.0:
        mask[1] = 1.0
    return mask


def build_lateral_obs(
    vid: str,
    vinfo: Mapping[str, Any],
    state: Mapping[str, Any],
    lat_weights: Sequence[float],
    prev_accel: float = 0.0,
    dt: float = 0.2,
    peers: Optional[Mapping[str, Mapping[str, Any]]] = None,
) -> Dict[str, Any]:
    """Build lateral obs; pass a shared ``peers`` map from the caller to avoid
    O(N_CAV × N_total) per-vehicle dict copies inside the env obs loop.

    Trailing 6 dims (was ``l_tgt≡l_cur`` + frozen ``lat_w``) are neighbor-lane
    queues and lead/follow gaps for left/right adjacent lanes.
    """
    del lat_weights  # recycled channels; weights no longer occupy obs slots
    if peers is None:
        peers = {}
        for group in ("cavs", "hdvs"):
            for oid, o in (state.get(group) or {}).items():
                peers[oid] = dict(o)
                peers[oid]["_id"] = oid
    ego = dict(vinfo)
    ego["_id"] = vid
    form = enrich_formation_state(ego, peers)
    all_v = peers  # v5.2: read-only use; the per-ego copy was O(N) for nothing
    l_cur, _l_tgt, l_min, queues = build_lane_features(vinfo, all_v, 0)
    cur_idx = _lane_index(str(vinfo.get("lane", "") or ""))
    sign = lane_index_sign(vinfo)
    left_idx = cur_idx + sign
    right_idx = cur_idx - sign
    n_q = len(queues) if queues is not None else 0
    # Safe boundary when no adjacent lane: empty queue + large gaps.
    if 0 <= left_idx < n_q:
        l_left = float(queues[left_idx])
        gap_ll, _ = _nearest_gap_on_lane(ego, peers, left_idx, ahead=True)
        gap_lf, _ = _nearest_gap_on_lane(ego, peers, left_idx, ahead=False)
    else:
        l_left, gap_ll, gap_lf = 0.0, 100.0, 100.0
    if 0 <= right_idx < n_q:
        l_right = float(queues[right_idx])
        gap_rl, _ = _nearest_gap_on_lane(ego, peers, right_idx, ahead=True)
        gap_rf, _ = _nearest_gap_on_lane(ego, peers, right_idx, ahead=False)
    else:
        l_right, gap_rl, gap_rf = 0.0, 100.0, 100.0
    gap_ll = 100.0 if gap_ll is None else float(gap_ll)
    gap_lf = 100.0 if gap_lf is None else float(gap_lf)
    gap_rl = 100.0 if gap_rl is None else float(gap_rl)
    gap_rf = 100.0 if gap_rf is None else float(gap_rf)

    speed = _finite_float(vinfo.get("speed", 0.0), 0.0)
    v_lim = max(_finite_float(vinfo.get("lane_max_speed", 16.67), 16.67), 5.0)
    accel = _finite_float(vinfo.get("acceleration", 0.0), 0.0)
    jerk = (accel - float(prev_accel)) / max(float(dt), 1e-6)
    leader_speed = _finite_float(vinfo.get("leader_speed", speed), speed)
    leader_gap = _finite_float(vinfo.get("leader_gap", 100.0), 100.0)
    delta_v = speed - leader_speed
    ttc = vinfo.get("ttc")
    ttc_f = _finite_float(ttc, 10.0) if ttc is not None else 10.0
    safe_d = safe_gap(speed)
    leader_is_cav = False
    lid = vinfo.get("leader_id")
    if lid and lid in peers:
        leader_is_cav = bool(peers[lid].get("is_cav", False))
    ptype = platoon_type_code(True, leader_is_cav if lid else None)

    phase, tg, tr, tls_c = _signal_time_features(vinfo, state)

    vec = np.asarray(
        [
            np.clip(speed / v_lim, 0.0, 1.5),
            np.clip(accel / 5.0, -1.0, 1.0),
            np.clip(jerk / 10.0, -1.0, 1.0),
            float(cur_idx) / 5.0,
            np.clip(_finite_float(vinfo.get("dist_to_stopline", 0.0), 0.0) / 700.0, 0.0, 1.5),
            1.0 if str(vinfo.get("zone_type")) == ZONE_PLATOON else 0.0,
            np.clip(leader_speed / v_lim, 0.0, 1.5),
            np.clip(delta_v / v_lim, -1.5, 1.5),
            np.clip(leader_gap / 100.0, 0.0, 2.0),
            1.0 if leader_is_cav else 0.0,
            np.clip(ttc_f / 10.0, 0.0, 2.0),
            np.clip(safe_d / 20.0, 0.0, 2.0),
            np.clip(l_cur / 20.0, 0.0, 2.5),
            np.clip(l_left / 20.0, 0.0, 2.5),
            np.clip(l_min / 20.0, 0.0, 2.5),
            np.clip(form["nearest_cav_distance"] / 100.0, 0.0, 2.0),
            np.clip(form["nearest_hdv_distance"] / 100.0, 0.0, 2.0),
            np.clip(form["relative_speed"] / v_lim, -1.5, 1.5),
            np.clip(form["relative_lane"] / 3.0, -1.0, 1.0),
            form["candidate_vehicle_type"],
            form["platoon_quality"],
            form["formation_probability"],
            phase,
            np.clip(tg / 60.0, 0.0, 1.0),
            np.clip(tr / 60.0, 0.0, 1.0),
            float(tls_c),
            np.clip(l_right / 20.0, 0.0, 2.5),
            np.clip(gap_ll / 100.0, 0.0, 2.0),
            np.clip(gap_lf / 100.0, 0.0, 2.0),
            np.clip(gap_rl / 100.0, 0.0, 2.0),
            np.clip(gap_rf / 100.0, 0.0, 2.0),
        ],
        dtype=np.float32,
    )
    vec = np.nan_to_num(vec, nan=0.0, posinf=2.5, neginf=-2.5).astype(np.float32, copy=False)
    assert vec.shape[0] == LAT_OBS_DIM, f"lat obs {vec.shape[0]} != {LAT_OBS_DIM}"
    return {
        "vector": vec,
        "action_mask": lateral_action_mask(vinfo, peers=peers),
        "meta": {
            "current_lane_queue": l_cur,
            "target_lane_queue": l_cur,
            "min_lane_queue": l_min,
            "left_lane_queue": l_left,
            "right_lane_queue": l_right,
            "platoon_type": ptype,
            **form,
        },
    }


def compute_lon_rl_authority(
    leader_gap: Any,
    *,
    has_leader: bool = False,
    enabled: bool = True,
    full_gap_m: float = 8.0,
    free_gap_m: float = 22.0,
    min_authority: float = 0.25,
) -> float:
    """Continuous RL longitudinal authority alpha in [min_authority, 1] above closed-loop CACC.

    - ``alpha = min_authority`` (default ``0.25``) when ``has_leader`` and net
      ``leader_gap <= full_gap_m`` so the RL policy retains residual control authority
      even in compact platoons while CACC supplies 75% string-stable damping.
    - Smooth linear ramp from ``min_authority`` to ``1.0`` on ``(full_gap_m, free_gap_m)``.
    - ``alpha = 1.0`` when ``leader_gap >= free_gap_m``, no leader, or CACC disabled.
    """
    if not bool(enabled) or not bool(has_leader):
        return 1.0
    floor_a = float(np.clip(_finite_float(min_authority, 0.25), 0.0, 1.0))
    gap = _finite_float(leader_gap, 100.0)
    lo = float(full_gap_m)
    hi = max(float(free_gap_m), lo + 1e-3)
    if gap <= lo:
        return floor_a
    if gap >= hi:
        return 1.0
    frac = float(np.clip((gap - lo) / (hi - lo), 0.0, 1.0))
    return float(floor_a + (1.0 - floor_a) * frac)


def compute_green_wave_goal_speed(
    vinfo: Mapping[str, Any],
    state: Mapping[str, Any],
    *,
    v_lim: Optional[float] = None,
) -> float:
    """Compute continuous GLOSA / kinematic-glide target speed in [0, v_lim] (m/s).

    - On green, in-junction, or without an approaching stop line: ``v_lim``.
    - On red within feasible GLOSA horizon (``16..220 m``, ``0.5..28 s``): non-stop
      green-wave arrival speed ``dist / (tr + 1.2)`` when ``>= min_glosa_v``.
    - On all other red/yellow approaches (e.g. ``tr = 45 s`` at ``100 m``): smooth
      kinematic deceleration envelope ``min(v_lim, sqrt(2 * b_glide * max(0, dist - d_buf)))``
      matching ``SUMO_interface``'s ``RED_GLIDE_DECEL = 1.25 m/s^2`` — completely
      continuous across ``130 m`` with zero step-to-zero cliff!
    """
    if v_lim is None:
        v_lim = max(_finite_float(vinfo.get("lane_max_speed", 16.67), 16.67), 5.0)
    v_lim_f = float(v_lim)
    dist = _finite_float(vinfo.get("dist_to_stopline", -1.0), -1.0)
    _phase, _tg, tr, tls_c = _signal_time_features(vinfo, state)
    if bool(vinfo.get("is_in_junction", False)) or dist < 0.0 or tls_c > 0.5:
        return v_lim_f
    if tls_c < -0.25:
        if (
            tls_c <= -0.75
            and GLOSA_GOAL_MIN_DIST_M <= dist <= GLOSA_GOAL_MAX_DIST_M
            and 0.5 <= tr <= GLOSA_GOAL_MAX_TTG_S
        ):
            v_glosa = dist / (tr + GLOSA_GOAL_ARRIVAL_BUF_S)
            min_v = 2.2 if tr <= 4.0 else 3.5
            if min_v <= v_glosa <= v_lim_f:
                return float(v_glosa)
        d_eff = max(0.0, dist - RED_GLIDE_STOP_BUFFER_M)
        v_glide = math.sqrt(2.0 * RED_GLIDE_GOAL_DECEL_MS2 * d_eff)
        return float(min(v_lim_f, v_glide))
    return v_lim_f


def build_longitudinal_obs(
    vid: str,
    vinfo: Mapping[str, Any],
    state: Mapping[str, Any],
    long_weights: Sequence[float],
    prev_accel: float = 0.0,
    dt: float = 0.2,
    a_idm: Optional[float] = None,
    vlm_lon_delta: float = 0.0,
    action_blend_beta: float = 1.0,
    goal_speed_conditioning: Optional[bool] = None,
) -> Dict[str, Any]:
    """23-dim longitudinal obs: preserves soft-start β at [21] and goal-speed delta at [22]."""
    del vid, long_weights
    speed = _finite_float(vinfo.get("speed", 0.0), 0.0)
    v_lim = max(_finite_float(vinfo.get("lane_max_speed", 16.67), 16.67), 5.0)
    accel = _finite_float(vinfo.get("acceleration", 0.0), 0.0)
    jerk = (accel - float(prev_accel)) / max(float(dt), 1e-6)
    leader_speed = _finite_float(vinfo.get("leader_speed", speed), speed)
    leader_gap = _finite_float(vinfo.get("leader_gap", 100.0), 100.0)
    follower_gap = _finite_float(vinfo.get("follower_gap", 100.0), 100.0)
    delta_v = speed - leader_speed
    ttc = vinfo.get("ttc")
    ttc_f = _finite_float(ttc, 10.0) if ttc is not None else 10.0
    safe_d = safe_gap(speed)
    in_plat = 1.0 if (vinfo.get("cluster_id") and not str(vinfo.get("cluster_id")).startswith("solo")) else 0.0
    lid = vinfo.get("leader_id")
    leader_is_cav = None
    leader_accel = 0.0
    if lid is not None:
        peer = (state.get("cavs") or {}).get(lid) or (state.get("hdvs") or {}).get(lid)
        if peer is not None:
            leader_is_cav = bool(
                peer.get("is_cav", "CAV" in str(peer.get("vtype", "") or ""))
            )
            leader_accel = _finite_float(peer.get("acceleration", 0.0), 0.0)
        else:
            leader_is_cav = False
    ptype = float(platoon_type_code(True, leader_is_cav if lid else None)) / 2.0

    phase, tg, tr, tls_c = _signal_time_features(vinfo, state)

    if a_idm is None:
        a_idm = _finite_float(vinfo.get("a_idm", accel), accel)
    a_idm_f = _finite_float(a_idm, 0.0)
    vlm_d = _finite_float(vlm_lon_delta, 0.0)
    beta = float(np.clip(_finite_float(action_blend_beta, 1.0), 0.0, 1.0))
    if goal_speed_conditioning is None:
        _env_gs = os.environ.get("VECTOR_GOAL_SPEED_COND", "1").strip().lower()
        use_goal_speed = _env_gs not in ("0", "false", "no", "off")
    else:
        use_goal_speed = bool(goal_speed_conditioning)
    if use_goal_speed:
        v_goal = compute_green_wave_goal_speed(vinfo, state, v_lim=v_lim)
        goal_speed_err_norm = float(np.clip((v_goal - speed) / v_lim, -1.5, 1.5))
    else:
        goal_speed_err_norm = 0.0

    vec = np.asarray(
        [
            np.clip(speed / v_lim, 0.0, 1.5),
            np.clip(accel / 5.0, -1.0, 1.0),
            np.clip(jerk / 10.0, -1.0, 1.0),
            np.clip(_finite_float(vinfo.get("dist_to_stopline", 0.0), 0.0) / 200.0, 0.0, 2.5),
            1.0 if str(vinfo.get("zone_type")) == ZONE_CONTROL else 0.0,
            np.clip(leader_speed / v_lim, 0.0, 1.5),
            np.clip(delta_v / v_lim, -1.5, 1.5),
            np.clip(leader_gap / 100.0, 0.0, 2.0),
            np.clip(follower_gap / 100.0, 0.0, 2.0),
            np.clip(ttc_f / 10.0, 0.0, 2.0),
            np.clip(safe_d / 20.0, 0.0, 2.0),
            in_plat,
            ptype,
            np.clip(leader_gap / max(platoon_gap(speed), 1e-3), 0.0, 2.0),
            phase,
            np.clip(tg / 60.0, 0.0, 1.0),
            np.clip(tr / 60.0, 0.0, 1.0),
            float(tls_c),
            np.clip(a_idm_f / 3.0, -1.5, 1.5),
            np.clip(leader_accel / 3.0, -1.5, 1.5),
            np.clip(vlm_d / 0.05, -2.0, 2.0),  # v5: matches VLM_CAV_RESIDUAL_SCALE (v4: /0.02)
            beta,
            goal_speed_err_norm,
        ],
        dtype=np.float32,
    )
    vec = np.nan_to_num(vec, nan=0.0, posinf=2.5, neginf=-2.5).astype(np.float32, copy=False)
    assert vec.shape[0] == LON_OBS_DIM, f"lon obs {vec.shape[0]} != {LON_OBS_DIM}"
    return {"vector": vec}
