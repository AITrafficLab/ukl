"""Shared TLS green-phase classification (protected 'G' only)."""
from __future__ import annotations

import os
import xml.etree.ElementTree as ET
from typing import Iterable, List, Sequence

# Upper bound for padded MAPPO / CoTV heads.
# 3-leg=3, 4-leg=4, 5-leg=5 decision greens; keep 7 for mask padding compat.
MAX_SIGNAL_ACTIONS = 7


def phase_kind(state: str) -> str:
    """Single-state hint. Prefer ``phase_kinds`` / ``green_phase_indices``."""
    s = str(state or "")
    if any(c in "Yy" for c in s):
        return "yellow"
    if "G" in s:
        return "green"
    return "red"


def green_phase_indices(phase_states: Sequence[str]) -> List[int]:
    """Decision greens: non-yellow phases that contain at least one capital ``G``.

    Lowercase-only ``g`` clearance / always-on right bits (e.g. 5-leg 2s
    overlaps) are never treated as agent actions.
    """
    out: List[int] = []
    for i, raw in enumerate(phase_states):
        s = str(raw or "")
        if any(c in "Yy" for c in s):
            continue
        if "G" in s:
            out.append(i)
    return out


def phase_kinds(phase_states: Sequence[str]) -> List[str]:
    greens = set(green_phase_indices(phase_states))
    kinds: List[str] = []
    for i, s in enumerate(phase_states):
        st = str(s or "")
        if any(c in "Yy" for c in st):
            kinds.append("yellow")
        elif i in greens:
            kinds.append("green")
        else:
            kinds.append("red")
    return kinds


def green_indices_from_logic_phases(phases: Iterable) -> List[int]:
    """``phases`` items have a ``.state`` attribute (TraCI Logic.phases)."""
    states = [getattr(p, "state", "") or "" for p in phases]
    idx = green_phase_indices(states)
    return idx or [0]


def n_green_from_net_xml(net_path: str, tls_id: str | None = None) -> int:
    if not net_path or not os.path.isfile(net_path):
        return 4
    try:
        tree = ET.parse(net_path)
    except (ET.ParseError, OSError):
        return 4
    logics = list(tree.getroot().findall("tlLogic"))
    if not logics:
        return 4
    chosen = None
    if tls_id:
        for tl in logics:
            if tl.get("id") == tls_id:
                chosen = tl
                break
    if chosen is None:
        chosen = logics[0]
    states = [p.get("state", "") or "" for p in chosen.findall("phase")]
    n = len(green_phase_indices(states))
    return max(1, n)


def traci_program_phases(tls_id: str):
    """Phases of the *currently active* TLS program (e.g. additional ``rl``).

    ``getAllProgramLogics()[0]`` is often net.xml program ``0``, which can
    disagree with ``programID=rl`` loaded from additional-files.
    """
    import traci

    logics = list(traci.trafficlight.getAllProgramLogics(tls_id) or [])
    if not logics:
        return []
    try:
        cur = str(traci.trafficlight.getProgram(tls_id) or "")
    except Exception:
        cur = ""
    if cur:
        for lg in logics:
            if str(getattr(lg, "programID", "")) == cur:
                return list(lg.phases)
    return list(logics[0].phases)


def n_green_from_sumocfg(sumocfg_path: str) -> int:
    """Prefer scenario.py MAX_GREEN_BY_PHASE / N_GREEN_PHASES, else net.xml."""
    cfg_dir = os.path.dirname(os.path.abspath(sumocfg_path))
    n = _n_from_scenario_py(cfg_dir)
    if n is not None:
        return int(n)
    net_name = None
    try:
        root = ET.parse(sumocfg_path).getroot()
        nf = root.find(".//net-file")
        if nf is not None:
            net_name = nf.get("value")
    except Exception:
        net_name = None
    if not net_name:
        return 4
    return n_green_from_net_xml(os.path.join(cfg_dir, net_name))


def _n_from_scenario_py(cfg_dir: str) -> int | None:
    scen = os.path.join(cfg_dir, "scenario.py")
    if not os.path.isfile(scen):
        return None
    ns: dict = {}
    try:
        with open(scen, "r", encoding="utf-8") as f:
            exec(compile(f.read(), scen, "exec"), ns, ns)
    except Exception:
        return None
    if "N_GREEN_PHASES" in ns:
        return max(1, int(ns["N_GREEN_PHASES"]))
    max_by = ns.get("MAX_GREEN_BY_PHASE")
    if max_by:
        return max(1, len(tuple(max_by)))
    return None
