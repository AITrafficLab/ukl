"""v6-P0: single source of truth for every gap / headway threshold.

v5.2.4 carried at least six mutually inconsistent definitions:

* ``platoon_manager.safe_gap``      max(0.15, 0.45 v)       (obs + formation reward)
* ``platoon_manager.platoon_gap``   max(4.5, 0.95 v)        (obs + formation reward)
* CACC target in ``SUMO_interface`` 0.65 + 0.60 v, SAME for CAV and HDV leaders
* safety-shield IDM cap trigger     gap < 4.5 m or headway < 0.85 s or TTC < 2.2 s
* v2 reward headway bands           CAV leader 0.6-1.0 s, HDV leader 1.2-2.0 s
* lateral LC gaps                   max(2.0, 0.65 v) / 4.5 m (left unchanged here)

The worst conflict: the CACC target (0.6 s) sits BELOW the shield trigger
(0.85 s), so every time CACC reaches its own target the shield caps the
command at a_IDM (and the Lagrangian term may charge the policy for it), while
the v2 reward pays nothing for that band. Behind an HDV the controller targets
0.6 s although the reward penalises anything under 1.2 s.

``GAP_POLICY=legacy`` (default) returns the v5.2.4 numbers bit-for-bit.
``GAP_POLICY=unified`` (set by ``--profile v6p0``) derives every threshold from
one ordered set of time gaps:

    shield trigger 0.5 s  <  CACC/CAV target 0.6 s  =  reward band low (CAV)
    CACC/HDV target 1.2 s =  reward band low (HDV)
    safe_gap slope 0.5 s  <  0.6 s ;  platoon_gap slope 1.0 s = reward band high (CAV)

All gaps are TraCI *net* leader gaps (bumper gap minus minGap; CAV minGap = 1.0 m).
"""
from __future__ import annotations

import os
from typing import Optional, Tuple

# ---------------------------------------------------------------------------
# Legacy (v5.2.4) constants — do not edit; regression tests pin them.
# ---------------------------------------------------------------------------
LEGACY_SAFE_GAP_MIN_M = 0.15
LEGACY_SAFE_GAP_H_S = 0.45
LEGACY_PLATOON_GAP_MIN_M = 4.5
LEGACY_PLATOON_GAP_H_S = 0.95
LEGACY_CACC_S0_M = 0.65
LEGACY_CACC_H_S = 0.60
LEGACY_SHIELD_GAP_M = 4.5
LEGACY_SHIELD_HEADWAY_S = 0.85
SHIELD_TTC_S = 2.2  # identical in both modes

# Reward headway bands (already consistent in v5.2.4; exported from here).
REWARD_BAND_CAV_S: Tuple[float, float] = (0.6, 1.0)
REWARD_BAND_HDV_S: Tuple[float, float] = (1.2, 2.0)

# ---------------------------------------------------------------------------
# Unified (v6-P0) constants.
# ---------------------------------------------------------------------------
UNIFIED_S0_M = 0.65              # standstill net gap of the CACC target (= 1.65 m bumper)
UNIFIED_H_CAV_S = REWARD_BAND_CAV_S[0]   # 0.6 s CACC behind a CAV
UNIFIED_H_HDV_S = REWARD_BAND_HDV_S[0]   # 1.2 s ACC behind an HDV / unknown leader
UNIFIED_SHIELD_GAP_M = 1.0
UNIFIED_SHIELD_HEADWAY_S = 0.5
UNIFIED_SAFE_GAP_MIN_M = 0.30
UNIFIED_SAFE_GAP_H_S = 0.50
UNIFIED_PLATOON_GAP_MIN_M = 2.0
UNIFIED_PLATOON_GAP_H_S = REWARD_BAND_CAV_S[1]   # 1.0 s

MODES = ("legacy", "unified")


def mode() -> str:
    """Current policy, read at call time so forked env workers see the CLI choice."""
    raw = str(os.environ.get("GAP_POLICY", "legacy") or "legacy").strip().lower()
    return "unified" if raw == "unified" else "legacy"


def _v(v) -> float:
    try:
        x = float(v)
    except (TypeError, ValueError, OverflowError):
        return 0.0
    if x != x or x in (float("inf"), float("-inf")):
        return 0.0
    return x


def safe_gap(v: float) -> float:
    """Minimum acceptable net gap at speed v (m)."""
    s = _v(v)
    if mode() == "unified":
        return max(UNIFIED_SAFE_GAP_MIN_M, UNIFIED_SAFE_GAP_H_S * max(s, 0.0))
    return max(LEGACY_SAFE_GAP_MIN_M, LEGACY_SAFE_GAP_H_S * s)


def platoon_gap(v: float) -> float:
    """Upper edge of the 'in platoon' net gap at speed v (m)."""
    s = _v(v)
    if mode() == "unified":
        return max(UNIFIED_PLATOON_GAP_MIN_M, UNIFIED_S0_M + UNIFIED_PLATOON_GAP_H_S * max(s, 0.0))
    return max(LEGACY_PLATOON_GAP_MIN_M, LEGACY_PLATOON_GAP_H_S * s)


def cacc_target_gap(v: float, leader_is_cav: Optional[bool]) -> float:
    """Net gap the CACC/ACC blend tracks. Legacy ignores the leader type."""
    if mode() == "unified":
        s = max(_v(v), 0.0)
        h = UNIFIED_H_CAV_S if leader_is_cav else UNIFIED_H_HDV_S
        return UNIFIED_S0_M + h * s
    # Legacy: exact v5.2.4 expression (no sanitising, so even NaN behaves as before).
    return LEGACY_CACC_S0_M + LEGACY_CACC_H_S * max(float(v), 0.0)


def shield_caps_to_idm(leader_gap: float, headway_s: float, ttc_s: float) -> bool:
    """True when the safety shield must cap the command at a_IDM.

    Unified thresholds sit strictly below the CACC target so a controller that
    reaches its own target is never overridden.
    """
    if mode() == "unified":
        g, h, t = _v(leader_gap), _v(headway_s), _v(ttc_s)
        return bool(g < UNIFIED_SHIELD_GAP_M or h < UNIFIED_SHIELD_HEADWAY_S or t < SHIELD_TTC_S)
    # Legacy: exact v5.2.4 comparison on raw floats.
    return bool(
        float(leader_gap) < LEGACY_SHIELD_GAP_M
        or float(headway_s) < LEGACY_SHIELD_HEADWAY_S
        or float(ttc_s) < SHIELD_TTC_S
    )


def reward_headway_band(leader_is_cav: Optional[bool]) -> Tuple[float, float]:
    return REWARD_BAND_CAV_S if leader_is_cav else REWARD_BAND_HDV_S


def summary() -> str:
    if mode() == "unified":
        return (
            f"gap_policy=unified shield<{UNIFIED_SHIELD_HEADWAY_S}s/{UNIFIED_SHIELD_GAP_M}m "
            f"cacc_cav={UNIFIED_H_CAV_S}s cacc_hdv={UNIFIED_H_HDV_S}s "
            f"safe={UNIFIED_SAFE_GAP_H_S}s platoon={UNIFIED_PLATOON_GAP_H_S}s"
        )
    return "gap_policy=legacy (v5.2.4 thresholds)"
