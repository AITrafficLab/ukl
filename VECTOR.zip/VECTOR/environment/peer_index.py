"""Per-step peer index for lateral features (VECTOR v5.2; behaviour-preserving).

v5.1 profiling (smoke test): in Stage-Lat the env step cost 4.3x Stage-S even
without congestion, and 1.5-2 s/step in a 4-leg jam, because every lateral
agent scanned ALL vehicles ~10 times per step (formation features, 4 adjacent
lane gap searches, lane queue counts, LC safety masks, lateral reward).

This index is built once per peers mapping (cached by object identity) and
lets those helpers visit only vehicles on the relevant edges / approach. The
candidate lists keep the GLOBAL insertion order of the mapping, so tie-breaks
(strict '<' minima) and floating-point summation order are bit-identical to
the full scans (verified in tests/test_v52_perf_reward.py).

Contract: callers pass a mapping that is not mutated in place after first use
(marl_env builds a fresh peers snapshot every step; shared_peers() below too).
"""
from __future__ import annotations

import re
from typing import Any, Dict, Iterable, List, Mapping, Optional

_STEM_RE = re.compile(r"(?:#\d+|\.ext)$")
_STEM_CACHE: Dict[str, str] = {}


def approach_stem(edge: str) -> str:
    """Identical to the inner ``stem`` of platoon_manager._same_approach."""
    key = str(edge)
    hit = _STEM_CACHE.get(key)
    if hit is not None:
        return hit
    value = key
    while True:
        cleaned = _STEM_RE.sub("", value)
        if cleaned == value:
            break
        value = cleaned
    if len(_STEM_CACHE) < 200000:
        _STEM_CACHE[key] = value
    return value


def _lane_index(lane_id: str) -> int:
    if not lane_id or "_" not in lane_id:
        return 0
    try:
        return int(str(lane_id).rsplit("_", 1)[-1])
    except ValueError:
        return 0


class PeerIndex:
    __slots__ = ("peers", "n", "items", "lanes", "by_edge", "by_stem", "empty_edge")

    def __init__(self, peers: Mapping[str, Mapping[str, Any]]):
        self.peers = peers
        self.items = list(peers.items())
        self.n = len(self.items)
        self.lanes: List[int] = []
        self.by_edge: Dict[str, List[int]] = {}
        self.by_stem: Dict[str, List[int]] = {}
        self.empty_edge: List[int] = []
        for i, (_oid, o) in enumerate(self.items):
            e = str(o.get("edge") or "")
            self.lanes.append(_lane_index(str(o.get("lane") or "")))
            self.by_edge.setdefault(e, []).append(i)
            if e:
                self.by_stem.setdefault(approach_stem(e.strip()), []).append(i)
            else:
                self.empty_edge.append(i)

    def for_edges(self, edges: Iterable[str]) -> List[int]:
        """Indices (global order) of peers whose edge is in ``edges``."""
        out: List[int] = []
        for e in set(edges):
            lst = self.by_edge.get(e)
            if lst:
                out.extend(lst)
        out.sort()
        return out

    def for_approach(self, ego_edge: str) -> List[int]:
        """Peers that pass enrich_formation_state's same-approach filter."""
        if not ego_edge:
            return list(range(self.n))
        out = list(self.by_stem.get(approach_stem(str(ego_edge).strip()), ()))
        out.extend(self.empty_edge)
        out.sort()
        return out


_INDEX_CACHE: List[PeerIndex] = []
_INDEX_CACHE_SIZE = 4  # obs snapshot + reward snapshot (+ spare) per step


def get_peer_index(peers: Optional[Mapping[str, Mapping[str, Any]]]) -> Optional[PeerIndex]:
    if not peers:
        return None
    for idx in _INDEX_CACHE:
        if idx.peers is peers and idx.n == len(peers):
            return idx
    idx = PeerIndex(peers)
    _INDEX_CACHE.insert(0, idx)
    del _INDEX_CACHE[_INDEX_CACHE_SIZE:]
    return idx


_PEERS_CACHE: Dict[str, Any] = {"state": None, "key": None, "peers": None}


def shared_peers(state: Mapping[str, Any]) -> Dict[str, Dict[str, Any]]:
    """{oid: dict(vehicle) + '_id'} over state['cavs'] then state['hdvs'], built
    once per state object (v5.1 rebuilt it for every lateral reward call)."""
    cavs = state.get("cavs") or {}
    hdvs = state.get("hdvs") or {}
    key = (id(cavs), id(hdvs), len(cavs), len(hdvs))
    c = _PEERS_CACHE
    if c["state"] is state and c["key"] == key and c["peers"] is not None:
        return c["peers"]
    peers: Dict[str, Dict[str, Any]] = {}
    for group in (cavs, hdvs):
        for oid, o in group.items():
            peers[oid] = dict(o)
            peers[oid]["_id"] = oid
    c["state"], c["key"], c["peers"] = state, key, peers
    return peers
