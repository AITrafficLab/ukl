"""DBSCAN platoon clustering on [x, v] with hysteresis for Leader selection."""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

import numpy as np


def _zscore(features: np.ndarray) -> np.ndarray:
    """Column-wise Z-score; constant columns → 0.

    Prefer :func:`_physical_scale` for platoon clustering — z-score makes
    2–4 vehicle gaps explode (pair distance ≈ 2) so DBSCAN never clusters.
    """
    if features.size == 0:
        return features
    mean = features.mean(axis=0, keepdims=True)
    std = features.std(axis=0, keepdims=True)
    std = np.where(std < 1e-6, 1.0, std)
    return (features - mean) / std


# Fixed scales so eps≈0.8 ≈ 12 m gap and ≈ 2.4 m/s Δv (euclidean in scaled space).
_POS_SCALE_M = 15.0
_SPD_SCALE_MS = 3.0


def _finite_float(value, default=0.0) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError):
        return float(default)
    return result if np.isfinite(result) else float(default)


def _physical_scale(features: np.ndarray) -> np.ndarray:
    """Scale [dist_to_stopline_m, speed_m/s] to unit-ish axes (not batch z-score)."""
    if features.size == 0:
        return features
    scales = np.asarray([_POS_SCALE_M, _SPD_SCALE_MS], dtype=np.float64)
    return features / scales


def dbscan_labels(
    features: np.ndarray,
    eps: float = 0.8,
    min_samples: int = 2,
) -> np.ndarray:
    """Minimal DBSCAN (Euclidean) without sklearn; invalid rows remain noise.

    The API and label convention are unchanged: ``>=0`` is a cluster and ``-1``
    is noise. Non-finite rows are excluded instead of allowing NaN distances to
    contaminate the neighborhood graph.
    """
    arr = np.asarray(features, dtype=np.float64)
    if arr.ndim != 2:
        raise ValueError(f"features must be a 2-D array, got shape={arr.shape}")
    n = int(arr.shape[0])
    labels = np.full(n, -1, dtype=np.int32)
    if n == 0:
        return labels

    finite_rows = np.all(np.isfinite(arr), axis=1)
    original_indices = np.flatnonzero(finite_rows)
    work = arr[finite_rows]
    n_valid = int(work.shape[0])
    if n_valid == 0:
        return labels

    eps_value = float(eps)
    if not np.isfinite(eps_value) or eps_value < 0.0:
        eps_value = 0.0
    min_samples_value = max(1, int(min_samples))

    # DBSCAN includes each point itself in its neighborhood.
    diff = work[:, None, :] - work[None, :, :]
    dist = np.sqrt(np.sum(diff * diff, axis=-1))
    neighbors = [np.flatnonzero(dist[i] <= eps_value).tolist() for i in range(n_valid)]

    local_labels = np.full(n_valid, -1, dtype=np.int32)
    visited = np.zeros(n_valid, dtype=bool)
    cluster_id = 0

    for i in range(n_valid):
        if visited[i]:
            continue
        visited[i] = True
        seed_neighbors = neighbors[i]
        if len(seed_neighbors) < min_samples_value:
            continue

        local_labels[i] = cluster_id
        seeds = list(seed_neighbors)
        seed_set = set(seeds)
        k = 0
        while k < len(seeds):
            j = seeds[k]
            if not visited[j]:
                visited[j] = True
                neighbors_j = neighbors[j]
                if len(neighbors_j) >= min_samples_value:
                    for m in neighbors_j:
                        if m not in seed_set:
                            seed_set.add(m)
                            seeds.append(m)
            # A previously-noise point can become a border point.
            if local_labels[j] < 0:
                local_labels[j] = cluster_id
            k += 1
        cluster_id += 1

    labels[original_indices] = local_labels
    return labels


@dataclass
class PlatoonTracker:
    """Per-lane DBSCAN + K-step hysteresis for stable Leader assignment."""

    eps: float = 0.8
    min_samples: int = 2
    hysteresis_steps: int = 5
    # vid -> pending (cluster_key, leader_vid, steps_stable)
    _pending: Dict[str, Tuple[str, Optional[str], int]] = field(default_factory=dict)
    # Stable outputs
    cluster_of: Dict[str, str] = field(default_factory=dict)
    leader_of_cluster: Dict[str, Optional[str]] = field(default_factory=dict)
    is_leader: Dict[str, bool] = field(default_factory=dict)
    members_of: Dict[str, List[str]] = field(default_factory=dict)
    cluster_length: Dict[str, float] = field(default_factory=dict)
    last_raw_labels: Dict[str, int] = field(default_factory=dict)

    def reset(self) -> None:
        self._pending.clear()
        self.cluster_of.clear()
        self.leader_of_cluster.clear()
        self.is_leader.clear()
        self.members_of.clear()
        self.cluster_length.clear()
        self.last_raw_labels.clear()

    def update(
        self,
        vehicles: Mapping[str, Mapping],
        cav_ids: Optional[Iterable[str]] = None,
    ) -> Dict[str, object]:
        """
        ``vehicles``: vid -> dict with lane, dist_to_stopline, speed, in_platoon_zone.
        Cluster over the full formation corridor (not control-only).
        """
        cav_set = set(cav_ids or ())
        by_lane: Dict[str, List[str]] = defaultdict(list)
        for vid, info in vehicles.items():
            if not (
                info.get('in_platoon_zone', False) or info.get('in_control_zone', False)
            ):
                continue
            if info.get('is_in_junction', False):
                continue
            lane = str(info.get('lane') or '')
            raw_d = info.get('dist_to_stopline', -1.0)
            dist = -1.0 if raw_d is None else float(raw_d)
            if not lane or dist < 0.0:
                continue
            by_lane[lane].append(vid)

        raw_cluster_of: Dict[str, str] = {}
        raw_leader: Dict[str, Optional[str]] = {}
        raw_members: Dict[str, List[str]] = {}
        raw_length: Dict[str, float] = {}
        self.last_raw_labels.clear()

        for lane, vids in by_lane.items():
            feats = np.asarray(
                [
                    [
                        _finite_float(vehicles[v].get('dist_to_stopline', 0.0), 0.0),
                        _finite_float(vehicles[v].get('speed', 0.0), 0.0),
                    ]
                    for v in vids
                ],
                dtype=np.float64,
            )
            # Physical scale (not z-score): same-lane 8–12 m gaps must cluster.
            feats_n = _physical_scale(feats)
            labels = dbscan_labels(feats_n, eps=self.eps, min_samples=self.min_samples)
            for v, lab in zip(vids, labels):
                self.last_raw_labels[v] = int(lab)

            for lab in sorted(set(int(x) for x in labels) - {-1}):
                members = [v for v, l in zip(vids, labels) if int(l) == lab]
                key = f"{lane}#{lab}"
                # Leader: CAV closest to stop-line (smallest dist_to_stopline)
                cav_members = [v for v in members if v in cav_set or 'CAV' in str(vehicles[v].get('vtype', ''))]
                if not cav_members:
                    # Also accept explicit is_cav flag
                    cav_members = [v for v in members if vehicles[v].get('is_cav', False)]
                leader = None
                if cav_members:
                    leader = min(
                        cav_members,
                        key=lambda v: _finite_float(vehicles[v].get('dist_to_stopline', 1e9), 1e9),
                    )
                dists = [_finite_float(vehicles[v].get('dist_to_stopline', 0.0), 0.0) for v in members]
                length = float(max(dists) - min(dists)) if len(dists) >= 2 else 0.0
                for v in members:
                    raw_cluster_of[v] = key
                raw_leader[key] = leader
                raw_members[key] = members
                raw_length[key] = max(length, 0.0)

        # Singleton / noise CAVs still need a Leader tag for RL control.
        # Formation band (200-700 m) included so longitudinal RL covers the
        # whole platoon corridor, not just the 200 m control zone.
        for vid in cav_set:
            if vid in raw_cluster_of:
                continue
            if vid not in vehicles or not (
                vehicles[vid].get('in_platoon_zone', False)
                or vehicles[vid].get('in_control_zone', False)
            ):
                continue
            if vehicles[vid].get('is_in_junction', False):
                continue
            key = f"solo:{vid}"
            raw_cluster_of[vid] = key
            raw_leader[key] = vid
            raw_members[key] = [vid]
            raw_length[key] = 0.0

        # Hysteresis: require K consecutive identical (cluster_key, leader) proposals
        proposed_leader_of_vid: Dict[str, Tuple[str, Optional[str]]] = {}
        for vid, key in raw_cluster_of.items():
            proposed_leader_of_vid[vid] = (key, raw_leader.get(key))

        new_cluster_of: Dict[str, str] = {}
        new_is_leader: Dict[str, bool] = {}
        active_vids = set(proposed_leader_of_vid.keys())

        for vid, (key, leader) in proposed_leader_of_vid.items():
            prev = self._pending.get(vid)
            if prev is not None and prev[0] == key and prev[1] == leader:
                steps = prev[2] + 1
            else:
                steps = 1
            self._pending[vid] = (key, leader, steps)
            if steps >= self.hysteresis_steps or vid not in self.cluster_of:
                new_cluster_of[vid] = key
                new_is_leader[vid] = leader is not None and vid == leader
            else:
                # Keep previous stable assignment if still present
                old_key = self.cluster_of.get(vid)
                if old_key is not None:
                    new_cluster_of[vid] = old_key
                    new_is_leader[vid] = bool(self.is_leader.get(vid, False))
                else:
                    new_cluster_of[vid] = key
                    new_is_leader[vid] = leader is not None and vid == leader

        # Drop stale pending
        for vid in list(self._pending.keys()):
            if vid not in active_vids:
                self._pending.pop(vid, None)

        # Rebuild cluster maps from stable assignments
        self.cluster_of = new_cluster_of
        self.is_leader = {v: bool(new_is_leader.get(v, False)) for v in new_cluster_of}
        members: Dict[str, List[str]] = defaultdict(list)
        for v, key in self.cluster_of.items():
            members[key].append(v)
        self.members_of = dict(members)
        self.leader_of_cluster = {}
        self.cluster_length = {}
        for key, mems in self.members_of.items():
            leaders = [v for v in mems if self.is_leader.get(v)]
            self.leader_of_cluster[key] = leaders[0] if leaders else raw_leader.get(key)
            # Prefer raw length if same key, else recompute
            if key in raw_length:
                self.cluster_length[key] = raw_length[key]
            else:
                dists = [
                    _finite_float(vehicles[v].get('dist_to_stopline', 0.0), 0.0)
                    for v in mems
                    if v in vehicles
                ]
                self.cluster_length[key] = (
                    float(max(dists) - min(dists)) if len(dists) >= 2 else 0.0
                )

        leader_vids = {v for v, flag in self.is_leader.items() if flag}
        return {
            'cluster_of': dict(self.cluster_of),
            'is_leader': dict(self.is_leader),
            'leader_vids': leader_vids,
            'leader_of_cluster': dict(self.leader_of_cluster),
            'members_of': {k: list(v) for k, v in self.members_of.items()},
            'cluster_length': dict(self.cluster_length),
        }

    def queue_length_for_lanes(self, lane_ids: Sequence[str]) -> float:
        """Sum of DBSCAN cluster lengths whose members lie on given lanes."""
        lane_set = set(lane_ids or ())
        total = 0.0
        seen = set()
        for key, mems in self.members_of.items():
            if key in seen:
                continue
            # key format lane#lab
            lane = key.rsplit('#', 1)[0]
            if lane in lane_set:
                total += float(self.cluster_length.get(key, 0.0))
                seen.add(key)
        return float(total)
