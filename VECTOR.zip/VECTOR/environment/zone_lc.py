"""Stop-line zone lane-change modes (shared by training TraCI + GUI launcher).

Stopline origin (approach distance ≥ 0 toward the stop line):
  0..control_m     → keep-lane for CAVs (HDVs keep SUMO strategic LC; v4)
	control..outer   → free LC, unless Lat RL owns a CAV (any RL_DLC agent)
	  >outer           → free LC
	
	Escape from a route-illegal lane always uses FREE_LC_MODE so TraCI / SUMO
	strategic LC can finish the correction.
"""
from __future__ import annotations

# 512 = no autonomous strategic/DLC; +4 = cooperative courtesy for TraCI LC.
KEEP_LANE_MODE = 516
FREE_LC_MODE = 1621


def desired_lc_mode(
    *,
    in_control_zone: bool,
    in_platoon_zone: bool,
    is_in_junction: bool,
    is_cav: bool,
    is_leader: bool = False,
    lateral_rl_owns: bool = False,
    needs_escape: bool = False,
    control_keep_lane: bool = True,
    control_keep_lane_hdv: bool = False,
    dof_mode: str = "",
) -> int:
    """Return SUMO laneChangeMode for one vehicle this step."""
    del is_leader  # Lat RL is no longer leaders-only; kept for call-site compat.
    if needs_escape or str(dof_mode) == "RULE_MLC":
        return FREE_LC_MODE
    # Universal: 0..control_m (and junction tagged as control) — all types keep.
    if bool(in_control_zone) and bool(control_keep_lane) and (
        bool(is_cav) or bool(control_keep_lane_hdv)
    ):
        # v4: HDVs keep SUMO strategic LC in 0..control_m by default. v3 forced
        # keep-lane on ALL vehicles, trapping HDVs on wrong lanes before turn
        # pockets and requiring OD rewrites (changeTarget) to clear them.
        return KEEP_LANE_MODE
    # Stage-Lat: RL_DLC / settled LOCKED_0DOF CAVs in formation band use RL-owned keep.
    own_lat = bool(lateral_rl_owns) and bool(is_cav)
    if own_lat and (bool(in_platoon_zone) or bool(is_in_junction)):
        return KEEP_LANE_MODE
    return FREE_LC_MODE
