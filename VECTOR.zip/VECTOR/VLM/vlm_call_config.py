"""Central VLM thinking-mode + per-channel max_tokens policy.

Thinking preference (all channels: Signal / Lon / Lat):
  Default env preference is ``low``.
    - ``low``: try ``reasoning_effort=low`` (or provider-specific low thinking);
      if rejected by gateway, demote cleanly to ``enable_thinking=False`` (off),
      and finally to ``bare`` (omit extra_body) for strict local servers.
    - ``off`` / ``auto``: try disabling thinking first; if rejected, demote to
      low effort or bare.
"""
from __future__ import annotations

import os
import re
import threading
from dataclasses import dataclass, field
from typing import Any, Dict, Optional, Tuple

# --- Task book caps (thinking off) ---
SIGNAL_VISION_MAX_TOKENS = 256
LONG_REWARD_VLM_MAX_TOKENS = 128
LAT_REWARD_VLM_MAX_TOKENS = 128

# --- Task book caps (thinking low / cannot disable) ---
SIGNAL_VISION_MAX_TOKENS_LOW = 512
LONG_REWARD_VLM_MAX_TOKENS_LOW = 256
LAT_REWARD_VLM_MAX_TOKENS_LOW = 256

SIG_REWARD_VLM_MAX_TOKENS = LONG_REWARD_VLM_MAX_TOKENS
SIG_REWARD_VLM_MAX_TOKENS_LOW = LONG_REWARD_VLM_MAX_TOKENS_LOW

CHANNEL_SIGNAL_VISION = "signal_vision"
CHANNEL_LON = "lon"
CHANNEL_LAT = "lat"
CHANNEL_SIG = "sig"

_OFF_CAPS = {
    CHANNEL_SIGNAL_VISION: SIGNAL_VISION_MAX_TOKENS,
    CHANNEL_LON: LONG_REWARD_VLM_MAX_TOKENS,
    CHANNEL_LAT: LAT_REWARD_VLM_MAX_TOKENS,
    CHANNEL_SIG: SIG_REWARD_VLM_MAX_TOKENS,
}
_LOW_CAPS = {
    CHANNEL_SIGNAL_VISION: SIGNAL_VISION_MAX_TOKENS_LOW,
    CHANNEL_LON: LONG_REWARD_VLM_MAX_TOKENS_LOW,
    CHANNEL_LAT: LAT_REWARD_VLM_MAX_TOKENS_LOW,
    CHANNEL_SIG: SIG_REWARD_VLM_MAX_TOKENS_LOW,
}


def normalize_channel(channel: str) -> str:
    raw = str(channel or "").strip().lower()
    if raw in ("signal_vision", "vision", "sig_vision", "signal-vision"):
        return CHANNEL_SIGNAL_VISION
    if raw in ("lat", "lateral", "l1"):
        return CHANNEL_LAT
    if raw in ("sig", "signal", "s", "tls"):
        return CHANNEL_SIG
    return CHANNEL_LON


def env_thinking_preference(
    *,
    api_base: Optional[str] = None,
    model: Optional[str] = None,
) -> str:
    """Return off | low | auto from env."""
    del api_base, model
    mode = str(
        os.environ.get("VLM_THINKING_MODE")
        or os.environ.get("VLM_THINKING")
        or ""
    ).strip().lower()
    if mode in ("off", "disabled", "disable", "false", "0", "none"):
        return "off"
    if mode in ("low", "min", "minimal", ""):
        return "low"
    if mode == "auto":
        if str(os.environ.get("VLM_ENABLE_THINKING", "")).strip().lower() in (
            "1", "true", "yes", "on",
        ):
            return "low"
        return "auto"
    return "auto"


def _reasoning_effort_low() -> str:
    effort = str(os.environ.get("VLM_REASONING_EFFORT", "") or "").strip().lower()
    if effort in ("low", "high", "max"):
        return effort
    return "low"


def api_family(api_base: str) -> str:
    """Coarse gateway family from API base URL."""
    base = str(api_base or "").lower()
    if "bigmodel.cn" in base:
        return "zhipu"
    if "siliconflow" in base:
        return "siliconflow"
    if "dashscope" in base or "qianwen" in base or "aliyuncs" in base:
        return "qwen_compat"
    if "127.0.0.1" in base or "localhost" in base:
        return "local_openai"
    return "openai_compat"


def uses_siliconflow_glm53_reasoning(
    api_base: Optional[str], model: Optional[str]
) -> bool:
    if "siliconflow" not in str(api_base or "").lower():
        return False
    ml = str(model or "").strip().lower()
    return "glm" in ml and "5.3" in ml


def _low_reasoning_body(family: str) -> Tuple[str, Dict[str, Any], str]:
    """Build the lowest supported thinking-on request body for ``family``."""
    effort = _reasoning_effort_low()
    if family == "zhipu":
        body = {
            "thinking": {"type": "enabled"},
            "reasoning_effort": effort,
        }
        return "low", body, f"zhipu low effort={effort}"
    if family == "siliconflow":
        body = {"reasoning_effort": effort}
        return "low", body, f"siliconflow low effort={effort}"
    if family == "local_openai":
        return "passthrough", {}, "local server omits cloud thinking params"
    if family == "qwen_compat":
        body = {"enable_thinking": True, "thinking_budget": 128}
        return "low", body, "qwen_compat low thinking_budget=128"
    body = {"reasoning_effort": effort}
    return "low", body, f"openai_compat reasoning_effort={effort}"


def plan_thinking_body(
    api_base: str,
    *,
    preference: Optional[str] = None,
    capability: Optional[str] = None,
    model: Optional[str] = None,
) -> Tuple[str, Dict[str, Any], str]:
    """Return (mode_label, extra_body, reason).

    capability transitions:
      None -> try preferred mode (low or off)
      low_rejected -> fall back to off (enable_thinking=False)
      off_rejected -> fall back to low (if untried) or bare
      bare -> omit thinking extra_body
    """
    pref = preference or env_thinking_preference(api_base=api_base, model=model)
    family = api_family(api_base)
    sf_glm53 = uses_siliconflow_glm53_reasoning(api_base, model)
    reason_bits = [f"family={family}", f"pref={pref}"]
    if model:
        reason_bits.append(f"model={model}")

    if capability == "bare" or family == "local_openai":
        return "passthrough", {}, "; ".join(reason_bits + ["omit thinking params"])

    if capability == "off_ok":
        body = {"thinking": {"type": "disabled"}} if family == "zhipu" else {"enable_thinking": False}
        return "off", body, "; ".join(reason_bits + ["cached off_ok"])

    if capability == "low_ok":
        mode, body, detail = _low_reasoning_body(family)
        return mode, body, "; ".join(reason_bits + [detail, "cached low_ok"])

    if sf_glm53 and pref != "off" and capability != "low_rejected":
        mode, body, detail = _low_reasoning_body("siliconflow")
        return mode, body, "; ".join(reason_bits + [detail, "glm53 always-on"])

    if pref == "low":
        if capability != "low_rejected":
            mode, body, detail = _low_reasoning_body(family)
            return mode, body, "; ".join(reason_bits + [detail])
        # low was rejected -> try explicit disable before going bare.
        body = {"thinking": {"type": "disabled"}} if family == "zhipu" else {"enable_thinking": False}
        return "off", body, "; ".join(reason_bits + ["low rejected -> try off"])

    if pref == "off":
        if capability != "off_rejected":
            body = {"thinking": {"type": "disabled"}} if family == "zhipu" else {"enable_thinking": False}
            return "off", body, "; ".join(reason_bits + ["try explicit disable"])
        mode, body, detail = _low_reasoning_body(family)
        return mode, body, "; ".join(reason_bits + ["off rejected -> try low", detail])

    # pref == "auto": try off first, then low, then bare.
    if capability != "off_rejected":
        body = {"thinking": {"type": "disabled"}} if family == "zhipu" else {"enable_thinking": False}
        return "off", body, "; ".join(reason_bits + ["auto first: disable"])
    if capability != "low_rejected":
        mode, body, detail = _low_reasoning_body(family)
        return mode, body, "; ".join(reason_bits + ["auto fallback: low", detail])
    return "passthrough", {}, "; ".join(reason_bits + ["bare fallback"])


_THINKING_ERR_RE = re.compile(
    r"(?:unknown|invalid|unsupported|not support|unexpected|unrecognized|"
    r"not allowed|not permitted|does not support).{0,100}"
    r"(?:thinking|enable_thinking|thinking_budget|reasoning_effort|reasoning|extra_body)"
    r"|(?:thinking|enable_thinking|thinking_budget|reasoning_effort|extra_body).{0,100}"
    r"(?:unknown|invalid|unsupported|not support|unexpected|unrecognized|"
    r"not allowed|not permitted|does not support)"
    r"|1210|思考|不支持关闭",
    re.I,
)


def is_thinking_param_error(exc: BaseException) -> bool:
    msg = str(exc or "")
    return bool(_THINKING_ERR_RE.search(msg))


def demote_capability(current: Optional[str], tried_mode: str) -> str:
    """Update capability after a thinking-param rejection without loops."""
    if tried_mode == "low":
        return "bare" if current == "off_rejected" else "low_rejected"
    if tried_mode == "off":
        return "bare" if current == "low_rejected" else "off_rejected"
    return "bare"


_TOKEN_OVERRIDE_WARNED = False

_CHANNEL_ENV_OVERRIDES = {
    CHANNEL_SIGNAL_VISION: "VLM_SIGNAL_VISION_MAX_TOKENS",
    CHANNEL_LON: "VLM_LON_MAX_TOKENS",
    CHANNEL_LAT: "VLM_LAT_MAX_TOKENS",
    CHANNEL_SIG: "VLM_LON_MAX_TOKENS",
}


def max_tokens_for_channel(channel: str, thinking_mode: str) -> int:
    """Return the per-task token budget."""
    global _TOKEN_OVERRIDE_WARNED
    raw = os.environ.get("VLM_MAX_TOKENS", os.environ.get("VLM_MAX_TOKEN", ""))
    if raw is not None and str(raw).strip() != "" and not _TOKEN_OVERRIDE_WARNED:
        print(
            "[VLM] Ignoring VLM_MAX_TOKENS/VLM_MAX_TOKEN for per-task budgets "
            f"(saw {raw!r}); use VLM_SIGNAL_VISION_MAX_TOKENS / "
            "VLM_LON_MAX_TOKENS / VLM_LAT_MAX_TOKENS instead.",
            flush=True,
        )
        _TOKEN_OVERRIDE_WARNED = True

    ch = normalize_channel(channel)
    env_name = _CHANNEL_ENV_OVERRIDES.get(ch)
    if env_name:
        env_raw = os.environ.get(env_name, "")
        if env_raw is not None and str(env_raw).strip() != "":
            try:
                override = int(str(env_raw).strip())
            except (TypeError, ValueError, OverflowError):
                override = 0
            if override > 0:
                return int(override)

    mode = str(thinking_mode or "off").strip().lower()
    if mode in ("off", "disabled"):
        return int(_OFF_CAPS[ch])
    if mode in ("low", "min", "minimal", "enabled_low"):
        return int(_LOW_CAPS[ch])
    return int(_LOW_CAPS[ch])


@dataclass
class ThinkingRuntime:
    """Thread-safe per-encoder cache of what the live API accepted."""

    capability: Optional[str] = None
    last_mode: str = "off"
    last_reason: str = ""
    last_extra_body: Dict[str, Any] = field(default_factory=dict)
    reject_log: list = field(default_factory=list)
    model: Optional[str] = None
    _lock: Any = field(default_factory=threading.RLock, repr=False, compare=False)

    def plan(
        self, api_base: str, *, model: Optional[str] = None
    ) -> Tuple[str, Dict[str, Any], str]:
        with self._lock:
            if model is not None:
                self.model = model
            mode, body, reason = plan_thinking_body(
                api_base, capability=self.capability, model=self.model
            )
            self.last_mode = mode
            self.last_reason = reason
            self.last_extra_body = dict(body)
            return mode, body, reason

    def on_param_rejected(self, api_base: str, tried_mode: str, exc: BaseException):
        with self._lock:
            self.reject_log.append(
                f"{tried_mode}:{type(exc).__name__}:{str(exc)[:160]}"
            )
            del self.reject_log[:-50]
            self.capability = demote_capability(self.capability, tried_mode)
            return self.plan(api_base, model=self.model)

    def on_success(self, mode: str):
        with self._lock:
            if mode == "off":
                self.capability = "off_ok"
            elif mode == "low":
                self.capability = "low_ok"
            self.last_mode = mode
