"""Offline BEV painter for VLM (state dict + static net geometry only).

Thread-safety / TraCI contract (training):
- Drawing uses OpenCV + optional PIL only. Do **not** import matplotlib /
  ``pyplot`` / global ``plt.*`` (not thread-safe for background VLM workers).
- Never call ``traci.*``. Render from the passed ``state`` snapshot and caches
  built at ``configure_scenario`` / first background build.
"""
import os
import xml.etree.ElementTree as ET

import cv2
import numpy as np

DEFAULT_JUNCTION_CENTER = (700.0, 700.0)
CONTROL_ZONE_METERS = 300.0
SUMO_CAR_LENGTH = 5.0
SUMO_CAR_WIDTH = 1.8

# BGR stop-bar colors for TLS R/Y/G (vivid on asphalt).
# Approach signal bars must never be white — unknown/off → red.
TLS_COLOR_RED = (40, 40, 245)
TLS_COLOR_YELLOW = (0, 220, 255)
TLS_COLOR_GREEN = (40, 210, 55)
TLS_COLOR_OFF = TLS_COLOR_RED  # legacy alias; do not paint white on approaches

# Classic 4-phase TLS (cross.net.xml A0): EW thru → EW left → NS thru → NS left
# (each green followed by yellow). Each approach has exclusive R / S / L lanes.
# Stop bar is split into 2 segments:
#   thru_right = lane0 right + lane1 straight
#   left       = lane2 protected left
# Link indices are even-only (0,2,4,…); color priority G/g > y/Y > r/R.
APPROACH_STOP_GROUPS = {
    # North approach top0A0 (southbound): lane0@692 right, lane1@695.2 thru, lane2@698.4 left
    'N': {'thru_right': (0, 2), 'left': (4,)},
    # East approach right0A0 (westbound): lane0@708 right, lane1@704.8 thru, lane2@701.6 left
    'E': {'thru_right': (6, 8), 'left': (10,)},
    # South approach bottom0A0 (northbound): lane0@708 right, lane1@704.8 thru, lane2@701.6 left
    'S': {'thru_right': (12, 14), 'left': (16,)},
    # West approach left0A0 (eastbound): lane0@692 right, lane1@695.2 thru, lane2@698.4 left
    'W': {'thru_right': (18, 20), 'left': (22,)},
}

# SUMO heading (deg): 0=N, 90=E, 180=S, 270=W — matches approach travel direction.
APPROACH_HEADING = {
    'N': 180.0,  # top0A0 southbound
    'E': 270.0,  # right0A0 westbound
    'S': 0.0,    # bottom0A0 northbound
    'W': 90.0,   # left0A0 eastbound
}

DUBLIN_NET_REL = os.path.join(
    '..', 'environment', 'sumo open model dublin jan 2026', 'dublin3.net.xml'
)
DUBLIN_JUNCTION_CENTER = (9446.71, 4073.57)
# Near-junction approach edges (lane counts from dublin3.net.xml):
# E 610330470#0×3, S 610330469#0×2, W 768402570#0×3, N 3819238#1×1
DUBLIN_APPROACH_EDGES = {
    'E': '610330470#0',
    'S': '610330469#0',
    'W': '768402570#0',
    'N': '3819238#1',
}
# Current dublin3 TLS stop grouping (layout fallback for the cross drawer).
DUBLIN_STOP_GROUPS = {
    'E': {'thru_right': (0, 1), 'left': (2,)},
    'S': {'thru_right': (3, 4), 'left': ()},
    'W': {'thru_right': (5, 6, 7), 'left': ()},
    'N': {'thru_right': (8,), 'left': ()},
}


def _default_net_path():
    here = os.path.abspath(os.path.dirname(__file__))
    return os.path.abspath(os.path.join(here, '..', 'environment', 'sumo_net', 'cross', 'cross.net.xml'))


def _dublin_net_path():
    here = os.path.abspath(os.path.dirname(__file__))
    return os.path.abspath(os.path.join(here, DUBLIN_NET_REL))

def _make_arrow_sprite(kind='straight', size=64):
    """
    Thin pavement arrow (sample-style): white glyph on transparent canvas.
    kind: straight | left | right
    Points UP (heading 0 / north) in image coords (y decreases upward in world).
    """
    canvas = np.zeros((size, size, 4), dtype=np.uint8)
    cx = size // 2
    # Stem: thin vertical bar
    stem_w = max(2, size // 18)
    stem_top = int(size * 0.38)
    stem_bot = int(size * 0.88)
    cv2.rectangle(
        canvas,
        (cx - stem_w, stem_top),
        (cx + stem_w, stem_bot),
        (245, 245, 248, 255),
        -1,
        lineType=cv2.LINE_AA,
    )
    # Arrow head
    tip = (cx, int(size * 0.12))
    if kind == 'straight':
        left = (cx - int(size * 0.22), int(size * 0.42))
        right = (cx + int(size * 0.22), int(size * 0.42))
        pts = np.asarray([tip, left, right], dtype=np.int32)
    elif kind == 'left':
        # turn-left: tip bends left
        tip = (int(size * 0.18), int(size * 0.22))
        mid = (cx, int(size * 0.22))
        base_l = (cx - stem_w, stem_top)
        base_r = (cx + stem_w, stem_top)
        wing = (int(size * 0.18), int(size * 0.42))
        pts = np.asarray([tip, mid, base_r, base_l, wing], dtype=np.int32)
        # redraw stem only lower part
        canvas[:] = 0
        cv2.rectangle(
            canvas, (cx - stem_w, int(size * 0.28)), (cx + stem_w, stem_bot),
            (245, 245, 248, 255), -1, lineType=cv2.LINE_AA,
        )
        # L-shaped head
        cv2.rectangle(
            canvas, (int(size * 0.18), int(size * 0.18)), (cx + stem_w, int(size * 0.28)),
            (245, 245, 248, 255), -1, lineType=cv2.LINE_AA,
        )
        head = np.asarray([
            (int(size * 0.10), int(size * 0.23)),
            (int(size * 0.32), int(size * 0.08)),
            (int(size * 0.32), int(size * 0.38)),
        ], dtype=np.int32)
        cv2.fillConvexPoly(canvas, head, (245, 245, 248, 255), lineType=cv2.LINE_AA)
        return canvas
    else:  # right
        canvas[:] = 0
        cv2.rectangle(
            canvas, (cx - stem_w, int(size * 0.28)), (cx + stem_w, stem_bot),
            (245, 245, 248, 255), -1, lineType=cv2.LINE_AA,
        )
        cv2.rectangle(
            canvas, (cx - stem_w, int(size * 0.18)), (int(size * 0.82), int(size * 0.28)),
            (245, 245, 248, 255), -1, lineType=cv2.LINE_AA,
        )
        head = np.asarray([
            (int(size * 0.90), int(size * 0.23)),
            (int(size * 0.68), int(size * 0.08)),
            (int(size * 0.68), int(size * 0.38)),
        ], dtype=np.int32)
        cv2.fillConvexPoly(canvas, head, (245, 245, 248, 255), lineType=cv2.LINE_AA)
        return canvas

    cv2.fillConvexPoly(canvas, pts, (245, 245, 248, 255), lineType=cv2.LINE_AA)
    return canvas


class BEVRenderer:
    """SUMO-like BEV with thin lane arrows, junction connectors, lane-centered cars."""

    def __init__(self, width=1024, height=1024, map_range=None, net_xml_path=None,
                 layout='cross', junction_center=None, n_lanes=None, junc_half=None):
        self.width = width
        self.height = height
        self.map_range = float(map_range if map_range is not None else 90.0)
        self.scale = self.width / (self.map_range * 2)
        self.bg_cache = None
        self._bg_center = None
        self.layout = layout  # 'cross' | 'dublin'
        self._default_center = junction_center or (
            DUBLIN_JUNCTION_CENTER if layout == 'dublin' else DEFAULT_JUNCTION_CENTER
        )
        if net_xml_path:
            self.net_xml_path = net_xml_path
        elif layout == 'dublin':
            self.net_xml_path = _dublin_net_path()
        else:
            self.net_xml_path = _default_net_path()
        self._lane_shapes = None  # id -> list[(x,y)]
        self._lane_meta = None    # id -> {edge, index, width, shape, internal}
        self._edge_to_lanes = None  # edge_id -> [lane_id by index]
        self._lane_upstream = None  # dest lane id -> preferred upstream lane id
        self._lane_turn_dirs = {}   # lane_id -> set of connection dir chars ('l','r','s')
        self._lefthand_net = False
        self._approach_lane_links = {}  # edge_id -> tuple of linkIndex tuples by lane
        self._junction_shapes = None  # list of junction polygons [(x,y), ...]
        self._internal_lanes = None
        self._edge_lanes = None  # non-internal lane shapes near junction
        self._draw_shape_cache = {}

        self.lane_w = 3.2
        self.n_lanes = int(n_lanes if n_lanes is not None else (2 if layout == 'dublin' else 3))
        self.junc_half = float(
            junc_half if junc_half is not None else (16.0 if layout == 'dublin' else 13.6)
        )
        # Dublin: GUI-matched geometry. Car size stays fixed (no queue shrink);
        # tight queues are spaced by nudging along the lane instead.
        self.road_vis_scale = 1.0
        self.half_road = self.n_lanes * self.lane_w * self.road_vis_scale
        # Dublin style (`_dublin_bev_preview.jpg`): modest median gap + dashed
        # double-line look between opposing directions.
        self.median_half = 0.7 if layout == 'dublin' else 0.45
        self._base_median_half = float(self.median_half)
        # Full canonical SUMO length in BEV (do not shrink sprites in queues).
        self.car_vis_scale = 1.0 if layout == 'dublin' else 0.92
        self.car_width_scale = 0.95 if layout == 'dublin' else 1.0
        # Minimum clear longitudinal gap (m) between drawn bodies in a queue.
        # Keep a visible seam even under heavy congestion (no body overlap).
        self.car_min_gap_m = 1.6
        # CAV gap to the vehicle ahead (tighter than HDV; HDV uses car_min_gap_m).
        self.car_min_gap_cav_m = 0.9
        # Lateral gate (m): only separate pairs closer than this cross-track.
        self.car_sep_lateral_m = 2.2
        # Optional per-edge lateral nudge (m to the RIGHT of travel). Keep empty
        # when cars already snap to the draw-centerline (dense-queue packing).
        self.edge_car_lateral_nudge_m = {}
        # Extra lateral separation between opposing carriageways (metres each side).
        # Set >0 for OSM nets that abut (four_four / three_four).
        self.opposing_spread_m = 0.0
        self._edge_lateral_shift = {}  # eid -> (dx, dy) world metres
        self.gui_bg_path = None  # optional explicit SUMO-GUI screenshot path
        self.junction_name = None  # optional HUD label (intersection name)
        self._stop_groups = (
            DUBLIN_STOP_GROUPS if layout == 'dublin' else APPROACH_STOP_GROUPS
        )
        self.approach_edges = dict(DUBLIN_APPROACH_EDGES) if layout == 'dublin' else {}

        # Thin arrow sprites (sample-style pavement markings)
        asset_dir = os.path.join(os.path.dirname(__file__), 'assets', 'arrows')
        os.makedirs(asset_dir, exist_ok=True)
        self._arrows = {}
        for kind in ('straight', 'left', 'right'):
            path = os.path.join(asset_dir, f'{kind}.png')
            if os.path.isfile(path):
                spr = cv2.imread(path, cv2.IMREAD_UNCHANGED)
            else:
                spr = _make_arrow_sprite(kind, size=72)
                cv2.imwrite(path, spr)
            if spr is not None and spr.shape[-1] == 3:
                # add opaque alpha
                a = np.full(spr.shape[:2] + (1,), 255, dtype=np.uint8)
                spr = np.concatenate([spr, a], axis=-1)
            self._arrows[kind] = spr

    def configure_scenario(self, net_xml_path=None, junction_center=None, approach_edges=None):
        """Bind net + camera center (+ optional approach edges) for the active scenario."""
        if net_xml_path and os.path.isfile(net_xml_path):
            self.net_xml_path = os.path.abspath(net_xml_path)
            self._lane_shapes = None
            self._lane_meta = None
            self._edge_to_lanes = None
            self._lane_upstream = None
            self._lane_turn_dirs = {}
            self._lefthand_net = False
            self._approach_lane_links = {}
            self._junction_shapes = None
            self._internal_lanes = None
            self._edge_lanes = None
            self._draw_shape_cache = {}
            self.bg_cache = None
            self._bg_center = None
        if junction_center is not None and len(junction_center) >= 2:
            self._default_center = (float(junction_center[0]), float(junction_center[1]))
            self.bg_cache = None
            self._bg_center = None
        if isinstance(approach_edges, dict) and approach_edges:
            edge_map = {}
            for k, v in approach_edges.items():
                if isinstance(v, (list, tuple)):
                    eid = v[0] if v else None
                else:
                    eid = v
                if eid:
                    edge_map[str(k)] = str(eid)
            if edge_map:
                # Instance-only; never mutate module-global DUBLIN_APPROACH_EDGES.
                self.approach_edges = edge_map
        # Align FOV with GUI screenshot meta for this junction center.
        cx, cy = self._default_center
        self._sync_map_range_from_gui_meta(cx, cy)

    def _sync_map_range_from_gui_meta(self, cx, cy):
        """If a GUI bg meta matches center, adopt its map_range (usually 90)."""
        for path in self._gui_bg_candidates(cx, cy):
            if not os.path.isfile(path):
                continue
            meta_path = os.path.splitext(path)[0] + '_meta.txt'
            if not os.path.isfile(meta_path):
                continue
            try:
                with open(meta_path, 'r', encoding='utf-8') as f:
                    parts = f.read().strip().split()
                captured_range = float(parts[0])
                if len(parts) >= 3:
                    mcx, mcy = float(parts[1]), float(parts[2])
                    if abs(mcx - cx) > 0.5 or abs(mcy - cy) > 0.5:
                        continue
                if abs(captured_range - self.map_range) > 1e-6:
                    self.map_range = float(captured_range)
                    self.scale = self.width / (self.map_range * 2)
                    self.bg_cache = None
                    self._bg_center = None
                return True
            except (ValueError, OSError, IndexError):
                continue
        return False

    def _load_lanes(self):
        if self._lane_shapes is not None:
            return
        self._lane_shapes = {}
        self._lane_meta = {}
        self._edge_to_lanes = {}
        self._lane_upstream = {}
        self._lane_turn_dirs = {}
        self._lefthand_net = False
        self._approach_lane_links = {}
        self._junction_shapes = []
        self._internal_lanes = []
        self._edge_lanes = []
        self._draw_shape_cache = {}
        if not os.path.isfile(self.net_xml_path):
            return
        root = ET.parse(self.net_xml_path).getroot()
        self._lefthand_net = str(root.get('lefthand', 'false')).strip().lower() in ('true', '1', 'yes')
        for edge in root.findall('edge'):
            eid = edge.get('id', '')
            internal = eid.startswith(':') or edge.get('function') == 'internal'
            lane_ids = []
            for lane in edge.findall('lane'):
                lid = lane.get('id', '')
                shape = lane.get('shape')
                if not shape:
                    continue
                pts = []
                for pair in shape.split():
                    xs, ys = pair.split(',')
                    pts.append((float(xs), float(ys)))
                if len(pts) < 2:
                    continue
                width = float(lane.get('width') or self.lane_w)
                idx = int(lane.get('index') or 0)
                self._lane_shapes[lid] = pts
                self._lane_meta[lid] = {
                    'edge': eid,
                    'index': idx,
                    'width': width,
                    'shape': pts,
                    'internal': internal or lid.startswith(':'),
                }
                lane_ids.append(lid)
                if internal or lid.startswith(':'):
                    self._internal_lanes.append(pts)
                else:
                    self._edge_lanes.append(pts)
            if lane_ids:
                lane_ids.sort(key=lambda x: self._lane_meta[x]['index'])
                self._edge_to_lanes[eid] = lane_ids
        # Corridor predecessors for short approach stubs (610330469#0 → E6, …).
        # Prefer chaining through the SUMO ``via`` internal lane so mini-junctions
        # (1425220694 / 5238330328 / 5238330336) stay occupied in dense queues
        # instead of teleporting across the connector gap.
        # Skip u-turns (dir=t).
        for conn in root.findall('connection'):
            fr = conn.get('from') or ''
            to = conn.get('to') or ''
            if not fr or not to or fr.startswith(':') or to.startswith(':'):
                continue
            d = (conn.get('dir') or 's').lower()
            if d == 't':
                continue
            from_lids = self._edge_to_lanes.get(fr) or []
            to_lids = self._edge_to_lanes.get(to) or []
            if not from_lids or not to_lids:
                continue
            try:
                fl = int(conn.get('fromLane') or 0)
                tl = int(conn.get('toLane') or 0)
            except (TypeError, ValueError):
                continue
            if fl < 0 or tl < 0 or fl >= len(from_lids) or tl >= len(to_lids):
                continue
            to_lid = to_lids[tl]
            from_lid = from_lids[fl]
            self._lane_turn_dirs.setdefault(from_lid, set()).add(d)
            via = (conn.get('via') or '').strip()
            via_lid = None
            if via:
                if via in self._lane_meta:
                    via_lid = via
                else:
                    via_lids = self._edge_to_lanes.get(via) or []
                    if via_lids:
                        # Internal edge: pick lane index matching fromLane when possible.
                        via_lid = via_lids[fl] if fl < len(via_lids) else via_lids[0]
            # to ← via ← from  (or to ← from if no via)
            pred_for_to = via_lid or from_lid
            prev = self._lane_upstream.get(to_lid)
            if prev is None or d == 's':
                self._lane_upstream[to_lid] = pred_for_to
            if via_lid:
                prev_via = self._lane_upstream.get(via_lid)
                if prev_via is None or d == 's':
                    self._lane_upstream[via_lid] = from_lid
        # TLS controlled links: edge → per-lane linkIndex tuples (3/4/5-leg).
        edge_lane_links = {}
        for conn in root.findall('connection'):
            if conn.get('tl') is None:
                continue
            raw_li = conn.get('linkIndex')
            if raw_li is None:
                continue
            fr = conn.get('from') or ''
            if not fr or fr.startswith(':'):
                continue
            try:
                link_i = int(raw_li)
                fl = int(conn.get('fromLane') or 0)
            except (TypeError, ValueError):
                continue
            if fl < 0 or link_i < 0:
                continue
            by_lane = edge_lane_links.setdefault(fr, {})
            by_lane.setdefault(fl, []).append(link_i)
        for eid, by_lane in edge_lane_links.items():
            if not by_lane:
                continue
            max_i = max(by_lane.keys())
            lanes = []
            for i in range(max_i + 1):
                lanes.append(tuple(by_lane.get(i, [])))
            self._approach_lane_links[eid] = tuple(lanes)
        for junc in root.findall('junction'):
            shape = junc.get('shape')
            if not shape:
                continue
            pts = []
            for pair in shape.split():
                try:
                    xs, ys = pair.split(',')
                    pts.append((float(xs), float(ys)))
                except ValueError:
                    continue
            if len(pts) >= 3:
                self._junction_shapes.append(pts)

    @staticmethod
    def _polyline_normals(pts):
        """Unit left-hand normals at each vertex of a polyline."""
        pts = np.asarray(pts, dtype=np.float64)
        n = len(pts)
        tangents = np.zeros_like(pts)
        for i in range(n):
            if i == 0:
                d = pts[1] - pts[0]
            elif i == n - 1:
                d = pts[-1] - pts[-2]
            else:
                d = pts[i + 1] - pts[i - 1]
            L = float(np.hypot(d[0], d[1]))
            if L < 1e-9:
                tangents[i] = (1.0, 0.0)
            else:
                tangents[i] = d / L
        # Left normal of (tx,ty) is (-ty, tx)
        normals = np.column_stack([-tangents[:, 1], tangents[:, 0]])
        return normals

    @classmethod
    def _offset_polyline(cls, pts, dist):
        normals = cls._polyline_normals(pts)
        pts = np.asarray(pts, dtype=np.float64)
        return pts + normals * float(dist)

    @classmethod
    def _lane_asphalt_poly(cls, pts, width):
        """Closed polygon covering a lane ribbon (centerline ± half width)."""
        half = 0.5 * float(width)
        left = cls._offset_polyline(pts, half)
        right = cls._offset_polyline(pts, -half)
        return np.vstack([left, right[::-1]])

    def _vis_lane_shape(self, meta):
        """Lane centerline with optional lateral spread for Dublin BEV."""
        shape = meta['shape']
        if self.road_vis_scale <= 1.0 + 1e-9 or meta.get('internal'):
            return shape
        eid = meta.get('edge')
        lids = (self._edge_to_lanes or {}).get(eid) or []
        n = len(lids)
        if n <= 1:
            return shape
        mid = 0.5 * (n - 1)
        # index 0 = rightmost; +left-normal moves toward higher indices
        extra = float(meta.get('width', self.lane_w)) * (self.road_vis_scale - 1.0)
        dist = (int(meta.get('index', 0)) - mid) * extra
        if abs(dist) < 1e-9:
            return shape
        return self._offset_polyline(shape, dist)

    def _w2p(self, x, y, cx, cy):
        px = int(round((x - cx + self.map_range) * self.scale))
        py = int(round((self.map_range - (y - cy)) * self.scale))
        return px, py

    def _px(self, meters):
        return max(1, int(round(meters * self.scale)))

    def _resolve_center(self, state, center_x, center_y):
        if center_x is not None and center_y is not None:
            return float(center_x), float(center_y)
        return self._default_center
    def _fill_rect(self, img, x0, y0, x1, y1, cx, cy, color):
        p0 = self._w2p(min(x0, x1), max(y0, y1), cx, cy)
        p1 = self._w2p(max(x0, x1), min(y0, y1), cx, cy)
        cv2.rectangle(img, p0, p1, color, thickness=-1, lineType=cv2.LINE_AA)

    def _line(self, img, x0, y0, x1, y1, cx, cy, color, thickness=1, dashed=False):
        if not dashed:
            cv2.line(
                img, self._w2p(x0, y0, cx, cy), self._w2p(x1, y1, cx, cy),
                color, thickness, lineType=cv2.LINE_AA,
            )
            return
        self._dashed_polyline(
            img, [(x0, y0), (x1, y1)], cx, cy, color, thickness
        )

    def _dashed_polyline(
        self, img, pts, cx, cy, color, thickness=1, dash=3.0, gap=4.5
    ):
        """Draw a dashed polyline with continuous dash phase along the whole path."""
        if pts is None or len(pts) < 2:
            return
        rem = 0.0  # leftover distance into current dash/gap cycle
        draw = True
        for i in range(len(pts) - 1):
            x0, y0 = float(pts[i][0]), float(pts[i][1])
            x1, y1 = float(pts[i + 1][0]), float(pts[i + 1][1])
            seg_len = float(np.hypot(x1 - x0, y1 - y0))
            if seg_len < 1e-6:
                continue
            dx, dy = (x1 - x0) / seg_len, (y1 - y0) / seg_len
            pos = 0.0
            while pos < seg_len - 1e-9:
                period = dash if draw else gap
                take = min(seg_len - pos, period - rem)
                if draw and take > 1e-6:
                    cv2.line(
                        img,
                        self._w2p(x0 + dx * pos, y0 + dy * pos, cx, cy),
                        self._w2p(x0 + dx * (pos + take), y0 + dy * (pos + take), cx, cy),
                        color, thickness, lineType=cv2.LINE_AA,
                    )
                pos += take
                rem += take
                if rem >= period - 1e-9:
                    rem = 0.0
                    draw = not draw

    def _solid_polyline(self, img, pts, cx, cy, color, thickness=1):
        if pts is None or len(pts) < 2:
            return
        pix = np.asarray(
            [self._w2p(float(x), float(y), cx, cy) for x, y in pts],
            dtype=np.int32,
        ).reshape((-1, 1, 2))
        cv2.polylines(img, [pix], False, color, thickness, lineType=cv2.LINE_AA)

    def _edge_mean_heading(self, eid):
        """SUMO heading (0=N, 90=E) along edge travel direction."""
        lids = (self._edge_to_lanes or {}).get(eid) or []
        if not lids:
            return 0.0
        shape = np.asarray(
            self._draw_shape_for_lane(self._lane_meta[lids[0]]), dtype=np.float64
        )
        if len(shape) < 2:
            return 0.0
        i = max(0, len(shape) // 2 - 1)
        dx = float(shape[i + 1][0] - shape[i][0])
        dy = float(shape[i + 1][1] - shape[i][1])
        return float((np.degrees(np.arctan2(dx, dy)) + 360.0) % 360.0)

    def _lane_side_sign_toward(self, sa, sb):
        """+1 if left-normal of sa points toward sb, else -1."""
        if len(sa) < 2 or len(sb) < 2:
            return 1.0
        ia, ib = len(sa) // 2, len(sb) // 2
        n = self._polyline_normals(sa)[ia]
        toward = np.asarray(sb[ib], dtype=np.float64) - np.asarray(sa[ia], dtype=np.float64)
        return 1.0 if float(np.dot(n, toward)) >= 0.0 else -1.0

    def _edge_left_right_outers(self, eid):
        """Return (left_outer, right_outer) polylines for an edge (travel frame)."""
        lids = (self._edge_to_lanes or {}).get(eid) or []
        metas = [self._lane_meta[l] for l in lids if l in self._lane_meta]
        if not metas:
            return None, None
        shapes = [
            np.asarray(self._draw_shape_for_lane(m), dtype=np.float64) for m in metas
        ]
        halves = [0.5 * float(m['width']) * self.road_vis_scale for m in metas]
        if len(metas) >= 2:
            # SUMO index 0 = rightmost; higher index is to the left of travel.
            sgn = self._lane_side_sign_toward(shapes[0], shapes[1])
            right = self._offset_polyline(shapes[0], -sgn * halves[0])
            left = self._offset_polyline(shapes[-1], sgn * halves[-1])
        else:
            right = self._offset_polyline(shapes[0], -halves[0])
            left = self._offset_polyline(shapes[0], halves[0])
        return left, right

    def _find_opposing_edge_pairs(self, cx, cy, rmax):
        """Pair dual-carriageway edges (opposite heading, close & parallel)."""
        eids = []
        for eid, lids in (self._edge_to_lanes or {}).items():
            if eid.startswith(':'):
                continue
            metas = [self._lane_meta[l] for l in lids if l in self._lane_meta]
            if not metas:
                continue
            if not any(
                abs(x - cx) <= rmax and abs(y - cy) <= rmax
                for m in metas for x, y in m['shape']
            ):
                continue
            eids.append(eid)

        pairs = []
        used = set()
        for i, a in enumerate(eids):
            if a in used:
                continue
            ha = self._edge_mean_heading(a)
            la, _ra = self._edge_left_right_outers(a)
            if la is None or len(la) < 2:
                continue
            best_b, best_score = None, 1e18
            for b in eids[i + 1:]:
                if b in used:
                    continue
                hb = self._edge_mean_heading(b)
                dhopp = abs(ha - hb) % 360.0
                dhopp = min(dhopp, 360.0 - dhopp)
                if abs(dhopp - 180.0) > 40.0:
                    continue
                lb, _rb = self._edge_left_right_outers(b)
                if lb is None or len(lb) < 2:
                    continue
                mind = 1e18
                lo, hi = len(la) // 5, 4 * len(la) // 5
                step_a = max(1, (hi - lo) // 40)
                step_b = max(1, len(lb) // 30)
                for p in la[lo:hi:step_a]:
                    for j in range(0, len(lb) - 1, step_b):
                        d, _ = self._dist_point_to_seg(
                            float(p[0]), float(p[1]), lb[j], lb[j + 1]
                        )
                        if d < mind:
                            mind = d
                if mind > 8.0:
                    continue
                score = mind + 0.02 * abs(dhopp - 180.0)
                if score < best_score:
                    best_score, best_b = score, b
            if best_b is not None:
                pairs.append((a, best_b))
                used.add(a)
                used.add(best_b)
        return pairs

    def _paint_median_between_edges(
        self, img, eid_a, eid_b, cx, cy, median_color, white, t_solid
    ):
        """Carve a gray median strip with solid white borders between opposing edges."""
        la, _ = self._edge_left_right_outers(eid_a)
        lb, _ = self._edge_left_right_outers(eid_b)
        if la is None or lb is None or len(la) < 2 or len(lb) < 2:
            return
        la = np.asarray(la, dtype=np.float64)
        lb = np.asarray(lb, dtype=np.float64)
        # Opposing edges run opposite ways — align so index 0 is the same end.
        if float(np.hypot(*(la[0] - lb[0]))) > float(np.hypot(*(la[0] - lb[-1]))):
            lb = lb[::-1].copy()

        def _resamp(pts, n):
            pts = np.asarray(pts, dtype=np.float64)
            seg = np.linalg.norm(np.diff(pts, axis=0), axis=1)
            total = float(np.sum(seg))
            if total < 1e-6:
                return np.repeat(pts[:1], n, axis=0)
            u = np.concatenate([[0.0], np.cumsum(seg)]) / total
            uu = np.linspace(0.0, 1.0, n)
            return np.column_stack([
                np.interp(uu, u, pts[:, 0]),
                np.interp(uu, u, pts[:, 1]),
            ])

        n = int(np.clip(max(len(la), len(lb)), 64, 240))
        la_s = _resamp(la, n)
        lb_s = _resamp(lb, n)
        mid = 0.5 * (la_s + lb_s)
        clear = max(20.0, self.junc_half * 1.4)
        keep = [
            i for i, p in enumerate(mid)
            if float(np.hypot(float(p[0]) - cx, float(p[1]) - cy)) > clear
        ]
        if len(keep) < 4:
            return
        runs = []
        run = [keep[0]]
        for i in keep[1:]:
            if i == run[-1] + 1:
                run.append(i)
            else:
                if len(run) >= 4:
                    runs.append(run)
                run = [i]
        if len(run) >= 4:
            runs.append(run)

        mh = float(self.median_half)
        for run in runs:
            seg = mid[run[0]:run[-1] + 1]
            if len(seg) < 4:
                continue
            left = self._offset_polyline(seg, mh)
            right = self._offset_polyline(seg, -mh)
            poly = np.vstack([left, right[::-1]])
            pix = np.asarray(
                [self._w2p(float(x), float(y), cx, cy) for x, y in poly],
                dtype=np.int32,
            ).reshape((-1, 1, 2))
            cv2.fillPoly(img, [pix], median_color, lineType=cv2.LINE_AA)
            # Dublin template: opposing separator reads as double dashed lines.
            self._dashed_polyline(
                img, left, cx, cy, white, t_solid, dash=3.0, gap=4.5
            )
            self._dashed_polyline(
                img, right, cx, cy, white, t_solid, dash=3.0, gap=4.5
            )

    def _blit_arrow(self, img, world_x, world_y, heading_deg, kind, cx, cy, scale_m=2.8):
        """Paste thin arrow sprite centered in lane, rotated to traffic heading."""
        spr = self._arrows.get(kind)
        if spr is None:
            return
        # Sprite points UP (image -y). SUMO heading 0 = north = image up → rotate by -heading.
        target_h = max(8, int(scale_m * self.scale))
        aspect = spr.shape[0] / max(spr.shape[1], 1)
        target_w = max(6, int(target_h / aspect * 0.55))
        resized = cv2.resize(spr, (target_w, target_h), interpolation=cv2.INTER_AREA)

        # Rotate so tip follows traffic direction
        angle = -float(heading_deg)  # cv2 rotate is CCW; map heading clockwise from north
        h, w = resized.shape[:2]
        M = cv2.getRotationMatrix2D((w / 2.0, h / 2.0), angle, 1.0)
        cos = abs(M[0, 0])
        sin = abs(M[0, 1])
        nW = int(h * sin + w * cos)
        nH = int(h * cos + w * sin)
        M[0, 2] += (nW / 2) - w / 2
        M[1, 2] += (nH / 2) - h / 2
        rotated = cv2.warpAffine(
            resized, M, (nW, nH),
            flags=cv2.INTER_LINEAR,
            borderMode=cv2.BORDER_CONSTANT,
            borderValue=(0, 0, 0, 0),
        )

        px, py = self._w2p(world_x, world_y, cx, cy)
        rh, rw = rotated.shape[:2]
        x0, y0 = px - rw // 2, py - rh // 2
        x1, y1 = x0 + rw, y0 + rh
        if x1 <= 0 or y1 <= 0 or x0 >= img.shape[1] or y0 >= img.shape[0]:
            return
        # clip
        sx0 = max(0, -x0)
        sy0 = max(0, -y0)
        sx1 = rw - max(0, x1 - img.shape[1])
        sy1 = rh - max(0, y1 - img.shape[0])
        dx0, dy0 = max(0, x0), max(0, y0)
        patch = rotated[sy0:sy1, sx0:sx1]
        if patch.size == 0:
            return
        alpha = patch[:, :, 3:4].astype(np.float32) / 255.0
        roi = img[dy0:dy0 + patch.shape[0], dx0:dx0 + patch.shape[1]]
        if roi.shape[:2] != patch.shape[:2]:
            return
        blended = (alpha * patch[:, :, :3] + (1.0 - alpha) * roi).astype(np.uint8)
        img[dy0:dy0 + patch.shape[0], dx0:dx0 + patch.shape[1]] = blended

    @staticmethod
    def _chaikin_subdivide(world_pts, iterations=2):
        """Corner-cutting densify — softens SUMO's few-vertex polylines."""
        pts = [np.asarray(p, dtype=np.float64) for p in world_pts]
        if len(pts) < 2:
            return np.asarray(pts, dtype=np.float64)
        for _ in range(max(0, int(iterations))):
            new = [pts[0]]
            for i in range(len(pts) - 1):
                p, q = pts[i], pts[i + 1]
                new.append(0.75 * p + 0.25 * q)
                new.append(0.25 * p + 0.75 * q)
            new.append(pts[-1])
            pts = new
        return np.asarray(pts, dtype=np.float64)

    @classmethod
    def _smooth_polyline(cls, world_pts, n_samples=72, chaikin=2):
        """Chaikin + spline resample for smoother junction / merge curves."""
        pts = np.asarray(world_pts, dtype=np.float64)
        if len(pts) < 2:
            return pts
        # Remember exact endpoints so smoothed ribbons still dock to neighbours.
        p0 = pts[0].copy()
        p1 = pts[-1].copy()
        if chaikin > 0 and len(pts) >= 2:
            pts = cls._chaikin_subdivide(pts, iterations=chaikin)
        if len(pts) == 2:
            t = np.linspace(0.0, 1.0, max(2, n_samples // 4))
            out = (1.0 - t)[:, None] * pts[0] + t[:, None] * pts[1]
            out[0], out[-1] = p0, p1
            return out
        dist = np.cumsum(np.r_[0.0, np.linalg.norm(np.diff(pts, axis=0), axis=1)])
        if dist[-1] < 1e-6:
            return pts
        dist /= dist[-1]
        keep = np.ones(len(dist), dtype=bool)
        keep[1:] = np.diff(dist) > 1e-9
        dist, pts = dist[keep], pts[keep]
        if len(pts) < 2:
            return np.asarray(world_pts, dtype=np.float64)
        k = int(min(3, len(pts) - 1))
        try:
            from scipy.interpolate import make_interp_spline
            spl_x = make_interp_spline(dist, pts[:, 0], k=k)
            spl_y = make_interp_spline(dist, pts[:, 1], k=k)
            uu = np.linspace(0.0, 1.0, max(n_samples, 8))
            out = np.column_stack([spl_x(uu), spl_y(uu)])
        except Exception:
            out = [pts[0]]
            for i in range(len(pts) - 1):
                for s in np.linspace(0.0, 1.0, 8, endpoint=False)[1:]:
                    out.append((1.0 - s) * pts[i] + s * pts[i + 1])
                out.append(pts[i + 1])
            out = np.asarray(out, dtype=np.float64)
        out[0], out[-1] = p0, p1
        return out

    def _draw_shape_for_lane(self, meta, n_samples=None):
        """Visually-spread centerline, smoothed for drawing (cached per lane)."""
        eid = meta.get('edge')
        shift = (self._edge_lateral_shift or {}).get(eid, (0.0, 0.0))
        key = (
            eid,
            int(meta.get('index', 0)),
            bool(meta.get('internal')),
            round(float(shift[0]), 3),
            round(float(shift[1]), 3),
        )
        cache = getattr(self, '_draw_shape_cache', None)
        if cache is None:
            self._draw_shape_cache = {}
            cache = self._draw_shape_cache
        if n_samples is None and key in cache:
            return cache[key]
        shape = self._vis_lane_shape(meta)
        if n_samples is None:
            length = 0.0
            for i in range(len(shape) - 1):
                length += float(np.hypot(
                    float(shape[i + 1][0]) - float(shape[i][0]),
                    float(shape[i + 1][1]) - float(shape[i][1]),
                ))
            n_samples = int(np.clip(length * 2.5, 48, 220))
            if meta.get('internal'):
                n_samples = max(n_samples, 120)
        out = self._smooth_polyline(shape, n_samples=n_samples, chaikin=3)
        sx, sy = float(shift[0]), float(shift[1])
        if abs(sx) + abs(sy) > 1e-9:
            out = np.asarray(out, dtype=np.float64).copy()
            out[:, 0] += sx
            out[:, 1] += sy
        if key is not None:
            cache[key] = out
        return out

    def _setup_opposing_spreads(self, cx, cy, rmax):
        """
        Optionally push opposing carriageways apart laterally, then return pairs.
        Clears shape cache so subsequent draws use the new shifts.
        """
        self._edge_lateral_shift = {}
        self._draw_shape_cache = {}
        pairs = self._find_opposing_edge_pairs(cx, cy, rmax)
        spread = float(getattr(self, 'opposing_spread_m', 0.0) or 0.0)
        if spread <= 1e-9 or not pairs:
            return pairs
        for a, b in pairs:
            lids_a = (self._edge_to_lanes or {}).get(a) or []
            lids_b = (self._edge_to_lanes or {}).get(b) or []
            if not lids_a or not lids_b:
                continue
            # Unshifted midpoints of each edge's lane pack (mean of lane centers).
            pts_a = []
            pts_b = []
            for lid in lids_a:
                sh = np.asarray(
                    self._smooth_polyline(
                        self._vis_lane_shape(self._lane_meta[lid]),
                        n_samples=48, chaikin=2,
                    ),
                    dtype=np.float64,
                )
                pts_a.append(sh[len(sh) // 2])
            for lid in lids_b:
                sh = np.asarray(
                    self._smooth_polyline(
                        self._vis_lane_shape(self._lane_meta[lid]),
                        n_samples=48, chaikin=2,
                    ),
                    dtype=np.float64,
                )
                pts_b.append(sh[len(sh) // 2])
            ca = np.mean(np.asarray(pts_a), axis=0)
            cb = np.mean(np.asarray(pts_b), axis=0)
            d = cb - ca
            L = float(np.hypot(d[0], d[1]))
            if L < 1e-3:
                # Fall back to left-normal of edge a travel.
                sh0 = np.asarray(
                    self._smooth_polyline(
                        self._vis_lane_shape(self._lane_meta[lids_a[0]]),
                        n_samples=48, chaikin=2,
                    ),
                    dtype=np.float64,
                )
                nrm = self._polyline_normals(sh0)[len(sh0) // 2]
                u = np.asarray(nrm, dtype=np.float64)
            else:
                u = d / L
            # Move each pack away from the other.
            self._edge_lateral_shift[a] = (-float(u[0]) * spread, -float(u[1]) * spread)
            self._edge_lateral_shift[b] = (float(u[0]) * spread, float(u[1]) * spread)
        self._draw_shape_cache = {}
        return pairs

    @staticmethod
    def _arc_frac_on_polyline(pts, x, y):
        """Arc-length fraction [0,1] of the closest point on polyline to (x,y)."""
        pts = np.asarray(pts, dtype=np.float64)
        if len(pts) < 2:
            return 0.0
        best_d, best_s = 1e18, 0.0
        seg_len = np.linalg.norm(np.diff(pts, axis=0), axis=1)
        total = float(np.sum(seg_len)) or 1.0
        acc = 0.0
        for i in range(len(pts) - 1):
            ax, ay = pts[i]
            bx, by = pts[i + 1]
            abx, aby = bx - ax, by - ay
            denom = abx * abx + aby * aby
            if denom < 1e-12:
                t, qx, qy = 0.0, ax, ay
            else:
                t = max(0.0, min(1.0, ((x - ax) * abx + (y - ay) * aby) / denom))
                qx, qy = ax + t * abx, ay + t * aby
            d = float(np.hypot(x - qx, y - qy))
            if d < best_d:
                best_d = d
                best_s = (acc + t * float(seg_len[i])) / total
            acc += float(seg_len[i])
        return best_s

    @staticmethod
    def _point_at_arc_frac(pts, frac):
        """Interpolate polyline point at arc-length fraction frac."""
        pts = np.asarray(pts, dtype=np.float64)
        if len(pts) < 2:
            return tuple(pts[0]) if len(pts) else (0.0, 0.0)
        frac = max(0.0, min(1.0, float(frac)))
        seg_len = np.linalg.norm(np.diff(pts, axis=0), axis=1)
        total = float(np.sum(seg_len))
        if total < 1e-9:
            return float(pts[0][0]), float(pts[0][1])
        target = frac * total
        acc = 0.0
        for i in range(len(pts) - 1):
            L = float(seg_len[i])
            if acc + L >= target - 1e-9 or i == len(pts) - 2:
                t = 0.0 if L < 1e-9 else (target - acc) / L
                t = max(0.0, min(1.0, t))
                x = pts[i][0] + t * (pts[i + 1][0] - pts[i][0])
                y = pts[i][1] + t * (pts[i + 1][1] - pts[i][1])
                return float(x), float(y)
            acc += L
        return float(pts[-1][0]), float(pts[-1][1])

    def _draw_junction_connectors(self, img, cx, cy):
        """Faint dashed turn guides inside the junction only (not on approaches)."""
        self._load_lanes()
        color = (210, 210, 215)
        thickness = max(1, self._px(0.12))
        # Strictly inside the junction plate — avoids solid strokes that
        # continue approach dividers and read as 虚实交织.
        junc_r = max(18.0, self.junc_half * 1.35)
        for shape in self._internal_lanes or []:
            if len(shape) < 2:
                continue
            near = [
                (x, y) for x, y in shape
                if abs(x - cx) <= junc_r and abs(y - cy) <= junc_r
            ]
            if len(near) < 2:
                continue
            # Require the guide to live mostly inside the junction.
            if len(near) < 0.6 * len(shape) and len(shape) > 4:
                continue
            n_samp = 96 if len(near) >= 3 else 32
            smooth = self._smooth_polyline(near, n_samples=n_samp, chaikin=3)
            self._dashed_polyline(
                img, smooth, cx, cy, color, thickness, dash=2.0, gap=2.5
            )

    def _build_background(self, cx, cy):
        if self.layout == 'dublin':
            # GUI screenshot for exact structure; recolor to gray palette.
            gui_bg = self._try_load_gui_background(cx, cy)
            if gui_bg is not None:
                return self._recolor_gui_to_gray(gui_bg)
            return self._build_background_from_net(cx, cy)
        return self._build_background_cross(cx, cy)

    def _gui_bg_candidates(self, cx, cy):
        """Candidate SUMO-GUI screenshot paths for this FOV / net."""
        renders = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'bev_renders'))
        bg_dir = os.path.join(renders, 'gui_backgrounds')
        explicit = getattr(self, 'gui_bg_path', None)
        out = []
        if explicit:
            out.append(os.path.abspath(explicit))
        # Stems match bev_renders/gui_backgrounds captures (meta centers below).
        # NOTE: cached screenshots are topology-bound; after widening 4/5-leg
        # their caches were removed so the renderer falls back to building the
        # background from the live net.xml (always correct).
        #   3leg: 6277.93, 1853.84  | 4leg: 9446.71, 4073.57
        #   xuancheng/5leg: 1130.16, 905.15
        stems = []
        if self.net_xml_path:
            base = os.path.basename(self.net_xml_path).lower()
            net_dir = os.path.basename(os.path.dirname(os.path.abspath(self.net_xml_path))).lower()
            if '5-leg' in net_dir or '5leg' in base or '34180200000479' in base or 'xuancheng' in base:
                stems = ['5leg_5phases', '5leg_4phases', 'xuancheng_34180200000479']
            elif '3-leg' in net_dir or '3leg' in base or '32471791' in base:
                stems = ['3leg_3phases', '3leg_2phases']
            elif '4-leg' in net_dir or '4leg' in base:
                stems = ['4leg_4phases', '4leg_3phases', '4leg_2phases']
        for d in (bg_dir, renders):
            for stem in stems:
                out.append(os.path.join(d, f'_gui_bg_{stem}.png'))
        if self.net_xml_path:
            net_dir = os.path.dirname(os.path.abspath(self.net_xml_path))
            out.append(os.path.join(net_dir, '_gui_bg.png'))
            out.append(os.path.join(net_dir, '_dublin_gui_bg.png'))
        # Legacy single-junction capture (±120 m at canonical Dublin center).
        if abs(cx - DUBLIN_JUNCTION_CENTER[0]) <= 0.05 and abs(cy - DUBLIN_JUNCTION_CENTER[1]) <= 0.05:
            out.append(os.path.join(renders, '_dublin_gui_bg.png'))
        # Deduplicate while preserving order.
        seen = set()
        uniq = []
        for p in out:
            ap = os.path.abspath(p)
            if ap in seen:
                continue
            seen.add(ap)
            uniq.append(ap)
        return uniq

    def _gui_bg_meta_ok(self, png_path, cx, cy):
        """Accept screenshot if meta matches FOV (and optionally center)."""
        meta_path = os.path.splitext(png_path)[0] + '_meta.txt'
        if not os.path.isfile(meta_path):
            # Legacy dublin file uses a shared meta next to it.
            legacy = os.path.abspath(os.path.join(
                os.path.dirname(__file__), '..', 'bev_renders', '_dublin_gui_bg_meta.txt'
            ))
            if os.path.basename(png_path) == '_dublin_gui_bg.png' and os.path.isfile(legacy):
                meta_path = legacy
            else:
                # No meta: only allow if FOV is the historical default.
                return abs(self.map_range - 120.0) <= 0.5
        try:
            with open(meta_path, 'r', encoding='utf-8') as f:
                parts = f.read().strip().split()
            captured_range = float(parts[0])
            if abs(captured_range - self.map_range) > 0.5:
                return False
            if len(parts) >= 3:
                mcx, mcy = float(parts[1]), float(parts[2])
                if abs(mcx - cx) > 0.5 or abs(mcy - cy) > 0.5:
                    return False
            return True
        except (ValueError, OSError):
            return False

    def _try_load_gui_background(self, cx, cy):
        """Load SUMO-GUI screenshot of the same FOV (exact GUI look)."""
        for path in self._gui_bg_candidates(cx, cy):
            if not os.path.isfile(path):
                continue
            if not self._gui_bg_meta_ok(path, cx, cy):
                continue
            img = cv2.imread(path, cv2.IMREAD_COLOR)
            if img is None:
                continue
            if img.shape[0] != self.height or img.shape[1] != self.width:
                img = cv2.resize(img, (self.width, self.height), interpolation=cv2.INTER_AREA)
            return img
        return None

    @staticmethod
    def _recolor_gui_to_gray(img):
        """Map SUMO-GUI white/black roads to gray bg + darker gray asphalt.

        Colored TLS glyphs from the GUI are replaced with asphalt so our own
        stop-bar overlay owns the signal colors. Do not dilate the road mask —
        that would paint white marks into medians/outer edges.
        """
        bg = np.array((142, 142, 142), dtype=np.uint8)
        road = np.array((92, 92, 94), dtype=np.uint8)
        mark = np.array((230, 230, 234), dtype=np.uint8)
        g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        b, gr, r = cv2.split(img)
        colorful = (
            (np.abs(r.astype(np.int16) - gr.astype(np.int16)) > 35)
            | (np.abs(b.astype(np.int16) - gr.astype(np.int16)) > 35)
            | (np.abs(r.astype(np.int16) - b.astype(np.int16)) > 35)
        )
        out = np.full_like(img, bg)
        road_mask = (g < 100) | colorful
        out[road_mask] = road
        # Lane paint on asphalt only (GUI white dashes / borders already on road).
        marks = (g > 140) & (g < 250) & (~colorful)
        # Keep marks only where they sit on/near asphalt (1px neighborhood).
        near_road = cv2.dilate(
            road_mask.astype(np.uint8), np.ones((3, 3), np.uint8), iterations=1
        ).astype(bool)
        mark_mask = (marks & near_road).astype(np.uint8)
        # Thicken dashed lane paint so it stays readable at ±90 m.
        mark_mask = cv2.dilate(mark_mask, np.ones((5, 5), np.uint8), iterations=2)
        mark_mask = mark_mask.astype(bool) & near_road
        out[mark_mask] = mark
        return out

    def _build_background_from_net(self, cx, cy):
        """Dublin BEV in the same pretty style as `_bev_pretty_preview.jpg`."""
        self._load_lanes()
        rmax = self.map_range + 25.0
        # Apply opposing-carriageway spread BEFORE asphalt / markings.
        opp_pairs = self._setup_opposing_spreads(cx, cy, rmax)
        base_mh = float(getattr(self, '_base_median_half', self.median_half))
        if float(getattr(self, 'opposing_spread_m', 0.0) or 0.0) > 1e-9:
            self.median_half = max(base_mh, 1.2)
        else:
            self.median_half = base_mh

        # Match cross pretty palette exactly.
        img = np.full((self.height, self.width, 3), (142, 142, 142), dtype=np.uint8)
        asphalt = (92, 92, 94)
        asphalt_junc = (98, 98, 100)
        white = (230, 230, 234)
        t_mark = max(2, self._px(0.28))  # same-direction dashed dividers (readable)

        # 0) Continuous junction plate (pretty-preview style) — convex hull so the
        #    cluster reads as one asphalt surface, not fragmented GUI islands.
        hull_pts = []
        hull_r = max(42.0, 28.0 * self.road_vis_scale)
        for jshape in self._junction_shapes or []:
            for x, y in jshape:
                if abs(x - cx) <= hull_r and abs(y - cy) <= hull_r:
                    hull_pts.append((x, y))
        for lid, meta in (self._lane_meta or {}).items():
            for x, y in meta['shape']:
                if abs(x - cx) <= hull_r and abs(y - cy) <= hull_r:
                    hull_pts.append((x, y))
        if len(hull_pts) >= 3:
            hp = np.asarray(hull_pts, dtype=np.float32).reshape((-1, 1, 2))
            hull = cv2.convexHull(hp)
            pix = np.asarray(
                [self._w2p(float(p[0][0]), float(p[0][1]), cx, cy) for p in hull],
                dtype=np.int32,
            ).reshape((-1, 1, 2))
            cv2.fillPoly(img, [pix], asphalt_junc, lineType=cv2.LINE_AA)

        for jshape in self._junction_shapes or []:
            if not any(abs(x - cx) <= rmax and abs(y - cy) <= rmax for x, y in jshape):
                continue
            js = np.asarray(jshape, dtype=np.float64)
            if len(js) >= 4:
                ring = np.vstack([js, js[0]])
                ring = self._smooth_polyline(ring, n_samples=max(64, len(js) * 4), chaikin=2)
                js = ring[:-1]
            pix = np.asarray(
                [self._w2p(float(x), float(y), cx, cy) for x, y in js],
                dtype=np.int32,
            ).reshape((-1, 1, 2))
            cv2.fillPoly(img, [pix], asphalt_junc, lineType=cv2.LINE_AA)

        for lid, meta in (self._lane_meta or {}).items():
            raw = self._vis_lane_shape(meta)
            if not any(abs(x - cx) <= rmax and abs(y - cy) <= rmax for x, y in raw):
                continue
            shape = self._draw_shape_for_lane(meta)
            w = float(meta.get('width', self.lane_w)) * self.road_vis_scale
            # Slight ribbon inflate like earlier pretty fills (covers abutting gaps).
            w *= 1.08 if meta.get('internal') else 1.04
            poly = self._lane_asphalt_poly(shape, w)
            pix = np.asarray(
                [self._w2p(float(x), float(y), cx, cy) for x, y in poly],
                dtype=np.int32,
            ).reshape((-1, 1, 2))
            color = asphalt_junc if meta.get('internal') else asphalt
            cv2.fillPoly(img, [pix], color, lineType=cv2.LINE_AA)

        # Pretty continuous asphalt: close residual cracks only (~1.2 m),
        # without heavily dilating the outer boundary (that made cars look
        # off-center relative to painted edges).
        bg = np.array((142, 142, 142), dtype=np.uint8)
        road_mask = np.any(img != bg, axis=2).astype(np.uint8) * 255
        seal_px = max(3, self._px(1.2))
        if seal_px % 2 == 0:
            seal_px += 1
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (seal_px, seal_px))
        sealed = cv2.morphologyEx(road_mask, cv2.MORPH_CLOSE, kernel)
        # Restore outer silhouette so seal only fills interior holes/gaps.
        outer = cv2.dilate(road_mask, kernel, iterations=1)
        sealed = cv2.bitwise_and(sealed, outer)
        sealed = cv2.bitwise_or(sealed, road_mask)
        fill = np.zeros_like(img)
        fill[:] = asphalt
        img = np.where(sealed[..., None] > 0, fill, img)

        median_color = (128, 128, 130)
        t_solid = max(2, self._px(0.22))
        t_mark = max(1, self._px(0.14))

        paired = set()
        for a, b in opp_pairs:
            paired.add(a)
            paired.add(b)
            self._paint_median_between_edges(
                img, a, b, cx, cy, median_color, white, t_solid
            )

        # Same-direction dashed dividers only (no outer solid curbs).
        for eid, lids in (self._edge_to_lanes or {}).items():
            if eid.startswith(':'):
                continue
            metas = [self._lane_meta[l] for l in lids if l in self._lane_meta]
            if not metas:
                continue
            if not any(
                abs(x - cx) <= rmax and abs(y - cy) <= rmax
                for m in metas for x, y in m['shape']
            ):
                continue

            for a, b in zip(metas, metas[1:]):
                sa = np.asarray(self._draw_shape_for_lane(a), dtype=np.float64)
                sb = np.asarray(self._draw_shape_for_lane(b), dtype=np.float64)
                if len(sa) < 2 or len(sb) < 2:
                    continue
                sign = self._lane_side_sign_toward(sa, sb)
                half = 0.5 * float(a['width']) * self.road_vis_scale
                divider = self._offset_polyline(sa, sign * half)
                self._dashed_polyline(
                    img, divider, cx, cy, white, t_mark, dash=3.0, gap=4.5
                )

        # Junction internal guides (same thin pale lines as cross pretty).
        self._draw_junction_connectors(img, cx, cy)

        # Pavement arrows resolved from real net.xml <connection dir> + LHT/RHT fallback.
        approach_edges = self.approach_edges or DUBLIN_APPROACH_EDGES
        for cardinal, eid in approach_edges.items():
            lids = (self._edge_to_lanes or {}).get(eid) or []
            if self._lefthand_net:
                fallback_kinds = ('left', 'straight') if len(lids) <= 2 else ('left', 'straight', 'right')
            else:
                fallback_kinds = ('right', 'straight') if len(lids) <= 2 else ('right', 'straight', 'left')
            for i, lid in enumerate(lids):
                meta = self._lane_meta.get(lid)
                if not meta:
                    continue
                shape = self._draw_shape_for_lane(meta)
                end_i = self._near_junction_end_index(shape, cx, cy)
                ax, ay, heading = self._point_back_along(shape, end_i, dist=10.0)
                dirs = (self._lane_turn_dirs or {}).get(lid) or set()
                if 's' in dirs:
                    kind = 'straight'
                elif 'l' in dirs and 'r' not in dirs:
                    kind = 'left'
                elif 'r' in dirs and 'l' not in dirs:
                    kind = 'right'
                else:
                    kind = fallback_kinds[min(i, len(fallback_kinds) - 1)]
                self._blit_arrow(
                    img, ax, ay, heading, kind, cx, cy,
                    scale_m=2.6 * max(1.0, self.road_vis_scale * 0.85),
                )

        return img


    @staticmethod
    def _near_junction_end_index(shape, cx, cy):
        """Index of polyline end closer to junction center."""
        d0 = (shape[0][0] - cx) ** 2 + (shape[0][1] - cy) ** 2
        d1 = (shape[-1][0] - cx) ** 2 + (shape[-1][1] - cy) ** 2
        return len(shape) - 1 if d1 <= d0 else 0

    @staticmethod
    def _point_back_along(shape, end_i, dist=10.0):
        """Point and SUMO heading `dist` metres upstream of the stop end."""
        if end_i == 0:
            upstream = list(shape)          # stop = shape[0], walk toward shape[-1]
        else:
            upstream = list(reversed(shape))  # stop = shape[-1], walk toward shape[0]
        rem = float(dist)
        x, y = float(upstream[0][0]), float(upstream[0][1])
        for i in range(len(upstream) - 1):
            x0, y0 = upstream[i]
            x1, y1 = upstream[i + 1]
            seg = float(np.hypot(x1 - x0, y1 - y0))
            if seg < 1e-6:
                continue
            if rem <= seg:
                t = rem / seg
                x = x0 + (x1 - x0) * t
                y = y0 + (y1 - y0) * t
                break
            rem -= seg
            x, y = float(x1), float(y1)
        # Travel toward junction: from upstream[1] → upstream[0] (stop)
        if len(upstream) >= 2:
            dx = float(upstream[0][0] - upstream[1][0])
            dy = float(upstream[0][1] - upstream[1][1])
        else:
            dx, dy = 0.0, 1.0
        heading = (np.degrees(np.arctan2(dx, dy)) + 360.0) % 360.0
        return x, y, float(heading)

    def _approach_stop_geometry(self, eid, cx, cy):
        """Return list of (lane_index, stop_xy, tangent_into_junction, half_width)."""
        self._load_lanes()
        out = []
        for lid in (self._edge_to_lanes or {}).get(eid) or []:
            meta = self._lane_meta.get(lid)
            if not meta:
                continue
            # GUI-matched: true net centerlines.
            shape = meta['shape']
            end_i = self._near_junction_end_index(shape, cx, cy)
            stop = shape[end_i]
            if end_i == 0:
                nxt = shape[min(1, len(shape) - 1)]
                tx, ty = float(stop[0] - nxt[0]), float(stop[1] - nxt[1])
            else:
                prv = shape[max(0, len(shape) - 2)]
                tx, ty = float(stop[0] - prv[0]), float(stop[1] - prv[1])
            L = float(np.hypot(tx, ty)) or 1.0
            tx, ty = tx / L, ty / L
            out.append((
                meta['index'], (float(stop[0]), float(stop[1])), (tx, ty),
                0.5 * meta['width'] * self.road_vis_scale,
            ))
        return out

    def _build_background_cross(self, cx, cy):
        img = np.full((self.height, self.width, 3), (142, 142, 142), dtype=np.uint8)
        asphalt = (92, 92, 94)
        asphalt_junc = (98, 98, 100)
        median = (128, 128, 130)
        white = (230, 230, 234)
        edge = (210, 210, 214)

        jh = self.junc_half
        hr = self.half_road
        mh = self.median_half
        arm = self.map_range * 0.99

        self._fill_rect(img, cx - hr, cy - arm, cx + hr, cy + arm, cx, cy, asphalt)
        self._fill_rect(img, cx - arm, cy - hr, cx + arm, cy + hr, cx, cy, asphalt)
        self._fill_rect(img, cx - jh, cy - jh, cx + jh, cy + jh, cx, cy, asphalt_junc)

        self._fill_rect(img, cx - mh, cy + jh, cx + mh, cy + arm, cx, cy, median)
        self._fill_rect(img, cx - mh, cy - arm, cx + mh, cy - jh, cx, cy, median)
        self._fill_rect(img, cx + jh, cy - mh, cx + arm, cy + mh, cx, cy, median)
        self._fill_rect(img, cx - arm, cy - mh, cx - jh, cy + mh, cx, cy, median)

        # Junction internal connectors (like first BEV version / net.xml internals)
        self._draw_junction_connectors(img, cx, cy)

        t_edge = self._px(0.18)
        t_mark = max(1, self._px(0.12))
        for s in (-1, 1):
            self._line(img, cx + s * hr, cy - arm, cx + s * hr, cy + arm, cx, cy, edge, t_edge)
            self._line(img, cx - arm, cy + s * hr, cx + arm, cy + s * hr, cx, cy, edge, t_edge)
            self._line(img, cx + s * mh, cy + jh, cx + s * mh, cy + arm, cx, cy, white, t_mark)
            self._line(img, cx + s * mh, cy - arm, cx + s * mh, cy - jh, cx, cy, white, t_mark)
            self._line(img, cx + jh, cy + s * mh, cx + arm, cy + s * mh, cx, cy, white, t_mark)
            self._line(img, cx - arm, cy + s * mh, cx - jh, cy + s * mh, cx, cy, white, t_mark)

        # Exact approach lane centers from cross.net.xml (A0 at 700,700).
        # Lane index 0 = right, 1 = straight, 2 = left (exclusive movements).
        # top0A0 SB:     692.0, 695.2, 698.4   heading 180
        # bottom0A0 NB:  708.0, 704.8, 701.6   heading 0
        # left0A0 EB:    692.0, 695.2, 698.4   heading 90
        # right0A0 WB:   708.0, 704.8, 701.6   heading 270
        sb_x = [692.0, 695.2, 698.4]
        nb_x = [708.0, 704.8, 701.6]
        eb_y = [692.0, 695.2, 698.4]
        wb_y = [708.0, 704.8, 701.6]
        # Dashed dividers between same-direction lanes
        sb_bounds = [693.6, 696.8]
        nb_bounds = [706.4, 703.2]
        eb_bounds = [693.6, 696.8]
        wb_bounds = [706.4, 703.2]
        for x in sb_bounds + nb_bounds:
            self._line(img, x, cy + jh + 1.0, x, cy + arm, cx, cy, white, t_mark, True)
            self._line(img, x, cy - arm, x, cy - jh - 1.0, cx, cy, white, t_mark, True)
        for y in eb_bounds + wb_bounds:
            self._line(img, cx + jh + 1.0, y, cx + arm, y, cx, cy, white, t_mark, True)
            self._line(img, cx - arm, y, cx - jh - 1.0, y, cx, cy, white, t_mark, True)

        st = max(2, self._px(0.35))
        # Departure-side stop bars stay white; approach bars are painted in render()
        # from live TLS state (red/yellow/green).
        self._line(img, 700.0 + mh, cy + jh, 709.6, cy + jh, cx, cy, white, st)  # N depart
        self._line(img, 690.4, cy - jh, 700.0 - mh, cy - jh, cx, cy, white, st)  # S depart
        self._line(img, cx + jh, 690.4, cx + jh, 700.0 - mh, cx, cy, white, st)  # E depart
        self._line(img, cx - jh, 700.0 + mh, cx - jh, 709.6, cx, cy, white, st)  # W depart

        kinds = ('right', 'straight', 'left')
        gap = 9.0
        for i, x in enumerate(sb_x):
            self._blit_arrow(img, x, cy + jh + gap, APPROACH_HEADING['N'], kinds[i], cx, cy)
        for i, x in enumerate(nb_x):
            self._blit_arrow(img, x, cy - jh - gap, APPROACH_HEADING['S'], kinds[i], cx, cy)
        for i, y in enumerate(eb_y):
            self._blit_arrow(img, cx - jh - gap, y, APPROACH_HEADING['W'], kinds[i], cx, cy)
        for i, y in enumerate(wb_y):
            self._blit_arrow(img, cx + jh + gap, y, APPROACH_HEADING['E'], kinds[i], cx, cy)
        return img

    def _snap_to_lane_center(self, vinfo):
        """Project vehicle onto the *drawn* lane centerline so cars sit mid-lane."""
        self._load_lanes()
        pos = vinfo.get('position')
        if pos is None or len(pos) < 2:
            return None
        x, y = float(pos[0]), float(pos[1])
        lane_id = vinfo.get('lane')
        meta = self._lane_meta.get(lane_id) if lane_id else None
        # Match painted asphalt / dashed dividers (smoothed visual centerline).
        if meta is not None:
            shape = self._draw_shape_for_lane(meta)
        else:
            shape = None
        if shape is None or len(shape) < 2:
            best, best_d = None, 1e18
            for pts in (self._lane_shapes or {}).values():
                for i in range(len(pts) - 1):
                    d, q = self._dist_point_to_seg(x, y, pts[i], pts[i + 1])
                    if d < best_d:
                        best_d, best = d, q
            return best if best is not None and best_d < 4.0 else (x, y)

        best, best_d, best_i = None, 1e18, 0
        for i in range(len(shape) - 1):
            d, q = self._dist_point_to_seg(x, y, shape[i], shape[i + 1])
            if d < best_d:
                best_d, best, best_i = d, q, i
        if best is None:
            return (x, y)
        # Align heading with local lane tangent (SUMO: 0=N, 90=E), but keep the
        # same travel sense as the original angle. A 180° flip would shift the
        # front-bumper → center correction the wrong way and stack cars nose-to-tail.
        a, b = shape[best_i], shape[min(best_i + 1, len(shape) - 1)]
        dx = float(b[0]) - float(a[0])
        dy = float(b[1]) - float(a[1])
        lane_angle = float(vinfo.get('angle', 0.0) or 0.0)
        if abs(dx) + abs(dy) > 1e-9:
            lane_angle = float((np.degrees(np.arctan2(dx, dy)) + 360.0) % 360.0)
            try:
                orig = float(vinfo.get('angle', lane_angle))
            except (TypeError, ValueError):
                orig = lane_angle
            delta = abs((lane_angle - orig + 180.0) % 360.0 - 180.0)
            if delta > 90.0:
                lane_angle = (lane_angle + 180.0) % 360.0
            vinfo['angle'] = lane_angle
        return best

    def _apply_edge_lateral_nudge(self, x, y, angle_deg, lane_id):
        """Shift right-of-travel for edges whose painted mid ≠ net centerline."""
        nudge_map = getattr(self, 'edge_car_lateral_nudge_m', None) or {}
        if not nudge_map:
            return float(x), float(y)
        eid = None
        meta = (self._lane_meta or {}).get(lane_id) if lane_id else None
        if meta is not None:
            eid = meta.get('edge')
        if eid is None and lane_id and '_' in str(lane_id):
            eid = str(lane_id).rsplit('_', 1)[0]
        nudge = float(nudge_map.get(eid, 0.0) or 0.0) if eid else 0.0
        if abs(nudge) <= 1e-9:
            return float(x), float(y)
        th = np.radians(float(angle_deg))
        rx, ry = float(np.cos(th)), float(-np.sin(th))
        return float(x) + nudge * rx, float(y) + nudge * ry

    @staticmethod
    def _dist_point_to_seg(px, py, a, b):
        ax, ay = a
        bx, by = b
        abx, aby = bx - ax, by - ay
        denom = abx * abx + aby * aby
        if denom < 1e-9:
            q = (ax, ay)
            return float(np.hypot(px - ax, py - ay)), q
        t = max(0.0, min(1.0, ((px - ax) * abx + (py - ay) * aby) / denom))
        qx, qy = ax + t * abx, ay + t * aby
        return float(np.hypot(px - qx, py - qy)), (qx, qy)

    def _xf(self, px, py, sin_t, cos_t, f, r):
        return int(round(px + f * sin_t + r * cos_t)), int(round(py - f * cos_t + r * sin_t))

    def _poly(self, px, py, sin_t, cos_t, pts):
        return np.asarray(
            [list(self._xf(px, py, sin_t, cos_t, f, r)) for f, r in pts],
            dtype=np.int32,
        )

    @staticmethod
    def _tls_char_color(ch):
        """Map one SUMO RYG char to approach-bar BGR. Only R / Y / G (never white)."""
        if not ch:
            return TLS_COLOR_RED
        c = str(ch).lower()
        if c == 'g':
            return TLS_COLOR_GREEN
        # y = yellow; u = red+yellow; s = stop-go / minor yellow-like
        if c in ('y', 'u', 's'):
            return TLS_COLOR_YELLOW
        # r = red; o = off / dark — show as red on the stop bar
        if c in ('r', 'o'):
            return TLS_COLOR_RED
        return TLS_COLOR_RED

    @classmethod
    def _lane_tls_color(cls, ry_g_state, link_indices):
        """Most-permissive color among a lane's controlling links (G > Y > R)."""
        if not ry_g_state or not link_indices:
            return TLS_COLOR_RED
        rank = {'g': 3, 'y': 2, 'u': 2, 's': 2, 'r': 1, 'o': 1}
        best_ch, best_rank = 'r', 0
        n = len(ry_g_state)
        for idx in link_indices:
            if idx < 0 or idx >= n:
                continue
            ch = ry_g_state[idx]
            r = rank.get(str(ch).lower(), 0)
            if r > best_rank:
                best_rank, best_ch = r, ch
        if best_rank <= 0:
            return TLS_COLOR_RED
        return cls._tls_char_color(best_ch)

    def _draw_signal_stop_bars(self, img, cx, cy, state):
        """Paint each approach stop bar as thru/right + left segments (R/Y/G)."""
        signals = (state or {}).get('signals') or {}
        tls = None
        if signals:
            prefer = (
                'GS_cluster_1417055450_2663809951_5238330325_5238330332'
                if self.layout == 'dublin' else 'A0'
            )
            tls = signals.get(prefer) or signals.get('A0') or next(
                iter(signals.values()), None
            )
        ry_g = ''
        if isinstance(tls, dict):
            ry_g = str(tls.get('state') or tls.get('ryg_state') or tls.get('ryg') or '')
        elif isinstance(tls, str):
            ry_g = tls
        jh = self.junc_half
        mh = self.median_half
        st = max(3, self._px(0.55))
        gap = 0.7
        groups = self._stop_groups

        if self.layout == 'dublin':
            # Slim colored bars — readable without covering lane paint.
            # Same approach: one shared stop line (mean tangent + junction-nearest
            # longitudinal plane); abutting segments so colors sit flush.
            st = max(2, self._px(0.40))
            bar_pull_m = 0.4
            self._load_lanes()
            approach_edges = self.approach_edges or DUBLIN_APPROACH_EDGES
            for _cardinal, eid in approach_edges.items():
                lane_links = (self._approach_lane_links or {}).get(eid)
                if not lane_links:
                    continue
                lanes = list(self._approach_stop_geometry(eid, cx, cy))
                if not lanes:
                    continue
                tx = float(np.mean([t[0] for _i, _s, t, _w in lanes]))
                ty = float(np.mean([t[1] for _i, _s, t, _w in lanes]))
                tL = float(np.hypot(tx, ty)) or 1.0
                tx, ty = tx / tL, ty / tL
                nx, ny = -ty, tx
                ref_i = int(np.argmin([
                    (s[0] - cx) ** 2 + (s[1] - cy) ** 2
                    for _i, s, _t, _w in lanes
                ]))
                s_ref = lanes[ref_i][1]
                along_ref = (s_ref[0] - cx) * tx + (s_ref[1] - cy) * ty
                # Origin of the shared stop line (lat = 0), pulled upstream.
                ox = cx + along_ref * tx - tx * bar_pull_m
                oy = cy + along_ref * ty - ty * bar_pull_m

                segs = []
                for lane_i, stop, _tangent, half_w in lanes:
                    lat = (stop[0] - cx) * nx + (stop[1] - cy) * ny
                    links = lane_links[lane_i] if lane_i < len(lane_links) else ()
                    color = self._lane_tls_color(ry_g, links)
                    segs.append((lat, float(half_w), color))
                segs.sort(key=lambda x: x[0])

                for i, (lat, half_w, color) in enumerate(segs):
                    if i == 0:
                        lat0 = lat - half_w * 0.95
                    else:
                        lat0 = 0.5 * (segs[i - 1][0] + lat)
                    if i == len(segs) - 1:
                        lat1 = lat + half_w * 0.95
                    else:
                        lat1 = 0.5 * (lat + segs[i + 1][0])
                    x0 = ox + lat0 * nx
                    y0 = oy + lat0 * ny
                    x1 = ox + lat1 * nx
                    y1 = oy + lat1 * ny
                    self._line(img, x0, y0, x1, y1, cx, cy, color, st)
            return

        # Cross layout (absolute coords for A0 @ 700,700)
        split_nw = 696.8
        split_se = 703.2

        c_tr = self._lane_tls_color(ry_g, groups['N']['thru_right'])
        c_lt = self._lane_tls_color(ry_g, groups['N']['left'])
        self._line(img, 690.4, cy + jh, split_nw - gap, cy + jh, cx, cy, c_tr, st)
        self._line(img, split_nw + gap, cy + jh, 700.0 - mh, cy + jh, cx, cy, c_lt, st)

        c_tr = self._lane_tls_color(ry_g, groups['S']['thru_right'])
        c_lt = self._lane_tls_color(ry_g, groups['S']['left'])
        self._line(img, split_se + gap, cy - jh, 709.6, cy - jh, cx, cy, c_tr, st)
        self._line(img, 700.0 + mh, cy - jh, split_se - gap, cy - jh, cx, cy, c_lt, st)

        c_tr = self._lane_tls_color(ry_g, groups['E']['thru_right'])
        c_lt = self._lane_tls_color(ry_g, groups['E']['left'])
        self._line(img, cx + jh, split_se + gap, cx + jh, 709.6, cx, cy, c_tr, st)
        self._line(img, cx + jh, 700.0 + mh, cx + jh, split_se - gap, cx, cy, c_lt, st)

        c_tr = self._lane_tls_color(ry_g, groups['W']['thru_right'])
        c_lt = self._lane_tls_color(ry_g, groups['W']['left'])
        self._line(img, cx - jh, 690.4, cx - jh, split_nw - gap, cx, cy, c_tr, st)
        self._line(img, cx - jh, split_nw + gap, cx - jh, 700.0 - mh, cx, cy, c_lt, st)

    def _draw_sumo_car(self, img, px, py, angle_deg, is_cav=False, length_m=None):
        # Shape switch: VLM/vehicle_visual_config.json (suv | classic).
        # Original drawer backed up under backups/vehicle_visual/.
        # Colors stay HDV white / CAV orange either way.
        from VLM.vehicle_shape import draw_sumo_car as _draw_vehicle

        _draw_vehicle(
            self, img, px, py, angle_deg, is_cav=is_cav, length_m=length_m
        )

    def _draw_hud_label(self, img, state):
        """Top-left: junction name + simulation time (single white pass)."""
        name = (
            (state or {}).get('junction_name')
            or getattr(self, 'junction_name', None)
            or ''
        )
        name = str(name).strip()
        stats = (state or {}).get('stats') or {}
        t = stats.get('time', None)
        if t is None:
            t = (state or {}).get('sim_time', None)
        if name and t is not None:
            label = f"{name}  t={float(t):.1f}s"
        elif name:
            label = name
        elif t is not None:
            label = f"t={float(t):.1f}s"
        else:
            return
        # PIL + system sans font: open '0' (no Hershey slash), one white pass.
        self._blit_hud_text(img, label, x=16, y=10, size=22)

    @staticmethod
    def _blit_hud_text(img, label, x=16, y=10, size=22):
        """Draw a single clean white HUD string (open zeros, no outline)."""
        try:
            from PIL import Image, ImageDraw, ImageFont
        except ImportError:
            cv2.putText(
                img, label, (x, y + size),
                cv2.FONT_HERSHEY_DUPLEX, 0.58, (250, 250, 252), 1, cv2.LINE_AA,
            )
            return
        font = None
        for path in (
            r"C:\Windows\Fonts\segoeui.ttf",
            r"C:\Windows\Fonts\arial.ttf",
            r"C:\Windows\Fonts\calibri.ttf",
            "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
            "/System/Library/Fonts/Helvetica.ttc",
        ):
            if os.path.isfile(path):
                try:
                    font = ImageFont.truetype(path, size)
                    break
                except OSError:
                    continue
        if font is None:
            font = ImageFont.load_default()
        rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        pil = Image.fromarray(rgb)
        draw = ImageDraw.Draw(pil)
        draw.text((x, y), label, font=font, fill=(250, 250, 252))
        img[:, :, :] = cv2.cvtColor(np.asarray(pil), cv2.COLOR_RGB2BGR)

    def _shift_front_to_center(self, x, y, angle_deg, half_len_m, lane_id=None, cx=None, cy=None):
        """
        SUMO position = middle of front bumper; sprite is center-based.
        Prefer shifting back along the lane centerline (keeps curved edges like
        34180201816 / E6 mid-lane); fall back to straight heading.
        """
        half_len_m = float(half_len_m)
        if half_len_m <= 1e-9:
            return float(x), float(y)
        if lane_id and (self._lane_meta or {}).get(lane_id) is not None:
            info = self._lane_station_and_point(lane_id, float(x), float(y))
            if info is not None:
                s, _xs, _ys, sang = info
                th = np.radians(float(angle_deg))
                p0 = self._lane_point_on_polyline(lane_id, s)
                p1 = self._lane_point_on_polyline(lane_id, s + 0.5)
                if p0 is not None and p1 is not None:
                    sx, sy = p1[0] - p0[0], p1[1] - p0[1]
                    align = float(np.sin(th) * sx + np.cos(th) * sy)
                    # Center is half_len behind the front bumper along travel.
                    s_c = s - half_len_m if align >= 0.0 else s + half_len_m
                    resolved = self._resolve_lane_station(lane_id, s_c)
                    if resolved is not None:
                        return float(resolved[2]), float(resolved[3])
        theta = np.radians(float(angle_deg))
        return (
            float(x) - half_len_m * float(np.sin(theta)),
            float(y) - half_len_m * float(np.cos(theta)),
        )

    def _lane_station_and_point(self, lane_id, x, y):
        """Project (x,y) onto lane draw-centerline → (s_m, x, y, angle_deg).

        Extrapolates past either end (negative / >L stations). Clamping to the
        endpoints would stack every overflow car on s=0 after dense packing —
        the failure mode on 3leg ``10575471#2`` (dead-end upstream).
        """
        self._load_lanes()
        meta = (self._lane_meta or {}).get(lane_id)
        if meta is None:
            return None
        shape = np.asarray(self._draw_shape_for_lane(meta), dtype=np.float64)
        if len(shape) < 2:
            return None
        xy = np.asarray([float(x), float(y)], dtype=np.float64)
        best_d, best_i, best_t, best_q = 1e18, 0, 0.0, shape[0]
        for i in range(len(shape) - 1):
            a, b = shape[i], shape[i + 1]
            ab = b - a
            denom = float(np.dot(ab, ab))
            t = 0.0 if denom < 1e-12 else float(
                np.clip(np.dot(xy - a, ab) / denom, 0.0, 1.0)
            )
            q = a + t * ab
            d = float(np.hypot(xy[0] - q[0], xy[1] - q[1]))
            if d < best_d:
                best_d, best_i, best_t, best_q = d, i, t, q
        # Arc length of clamped projection.
        s = 0.0
        for i in range(best_i):
            s += float(np.hypot(shape[i + 1][0] - shape[i][0], shape[i + 1][1] - shape[i][1]))
        seg = shape[best_i + 1] - shape[best_i]
        seg_len = float(np.hypot(seg[0], seg[1]))
        s += best_t * seg_len
        if abs(seg[0]) + abs(seg[1]) < 1e-9 and best_i > 0:
            seg = shape[best_i] - shape[best_i - 1]
            seg_len = float(np.hypot(seg[0], seg[1]))
        ang = float((np.degrees(np.arctan2(seg[0], seg[1])) + 360.0) % 360.0)

        # Beyond start: allow s < 0 along first-segment direction.
        if best_i == 0 and best_t <= 1e-9:
            seg0 = shape[1] - shape[0]
            len0 = float(np.hypot(seg0[0], seg0[1]))
            if len0 > 1e-12:
                ux, uy = float(seg0[0] / len0), float(seg0[1] / len0)
                along = float((xy[0] - shape[0][0]) * ux + (xy[1] - shape[0][1]) * uy)
                if along < 0.0:
                    qx = float(shape[0][0] + along * ux)
                    qy = float(shape[0][1] + along * uy)
                    ang0 = float((np.degrees(np.arctan2(seg0[0], seg0[1])) + 360.0) % 360.0)
                    return along, qx, qy, ang0

        # Beyond end: allow s > L along last-segment direction.
        total = float(np.sum(np.linalg.norm(np.diff(shape, axis=0), axis=1)))
        if best_i >= len(shape) - 2 and best_t >= 1.0 - 1e-9:
            seg1 = shape[-1] - shape[-2]
            len1 = float(np.hypot(seg1[0], seg1[1]))
            if len1 > 1e-12:
                ux, uy = float(seg1[0] / len1), float(seg1[1] / len1)
                along = float((xy[0] - shape[-1][0]) * ux + (xy[1] - shape[-1][1]) * uy)
                if along > 0.0:
                    qx = float(shape[-1][0] + along * ux)
                    qy = float(shape[-1][1] + along * uy)
                    ang1 = float((np.degrees(np.arctan2(seg1[0], seg1[1])) + 360.0) % 360.0)
                    return total + along, qx, qy, ang1

        return s, float(best_q[0]), float(best_q[1]), ang

    def _lane_polyline_length(self, lane_id):
        """Arc length (m) of a lane's draw-centerline."""
        self._load_lanes()
        meta = (self._lane_meta or {}).get(lane_id)
        if meta is None:
            return 0.0
        shape = np.asarray(self._draw_shape_for_lane(meta), dtype=np.float64)
        if len(shape) < 2:
            return 0.0
        return float(
            np.sum(np.linalg.norm(np.diff(shape, axis=0), axis=1))
        )

    def _lane_point_on_polyline(self, lane_id, s_m):
        """Pose on a single lane polyline (local extrapolate at ends)."""
        self._load_lanes()
        meta = (self._lane_meta or {}).get(lane_id)
        if meta is None:
            return None
        shape = np.asarray(self._draw_shape_for_lane(meta), dtype=np.float64)
        if len(shape) < 2:
            return None
        s_m = float(s_m)
        seg0 = shape[1] - shape[0]
        len0 = float(np.hypot(seg0[0], seg0[1]))
        if s_m < 0.0:
            if len0 < 1e-12:
                ang = 0.0
                ux = uy = 0.0
            else:
                ux, uy = float(seg0[0] / len0), float(seg0[1] / len0)
                ang = float((np.degrees(np.arctan2(seg0[0], seg0[1])) + 360.0) % 360.0)
            return float(shape[0][0] + s_m * ux), float(shape[0][1] + s_m * uy), ang
        walked = 0.0
        for i in range(len(shape) - 1):
            a, b = shape[i], shape[i + 1]
            seg_len = float(np.hypot(b[0] - a[0], b[1] - a[1]))
            if walked + seg_len >= s_m - 1e-9:
                t = 0.0 if seg_len < 1e-12 else (s_m - walked) / seg_len
                q = a + t * (b - a)
                ang = float((np.degrees(np.arctan2(b[0] - a[0], b[1] - a[1])) + 360.0) % 360.0)
                return float(q[0]), float(q[1]), ang
            walked += seg_len
        seg = shape[-1] - shape[-2]
        seg_len = float(np.hypot(seg[0], seg[1]))
        ang = float((np.degrees(np.arctan2(seg[0], seg[1])) + 360.0) % 360.0)
        if seg_len < 1e-12:
            return float(shape[-1][0]), float(shape[-1][1]), ang
        over = s_m - walked
        ux, uy = float(seg[0] / seg_len), float(seg[1] / seg_len)
        return (
            float(shape[-1][0] + over * ux),
            float(shape[-1][1] + over * uy),
            ang,
        )

    def _resolve_lane_station(self, lane_id, s_m, depth=0):
        """Map (lane, s) across upstream edges when s < 0.

        Short stubs like ``610330469#0`` / ``610330470#0`` chain onto ``E6`` /
        ``190858946#3.14`` so dense queues stay on the painted centerline.
        Returns ``(lane_id, s_on_lane, x, y, angle_deg)`` or None.
        """
        self._load_lanes()
        if not lane_id or (self._lane_meta or {}).get(lane_id) is None:
            return None
        s_m = float(s_m)
        if s_m < 0.0 and depth < 8:
            up = (self._lane_upstream or {}).get(lane_id)
            if up and (self._lane_meta or {}).get(up) is not None:
                up_len = self._lane_polyline_length(up)
                return self._resolve_lane_station(up, up_len + s_m, depth + 1)
        pt = self._lane_point_on_polyline(lane_id, s_m)
        if pt is None:
            return None
        return lane_id, s_m, float(pt[0]), float(pt[1]), float(pt[2])

    def _lane_point_at_station(self, lane_id, s_m):
        """Interpolate lane draw-centerline at arc length s_m → (x, y, angle_deg).

        Follows upstream normal-edge predecessors when ``s_m < 0`` so queues on
        short approaches do not drift off the real corridor centerline.
        """
        resolved = self._resolve_lane_station(lane_id, s_m)
        if resolved is None:
            return None
        _lid, _s, x, y, ang = resolved
        return x, y, ang

    def _nearest_lane_id(self, x, y, max_dist_m=6.0):
        """Pick the closest known lane centerline for orphan vehicles."""
        self._load_lanes()
        best_id, best_d = None, float(max_dist_m)
        for lid, meta in (self._lane_meta or {}).items():
            shape = np.asarray(self._draw_shape_for_lane(meta), dtype=np.float64)
            if len(shape) < 2:
                continue
            for i in range(len(shape) - 1):
                d, _q = self._dist_point_to_seg(x, y, shape[i], shape[i + 1])
                if d < best_d:
                    best_d, best_id = d, lid
        return best_id

    def _keep_travel_angle(self, sang, fol_ang):
        da = abs((float(sang) - float(fol_ang) + 180.0) % 360.0 - 180.0)
        if da > 90.0:
            return (float(sang) + 180.0) % 360.0
        return float(sang)

    def _apply_station_pose(self, entries, idx, lid, new_s):
        """Write lane station ``new_s``; chain onto upstream edge if needed."""
        resolved = self._resolve_lane_station(lid, new_s)
        if resolved is None:
            return False
        new_lid, _s, x, y, sang = resolved
        sang = self._keep_travel_angle(sang, entries[idx][2])
        entries[idx][0] = x
        entries[idx][1] = y
        entries[idx][2] = sang
        entries[idx][5] = new_lid
        return True

    def _resnap_entry_to_lane(self, entries, idx):
        """Project a vehicle back onto its lane draw-centerline (mid-lane)."""
        lid = entries[idx][5] if len(entries[idx]) > 5 else None
        if not lid or (self._lane_meta or {}).get(lid) is None:
            return False
        info = self._lane_station_and_point(lid, float(entries[idx][0]), float(entries[idx][1]))
        if info is None:
            return False
        s, xs, ys, sang = info
        sang = self._keep_travel_angle(sang, entries[idx][2])
        entries[idx][0], entries[idx][1], entries[idx][2] = xs, ys, sang
        return True

    def _heading_aligns_plus_s(self, lid, s, angle_deg):
        """True if vehicle heading aligns with increasing lane station."""
        pa = self._lane_point_on_polyline(lid, float(s))
        pb = self._lane_point_on_polyline(lid, float(s) + 0.5)
        if pa is None or pb is None:
            return True
        th = np.radians(float(angle_deg))
        sx, sy = pb[0] - pa[0], pb[1] - pa[1]
        return float(np.sin(th) * sx + np.cos(th) * sy) >= 0.0

    def _body_interval_on_lane(self, s, length_m, facing_plus_s):
        """Front-bumper station → occupied [rear, front] along lane arc."""
        s = float(s)
        L = float(length_m)
        if facing_plus_s:
            return s - L, s
        return s, s + L

    def _set_entry_station_facing(self, entries, idx, lid, s_m, face_plus_s):
        """Place entry at station ``s_m`` (tip-lane frame) and force facing."""
        resolved = self._resolve_lane_station(lid, s_m)
        if resolved is None:
            return False
        new_lid, _s, x, y, sang = resolved
        sang = float(sang)
        if not face_plus_s:
            sang = (sang + 180.0) % 360.0
        entries[idx][0] = x
        entries[idx][1] = y
        entries[idx][2] = sang
        entries[idx][5] = new_lid
        return True

    def _station_in_lane_chain(self, tip_lid, x, y, max_lat_m=5.0):
        """Station in ``tip_lid`` coordinates (negative = on upstream edges).

        After packing pushes cars onto upstream lanes, local ``s`` on those lanes
        must not be mixed with tip ``s`` — that caused zero-distance stacking.
        """
        x, y = float(x), float(y)
        info = self._lane_station_and_point(tip_lid, x, y)
        if info is not None:
            s, xs, ys, _sang = info
            if float(np.hypot(x - xs, y - ys)) <= float(max_lat_m):
                return float(s)
        acc_up = 0.0
        cur = tip_lid
        for _ in range(8):
            up = (self._lane_upstream or {}).get(cur)
            if not up or (self._lane_meta or {}).get(up) is None:
                break
            up_len = float(self._lane_polyline_length(up))
            info = self._lane_station_and_point(up, x, y)
            if info is not None:
                s, xs, ys, _sang = info
                if float(np.hypot(x - xs, y - ys)) <= float(max_lat_m):
                    return float(s) - up_len - acc_up
            acc_up += up_len
            cur = up
        info = self._lane_station_and_point(tip_lid, x, y)
        return None if info is None else float(info[0])

    def _pack_lane_queue(self, entries, idxs, lid, min_gap):
        """Front-to-back pack on one approach corridor: fixed size, clear gaps.

        All stations are expressed in the tip-lane frame (may be negative when
        the car sits on an upstream edge). Placement always goes through
        ``_resolve_lane_station(tip_lid, s)`` so the queue stays one continuous
        1-D line instead of stacking at stub endpoints.
        """
        if len(idxs) < 2:
            return
        # Curve slack: chord < arc makes sprites look tighter than the s-gap.
        # HDV keeps min_gap; CAV (follower) uses a tighter gap to the leader.
        gap_hdv = float(min_gap) + 0.4
        gap_cav = float(getattr(self, 'car_min_gap_cav_m', 0.9) or 0.9) + 0.25
        cx, cy = self._default_center
        L_lane = float(self._lane_polyline_length(lid))
        p0 = self._lane_point_on_polyline(lid, 0.0)
        p1 = self._lane_point_on_polyline(lid, max(L_lane, 1e-3))
        junc_at_high_s = True
        if p0 is not None and p1 is not None:
            d0 = (float(p0[0]) - cx) ** 2 + (float(p0[1]) - cy) ** 2
            d1 = (float(p1[0]) - cx) ** 2 + (float(p1[1]) - cy) ** 2
            junc_at_high_s = d1 < d0

        valid = []
        s_of = {}
        align_votes = 0.0
        for idx in idxs:
            s = self._station_in_lane_chain(lid, entries[idx][0], entries[idx][1])
            if s is None:
                continue
            resolved = self._resolve_lane_station(lid, float(s))
            if resolved is None:
                continue
            new_lid, _s, xs, ys, sang = resolved
            sang = self._keep_travel_angle(float(sang), entries[idx][2])
            entries[idx][0], entries[idx][1], entries[idx][2] = xs, ys, sang
            entries[idx][5] = new_lid
            valid.append(idx)
            s_of[idx] = float(s)
            if self._heading_aligns_plus_s(lid, float(s), sang):
                align_votes += 1.0
            else:
                align_votes -= 1.0
        if len(valid) < 2:
            return
        if abs(align_votes) < 1e-9:
            face_plus = bool(junc_at_high_s)
        else:
            face_plus = align_votes >= 0.0
        for idx in valid:
            self._set_entry_station_facing(entries, idx, lid, s_of[idx], face_plus)

        if junc_at_high_s:
            order = sorted(valid, key=lambda i: s_of[i], reverse=True)
        else:
            order = sorted(valid, key=lambda i: s_of[i])

        for _pass in range(8):
            changed = False
            for k in range(1, len(order)):
                lead, fol = order[k - 1], order[k]
                s_l = self._station_in_lane_chain(
                    lid, entries[lead][0], entries[lead][1]
                )
                s_f = self._station_in_lane_chain(
                    lid, entries[fol][0], entries[fol][1]
                )
                if s_l is None or s_f is None:
                    continue
                s_of[lead], s_of[fol] = float(s_l), float(s_f)
                l_l, l_f = float(entries[lead][3]), float(entries[fol][3])
                a_l, a_f = self._body_interval_on_lane(s_of[lead], l_l, face_plus)
                b_l, b_f = self._body_interval_on_lane(s_of[fol], l_f, face_plus)
                # Follower CAV → tighter gap to the vehicle ahead; HDV unchanged.
                gap = gap_cav if bool(entries[fol][4]) else gap_hdv
                if junc_at_high_s:
                    limit = a_l - gap
                    if b_f > limit + 1e-9:
                        new_s = limit if face_plus else (limit - l_f)
                        if self._set_entry_station_facing(
                            entries, fol, lid, new_s, face_plus
                        ):
                            s_of[fol] = float(new_s)
                            changed = True
                else:
                    limit = a_f + gap
                    if b_l < limit - 1e-9:
                        new_s = (limit + l_f) if face_plus else limit
                        if self._set_entry_station_facing(
                            entries, fol, lid, new_s, face_plus
                        ):
                            s_of[fol] = float(new_s)
                            changed = True
            if not changed:
                break

    def _enforce_world_longitudinal_gaps(self, entries, min_gap):
        """Orphan-only safety net; never shove lane cars off the centerline."""
        n = len(entries)
        if n < 2:
            return
        lat_gate = float(getattr(self, 'car_sep_lateral_m', 2.2) or 2.2)
        cav_gap = float(getattr(self, 'car_min_gap_cav_m', 0.9) or 0.9)
        for _ in range(max(6, n)):
            changed = False
            for i in range(n):
                # Only move vehicles that have no usable lane binding.
                if entries[i][5] and (self._lane_meta or {}).get(entries[i][5]) is not None:
                    continue
                xi, yi, angi, li = (
                    float(entries[i][0]),
                    float(entries[i][1]),
                    float(entries[i][2]),
                    float(entries[i][3]),
                )
                need_i = cav_gap if bool(entries[i][4]) else float(min_gap)
                thi = np.radians(angi)
                fxi, fyi = float(np.sin(thi)), float(np.cos(thi))
                rxi, ryi = float(np.cos(thi)), float(-np.sin(thi))
                for j in range(n):
                    if i == j:
                        continue
                    xj, yj, angj, lj = (
                        float(entries[j][0]),
                        float(entries[j][1]),
                        float(entries[j][2]),
                        float(entries[j][3]),
                    )
                    dang = abs((angi - angj + 180.0) % 360.0 - 180.0)
                    if dang > 35.0:
                        continue
                    dx, dy = xj - xi, yj - yi
                    along = dx * fxi + dy * fyi
                    lateral = abs(dx * rxi + dy * ryi)
                    if lateral > lat_gate:
                        continue
                    if along >= 0.0:
                        gap = along - lj
                        if gap + 1e-9 >= need_i:
                            continue
                        push = need_i - gap
                        entries[i][0] = xi - push * fxi
                        entries[i][1] = yi - push * fyi
                        xi, yi = float(entries[i][0]), float(entries[i][1])
                        changed = True
                    else:
                        need_j = cav_gap if bool(entries[j][4]) else float(min_gap)
                        gap = (-along) - li
                        if gap + 1e-9 >= need_j:
                            continue
                        # j is behind orphan i; only push j if j is also orphan.
                        if entries[j][5] and (self._lane_meta or {}).get(entries[j][5]) is not None:
                            continue
                        push = need_j - gap
                        thj = np.radians(angj)
                        fxj, fyj = float(np.sin(thj)), float(np.cos(thj))
                        entries[j][0] = xj - push * fxj
                        entries[j][1] = yj - push * fyj
                        changed = True
            if not changed:
                break

    def _group_entries_by_lane(self, entries):
        by_lane = {}
        for idx, ent in enumerate(entries):
            lid = ent[5] if len(ent) > 5 else None
            if not lid or (self._lane_meta or {}).get(lid) is None:
                lid = self._nearest_lane_id(float(ent[0]), float(ent[1]))
                if lid:
                    entries[idx][5] = lid
            if not lid:
                continue
            by_lane.setdefault(lid, []).append(idx)
        return by_lane

    def _enforce_longitudinal_gaps(self, entries):
        """Keep clear bumper gaps without shrinking vehicle length.

        Pack each approach tip corridor once in tip-lane station coordinates.
        Do not re-group by the upstream lids that packing assigns for drawing —
        that used to split a queue mid-corridor and stack cars at stub ends.

        ``entries``: ``[x, y, angle, length_m, is_cav, lane_id]``.
        """
        if len(entries) < 2:
            return
        min_gap = float(getattr(self, 'car_min_gap_m', 1.8) or 1.8)
        # 1) Pack each approach-tip corridor (tip-lane station frame).
        by_lane = self._group_entries_by_lane(entries)
        for lid, idxs in by_lane.items():
            self._pack_lane_queue(entries, idxs, lid, min_gap)
        # 2) Re-pack by the lane cars actually sit on after upstream chaining.
        #    Needed when several tip lanes merge onto one upstream (e.g. 4leg
        #    610330470#0_1/_2 → 190858946#3.14_1) so merged queues don't overlap.
        by_draw = {}
        for idx, ent in enumerate(entries):
            d_lid = ent[5] if len(ent) > 5 else None
            if d_lid and (self._lane_meta or {}).get(d_lid) is not None:
                by_draw.setdefault(d_lid, []).append(idx)
        for lid, idxs in by_draw.items():
            if len(idxs) >= 2:
                self._pack_lane_queue(entries, idxs, lid, min_gap)
        self._enforce_world_longitudinal_gaps(entries, min_gap)
        # Do NOT globally re-snap here: clamping projections collapse every car
        # that was packed past a dead-end upstream (s<0) back onto s=0.

    def render(self, state, center_x=None, center_y=None):
        center_x, center_y = self._resolve_center(state, center_x, center_y)
        if self.bg_cache is None or self._bg_center != (center_x, center_y):
            self.bg_cache = self._build_background(center_x, center_y)
            self._bg_center = (center_x, center_y)

        img = self.bg_cache.copy()
        self._draw_signal_stop_bars(img, center_x, center_y, state)
        # SUMO VAR_POSITION is the middle of the front bumper; our sprite is
        # center-based — shift back so the drawn nose sits on the bumper.
        # Keep fixed car size; space queues along the lane centerline only.
        # Keep a margin so mini-junction connectors near the FOV rim
        # (4leg: 1425220694 / 5238330328 / 5238330336) are not dropped before packing.
        view_lim = float(self.map_range) + 25.0
        entries = []
        for group, is_cav in (('hdvs', False), ('cavs', True)):
            for raw_vinfo in (state or {}).get(group, {}).values():
                if not isinstance(raw_vinfo, dict):
                    continue
                # Copy before snapping so _snap_to_lane_center never mutates caller state in-place.
                vinfo = dict(raw_vinfo)
                snapped = self._snap_to_lane_center(vinfo)
                if snapped is None:
                    continue
                x, y = snapped
                if abs(x - center_x) > view_lim or abs(y - center_y) > view_lim:
                    continue
                angle = float(vinfo.get('angle', 0.0))
                # Fixed BEV body size (canonical SUMO length × vis scale). Do not
                # inherit GUI zoom/exaggeration shrink; queue density is handled
                # by longitudinal packing below, never by shrinking sprites.
                length_m = float(SUMO_CAR_LENGTH) * float(self.car_vis_scale)
                lane_id = vinfo.get('lane')
                entries.append([float(x), float(y), angle, length_m, is_cav, lane_id])
        self._enforce_longitudinal_gaps(entries)

        draw_lim = float(self.map_range) + 5.0
        draw_list = []
        for x, y, angle, length_m, is_cav, lane_id in entries:
            half_len_m = 0.5 * float(length_m)
            # Shift along lane first (mid-lane on curves), then optional edge nudge.
            x_c, y_c = self._shift_front_to_center(
                x, y, angle, half_len_m, lane_id=lane_id
            )
            x_c, y_c = self._apply_edge_lateral_nudge(x_c, y_c, angle, lane_id)
            if abs(x_c - center_x) > draw_lim or abs(y_c - center_y) > draw_lim:
                continue
            dist2 = (x_c - center_x) ** 2 + (y_c - center_y) ** 2
            draw_list.append((dist2, x_c, y_c, angle, is_cav, float(length_m)))
        draw_list.sort(key=lambda t: -t[0])
        for _dist2, x_c, y_c, angle, is_cav, length_m in draw_list:
            px, py = self._w2p(x_c, y_c, center_x, center_y)
            self._draw_sumo_car(
                img, px, py, angle, is_cav=is_cav, length_m=length_m
            )
        self._draw_hud_label(img, state)
        return cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
