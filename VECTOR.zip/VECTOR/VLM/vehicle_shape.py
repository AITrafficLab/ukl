"""SUV.obj top-down hull for BEV car drawing (colors stay HDV white / CAV orange)."""
from __future__ import annotations

import json
import os
from functools import lru_cache

import cv2
import numpy as np

_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
_CONFIG_PATH = os.path.join(os.path.dirname(__file__), "vehicle_visual_config.json")
_DEFAULT_OBJ = os.path.join(_ROOT, "assets", "vehicles", "SUV.obj")


def load_vehicle_visual_config():
    cfg = {"shape": "suv", "obj_path": "assets/vehicles/SUV.obj"}
    if os.path.isfile(_CONFIG_PATH):
        try:
            with open(_CONFIG_PATH, encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict):
                cfg.update(data)
        except Exception:
            pass
    return cfg


def set_vehicle_visual_shape(shape: str, obj_path: str | None = None):
    shape = str(shape).strip().lower()
    if shape not in ("classic", "suv"):
        raise ValueError("shape must be 'classic' or 'suv'")
    cfg = load_vehicle_visual_config()
    cfg["shape"] = shape
    if obj_path:
        cfg["obj_path"] = obj_path
    cfg.setdefault(
        "note",
        "shape=classic restores the previous BEV car silhouette; "
        "shape=suv uses the Realistic Car Pack SUV.obj top-down hull. "
        "Colors (HDV white / CAV orange) are unchanged.",
    )
    with open(_CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)
        f.write("\n")
    _load_suv_templates_cached.cache_clear()
    return cfg


def _resolve_obj_path(cfg=None):
    cfg = cfg or load_vehicle_visual_config()
    rel = cfg.get("obj_path") or "assets/vehicles/SUV.obj"
    path = rel if os.path.isabs(rel) else os.path.join(_ROOT, rel)
    return os.path.abspath(path if os.path.isfile(path) else _DEFAULT_OBJ)


def _read_obj_vertices(path):
    verts = []
    with open(path, encoding="utf-8", errors="ignore") as f:
        for line in f:
            if not line.startswith("v "):
                continue
            parts = line.split()
            if len(parts) < 4:
                continue
            verts.append((float(parts[1]), float(parts[2]), float(parts[3])))
    if not verts:
        raise RuntimeError(f"no vertices in OBJ: {path}")
    return np.asarray(verts, dtype=np.float64)


def _synthetic_suv_templates(source_label: str = "synthetic_fallback"):
    """Fail-safe procedural SUV top-down polygons when SUV.obj is absent."""
    body = np.asarray(
        [
            (0.98, -0.72), (1.00, 0.0), (0.98, 0.72),
            (0.76, 0.96), (-0.78, 0.96),
            (-0.98, 0.76), (-1.00, 0.0), (-0.98, -0.76),
            (-0.78, -0.96), (0.76, -0.96),
        ],
        dtype=np.float64,
    )
    cabin = body * 0.80
    windshield = np.asarray(
        [(0.58, -0.72), (0.58, 0.72), (0.22, 0.80), (0.22, -0.80)],
        dtype=np.float64,
    )
    roof = np.asarray(
        [(0.20, -0.76), (0.20, 0.76), (-0.42, 0.76), (-0.42, -0.76)],
        dtype=np.float64,
    )
    rear_glass = np.asarray(
        [(-0.44, -0.76), (-0.44, 0.76), (-0.76, 0.68), (-0.76, -0.68)],
        dtype=np.float64,
    )
    return {
        "body": body,
        "cabin": cabin,
        "roof": roof,
        "windshield": windshield,
        "rear_glass": rear_glass,
        "source": source_label,
    }


def _convex_hull_2d(pts_xy):
    pts = np.asarray(pts_xy, dtype=np.float32)
    if len(pts) < 3:
        return pts
    hull = cv2.convexHull(pts.reshape(-1, 1, 2))
    return hull.reshape(-1, 2)


def _resample_closed(pts, n=48):
    pts = np.asarray(pts, dtype=np.float64)
    if len(pts) < 2:
        return pts
    closed = np.vstack([pts, pts[0]])
    seg = np.linalg.norm(np.diff(closed, axis=0), axis=1)
    total = float(seg.sum())
    if total < 1e-9:
        return pts
    dist = np.concatenate([[0.0], np.cumsum(seg)])
    samples = np.linspace(0.0, total, n, endpoint=False)
    out = []
    j = 0
    for s in samples:
        while j + 1 < len(dist) and dist[j + 1] < s:
            j += 1
        t = (s - dist[j]) / max(dist[j + 1] - dist[j], 1e-9)
        out.append(closed[j] * (1 - t) + closed[j + 1] * t)
    return np.asarray(out, dtype=np.float64)


@lru_cache(maxsize=4)
def _load_suv_templates_cached(resolved_path: str):
    if not os.path.isfile(resolved_path):
        return _synthetic_suv_templates(resolved_path)
    try:
        v = _read_obj_vertices(resolved_path)
    except Exception:
        return _synthetic_suv_templates(resolved_path)
    xz = v[:, [0, 2]]
    y = v[:, 1]
    x_min, x_max = float(xz[:, 0].min()), float(xz[:, 0].max())
    z_min, z_max = float(xz[:, 1].min()), float(xz[:, 1].max())
    x_c = 0.5 * (x_min + x_max)
    z_c = 0.5 * (z_min + z_max)
    half_w = max(0.5 * (x_max - x_min), 1e-6)
    half_l = max(0.5 * (z_max - z_min), 1e-6)

    def to_fr(pts_xz):
        r = (pts_xz[:, 0] - x_c) / half_w
        f = (pts_xz[:, 1] - z_c) / half_l
        return np.column_stack([f, r])

    body = _resample_closed(to_fr(_convex_hull_2d(xz)), n=56)

    y_hi = float(np.percentile(y, 72))
    cabin_mask = y >= y_hi
    cabin_xz = xz[cabin_mask] if cabin_mask.any() else xz
    cabin = _resample_closed(to_fr(_convex_hull_2d(cabin_xz)), n=36) * 0.88

    f_vals = cabin[:, 0]
    f_min, f_max = float(f_vals.min()), float(f_vals.max())
    f_span = max(f_max - f_min, 1e-6)
    wind_mask = cabin[:, 0] >= (f_max - 0.32 * f_span)
    rear_mask = cabin[:, 0] <= (f_min + 0.28 * f_span)
    mid_mask = ~(wind_mask | rear_mask)

    def subset_hull(mask, fallback):
        pts = cabin[mask] if mask.any() else fallback
        if len(pts) < 3:
            return fallback
        return _resample_closed(_convex_hull_2d(pts), n=20)

    windshield = subset_hull(wind_mask, cabin[:8])
    rear_glass = subset_hull(rear_mask, cabin[-8:])
    roof = subset_hull(mid_mask, cabin)

    return {
        "body": body,
        "cabin": cabin,
        "roof": roof,
        "windshield": windshield,
        "rear_glass": rear_glass,
        "source": resolved_path,
    }


def load_suv_templates(obj_path: str | None = None):
    resolved = os.path.abspath(obj_path) if obj_path else _resolve_obj_path()
    return _load_suv_templates_cached(resolved)


def _scale_fr(pts_fr, hl, hw):
    pts = np.asarray(pts_fr, dtype=np.float64)
    return [(float(f) * hl, float(r) * hw) for f, r in pts]


def draw_sumo_car_suv(renderer, img, px, py, angle_deg, is_cav=False, length_m=None):
    from VLM.bev_renderer import SUMO_CAR_LENGTH, SUMO_CAR_WIDTH

    length_m = float(length_m) if length_m is not None else (
        SUMO_CAR_LENGTH * float(renderer.car_vis_scale)
    )
    length = length_m * renderer.scale
    width = SUMO_CAR_WIDTH * renderer.scale * renderer.car_width_scale
    theta = np.radians(angle_deg)
    sin_t, cos_t = np.sin(theta), np.cos(theta)
    hl, hw = length / 2.0, width / 2.0

    templates = load_suv_templates()
    body_fr = _scale_fr(templates["body"], hl, hw)
    roof_fr = _scale_fr(templates["roof"], hl * 0.92, hw * 0.82)
    wind_fr = _scale_fr(templates["windshield"], hl * 0.95, hw * 0.78)
    rear_fr = _scale_fr(templates["rear_glass"], hl * 0.95, hw * 0.78)

    if renderer.layout != "dublin":
        shadow = renderer._poly(px + 1, py + 2, sin_t, cos_t, body_fr)
        overlay = img.copy()
        cv2.fillPoly(overlay, [shadow], (50, 50, 50), lineType=cv2.LINE_AA)
        cv2.addWeighted(overlay, 0.22, img, 0.78, 0, img)

    if is_cav:
        body, edge, roof = (15, 140, 255), (10, 90, 180), (20, 125, 230)
    else:
        body, edge, roof = (250, 250, 252), (150, 150, 155), (235, 235, 240)
    glass, wheel = (55, 50, 48), (32, 32, 34)

    wr = max(1, int(width * 0.12))
    for f, r in (
        (hl * 0.52, hw * 0.92),
        (hl * 0.52, -hw * 0.92),
        (-hl * 0.48, hw * 0.92),
        (-hl * 0.48, -hw * 0.92),
    ):
        wx, wy = renderer._xf(px, py, sin_t, cos_t, f, r)
        cv2.circle(img, (wx, wy), wr, wheel, -1, lineType=cv2.LINE_AA)

    body_pts = renderer._poly(px, py, sin_t, cos_t, body_fr)
    cv2.fillPoly(img, [body_pts], body, lineType=cv2.LINE_AA)
    cv2.polylines(img, [body_pts], True, edge, 1, lineType=cv2.LINE_AA)

    wind_pts = renderer._poly(px, py, sin_t, cos_t, wind_fr)
    rear_pts = renderer._poly(px, py, sin_t, cos_t, rear_fr)
    roof_pts = renderer._poly(px, py, sin_t, cos_t, roof_fr)
    cv2.fillPoly(img, [wind_pts], glass, lineType=cv2.LINE_AA)
    cv2.fillPoly(img, [rear_pts], glass, lineType=cv2.LINE_AA)
    cv2.fillPoly(img, [roof_pts], roof, lineType=cv2.LINE_AA)

    lamp_r = max(1, int(width * 0.08))
    for r in (-hw * 0.55, hw * 0.55):
        hx, hy = renderer._xf(px, py, sin_t, cos_t, hl * 0.90, r)
        tx, ty = renderer._xf(px, py, sin_t, cos_t, -hl * 0.93, r)
        cv2.circle(img, (hx, hy), lamp_r, (230, 240, 255), -1, lineType=cv2.LINE_AA)
        cv2.circle(img, (tx, ty), lamp_r, (50, 50, 190), -1, lineType=cv2.LINE_AA)


def _load_classic_drawer():
    import importlib.util

    path = os.path.join(_ROOT, "backups", "vehicle_visual", "draw_sumo_car_classic.py")
    if not os.path.isfile(path):
        return None
    spec = importlib.util.spec_from_file_location("draw_sumo_car_classic", path)
    if spec is None or spec.loader is None:
        return None
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return getattr(mod, "draw_sumo_car_classic", None)


def draw_sumo_car(renderer, img, px, py, angle_deg, is_cav=False, length_m=None):
    cfg = load_vehicle_visual_config()
    shape = str(cfg.get("shape", "suv")).strip().lower()
    if shape == "classic":
        classic = _load_classic_drawer()
        if classic is not None:
            return classic(
                renderer, img, px, py, angle_deg, is_cav=is_cav, length_m=length_m
            )
    return draw_sumo_car_suv(
        renderer, img, px, py, angle_deg, is_cav=is_cav, length_m=length_m
    )
