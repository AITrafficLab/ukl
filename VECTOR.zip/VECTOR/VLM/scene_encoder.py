import json
import base64
import copy
import math
import cv2
import os
import time
import re
import threading
from collections.abc import Mapping

import numpy as np
try:
    from openai import OpenAI
except ImportError:
    OpenAI = None
from VLM.prompt import (
    SYSTEM_PROMPT_LAT,
    SYSTEM_PROMPT_LON,
    SYSTEM_PROMPT_SIGNAL_TEACHER,
    SYSTEM_PROMPT_SIGNAL_VISION,
    build_scene_prompt,
    build_signal_teacher_prompt,
    build_signal_vision_prompt,
)
from VLM.vlm_call_config import (
    CHANNEL_LAT,
    CHANNEL_LON,
    CHANNEL_SIGNAL_VISION,
    ThinkingRuntime,
    is_thinking_param_error,
    max_tokens_for_channel,
    normalize_channel,
)
from VLM.bev_renderer import (
    BEVRenderer,
    DEFAULT_JUNCTION_CENTER,
    DUBLIN_JUNCTION_CENTER,
)


def _env_int(name, default, minimum=None, maximum=None):
    try:
        value = int(str(os.environ.get(name, default)).strip())
        if minimum is not None and value < minimum:
            raise ValueError
        if maximum is not None and value > maximum:
            raise ValueError
        return value
    except (TypeError, ValueError, OverflowError):
        print(f"[VLM] Invalid {name}; using default={default}.", flush=True)
        return int(default)


def _env_float(name, default, minimum=None, maximum=None):
    try:
        value = float(str(os.environ.get(name, default)).strip())
        if not math.isfinite(value):
            raise ValueError
        if minimum is not None and value < minimum:
            raise ValueError
        if maximum is not None and value > maximum:
            raise ValueError
        return value
    except (TypeError, ValueError, OverflowError):
        print(f"[VLM] Invalid {name}; using default={default}.", flush=True)
        return float(default)


def _env_bool(name, default=False):
    raw = os.environ.get(name)
    if raw is None:
        return bool(default)
    return str(raw).strip().lower() in {"1", "true", "yes", "on", "enabled"}


def _as_mapping(value):
    return dict(value) if isinstance(value, Mapping) else {}


def _safe_finite_number(value):
    if value is None or isinstance(value, bool):
        return None
    try:
        number = float(value)
    except (TypeError, ValueError, OverflowError):
        return None
    return number if math.isfinite(number) else None


def _content_as_text(value):
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, list):
        pieces = []
        for part in value:
            if isinstance(part, str):
                pieces.append(part)
            elif isinstance(part, dict):
                if part.get("type") == "text" and part.get("text") is not None:
                    pieces.append(str(part.get("text")))
        return "".join(pieces).strip()
    return str(value).strip() if value is not None else ""


def _extract_last_json_object(raw_text):
    """Extract the last balanced JSON object (safe for completed CoT tails)."""
    text = str(raw_text or "")
    pos = 0
    found = []
    while True:
        start = text.find("{", pos)
        if start < 0:
            break
        sub = _extract_first_json_object(text[start:])
        if sub is not None:
            found.append(sub)
            pos = start + len(sub)
        else:
            pos = start + 1
    return found[-1] if found else None


def _extract_first_json_object(raw_text):
    """Extract the first balanced JSON object, respecting braces inside strings."""
    text = str(raw_text or "")
    start = text.find("{")
    if start < 0:
        return None
    depth = 0
    in_string = False
    escaped = False
    for index in range(start, len(text)):
        char = text[index]
        if in_string:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                in_string = False
            continue
        if char == '"':
            in_string = True
        elif char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                return text[start:index + 1]
    return None


class VLMSceneEncoder:
    DEFAULT_API_BASE = "http://127.0.0.1:8080/v1"

    @staticmethod
    def _normalize_api_base(api_base: str) -> str:
        """Strip whitespace and ensure an OpenAI-compatible API root.

        Most gateways use ``.../v1``; some (e.g. Zhipu ``.../paas/v4``) already
        expose a versioned root — do not append another ``/v1``.
        """
        base = str(api_base or "").strip().rstrip("/")
        if not base:
            return VLMSceneEncoder.DEFAULT_API_BASE
        if "://" not in base:
            base = "http://" + base
        lower = base.lower()
        # Avoid doubling when user passed .../v1/chat/completions by mistake.
        for suffix in ("/chat/completions", "/completions"):
            if lower.endswith(suffix):
                base = base[: -len(suffix)].rstrip("/")
                lower = base.lower()
                break
        # Already versioned: /v1, /openai/v1, /paas/v4, /v4, …
        if lower.endswith("/openai/v1") or re.search(r"/v\d+$", lower):
            return base
        return base + "/v1"

    def __init__(self, api_key=None, model="qwen3-vl-flash", layout=None, api_base=None):
        # OpenAI-compatible client: local VLM server or online API.
        self.api_key = str(
            api_key or os.environ.get("VLM_API_KEY") or "local-mock-key"
        ).strip()
        self.model = str(
            model or os.environ.get("VLM_MODEL") or "qwen3-vl-flash"
        ).strip()
        self.api_base = self._normalize_api_base(
            api_base or os.environ.get("VLM_API_BASE") or self.DEFAULT_API_BASE
        )

        # Online multimodal + reasoning often needs >60s; local servers are fast.
        timeout_s = _env_float("VLM_API_TIMEOUT", 180.0, minimum=1.0, maximum=3600.0)
        max_retries = _env_int("VLM_API_MAX_RETRIES", 2, minimum=0, maximum=10)
        self.client = (
            OpenAI(
                api_key=self.api_key,
                base_url=self.api_base,
                timeout=timeout_s,
                max_retries=max_retries,
            )
            if OpenAI is not None
            else None
        )

        # layout: 'cross' (default) | 'dublin' — also via env VLM_BEV_LAYOUT
        # N-leg GUI captures use ±90 m (see bev_renders/gui_backgrounds/*_meta.txt).
        requested_layout = str(layout or os.environ.get("VLM_BEV_LAYOUT") or "cross").strip().lower()
        self.layout = requested_layout if requested_layout in {"cross", "dublin"} else "cross"
        if self.layout == 'dublin':
            self.renderer = BEVRenderer(
                width=1024, height=1024, map_range=90.0, layout='dublin'
            )
            self.junction_center = DUBLIN_JUNCTION_CENTER
        else:
            self.renderer = BEVRenderer(width=1024, height=1024, map_range=90.0)
            self.junction_center = DEFAULT_JUNCTION_CENTER
        
        # Absolute project-relative dir so multiprocessing workers always write here.
        # Overridden by configure_output_dir(...) to
        # bev_renders/{method}/{scenario}/seed_{N}/.
        project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
        self.project_root = project_root
        self.render_dir = os.path.join(project_root, 'bev_renders')
        os.makedirs(self.render_dir, exist_ok=True)
        self._bev_save_counter = 0
        self._render_lock = threading.Lock()
        # Persist the last BEV of every N VLM calls (default: every 100th frame).
        self.bev_save_every = _env_int("BEV_SAVE_EVERY", 100, minimum=0, maximum=1000000)
        self._bev_method = ''
        self._bev_scenario = ''
        self._bev_vlm_model = ''
        self._bev_seed = None
        self._bev_env_index = 0
        # Key-frame cache: worst-TTC / peak-DLC BEV since last VLM call.
        # compute_agent_rewards refreshes it every 0.2s step; trigger path
        # prefers it over a fresh render so VLM sees the event frame.
        self._key_frame_b64 = None
        self._key_frame_score = None  # (min_ttc, -max_dlc): lower = worse
        # Shared thinking/token policy for all VLM channels on this encoder.
        self._thinking_runtime = ThinkingRuntime(model=self.model)
        self._last_vlm_call_meta = {}
        # Optional HUD name; also accepted via state['junction_name'].
        self.junction_name = os.environ.get('VLM_JUNCTION_NAME') or None
        if self.junction_name:
            self.renderer.junction_name = self.junction_name

        # Reward-weight cache is only for Stage-Lon / Stage-Lat.
        # Stage-S no longer adapts W_sig; it consumes visual semantics instead.
        self.latest_weights = {
            "safety_weight": 0.24,
            "efficiency_weight": 0.38,
            "comfort_weight": 0.18,
            "platoon_weight": 0.20,
            "reason": "[Init] Waiting for first longitudinal VLM response...",
            "weight_mode": "lon",
        }
        self.latest_signal_semantics = self._signal_semantic_fallback()
        self._last_signal_semantics_time = None
        self.vlm_thread_running = False
        self.lock = threading.Lock()
        # When True, teacher/vision transport failures re-raise so schedulers
        # can arm fail-stop; when False, return invalid advice (control continues).
        self.fail_stop_on_vlm_error = _env_bool("VLM_FAIL_STOP", True)

    def configure_scenario(self, net_xml_path=None, junction_center=None, approach_edges=None):
        """Align BEV camera/net with the active SUMO scenario."""
        self.renderer.configure_scenario(
            net_xml_path=net_xml_path,
            junction_center=junction_center,
            approach_edges=approach_edges,
        )
        if junction_center is not None and len(junction_center) >= 2:
            self.junction_center = (float(junction_center[0]), float(junction_center[1]))
        if self.junction_name:
            self.renderer.junction_name = self.junction_name

    def configure_output_dir(
        self, method=None, scenario=None, seed=None, env_index=0, vlm_model=None
    ):
        """Set BEV dir to bev_renders/{method}/[vlm_model/]{scenario}/seed_{N}/."""
        method = str(method or self._bev_method or "unknown_method").strip() or "unknown_method"
        scenario = str(scenario or self._bev_scenario or "unknown_scenario").strip() or "unknown_scenario"
        # Keep user-supplied labels as path components, not arbitrary paths.
        method = re.sub(r"[^A-Za-z0-9_.-]+", "_", method).strip("._") or "unknown_method"
        scenario = re.sub(r"[^A-Za-z0-9_.-]+", "_", scenario).strip("._") or "unknown_scenario"
        model = str(
            vlm_model
            if vlm_model is not None
            else getattr(self, "_bev_vlm_model", "") or ""
        ).strip()
        try:
            seed_i = int(seed if seed is not None else (self._bev_seed if self._bev_seed is not None else 0))
        except (TypeError, ValueError, OverflowError):
            seed_i = 0
        try:
            env_i = max(0, int(env_index or 0))
        except (TypeError, ValueError, OverflowError):
            env_i = 0

        self._bev_method = method
        self._bev_scenario = scenario
        self._bev_vlm_model = model
        self._bev_seed = seed_i
        self._bev_env_index = env_i
        try:
            from baselines.result_paths import bev_run_dir

            self.render_dir = str(
                bev_run_dir(
                    method,
                    scenario,
                    seed_i,
                    vlm_model=model,
                    root=os.path.join(self.project_root, "bev_renders"),
                )
            )
        except Exception:
            # Fallback without result_paths (older checkouts / circular import).
            parts = [self.project_root, "bev_renders", method]
            if model:
                slug = re.sub(r"[^A-Za-z0-9_.-]+", "_", model).strip("._") or "model"
                parts.append(slug)
            parts.extend([scenario, f"seed_{seed_i}"])
            self.render_dir = os.path.join(*parts)
        os.makedirs(self.render_dir, exist_ok=True)
        print(f"[BEV] output_dir={self.render_dir} save_every={self.bev_save_every}", flush=True)

    def _image_to_base64(self, img_rgb):
        """Encode an RGB/RGBA/grayscale numpy image as PNG base64."""
        if img_rgb is None:
            raise ValueError("BEV renderer returned no image.")
        image = np.asarray(img_rgb)
        if image.size == 0:
            raise ValueError("BEV renderer returned an empty image.")
        if image.ndim == 2:
            image = cv2.cvtColor(image, cv2.COLOR_GRAY2RGB)
        elif image.ndim == 3 and image.shape[2] == 4:
            image = cv2.cvtColor(image, cv2.COLOR_RGBA2RGB)
        elif image.ndim != 3 or image.shape[2] != 3:
            raise ValueError(f"Unsupported BEV image shape: {image.shape!r}")
        image = np.ascontiguousarray(image.astype(np.uint8, copy=False))
        ok, buffer = cv2.imencode(".png", cv2.cvtColor(image, cv2.COLOR_RGB2BGR))
        if not ok:
            raise RuntimeError("OpenCV failed to encode the BEV image as PNG.")
        return base64.b64encode(buffer).decode("ascii")

    def note_key_frame(self, base64_image, min_ttc, max_dlc):
        """Cache the most dangerous/imbalanced BEV since the previous VLM call."""
        ttc = _safe_finite_number(min_ttc)
        dlc = _safe_finite_number(max_dlc)
        if not base64_image or ttc is None or dlc is None:
            return
        score = (ttc, -dlc)
        with self.lock:
            if self._key_frame_score is None or score < self._key_frame_score:
                self._key_frame_score = score
                self._key_frame_b64 = str(base64_image)

    def take_key_frame(self):
        """Pop the cached worst frame (or None); resets for next window."""
        with self.lock:
            img, self._key_frame_b64 = self._key_frame_b64, None
            self._key_frame_score = None
        return img

    def prepare_scene_image(
        self,
        state,
        junction_center=None,
        ep=0,
        step=0,
        save_to_disk=None,
        prefer_key_frame=True,
    ):
        """Render a BEV from a state snapshot; this method never calls TraCI."""
        state = state if isinstance(state, Mapping) else {}
        center = junction_center if junction_center is not None else self.junction_center
        if not isinstance(center, (list, tuple, np.ndarray)) or len(center) < 2:
            center = self.junction_center
        center_x, center_y = float(center[0]), float(center[1])

        if "junction_name" not in state:
            name = self.junction_name or getattr(self.renderer, "junction_name", None)
            if name:
                state = dict(state)
                state["junction_name"] = name

        if prefer_key_frame:
            cached = self.take_key_frame()
            if cached:
                return cached

        bev_img = self.renderer.render(state, center_x=center_x, center_y=center_y)
        base64_image = self._image_to_base64(bev_img)

        with self._render_lock:
            self._bev_save_counter += 1
            save_counter = self._bev_save_counter
        if save_to_disk is None:
            save_to_disk = (
                self.bev_save_every > 0
                and save_counter % self.bev_save_every == 0
            )
        if save_to_disk:
            os.makedirs(self.render_dir, exist_ok=True)
            timestamp = int(time.time())
            env_tag = f"_env{self._bev_env_index}" if self._bev_env_index else ""
            filename = os.path.join(
                self.render_dir,
                f"bev_ep{int(ep):04d}_step{int(step):05d}{env_tag}_{timestamp}.png",
            )
            try:
                ok = cv2.imwrite(filename, cv2.cvtColor(np.asarray(bev_img), cv2.COLOR_RGB2BGR))
            except Exception as exc:
                ok = False
                print(f"[BEV] failed to save {filename}: {exc}", flush=True)
            if ok:
                print(f"[BEV] saved {filename}", flush=True)
            elif not os.path.exists(filename):
                print(f"[BEV] failed to save {filename}", flush=True)
        return base64_image

    def _resolve_max_tokens(self, channel: str = CHANNEL_LON) -> int:
        """Per-channel completion budget from centralized thinking/token policy."""
        mode = str(getattr(self._thinking_runtime, "last_mode", "off") or "off")
        return int(max_tokens_for_channel(channel, mode))

    def resolve_call_budget(self, channel: str) -> tuple:
        """Plan thinking body + max_tokens for ``channel`` (lon/lat/signal_vision)."""
        ch = normalize_channel(channel)
        mode, extra_body, reason = self._thinking_runtime.plan(
            self.api_base, model=self.model
        )
        max_tokens = int(max_tokens_for_channel(ch, mode))
        meta = {
            "channel": ch,
            "thinking_mode": mode,
            "thinking_reason": reason,
            "max_tokens": max_tokens,
            "extra_body_keys": sorted(extra_body.keys()),
        }
        self._last_vlm_call_meta = meta
        return mode, extra_body, max_tokens, meta

    def get_reward_weights(self, state, junction_center=None, ep=0, step=0, prepared_image=None):
        """Return the latest cached weights and start one background request if idle."""
        center = junction_center if junction_center is not None else self.junction_center
        try:
            state_snapshot = copy.deepcopy(dict(state)) if isinstance(state, Mapping) else {}
        except Exception:
            state_snapshot = dict(state) if isinstance(state, Mapping) else {}

        should_launch = False
        with self.lock:
            if not self.vlm_thread_running:
                self.vlm_thread_running = True
                should_launch = True
            snapshot = dict(self.latest_weights)

        if should_launch:
            worker = threading.Thread(
                target=self._fetch_weights_task,
                args=(state_snapshot, center, ep, step, prepared_image),
                daemon=True,
                name="vlm-reward-weight-worker",
            )
            try:
                worker.start()
            except Exception as exc:
                with self.lock:
                    self.vlm_thread_running = False
                print(f"[VLM Thread Error] Unable to start worker: {exc}", flush=True)
        return snapshot

    def fetch_reward_weights_sync(
        self,
        state,
        junction_center=None,
        ep=0,
        step=0,
        prepared_image=None,
        weight_mode="lon",
    ):
        """Blocking VLM call used by AdaptiveReward's background thread.

        Only Stage-Lon and Stage-Lat use reward-weight adaptation. Signal VLM
        is a separate visual-semantic channel; use fetch_signal_vision_text()
        or fetch_signal_vision_semantics() for Stage-S.
        """
        if str(weight_mode or "lon").strip().lower() in (
            "sig", "signal", "s", "tls", "signal_vision", "vision"
        ):
            raise RuntimeError(
                "Stage-S signal VLM now returns visual semantics, not W_sig. "
                "Call fetch_signal_vision_text() or fetch_signal_vision_semantics()."
            )
        center = junction_center or self.junction_center
        new_weights = self._compute_reward_weights(
            state,
            junction_center=center,
            ep=ep,
            step=step,
            prepared_image=prepared_image,
            weight_mode=weight_mode,
        )
        with self.lock:
            self.latest_weights = dict(new_weights)
        return new_weights

    @staticmethod
    def _signal_semantic_fallback():
        """Conservative invalid result used when visual inference fails.

        valid=0 and unseen_scene=1 ensure downstream code can distinguish
        an inference failure from a genuinely clear scene.
        """
        return {
            "lane_blockage": 0.0,
            "spillback": 0.0,
            "incident_obstruction": 0.0,
            "roadwork": 0.0,
            "special_vehicle": 0.0,
            "unseen_scene": 1.0,
            "confidence": 0.0,
            "valid": 0.0,
        }

    @classmethod
    def _parse_signal_semantic_json(cls, content):
        """Parse and validate the fixed eight-field signal-semantic schema."""
        raw = str(content or "").strip()
        if not raw:
            raise RuntimeError("Signal-vision response is empty")
        candidate = _extract_first_json_object(raw)
        if candidate is None:
            raise RuntimeError("Signal-vision response contains no JSON object")

        def reject_constant(value):
            raise ValueError(f"Non-standard JSON numeric constant: {value}")

        try:
            data = json.loads(candidate, parse_constant=reject_constant)
        except (json.JSONDecodeError, ValueError, TypeError) as exc:
            raise RuntimeError(
                f"Signal-vision response is not valid finite JSON: {raw[:160]!r}"
            ) from exc
        if not isinstance(data, Mapping):
            raise RuntimeError("Signal-vision JSON root must be an object")

        keys = (
            "lane_blockage",
            "spillback",
            "incident_obstruction",
            "roadwork",
            "special_vehicle",
            "unseen_scene",
            "confidence",
            "valid",
        )
        normalized = {}
        for key in keys:
            if key not in data:
                raise RuntimeError(f"Signal-vision JSON missing required key: {key}")
            value = data[key]
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                raise RuntimeError(f"Signal-vision field {key!r} must be numeric")
            value = float(value)
            if not math.isfinite(value) or value < 0.0 or value > 1.0:
                raise RuntimeError(
                    f"Signal-vision field {key!r} must be finite and in [0, 1]"
                )
            normalized[key] = round(value, 4)

        normalized["valid"] = 1.0 if normalized["valid"] >= 0.5 else 0.0
        if normalized["valid"] < 0.5:
            for key in (
                "lane_blockage", "spillback", "incident_obstruction",
                "roadwork", "special_vehicle",
            ):
                normalized[key] = 0.0
            normalized["unseen_scene"] = max(normalized["unseen_scene"], 0.8)
            normalized["confidence"] = min(normalized["confidence"], 0.3)
        return normalized

    def _fetch_signal_vision_semantics_dict(
        self,
        state,
        prepared_image=None,
        ep=0,
        step=0,
    ):
        """Perform one signal visual-semantic inference with one repair retry."""
        del ep, step
        state = state if isinstance(state, dict) else {}
        fallback = self._signal_semantic_fallback()

        try:
            img = prepared_image
            if not img:
                img = self.prepare_scene_image(
                    state, prefer_key_frame=False, save_to_disk=False
                )
            if not img:
                raise RuntimeError("No usable BEV image available for signal vision")

            user_text = build_signal_vision_prompt(state)
            content = [
                {"type": "text", "text": user_text},
                {
                    "type": "image_url",
                    "image_url": {"url": f"data:image/png;base64,{img}"},
                },
            ]
            messages = [
                {"role": "system", "content": SYSTEM_PROMPT_SIGNAL_VISION},
                {"role": "user", "content": content},
            ]
            mode, _body, max_tokens, meta = self.resolve_call_budget(
                CHANNEL_SIGNAL_VISION
            )
            img_note = f"attached ({len(img)} b64 chars)"
            print(
                f"[SignalVision] model={self.model} thinking={mode} "
                f"max_tokens={max_tokens} ({meta.get('thinking_reason')})\n"
                f"[SignalVision] request image={img_note}\n"
                f"[SignalVision] request text:\n{user_text}",
                flush=True,
            )

            raw = self._chat_once(
                messages,
                max_tokens=max_tokens,
                retries=1,
                channel=CHANNEL_SIGNAL_VISION,
            )
            if os.environ.get("VLM_LOG_RAW", "").strip().lower() in (
                "1", "true", "yes", "on"
            ):
                print(f"[SignalVision] raw response:\n{raw}", flush=True)

            try:
                semantics = self._parse_signal_semantic_json(raw)
            except RuntimeError as first_exc:
                print(
                    f"[SignalVision] invalid schema; requesting one repair: {first_exc}",
                    flush=True,
                )
                repair_messages = list(messages) + [
                    {"role": "assistant", "content": raw},
                    {
                        "role": "user",
                        "content": (
                            "Your previous reply was invalid or incomplete. "
                            "Return exactly one valid JSON object with all eight numeric "
                            "keys: lane_blockage, spillback, incident_obstruction, "
                            "roadwork, special_vehicle, unseen_scene, confidence, valid. "
                            "Every value must be finite and in [0,1]. Do not include "
                            "Markdown, explanations, reward weights, or actions."
                        ),
                    },
                ]
                repaired = self._chat_once(
                    repair_messages,
                    max_tokens=max_tokens,
                    retries=1,
                    channel=CHANNEL_SIGNAL_VISION,
                )
                if os.environ.get("VLM_LOG_RAW", "").strip().lower() in (
                    "1", "true", "yes", "on"
                ):
                    print(
                        f"[SignalVision] repair response:\n{repaired}",
                        flush=True,
                    )
                semantics = self._parse_signal_semantic_json(repaired)

            # An invalid assessment must not leak event flags into the controller.
            # Do not treat an unusable/occluded image as a confirmed clear scene.
            if semantics["valid"] < 0.5:
                for key in (
                    "lane_blockage", "spillback", "incident_obstruction",
                    "roadwork", "special_vehicle",
                ):
                    semantics[key] = 0.0
                semantics["unseen_scene"] = max(semantics["unseen_scene"], 0.8)
                semantics["confidence"] = min(semantics["confidence"], 0.3)

            with self.lock:
                self.latest_signal_semantics = dict(semantics)
                self._last_signal_semantics_time = time.time()

            print(
                "[SignalVision] parsed semantics: "
                + json.dumps(semantics, ensure_ascii=False, sort_keys=True),
                flush=True,
            )
            return semantics

        except Exception as exc:
            print(
                f"[SignalVision] inference failed; returning invalid fallback: {exc}",
                flush=True,
            )
            with self.lock:
                self.latest_signal_semantics = dict(fallback)
                self._last_signal_semantics_time = time.time()
            return fallback

    def fetch_signal_vision_text(
        self,
        state,
        prepared_image=None,
        ep=0,
        step=0,
    ):
        """Backward-compatible API: return canonical signal-semantic JSON text.

        Existing SignalVisionScheduler code that expects a text payload can
        continue using this method. The returned schema is validated and never
        contains W_sig reward weights.
        """
        semantics = self._fetch_signal_vision_semantics_dict(
            state,
            prepared_image=prepared_image,
            ep=ep,
            step=step,
        )
        return json.dumps(semantics, ensure_ascii=False, separators=(",", ":"))

    def fetch_signal_vision_semantics(
        self,
        state,
        prepared_image=None,
        ep=0,
        step=0,
    ):
        """Structured API for consumers that can accept a Python dictionary."""
        return self._fetch_signal_vision_semantics_dict(
            state,
            prepared_image=prepared_image,
            ep=ep,
            step=step,
        )

    @staticmethod
    def _invalid_signal_teacher_advice(reason="invalid"):
        return {
            "recommended_phase": -1,
            "confidence": 0.0,
            "valid": 0.0,
            "visual_event": "none",
            "reason": str(reason or "invalid"),
        }

    def _parse_signal_teacher_json(self, content, legal_phases):
        """Strict teacher JSON parse; illegal phases → invalid advice."""
        legal = set()
        for item in list(legal_phases or []):
            try:
                legal.add(int(item))
            except (TypeError, ValueError, OverflowError):
                continue
        fallback = self._invalid_signal_teacher_advice("invalid")
        raw = str(content or "").strip()
        if not raw or not legal:
            return fallback
        if "```" in raw:
            match = re.search(r"```(?:json)?\s*([\s\S]*?)```", raw, flags=re.I)
            if match:
                raw = match.group(1).strip()
        start = raw.find("{")
        if start < 0:
            return fallback
        depth = 0
        in_string = False
        escaped = False
        candidate = None
        for index in range(start, len(raw)):
            char = raw[index]
            if in_string:
                if escaped:
                    escaped = False
                elif char == "\\":
                    escaped = True
                elif char == '"':
                    in_string = False
                continue
            if char == '"':
                in_string = True
            elif char == "{":
                depth += 1
            elif char == "}":
                depth -= 1
                if depth == 0:
                    candidate = raw[start : index + 1]
                    break
        if not candidate:
            return fallback

        def reject_constant(value):
            raise ValueError(f"Non-standard JSON numeric constant: {value}")

        try:
            data = json.loads(candidate, parse_constant=reject_constant)
        except (json.JSONDecodeError, ValueError, TypeError):
            return fallback
        if not isinstance(data, Mapping):
            return fallback
        try:
            phase = int(data.get("recommended_phase"))
        except (TypeError, ValueError, OverflowError):
            return self._invalid_signal_teacher_advice("illegal_phase")
        if phase not in legal:
            return self._invalid_signal_teacher_advice("illegal_phase")
        try:
            conf = float(data.get("confidence"))
        except (TypeError, ValueError, OverflowError):
            return fallback
        if isinstance(data.get("confidence"), bool) or not math.isfinite(conf):
            return fallback
        if conf < 0.0 or conf > 1.0:
            return fallback
        event = str(data.get("visual_event") or "none").strip().lower()
        allowed_events = {
            "none",
            "spillback",
            "queue_imbalance",
            "blockage",
            "incident",
            "roadwork",
            "special_vehicle",
        }
        if event not in allowed_events:
            event = "none"
        reason = str(data.get("reason") or "").strip()
        words = reason.split()
        if len(words) > 15:
            reason = " ".join(words[:15])
        return {
            "recommended_phase": int(phase),
            "confidence": float(conf),
            "valid": 1.0,
            "visual_event": event,
            "reason": reason or "ok",
        }

    def fetch_signal_teacher_advice(
        self,
        state,
        legal_phases,
        prepared_image=None,
        ep=0,
        step=0,
    ):
        """Teacher-phase advice for Stage-S.

        On transport/inference failure: re-raise when ``fail_stop_on_vlm_error``
        so SignalVisionScheduler can increment fail counts / arm fail-stop;
        otherwise return an invalid advice dict (control continues).
        """
        del ep, step
        legal = []
        for item in list(legal_phases or []):
            try:
                legal.append(int(item))
            except (TypeError, ValueError, OverflowError):
                continue
        legal = sorted(set(p for p in legal if p >= 0))
        if len(legal) < 2:
            return self._invalid_signal_teacher_advice("need_two_legal")
        state = state if isinstance(state, dict) else {}
        try:
            img = prepared_image
            if not img:
                img = self.prepare_scene_image(
                    state, prefer_key_frame=False, save_to_disk=False
                )
            if not img:
                raise RuntimeError("No usable BEV image for signal teacher")

            user_text = build_signal_teacher_prompt(state, legal)
            content = [
                {"type": "text", "text": user_text},
                {
                    "type": "image_url",
                    "image_url": {"url": f"data:image/png;base64,{img}"},
                },
            ]
            messages = [
                {"role": "system", "content": SYSTEM_PROMPT_SIGNAL_TEACHER},
                {"role": "user", "content": content},
            ]
            mode, _body, max_tokens, meta = self.resolve_call_budget(
                CHANNEL_SIGNAL_VISION
            )
            print(
                f"[SignalTeacher] model={self.model} thinking={mode} "
                f"max_tokens={max_tokens} ({meta.get('thinking_reason')}) "
                f"legal={legal}",
                flush=True,
            )
            raw = self._chat_once(
                messages,
                max_tokens=max_tokens,
                retries=1,
                channel=CHANNEL_SIGNAL_VISION,
            )
            advice = self._parse_signal_teacher_json(raw, legal)
            if float(advice.get("valid", 0.0)) < 0.5:
                repair_messages = list(messages) + [
                    {"role": "assistant", "content": raw},
                    {
                        "role": "user",
                        "content": (
                            "Previous reply was invalid. Return one JSON object with "
                            "recommended_phase (integer in legal_phases), confidence "
                            "in [0,1], visual_event, and reason (<=15 words). "
                            f"legal_phases={legal}"
                        ),
                    },
                ]
                repaired = self._chat_once(
                    repair_messages,
                    max_tokens=max_tokens,
                    retries=1,
                    channel=CHANNEL_SIGNAL_VISION,
                )
                advice = self._parse_signal_teacher_json(repaired, legal)
            print(
                "[SignalTeacher] advice: "
                + json.dumps(advice, ensure_ascii=False, sort_keys=True),
                flush=True,
            )
            return advice
        except Exception as exc:
            print(f"[SignalTeacher] inference failed: {exc}", flush=True)
            if bool(getattr(self, "fail_stop_on_vlm_error", False)):
                raise
            return self._invalid_signal_teacher_advice("exception")

    def _fetch_weights_task(self, state, junction_center, ep, step, prepared_image):
        try:
            self.fetch_reward_weights_sync(
                state,
                junction_center=junction_center,
                ep=ep,
                step=step,
                prepared_image=prepared_image,
            )
        except Exception as e:
            print(f"[VLM Thread Error] {str(e)}", flush=True)
        finally:
            with self.lock:
                self.vlm_thread_running = False

    def _compute_reward_weights(
        self,
        state,
        junction_center=None,
        ep=0,
        step=0,
        prepared_image=None,
        weight_mode="lon",
    ):
        """Compute longitudinal or lateral reward weights only.

        Signal VLM is deliberately not a reward-weight channel anymore.
        """
        raw_mode = str(weight_mode or "lon").strip().lower()
        if raw_mode in ("sig", "signal", "s", "tls", "signal_vision", "vision"):
            raise RuntimeError(
                "Signal VLM no longer generates W_sig. "
                "Use fetch_signal_vision_text() or fetch_signal_vision_semantics()."
            )
        if raw_mode in ("lat", "lateral", "l1"):
            wmode = "lat"
        else:
            wmode = "lon"
        center = junction_center if junction_center is not None else self.junction_center
        try:
            state = copy.deepcopy(dict(state)) if isinstance(state, Mapping) else {}
        except Exception:
            state = dict(state) if isinstance(state, Mapping) else {}
        base64_image = prepared_image or self.prepare_scene_image(
            state, junction_center=center, ep=ep, step=step
        )
        if not base64_image:
            raise RuntimeError("No usable BEV image is available for reward-weight inference.")

        reward_summary = None
        try:
            from reward.base_reward import BaseReward
            helper = getattr(self, "_vlm_reward_helper", None)
            if helper is None:
                helper = BaseReward()
                self._vlm_reward_helper = helper
            stats = _as_mapping(state.get("stats"))
            previous_summary = _as_mapping(stats.get("vlm_reward_summary"))
            control_zone = _safe_finite_number(previous_summary.get("control_zone_m"))
            if control_zone is not None and hasattr(helper, "control_zone_length"):
                helper.control_zone_length = control_zone
            reward_summary = helper.summarize_for_vlm(state)
            # Attach to this local prompt snapshot only; never mutate caller-owned state.
            stats["vlm_reward_summary"] = reward_summary
            state["stats"] = stats
        except Exception as exc:
            print(f"[VLM Thread] reward summary failed: {exc}", flush=True)

        prompt_text = build_scene_prompt(
            state, reward_summary=reward_summary, weight_mode=wmode
        )
        if wmode == "lat":
            system_prompt = SYSTEM_PROMPT_LAT
            channel = CHANNEL_LAT
        else:
            system_prompt = SYSTEM_PROMPT_LON
            channel = CHANNEL_LON
        mode, _body, max_tokens, meta = self.resolve_call_budget(channel)
        messages = [
            {"role": "system", "content": system_prompt},
            {
                "role": "user",
                "content": [
                    {
                        "type": "image_url",
                        "image_url": {"url": f"data:image/png;base64,{base64_image}"},
                    },
                    {"type": "text", "text": prompt_text},
                ],
            },
        ]

        print(
            f"[VLM Thread] Calling VLM model={self.model} mode={wmode} "
            f"thinking={mode} base={self.api_base} max_tokens={max_tokens} "
            f"({meta.get('thinking_reason')})",
            flush=True,
        )
        content = self._chat_once(messages, max_tokens=max_tokens, channel=channel)
        if os.environ.get("VLM_LOG_RAW", "").strip().lower() in ("1", "true", "yes", "on"):
            print(f"[VLM Thread] Raw API Response:\n{content}", flush=True)

        repair_keys = (
            "residual_risk, confidence, valid, traffic_mode "
            "(semantic_analysis optional, <=12 words)"
        )

        try:
            weights = self._parse_weight_json(content)
        except RuntimeError as first_exc:
            print(f"[VLM Thread] JSON parse failed, retrying once: {first_exc}")
            repair_messages = list(messages) + [
                {"role": "assistant", "content": content},
                {
                    "role": "user",
                    "content": (
                        "Your previous reply was truncated or invalid JSON. "
                        "Reply again with ONE complete JSON object only, including "
                        f"{repair_keys}. No markdown."
                    ),
                },
            ]
            content = self._chat_once(
                repair_messages, max_tokens=max_tokens, channel=channel
            )
            if os.environ.get("VLM_LOG_RAW", "").strip().lower() in ("1", "true", "yes", "on"):
                print(f"[VLM Thread] Retry Raw API Response:\n{content}", flush=True)
            weights = self._parse_weight_json(content)

        # Formal W is frozen; keep legacy weight keys filled from defaults so
        # older callers still see a complete dict. Residual fields are primary.
        if wmode == "lat":
            from reward.lateral_reward import DEFAULT_LAT_WEIGHTS as _DLAT

            _lat_defs = (
                ("lane_weight", "lane", float(_DLAT[0])),
                ("safe_lc_weight", "safe_lc", float(_DLAT[1])),
                ("eff_lc_weight", "eff_lc", float(_DLAT[2])),
                ("formation_weight", "form", float(_DLAT[3])),
                ("comfort_lc_weight", "comfort_lc", float(_DLAT[4])),
            )
            for canon, alias, default in _lat_defs:
                if canon not in weights and alias in weights:
                    weights[canon] = weights[alias]
                if canon not in weights:
                    weights[canon] = default
            self._clamp_weight_ranges(weights, self._LAT_WEIGHT_KEYS)
            self._renormalize_weight_group(weights, self._LAT_WEIGHT_KEYS)
            out = {k: float(weights[k]) for k in self._LAT_WEIGHT_KEYS}
        else:
            from reward.longitudinal_reward import DEFAULT_LONG_WEIGHTS as _DLON

            if "safety_weight" not in weights and "safety" in weights:
                weights["safety_weight"] = weights["safety"]
            if "efficiency_weight" not in weights and "efficiency" in weights:
                weights["efficiency_weight"] = weights["efficiency"]
            if "comfort_weight" not in weights and "comfort" in weights:
                weights["comfort_weight"] = weights["comfort"]
            if "platoon_weight" not in weights and "platoon" in weights:
                weights["platoon_weight"] = weights["platoon"]
            for key, default in (
                ("safety_weight", float(_DLON[0])),
                ("efficiency_weight", float(_DLON[1])),
                ("comfort_weight", float(_DLON[2])),
                ("platoon_weight", float(_DLON[3])),
            ):
                if key not in weights:
                    weights[key] = default
            self._clamp_weight_ranges(weights, self._LONG_WEIGHT_KEYS)
            self._renormalize_weight_group(weights, self._LONG_WEIGHT_KEYS)
            out = {k: float(weights[k]) for k in self._LONG_WEIGHT_KEYS}

        reason = weights.get("reason")
        traffic_mode = weights.get("traffic_mode")
        if isinstance(traffic_mode, str) and "|" in traffic_mode:
            traffic_mode = traffic_mode.split("|")[0].strip()
            weights["traffic_mode"] = traffic_mode
        analysis = weights.get("semantic_analysis", [])
        if isinstance(analysis, list):
            analysis = " ".join(str(x) for x in analysis)
        analysis = str(analysis).strip() if analysis else ""

        mode_l = str(traffic_mode or "").strip().lower()
        analysis_l = analysis.lower()
        if mode_l == "fallback" or "vlm inference failed" in analysis_l:
            raise RuntimeError(
                "Local/remote VLM returned Fallback residual (inference failed). "
                f"mode={traffic_mode!r} analysis={analysis[:160]!r}"
            )

        if traffic_mode or analysis:
            mode_txt = str(traffic_mode).strip() if traffic_mode else "Unknown"
            analysis_txt = analysis if analysis else (str(reason).strip() if reason else "")
            reason = f"Mode: {mode_txt}. Analysis: {analysis_txt}".strip()
        elif reason:
            reason = str(reason).strip()
        else:
            reason = "Mode: Unknown. Analysis: No semantic explanation returned."

        # Residual schema (preferred). Fall back to mode→risk if omitted.
        risk = None
        for key in ("residual_risk", "risk", "hazard"):
            if key not in weights:
                continue
            try:
                risk = float(weights.get(key))
            except (TypeError, ValueError, OverflowError):
                risk = None
            if risk is not None and math.isfinite(risk):
                break
        if risk is None:
            _mode_risk = {
                "safety_critical": 1.0,
                "safety-critical": 1.0,
                "congestion_dominated": 0.0,
                "queue_imbalance": 0.35,
                "platoon_opportunity": 0.0,
                "formation_opportunity": 0.0,
                "free_flow": 0.0,
            }
            mode_key = str(traffic_mode or "").strip().lower().replace(" ", "_")
            risk = float(_mode_risk.get(mode_key, 0.0))
        risk = float(min(1.0, max(0.0, risk)))
        try:
            # v4: missing confidence => residual OFF (v3 defaulted to 0.85 > 0.6 gate)
            conf = float(weights.get("confidence", 0.0) or 0.0)
        except (TypeError, ValueError, OverflowError):
            conf = 0.0
        conf = float(min(1.0, max(0.0, conf)))
        try:
            valid = float(weights.get("valid", 0.0) or 0.0)
        except (TypeError, ValueError, OverflowError):
            valid = 0.0
        valid = 1.0 if valid >= 0.5 else 0.0

        out["reason"] = reason
        out["traffic_mode"] = traffic_mode
        out["semantic_analysis"] = analysis
        out["weight_mode"] = wmode
        out["residual_risk"] = risk
        out["confidence"] = conf
        out["valid"] = valid
        print(
            f"[VLM Thread] Parsed mode={traffic_mode!r} "
            f"risk={risk:.3f} conf={conf:.2f} valid={valid:.0f} | "
            f"analysis={analysis!r}",
            flush=True,
        )
        return out


    def _note_served_model(self, completion):
        """v4: record which model actually answered (local servers may ignore 'model')."""
        try:
            served = getattr(completion, "model", None)
            if served is None and isinstance(completion, Mapping):
                served = completion.get("model")
            if not served:
                return
            served = str(served)
            meta = dict(getattr(self, "_last_vlm_call_meta", {}) or {})
            meta["served_model"] = served
            self._last_vlm_call_meta = meta
            if served != str(self.model) and not getattr(self, "_served_model_warned", False):
                self._served_model_warned = True
                print(
                    f"[VLM] WARNING: requested model={self.model!r} but the server "
                    f"answered as {served!r}; results are labelled by the requested name.",
                    flush=True,
                )
        except Exception:
            pass

    @staticmethod
    def _completion_to_text(completion):
        """Normalize OpenAI SDK / gateway responses into assistant text."""
        if completion is None:
            return "", None, None
        if isinstance(completion, str):
            result = completion.strip()
            if result.lower().startswith(("<!doctype", "<html")):
                raise RuntimeError(
                    "VLM API returned HTML instead of JSON — check --vlm-api-base "
                    "(usually needs .../v1) and that the key is valid."
                )
            return result, None, None

        if isinstance(completion, Mapping):
            error = completion.get("error")
            if error:
                raise RuntimeError(f"VLM API error: {error}")
            choices = completion.get("choices") or []
            if not choices:
                return "", None, completion.get("usage")
            choice = choices[0] if isinstance(choices[0], Mapping) else {}
            message = choice.get("message") or {}
            content = message.get("content") if isinstance(message, Mapping) else None
            return _content_as_text(content), choice.get("finish_reason"), completion.get("usage")

        choices = getattr(completion, "choices", None)
        if choices is None:
            raise RuntimeError(
                f"Unexpected VLM response type={type(completion).__name__}: "
                f"{str(completion)[:240]!r}"
            )
        choice = choices[0] if choices else None
        message = getattr(choice, "message", None) if choice is not None else None
        content = getattr(message, "content", None) if message is not None else None
        finish = getattr(choice, "finish_reason", None) if choice is not None else None
        return _content_as_text(content), finish, getattr(completion, "usage", None)

    def _thinking_extra_body(self):
        """Deprecated wrapper: use ``resolve_call_budget`` / ThinkingRuntime."""
        _mode, body, _reason = self._thinking_runtime.plan(
            self.api_base, model=self.model
        )
        return body

    def _chat_once(self, messages, max_tokens=4096, retries: int = 2, channel: str = CHANNEL_LON):
        """One chat completion; adapt thinking params from live API errors."""
        last_err = None
        attempts = max(1, int(retries) + 1)
        ch = normalize_channel(channel)
        mode, extra_body, reason = self._thinking_runtime.plan(
            self.api_base, model=self.model
        )
        # Recompute budget if caller passed a stale max_tokens before demotion.
        planned_max = int(max_tokens_for_channel(ch, mode))
        cur_max = int(max_tokens) if int(max_tokens) > 0 else planned_max
        # Prefer the centralized channel budget when caller used the old default.
        if int(max_tokens) >= 4096:
            cur_max = planned_max
        hard_cap = _env_int("VLM_MAX_TOKENS_CAP", 8192, minimum=1, maximum=65536)
        cur_max = min(max(1, cur_max), hard_cap)
        thinking_retries = 0
        max_thinking_retries = 2
        sampling_retries = 0
        _temp = _env_float("VLM_TEMPERATURE", 0.1, minimum=0.0, maximum=2.0)
        _top_p = _env_float("VLM_TOP_P", 1.0, minimum=0.0, maximum=1.0)
        _rep = _env_float("VLM_REPETITION_PENALTY", 1.0, minimum=0.1, maximum=3.0)
        # Opt out of sampling only when the gateway requires it (env flag).
        # Do not invent model-name lists for thinking capability.
        _omit_sampling = str(os.environ.get("VLM_FIXED_TEMPERATURE", "")).strip().lower() in (
            "1", "true", "yes", "on",
        )
        attempt = 0
        while attempt < attempts:
            try:
                create_kwargs = {
                    "model": self.model,
                    "messages": messages,
                    "max_tokens": cur_max,
                }
                if not _omit_sampling:
                    create_kwargs["temperature"] = _temp
                    create_kwargs["top_p"] = _top_p
                if extra_body:
                    create_kwargs["extra_body"] = dict(extra_body)
                if not _omit_sampling and _rep is not None:
                    try:
                        _is_local = (
                            "127.0.0.1" in str(self.api_base or "")
                            or "localhost" in str(self.api_base or "").lower()
                        )
                    except Exception:
                        _is_local = False
                    if _is_local:
                        _eb = dict(create_kwargs.get("extra_body") or {})
                        _eb.setdefault("repetition_penalty", float(_rep))
                        create_kwargs["extra_body"] = _eb
                self._last_vlm_call_meta = {
                    "channel": ch,
                    "thinking_mode": mode,
                    "thinking_reason": reason,
                    "max_tokens": cur_max,
                    "extra_body_keys": sorted((extra_body or {}).keys()),
                }
                completion = self.client.chat.completions.create(**create_kwargs)
                self._note_served_model(completion)
                text, finish, usage = self._completion_to_text(completion)
                if text:
                    self._thinking_runtime.on_success(mode)
                    return text

                choice = None
                msg = None
                choices = getattr(completion, "choices", None)
                if choices:
                    choice = choices[0]
                    msg = getattr(choice, "message", None)
                elif isinstance(completion, dict):
                    chs = completion.get("choices") or []
                    if chs and isinstance(chs[0], dict):
                        msg = chs[0].get("message")
                alt = self._extract_alt_message_text(msg, finish_reason=finish)
                if alt:
                    print(
                        f"[VLM Thread] content empty (finish={finish!r}); "
                        f"using alternate field ({len(alt)} chars)"
                    )
                    self._thinking_runtime.on_success(mode)
                    return alt

                details = getattr(usage, "completion_tokens_details", None) if usage else None
                if details is None and isinstance(usage, dict):
                    details = usage.get("completion_tokens_details")
                reasoning_toks = (
                    details.get("reasoning_tokens")
                    if isinstance(details, dict)
                    else getattr(details, "reasoning_tokens", None)
                )
                last_err = RuntimeError(
                    f"VLM returned empty message content "
                    f"(finish_reason={finish!r}, max_tokens={cur_max}, "
                    f"reasoning_tokens={reasoning_toks}, "
                    f"thinking={mode}, attempt={attempt + 1}/{attempts})"
                )
                # Shared reasoning+answer budget ate the completion → raise cap.
                if str(finish).lower() == "length" and cur_max < hard_cap:
                    cur_max = min(hard_cap, max(cur_max * 2, planned_max * 2))
                    print(
                        f"[VLM Thread] length-truncated empty content; "
                        f"raising max_tokens -> {cur_max}"
                    )
            except Exception as exc:
                last_err = exc
                error_text = str(exc).lower()
                sampling_param_error = (
                    ("temperature" in error_text or "top_p" in error_text or "top-p" in error_text)
                    and any(token in error_text for token in (
                        "unsupported", "not support", "unknown", "invalid", "unexpected",
                        "unrecognized", "not allowed", "not permitted", "does not support"
                    ))
                )
                if not _omit_sampling and sampling_retries < 1 and sampling_param_error:
                    _omit_sampling = True
                    sampling_retries += 1
                    print(
                        "[VLM Thread] gateway rejected sampling parameters; retrying without them.",
                        flush=True,
                    )
                    continue
                if (
                    thinking_retries < max_thinking_retries
                    and is_thinking_param_error(exc)
                    and extra_body
                ):
                    mode, extra_body, reason = self._thinking_runtime.on_param_rejected(
                        self.api_base, mode, exc
                    )
                    cur_max = min(int(max_tokens_for_channel(ch, mode)), hard_cap)
                    thinking_retries += 1
                    print(
                        f"[VLM Thread] thinking params rejected; demote to "
                        f"{mode} max_tokens={cur_max} ({reason})",
                        flush=True,
                    )
                    continue
            attempt += 1
            if attempt < attempts:
                print(
                    f"[VLM Thread] empty/error reply, retrying "
                    f"({attempt}/{attempts}): {last_err}"
                )
                time.sleep(1.5 * attempt)
        raise RuntimeError(str(last_err) if last_err else "VLM returned empty message content")

    @staticmethod
    def _extract_alt_message_text(msg, finish_reason=None) -> str:
        """Extract final JSON from non-standard fields only when not length-truncated."""
        if msg is None:
            return ""
        if str(finish_reason or "").strip().lower() == "length":
            return ""
        candidates = []
        keys = ("reasoning_content", "reasoning", "refusal")
        if isinstance(msg, Mapping):
            for key in keys:
                value = msg.get(key)
                if value:
                    candidates.append(str(value))
        else:
            for key in keys:
                value = getattr(msg, key, None)
                if value:
                    candidates.append(str(value))
            if hasattr(msg, "model_dump"):
                try:
                    dump = msg.model_dump()
                except Exception:
                    dump = None
                if isinstance(dump, Mapping):
                    for key in keys:
                        value = dump.get(key)
                        if value:
                            candidates.append(str(value))

        for candidate in candidates:
            candidate = str(candidate).strip()
            if not candidate:
                continue
            if re.search(
                r"(residual_risk|traffic_mode|recommended_phase|"
                r"safety_weight|efficiency_weight|lane_weight|platoon_weight|"
                r"safe_lc_weight|eff_lc_weight|formation_weight|comfort_lc_weight|"
                r"lane_blockage|incident_obstruction|spillback|unseen_scene)",
                candidate,
            ):
                last_obj = _extract_last_json_object(candidate)
                if last_obj:
                    return last_obj
        return ""

    _LONG_WEIGHT_KEYS = (
        "safety_weight",
        "efficiency_weight",
        "comfort_weight",
        "platoon_weight",
    )
    _LAT_WEIGHT_KEYS = (
        "lane_weight",
        "safe_lc_weight",
        "eff_lc_weight",
        "formation_weight",
        "comfort_lc_weight",
    )
    # Stage-S uses visual semantics only; there are no VLM-generated signal weights.
    _WEIGHT_RANGES = {
        "lane_weight": (0.08, 0.25),
        "safe_lc_weight": (0.20, 0.38),
        "eff_lc_weight": (0.14, 0.28),
        "formation_weight": (0.14, 0.34),
        "comfort_lc_weight": (0.14, 0.25),
        "safety_weight": (0.15, 0.35),
        "efficiency_weight": (0.28, 0.52),
        "comfort_weight": (0.10, 0.25),
        "platoon_weight": (0.12, 0.28),
    }

    @classmethod
    def _clamp_weight_ranges(cls, data: dict, keys) -> None:
        """Clamp finite numeric weights; replace malformed values with range midpoints."""
        for key in keys:
            if key not in data:
                continue
            low, high = cls._WEIGHT_RANGES.get(key, (0.0, 1.0))
            value = data[key]
            try:
                number = float(value) if not isinstance(value, bool) else float("nan")
            except (TypeError, ValueError, OverflowError):
                number = float("nan")
            if not math.isfinite(number):
                number = (float(low) + float(high)) / 2.0
            data[key] = min(float(high), max(float(low), number))

    @classmethod
    def _renormalize_weight_group(cls, data: dict, keys) -> None:
        """Project a complete weight group onto its bounded simplex (sum exactly 1)."""
        keys = tuple(keys)
        if not keys or any(key not in data for key in keys):
            # Never renormalize a partial group: missing weights are filled from
            # environment defaults first, then this method is called again.
            return

        lows = np.asarray([cls._WEIGHT_RANGES.get(k, (0.0, 1.0))[0] for k in keys], dtype=np.float64)
        highs = np.asarray([cls._WEIGHT_RANGES.get(k, (0.0, 1.0))[1] for k in keys], dtype=np.float64)
        values = []
        for key, low, high in zip(keys, lows, highs):
            try:
                value = float(data[key]) if not isinstance(data[key], bool) else float("nan")
            except (TypeError, ValueError, OverflowError):
                value = float("nan")
            if not math.isfinite(value):
                value = (float(low) + float(high)) / 2.0
            values.append(value)
        values = np.asarray(values, dtype=np.float64)

        if float(lows.sum()) > 1.0 + 1e-8 or float(highs.sum()) < 1.0 - 1e-8:
            raise RuntimeError(f"Infeasible weight bounds for keys={keys!r}")

        # Find lambda where sum(clip(values + lambda, low, high)) = 1.
        left = float(np.min(lows - values)) - 1.0
        right = float(np.max(highs - values)) + 1.0
        for _ in range(80):
            mid = (left + right) / 2.0
            total = float(np.clip(values + mid, lows, highs).sum())
            if total < 1.0:
                left = mid
            else:
                right = mid
        projected = np.clip(values + (left + right) / 2.0, lows, highs)
        rounded = [round(float(value), 4) for value in projected]

        drift = round(1.0 - sum(rounded), 4)
        if abs(drift) > 0:
            order = sorted(
                range(len(keys)),
                key=lambda i: (
                    (highs[i] - rounded[i]) if drift > 0 else (rounded[i] - lows[i])
                ),
                reverse=True,
            )
            for i in order:
                candidate = rounded[i] + drift
                if lows[i] - 1e-8 <= candidate <= highs[i] + 1e-8:
                    rounded[i] = round(min(float(highs[i]), max(float(lows[i]), candidate)), 4)
                    break

        for key, value in zip(keys, rounded):
            data[key] = float(value)

    @classmethod
    def _parse_weight_json(cls, content: str) -> dict:
        """Parse a JSON object and reject non-finite or non-numeric weight values."""
        raw_content = str(content or "").strip()
        if not raw_content:
            raise RuntimeError("VLM response is empty")

        candidate = _extract_first_json_object(raw_content)
        if candidate is None:
            raise RuntimeError(f"VLM response contains no JSON object: {raw_content[:120]!r}")

        def reject_constant(value):
            raise ValueError(f"Non-standard JSON numeric constant: {value}")

        try:
            data = json.loads(candidate, parse_constant=reject_constant)
        except (json.JSONDecodeError, ValueError, TypeError) as exc:
            raise RuntimeError(
                f"VLM response is not valid finite JSON: {raw_content[:160]!r}"
            ) from exc
        if not isinstance(data, dict):
            raise RuntimeError(
                f"VLM JSON root must be an object, got {type(data).__name__}"
            )

        weight_fields = set(cls._LONG_WEIGHT_KEYS) | set(cls._LAT_WEIGHT_KEYS) | {
            "safety", "efficiency", "comfort", "platoon",
        }
        for key in weight_fields:
            if key not in data:
                continue
            value = data[key]
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                raise RuntimeError(f"VLM weight {key!r} must be a JSON number")
            if not math.isfinite(float(value)):
                raise RuntimeError(f"VLM weight {key!r} must be finite")

        if "traffic_mode" in data and not isinstance(data["traffic_mode"], str):
            raise RuntimeError("VLM traffic_mode must be a string")
        if "semantic_analysis" in data and not isinstance(
            data["semantic_analysis"], (str, list)
        ):
            raise RuntimeError("VLM semantic_analysis must be a string or list")

        # When a complete lon/lat group is present, project onto the bounded
        # simplex so callers (and unit tests) see sum==1 after fence-stripped JSON.
        if all(k in data for k in cls._LONG_WEIGHT_KEYS):
            cls._clamp_weight_ranges(data, cls._LONG_WEIGHT_KEYS)
            cls._renormalize_weight_group(data, cls._LONG_WEIGHT_KEYS)
        if all(k in data for k in cls._LAT_WEIGHT_KEYS):
            cls._clamp_weight_ranges(data, cls._LAT_WEIGHT_KEYS)
            cls._renormalize_weight_group(data, cls._LAT_WEIGHT_KEYS)
        return data
