
import math
from collections.abc import Mapping


# ============================================================
# Stage-Lon: Longitudinal residual (fixed formal W_long)
# ============================================================

SYSTEM_PROMPT_LON = """
You are a traffic-scene semantic residual advisor for a hierarchical
VLM + MAPPO cooperative traffic-control system at mixed CAV/HDV
intersections.

Your task in Stage-Lon is to analyze the SUMO BEV image and structured
statistics, then output ONLY a bounded residual risk for the
longitudinal reward. Formal W_long is frozen; you do NOT retune weights.

Do NOT output vehicle actions, trajectories, accelerations, signal
commands, lateral residuals, or reward weights.

## 1. Control architecture

- Signal actor is frozen; lateral actor is inactive in Stage-Lon.
- Longitudinal RL uses a fixed formal reward (safe/eff/comfort/platoon)
  with three-mode efficiency (Pass / Stop / Maintain).
- Your residual only patches visual / semantic blind spots the formal
  term cannot see (near-miss clustering, abnormal idle, over-sprint
  into a queue, spill that harms following).
- Residual magnitude is applied as δ = -0.05 * confidence * residual_risk
  with confidence < 0.60 → δ = 0.

## 2. Evidence interpretation

Use visual evidence and supplied statistics.

- min_TTC, frac_unsafe_ttc, danger_events, queue_total, avg_speed,
  platoon_rate.
- Do not invent missing values from pixels.
- Ordinary red-light queuing or smooth kinematic braking is NOT a
  high residual risk.

## 3. Strict decision priority (first match wins)

### Rule 1: Safety_Critical
Trigger when ANY of the following holds:
- min_TTC < 1.5 s
- danger_events >= 2
- frac_unsafe_ttc > 0.10
→ traffic_mode="Safety_Critical", residual_risk in [0.85, 1.0],
  confidence in [0.75, 0.95].

### Rule 2: Congestion_Dominated
Otherwise, if either condition holds:
- queue_total >= 32
- avg_speed < 5.0 m/s
→ traffic_mode="Congestion_Dominated", residual_risk in [0.0, 0.15],
  confidence in [0.70, 0.90].
Do NOT treat ordinary 3-leg queues of 10–30 as Congestion_Dominated.

### Rule 3: Platoon_Opportunity
Otherwise, if ALL conditions hold:
- queue_total < 32
- avg_speed >= 6.8 m/s
- platoon_rate >= 0.20
- min_TTC >= 1.5 s
→ traffic_mode="Platoon_Opportunity", residual_risk in [0.0, 0.15],
  confidence in [0.65, 0.85].

### Rule 4: Free_Flow
Otherwise → traffic_mode="Free_Flow", residual_risk = 0.0,
  confidence in [0.60, 0.85]. If evidence is weak, lower confidence
  below 0.60 so the residual stays off.

## 4. Output format

Return exactly one valid JSON object. No Markdown, no code fences.

{
  "traffic_mode": "Safety_Critical | Platoon_Opportunity | Congestion_Dominated | Free_Flow",
  "semantic_analysis": "At most 12 words citing evidence, or empty string.",
  "residual_risk": 0.0,
  "confidence": 0.85,
  "valid": 1.0
}
""".strip()


# ============================================================
# Stage-Lat: Lateral residual (fixed formal W_lat)
# ============================================================

SYSTEM_PROMPT_LAT = """
You are a traffic-scene semantic residual advisor for a hierarchical
VLM + MAPPO cooperative traffic-control system at mixed CAV/HDV
intersections.

Your task in Stage-Lat is to analyze the SUMO BEV image and structured
statistics, then output ONLY a bounded residual risk for the lateral
reward. Formal W_lat is frozen; you do NOT retune weights.

Do NOT output vehicle actions, lane-change commands, trajectories,
signal commands, longitudinal residuals, or reward weights.

## 1. Control architecture

- Signal and longitudinal actors are frozen; only the lateral actor trains.
- Formal lateral reward stays fixed; your residual patches visual blind
  spots (unsafe LC scene, blocked target lane, severe queue imbalance
  that formal terms understate).
- Residual: δ = -0.05 * confidence * residual_risk; confidence < 0.60 → 0.

## 2. Evidence interpretation

- thru_dlc_queue_diff, n_dlc, min_TTC, frac_unsafe_ttc, danger_events.
- Do not invent missing values.
- Ordinary red-light queuing alone is not a high residual risk.
- Never imply illegal or unsafe lane changes.

## 3. Strict decision priority (first match wins)

### Rule 1: Safety_Critical
min_TTC < 1.2 s AND (frac_unsafe_ttc > 0.15 OR danger_events >= 3)
→ traffic_mode="Safety_Critical", residual_risk in [0.85, 1.0],
  confidence in [0.75, 0.95].

### Rule 2: Queue_Imbalance
thru_dlc_queue_diff >= 2
→ traffic_mode="Queue_Imbalance", residual_risk in [0.15, 0.35],
  confidence in [0.70, 0.90].

### Rule 3: Formation_Opportunity
thru_dlc_queue_diff < 2 AND n_dlc >= 2
→ traffic_mode="Formation_Opportunity", residual_risk in [0.0, 0.15],
  confidence in [0.65, 0.85].

### Rule 4: Free_Flow
Otherwise → traffic_mode="Free_Flow", residual_risk = 0.0,
  confidence in [0.60, 0.85]. Weak evidence → confidence < 0.60.

## 4. Output format

Return exactly one valid JSON object. No Markdown or extra text.

{
  "traffic_mode": "Safety_Critical | Queue_Imbalance | Formation_Opportunity | Free_Flow",
  "semantic_analysis": "At most 12 words citing evidence, or empty string.",
  "residual_risk": 0.0,
  "confidence": 0.85,
  "valid": 1.0
}
""".strip()


# ============================================================
# Stage-S: Signal visual-semantic encoding (not reward weights)
# ============================================================

SYSTEM_PROMPT_SIGNAL_VISION = """
You are a visual-semantic encoder for Stage-S signal control in a
hierarchical VLM + MAPPO cooperative traffic-control system.

Your task in Stage-S is scene perception only: analyze the supplied
SUMO bird's-eye-view (BEV) image (and optional numeric statistics) and
return ONLY the specified JSON semantic features.

Architecture context:
- Stage-S trains the signal actor. Longitudinal and lateral RL actors
  are not the focus of this call.
- The formal signal objective (queue / wait, 3:1) is computed in code.
  Your semantics feed only the bounded visual residual R_res
  (spillback / blockage / incident-style events).
- Do NOT adapt reward weights. There is no W_sig channel in Stage-S.

NEVER output:
- signal reward weights or W_sig;
- longitudinal or lateral reward weights;
- signal phase selections or green durations;
- vehicle actions, trajectories, acceleration commands or lane-change
  commands;
- explanations outside the required JSON object.

## 1. Image interpretation

This is a synthetic simulator BEV render, not necessarily a real
roadside camera image.

BEV legend:
- Orange vehicles are CAVs.
- White vehicles are HDVs.
- Dark windshield marks indicate vehicle heading.
- White lines indicate lanes and intersection geometry.
- Approach stop bars may use red, yellow or green to represent the
  live signal state. These colors are NOT evidence of road blockage.
- Departure-side stop bars remain white.

Use the supplied image as the primary evidence for visual semantics.
Use numeric statistics as supporting context, not as a replacement
for visual evidence.

## 2. Required semantic fields

Return exactly these eight fields, each represented as a number
between 0.0 and 1.0.

1. lane_blockage
   Degree of evidence that a lane near the intersection or stop bar
   is physically blocked or impassable.

2. spillback
   Degree of evidence that a queue has extended upstream enough to
   obstruct an upstream junction, upstream access, or intersection box.

3. incident_obstruction
   Degree of visible evidence of a crash, disabled vehicle, debris,
   or another incident physically obstructing traffic.

4. roadwork
   Degree of visible evidence of a work zone, temporary lane closure,
   construction barrier, or road maintenance obstruction.

5. special_vehicle
   Degree of evidence that a bus, emergency vehicle, or explicitly
   identifiable priority vehicle is present near the junction.

6. unseen_scene
   Set close to 1.0 when the image is missing, unreadable, severely
   obscured, or provides almost no useful scene information.
   Set close to 0.0 when the scene is adequately visible.

7. confidence
   Confidence in the semantic assessment as a whole.

8. valid
   Set to 1.0 when the image is usable and the returned JSON is a
   meaningful assessment. Set to 0.0 when the image is unusable or
   a reliable assessment cannot be made.

## 3. Critical distinctions

- Ordinary queued vehicles do not automatically imply lane_blockage.
- A long queue does not automatically imply spillback. Look for
  evidence of upstream extension or blocked junction access.
- Congestion alone does not imply incident_obstruction.
- Normal lane markings do not imply roadwork.
- Red, yellow and green signal colors do not imply a blocked lane.
- Do not infer a crash, construction area or special vehicle without
  visual evidence.
- Do not invent vehicle counts, wait times, road geometry or events.
- When evidence is weak, use conservative low scores.
- If a condition is genuinely ambiguous, reflect the uncertainty
  in confidence instead of inventing a definite event.
- If the image is usable and no special event is visible, return low
  event scores with valid = 1.0. Do not mark a normal scene invalid
  simply because no incident is present.

## 4. Output constraints

- Output exactly one JSON object.
- Include all eight required keys.
- All values must be finite numeric values in [0.0, 1.0].
- Do not use null, NaN, Infinity, strings in place of numbers,
  Markdown, comments or additional keys.
- Do not output reward weights or controller actions.

Output schema:

{
  "lane_blockage": 0.0,
  "spillback": 0.0,
  "incident_obstruction": 0.0,
  "roadwork": 0.0,
  "special_vehicle": 0.0,
  "unseen_scene": 0.0,
  "confidence": 1.0,
  "valid": 1.0
}
""".strip()


# ============================================================
# Backward-compatible exported names
# ============================================================

# Existing code importing SYSTEM_PROMPT continues to receive
# the longitudinal reward-weight prompt.
SYSTEM_PROMPT = SYSTEM_PROMPT_LON

# IMPORTANT:
# Signal VLM no longer generates W_sig. This legacy symbol now points
# to the independent visual-semantic prompt.
SYSTEM_PROMPT_SIG = SYSTEM_PROMPT_SIGNAL_VISION


SYSTEM_PROMPT_SIGNAL_TEACHER = """
You are a Stage-S traffic-signal teacher for a SUMO bird's-eye-view
(BEV) intersection render used in hierarchical VLM + MAPPO training.

Your task in Stage-S is to recommend exactly one legal green phase.
You do not output reward weights, W_sig, longitudinal/lateral weights,
continuous green durations, or vehicle controls. The formal 3:1
queue/wait objective remains in the numeric reward; use BEV evidence
plus the supplied queue/wait statistics to choose among legal_phases.

## 1. BEV interpretation & critical visual distinctions
- Orange vehicles = CAVs; white vehicles = HDVs; dark windshield = heading.
- Approach stop bars colored red / yellow / green represent the live signal
  state, NOT road blockage or construction.
- Ordinary queued vehicles waiting at a red light do NOT imply "blockage"
  or "spillback".
- Set visual_event = "spillback" when a queue visibly extends far
  upstream near the approach boundary, crowds the BEV frame edge, or
  obstructs the intersection box (beyond ordinary stop-bar waiting).
- Set visual_event = "blockage" ONLY when a disabled vehicle or physical
  obstacle blocks a lane or the junction box.
- Set visual_event = "incident" when a vehicle collision / crash obstructs
  traffic, or "roadwork" when construction barriers / work zones narrow lanes.

## 2. Phase selection rules (aligned with 3:1 queue/wait objective)
- Choose recommended_phase ONLY from the supplied legal_phases list.
- Primary objective (weight 3/4): favor the legal phase serving the longest
  physical queue (queue_m) to clear approach backlogs efficiently.
- Secondary objective (weight 1/4, anti-starvation): if a non-active legal
  phase has accumulated high waiting time (e.g., avg_wait >= 40s or
  max_wait approaching the 105s starvation limit) while the current green
  queue is already small or draining, switch to serve the waiting phase.
- Downstream protection: avoid selecting a phase whose receiving/downstream
  lanes show visible spillback or junction blockage in the BEV image.
- Do NOT invent illegal phases, reward weights, or continuous green times.
- When evidence is ambiguous, lower confidence rather than guessing.

## 3. Output format
Return exactly one JSON object (no Markdown, no extra text):
{
  "recommended_phase": 0,
  "confidence": 0.85,
  "visual_event": "none | spillback | queue_imbalance | blockage | incident | roadwork | special_vehicle",
  "reason": "<=15 words citing visual & queue/wait evidence"
}
All numeric fields must be finite. recommended_phase is an integer green
index from legal_phases. confidence is in [0.0, 1.0].
""".strip()


_BEV_LEGEND = """
BEV legend:
- Orange vehicles = CAVs; white vehicles = HDVs.
- Dark windshield marks heading.
- White lines = lanes / intersection geometry.
- Approach stop bars may be colored red / yellow / green to represent
  the live signal state. These colors do not indicate road blockage.
- Departure-side stop bars remain white.
""".strip()



# ============================================================
# Defensive parsing helpers for prompt construction
# ============================================================

_MISSING_TEXT = {"", "n/a", "na", "none", "null", "unknown", "not available", "missing"}


def _as_dict(value):
    """Return a shallow dictionary for mapping-like values, otherwise empty."""
    return dict(value) if isinstance(value, Mapping) else {}


def _optional_float(value):
    """Parse a finite number; preserve missing/invalid values as None."""
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, str) and value.strip().lower() in _MISSING_TEXT:
        return None
    try:
        number = float(value)
    except (TypeError, ValueError, OverflowError):
        return None
    return number if math.isfinite(number) else None


def _safe_float(value, default=0.0):
    number = _optional_float(value)
    return float(default) if number is None else number


def _safe_int(value, default=0):
    number = _optional_float(value)
    return int(default) if number is None else int(number)


def _safe_len(value):
    try:
        return len(value)
    except (TypeError, AttributeError):
        return 0


def _count_value(value, container=None):
    """Use a supplied count, or infer it only from an explicitly supplied container."""
    number = _optional_float(value)
    if number is not None:
        return max(0, int(number))
    if isinstance(container, (Mapping, list, tuple, set)):
        return len(container)
    return None


def _format_optional(value, fmt=".2f"):
    number = _optional_float(value)
    return "N/A" if number is None else format(number, fmt)


def _format_ttc(value):
    """Format TTC without interpreting missing values as zero."""
    return _format_optional(value, ".2f")


def _format_metric(value, fmt=".2f", default=None):
    """Format a numeric metric; use a default only when one was explicitly supplied."""
    if value is None and default is not None:
        value = default
    return _format_optional(value, fmt)


def _first_number(*values):
    for value in values:
        number = _optional_float(value)
        if number is not None:
            return number
    return None


def _key_value_text(items, fmt=".1f", separator="/"):
    rendered = []
    for key, value in items:
        number = _optional_float(value)
        if number is not None:
            rendered.append(f"{key}:{format(number, fmt)}")
    return separator.join(rendered) if rendered else "N/A (not supplied)"


# ============================================================
# Scene prompt builder for Lon / Lat / Signal Vision
# ============================================================

def build_scene_prompt(state, reward_summary=None, weight_mode="lon"):
    """
    Build a task-specific user prompt without fabricating missing statistics.

    Supported modes:
      lon -> longitudinal semantic residual risk (formal W_long frozen)
      lat -> lateral semantic residual risk (formal W_lat frozen)
      sig / signal / vision -> signal visual semantics ONLY
    """
    state = _as_dict(state)
    mode = str(weight_mode or "lon").strip().lower()

    if mode in {
        "sig", "signal", "s", "tls", "vision", "signal_vision", "visual_semantics"
    }:
        return build_signal_vision_prompt(state, reward_summary=reward_summary)

    if mode not in {"lon", "longitudinal", "l", "lat", "lateral", "l1"}:
        raise ValueError(
            f"Unsupported weight_mode={weight_mode!r}. "
            "Expected lon, lat, or signal vision mode."
        )

    stats = _as_dict(state.get("stats"))
    signals = _as_dict(state.get("signals"))
    cavs = state.get("cavs") if "cavs" in state else None
    hdvs = state.get("hdvs") if "hdvs" in state else None

    num_cavs = _count_value(stats.get("cav_number"), cavs)
    num_hdvs = _count_value(stats.get("hdv_number"), hdvs)
    total_vehicles = _count_value(stats.get("total_vehicles"))
    if total_vehicles is None and num_cavs is not None and num_hdvs is not None:
        total_vehicles = num_cavs + num_hdvs

    signal_phase = "Unknown"
    remaining_time = None
    if signals:
        tls_id = next(iter(signals))
        tls = _as_dict(signals.get(tls_id))
        signal_phase = (
            f"Phase {tls.get('phase', 'Unknown')} "
            f"(State: {tls.get('state', 'Unknown')})"
        )
        remaining_time = _optional_float(tls.get("remaining_time"))

    summary_source = (
        reward_summary if isinstance(reward_summary, Mapping)
        else stats.get("vlm_reward_summary")
    )
    rs = _as_dict(summary_source)

    queue_by = _as_dict(rs.get("queue_by_approach"))
    if not queue_by:
        queue_by = _as_dict(stats.get("queue_by_approach"))

    queue_items = []
    if queue_by:
        queue_items = [
            (str(key), value) for key, value in queue_by.items()
            if _optional_float(value) is not None
        ]
    if not queue_items:
        for direction in ("N", "S", "E", "W", "FZ"):
            key = f"queue_{direction}"
            if key in stats and _optional_float(stats.get(key)) is not None:
                queue_items.append((direction, stats[key]))

    queue_txt = _key_value_text(queue_items)
    q_vals = [_optional_float(value) for _, value in queue_items]
    q_vals = [value for value in q_vals if value is not None]
    q_sorted = sorted(q_vals, reverse=True)
    max_queue = q_sorted[0] if q_sorted else None
    second_max_queue = q_sorted[1] if len(q_sorted) > 1 else None

    queue_diff = _first_number(rs.get("queue_diff"))
    if queue_diff is None and max_queue is not None and second_max_queue is not None:
        queue_diff = max_queue - second_max_queue

    queue_total = _first_number(
        rs.get("queue_total"),
        stats.get("queue_length"),
    )

    def metric(key, default=None, fmt=".2f"):
        value = rs.get(key)
        if value is None:
            value = default
        return _format_metric(value, fmt)

    # Prefer sliding-window / 500 m corridor aggregates in stats over
    # instantaneous 200 m control-zone values recomputed into rs.
    corridor_platoon_rate = _first_number(
        stats.get("platoon_rate"), rs.get("platoon_rate")
    )
    corridor_lc_rate = _first_number(
        stats.get("lane_change_rate"), rs.get("lane_change_rate")
    )
    corridor_dlc_diff = _first_number(
        stats.get("thru_dlc_queue_diff"), rs.get("thru_dlc_queue_diff")
    )
    corridor_n_dlc = _first_number(
        stats.get("n_dlc"), rs.get("n_dlc"), num_cavs
    )

    wait_items = []
    for direction in ("N", "S", "E", "W", "FZ"):
        key = f"max_wait_{direction}"
        if key in stats and _optional_float(stats.get(key)) is not None:
            wait_items.append((direction, stats[key]))
    max_wait = _first_number(
        rs.get("max_wait_time_s"),
        stats.get("max_waiting_time"),
        stats.get("max_wait"),
    )
    if max_wait is None and wait_items:
        max_wait = max(_optional_float(value) for _, value in wait_items)
    wait_txt = _key_value_text(
        [(direction, f"{_optional_float(value):.0f}") for direction, value in wait_items],
        fmt=".0f",
    ) if wait_items else "N/A (not supplied)"
    # Add units without turning missing values into zero.
    if wait_items:
        wait_txt = "/".join(
            f"{direction}:{_optional_float(value):.0f}s"
            for direction, value in wait_items
        )

    progress_items = []
    for direction in ("N", "S", "E", "W", "FZ"):
        key = f"n_prog_{direction}"
        if key in stats and _optional_float(stats.get(key)) is not None:
            progress_items.append((direction, stats[key]))
    n_prog = _count_value(stats.get("green_wave_candidate_number"))
    if n_prog is None and progress_items:
        n_prog = sum(max(0, int(_optional_float(value))) for _, value in progress_items)
    prog_txt = _key_value_text(progress_items, fmt=".0f")

    num_cavs_txt = "N/A" if num_cavs is None else str(num_cavs)
    num_hdvs_txt = "N/A" if num_hdvs is None else str(num_hdvs)
    total_vehicles_txt = "N/A" if total_vehicles is None else str(total_vehicles)
    n_prog_txt = "N/A" if n_prog is None else str(n_prog)

    ttc_thr = metric("ttc_threshold_s", 1.5, ".1f")
    control_zone = metric("control_zone_m", 200.0, ".0f")
    vmax = metric("v_max", 16.67, ".2f")

    header = f"""{_BEV_LEGEND}

Current scene (use the supplied image and numerical statistics):
- Simulation time: {_format_metric(stats.get('time'), '.1f')} s
- Current signal: {signal_phase}
- Remaining green time: {_format_metric(remaining_time, '.1f')} s
- Vehicles: total={total_vehicles_txt}, CAV={num_cavs_txt}, HDV={num_hdvs_txt}
- Average speed: {_format_metric(stats.get('average_speed'), '.2f')} m/s
- Queues by approach: {queue_txt}
- Maximum queue: {_format_metric(max_queue, '.1f')}
- Queue difference: {_format_metric(queue_diff, '.1f')}
- Total queue proxy: {_format_metric(queue_total, '.1f')}
- Maximum waiting time: {_format_metric(max_wait, '.1f')} s
- Waiting time by approach: {wait_txt}
- Starvation fraction: {_format_metric(stats.get('starve_fraction'), '.3f')}
- Approaching vehicles: {_format_metric(stats.get('approaching_vehicle_number'), '.0f')}
- Average ETA: {_format_metric(stats.get('average_ETA'), '.2f')} s
- Green-wave candidates: {n_prog_txt} [{prog_txt}]
- Legal through-lane queue difference: {_format_metric(corridor_dlc_diff, '.1f')}
- Relevant CAVs for lane changes: {_format_metric(corridor_n_dlc, '.0f')}

Reward-aligned CAV statistics:
- Control zone: {control_zone}m
- Maximum speed: {vmax}m/s
- TTC threshold: {ttc_thr}s
- Minimum TTC: {_format_ttc(stats.get('min_ttc'))}
- Danger events: {_format_metric(stats.get('danger_event_number'), '.0f')}
- Unsafe TTC count: {_format_metric(rs.get('n_unsafe_ttc'), '.0f')}
- Unsafe TTC fraction: {metric('frac_unsafe_ttc')}
- Average zone progress: {metric('avg_zone_progress')}
- Average control time: {metric('avg_control_time_s', None, '.1f')} s
- Acceleration variance: {_format_metric(stats.get('acc_variance'), '.3f')}
- Mean absolute acceleration: {metric('mean_abs_accel')}
- Platoon rate: {_format_metric(corridor_platoon_rate, '.2f')}
- Lane-change rate: {_format_metric(corridor_lc_rate, '.2f')}
"""

    if mode in {"lat", "lateral", "l1"}:
        task = """
Task: evaluate ONLY the Stage-Lat lateral semantic residual risk.

Return one compact JSON object with:
traffic_mode, semantic_analysis, residual_risk, confidence, valid.

Follow the Stage-Lat system prompt priority rules (Safety_Critical >
Queue_Imbalance > Formation_Opportunity > Free_Flow). Do NOT output
reward weights or vehicle actions.
"""
    else:
        task = """
Task: evaluate ONLY the Stage-Lon longitudinal semantic residual risk.

Return one compact JSON object with:
traffic_mode, semantic_analysis, residual_risk, confidence, valid.

Follow the Stage-Lon system prompt priority rules (Safety_Critical >
Congestion_Dominated > Platoon_Opportunity > Free_Flow). Do NOT output
reward weights or vehicle actions.
"""

    return header + "\n" + task


# ============================================================
# Dedicated signal visual-semantic prompt builder
# ============================================================

def build_signal_vision_prompt(state, reward_summary=None):
    """
    Build the user prompt for signal visual-semantic encoding.

    This task is independent of reward-weight adaptation. Missing statistics
    are shown as N/A rather than silently represented as zero.
    """
    state = _as_dict(state)
    stats = _as_dict(state.get("stats"))
    summary_source = (
        reward_summary if isinstance(reward_summary, Mapping)
        else stats.get("vlm_reward_summary")
    )
    rs = _as_dict(summary_source)

    queue = _first_number(
        rs.get("queue_total"),
        stats.get("queue_length"),
        stats.get("avg_queue_length"),
    )
    max_wait = _first_number(
        rs.get("max_wait_time_s"),
        stats.get("max_waiting_time"),
        stats.get("max_wait"),
    )

    source = str(state.get("image_source") or "sumo_bev_synthetic")
    junction_name = str(
        state.get("junction_name") or stats.get("junction_name") or "junction"
    )

    signals = _as_dict(state.get("signals"))
    signal_description = "Unknown"
    if signals:
        tls_id = next(iter(signals))
        tls = _as_dict(signals.get(tls_id))
        remaining = _format_metric(tls.get("remaining_time"), ".1f")
        signal_description = (
            f"phase={tls.get('phase', 'Unknown')}, "
            f"state={tls.get('state', 'Unknown')}, "
            f"remaining_green={remaining}s"
        )

    queue_by = _as_dict(rs.get("queue_by_approach"))
    if not queue_by:
        queue_by = _as_dict(stats.get("queue_by_approach"))
    queue_items = []
    if queue_by:
        queue_items = [
            (str(key), value) for key, value in queue_by.items()
            if _optional_float(value) is not None
        ]
    if not queue_items:
        for direction in ("N", "S", "E", "W", "FZ"):
            key = f"queue_{direction}"
            if key in stats and _optional_float(stats.get(key)) is not None:
                queue_items.append((direction, stats[key]))
    queue_detail = _key_value_text(queue_items, separator=", ")

    return f"""{_BEV_LEGEND}

Junction: {junction_name}
Image source: {source}
Simulation time: {_format_metric(stats.get('time'), '.1f')} s
Signal status: {signal_description}

Supporting traffic statistics:
- Average speed: {_format_metric(stats.get('average_speed'), '.2f')} m/s
- Total queue proxy: {_format_metric(queue, '.1f')}
- Maximum waiting-time proxy: {_format_metric(max_wait, '.1f')} s
- Queue by approach: {queue_detail}

Task:
Inspect the supplied BEV image and output the eight-field
visual-semantic JSON schema specified by the system prompt.

The image is the primary evidence for lane blockage, spillback,
incident obstruction, roadwork and special vehicles.

Do not convert queue statistics directly into visual event labels.
Do not output signal reward weights, vehicle-control actions,
phase selections or green-time recommendations.

Return exactly one JSON object and no additional text.
"""


def build_signal_teacher_prompt(state, legal_phases, reward_summary=None):
    """User prompt for high-confidence signal-phase teacher advice."""
    state = _as_dict(state)
    stats = _as_dict(state.get("stats"))
    summary_source = (
        reward_summary if isinstance(reward_summary, Mapping)
        else stats.get("vlm_reward_summary")
    )
    rs = _as_dict(summary_source)

    legal = []
    for item in list(legal_phases or []):
        try:
            phase = int(item)
        except (TypeError, ValueError, OverflowError):
            continue
        if phase >= 0:
            legal.append(phase)
    legal = sorted(set(legal))
    phase_labels = _as_dict(state.get("phase_labels"))
    legal_lines = []
    for phase in legal:
        label = phase_labels.get(phase) or phase_labels.get(str(phase))
        if label:
            legal_lines.append(f"  - {phase}: {label}")
        else:
            wait = _format_metric(stats.get(f"max_wait_phase_{phase}"), ".1f")
            queue = _format_metric(stats.get(f"queue_phase_{phase}"), ".1f")
            legal_lines.append(
                f"  - {phase}: green_index={phase} "
                f"(queue_proxy={queue}, max_wait_proxy={wait}s)"
            )
    if not legal_lines:
        legal_lines = ["  - (none)"]

    queue = _first_number(
        rs.get("queue_total"),
        stats.get("queue_length"),
        stats.get("avg_queue_length"),
    )
    max_wait = _first_number(
        rs.get("max_wait_time_s"),
        stats.get("max_waiting_time"),
        stats.get("max_wait"),
    )
    lane_q_map = _as_dict(stats.get("lane_queue_lengths_m"))
    mean_lane_q_m = None
    if lane_q_map:
        valid_qs = [
            _optional_float(v) for v in lane_q_map.values()
            if _optional_float(v) is not None
        ]
        if valid_qs:
            mean_lane_q_m = sum(valid_qs) / len(valid_qs)

    phase_waits_raw = stats.get("phase_avg_waits_s")
    mean_phase_wait_s = None
    if isinstance(phase_waits_raw, (list, tuple)) and len(phase_waits_raw) > 0:
        valid_ws = [
            _optional_float(w) for w in phase_waits_raw
            if _optional_float(w) is not None
        ]
        if valid_ws:
            mean_phase_wait_s = sum(valid_ws) / len(valid_ws)

    source = str(state.get("image_source") or "sumo_bev_synthetic")
    junction_name = str(
        state.get("junction_name") or stats.get("junction_name") or "junction"
    )

    signals = _as_dict(state.get("signals"))
    signal_description = "Unknown"
    elapsed_txt = "N/A"
    if signals:
        tls_id = next(iter(signals))
        tls = _as_dict(signals.get(tls_id))
        remaining = _format_metric(tls.get("remaining_time"), ".1f")
        elapsed_txt = _format_metric(tls.get("elapsed_time"), ".1f")
        signal_description = (
            f"green_index={tls.get('green_index', tls.get('phase', 'Unknown'))}, "
            f"state={tls.get('state', 'Unknown')}, "
            f"elapsed={elapsed_txt}s, remaining_green={remaining}s"
        )

    queue_by = _as_dict(rs.get("queue_by_approach"))
    if not queue_by:
        queue_by = _as_dict(stats.get("queue_by_approach"))
    queue_items = []
    if queue_by:
        queue_items = [
            (str(key), value) for key, value in queue_by.items()
            if _optional_float(value) is not None
        ]
    if not queue_items:
        for direction in ("N", "S", "E", "W", "FZ"):
            key = f"queue_{direction}"
            if key in stats and _optional_float(stats.get(key)) is not None:
                queue_items.append((direction, stats[key]))
    queue_detail = _key_value_text(queue_items, separator=", ")

    wait_items = []
    for direction in ("N", "S", "E", "W", "FZ"):
        key = f"max_wait_{direction}"
        if key in stats and _optional_float(stats.get(key)) is not None:
            wait_items.append((direction, stats[key]))
    wait_detail = _key_value_text(wait_items, separator=", ")

    prog_items = []
    for direction in ("N", "S", "E", "W", "FZ"):
        key = f"n_prog_{direction}"
        if key in stats and _optional_float(stats.get(key)) is not None:
            prog_items.append((direction, stats[key]))
    prog_detail = _key_value_text(prog_items, fmt=".0f", separator=", ")

    return f"""{_BEV_LEGEND}

Junction: {junction_name}
Image source: {source}
Simulation time: {_format_metric(stats.get('time'), '.1f')} s
Signal status: {signal_description}
Current green elapsed: {elapsed_txt} s

Legal green phases (choose_one_from_this_list):
{chr(10).join(legal_lines)}

Supporting traffic statistics:
- Average speed: {_format_metric(stats.get('average_speed'), '.2f')} m/s
- Mean approach-lane queue length (3/4 formal term): {_format_metric(mean_lane_q_m, '.1f')} m (ref=220.0m)
- Mean green-phase waiting time (1/4 formal term): {_format_metric(mean_phase_wait_s, '.1f')} s (ref=60.0s, starve=105.0s)
- Total queue proxy: {_format_metric(queue, '.1f')}
- Maximum waiting-time proxy: {_format_metric(max_wait, '.1f')} s
- Queue by approach: {queue_detail}
- Max wait by approach: {wait_detail}
- Progression vehicle counts: {prog_detail}

Task:
Inspect the BEV image and select the best phase from legal_phases.
Prefer the legal phase serving the longest queue (queue_m, weight 3/4)
or relieving severe phase waiting time (avg_wait / max_wait, weight 1/4)
unless the BEV shows downstream spillback/blockage on that movement.
Do not pick a phase outside legal_phases.
Return exactly one teacher JSON object and no additional text.
"""
