"""Local OpenAI-compatible VLM server for AdaptiveReward (LLaVA-NeXT)."""
from __future__ import annotations

import base64
import io
import json
import os
import sys
import threading
from typing import Any, Dict, List, Optional, Tuple

import torch
import uvicorn
from fastapi import FastAPI, HTTPException, Request
from PIL import Image
from starlette.concurrency import run_in_threadpool
from transformers import LlavaNextForConditionalGeneration, LlavaNextProcessor


def _env_bool(name: str, default: bool) -> bool:
    raw = os.environ.get(name)
    if raw is None:
        return bool(default)
    return str(raw).strip().lower() in {"1", "true", "yes", "on", "enabled"}


def _env_int(name: str, default: int, minimum: int = 1, maximum: Optional[int] = None) -> int:
    try:
        value = int(str(os.environ.get(name, default)).strip())
        if value < minimum or (maximum is not None and value > maximum):
            raise ValueError(f"outside [{minimum}, {maximum}]")
        return value
    except (TypeError, ValueError, OverflowError):
        print(f"[VLM Server] Invalid {name}; using default={default}.", flush=True)
        return int(default)


MODEL_ID = os.environ.get("VLM_MODEL_ID", "llava-hf/llama3-llava-next-8b-hf").strip()
DEVICE = os.environ.get("VLM_DEVICE", "cpu").strip().lower()
if DEVICE == "gpu" or DEVICE.startswith("cuda"):
    DEVICE = "cuda"
if DEVICE not in {"cpu", "cuda"}:
    raise ValueError("VLM_DEVICE must be cpu or cuda.")
LOAD_IN_4BIT = _env_bool("VLM_LOAD_IN_4BIT", False)
LOCAL_ONLY = _env_bool("VLM_LOCAL_FILES_ONLY", True)
MAX_NEW_TOKENS = _env_int("VLM_MAX_NEW_TOKENS", 512, minimum=1, maximum=16384)
MAX_NEW_TOKENS_CAP = _env_int("VLM_MAX_TOKENS_CAP", 4096, minimum=64, maximum=16384)
PORT = _env_int("VLM_PORT", 8080, minimum=1, maximum=65535)
ALLOW_FALLBACK = _env_bool("VLM_ALLOW_FALLBACK", False)
_CUDA_POISONED = False
_INFER_LOCK = threading.Lock()

if DEVICE == "cuda" and not torch.cuda.is_available():
    print("[VLM Server] CUDA unavailable; falling back to VLM_DEVICE=cpu.", flush=True)
    DEVICE = "cpu"
    LOAD_IN_4BIT = False
if DEVICE == "cuda" and LOAD_IN_4BIT and sys.platform.startswith("win"):
    if not _env_bool("VLM_ALLOW_WIN_GPU", False):
        print(
            "[VLM Server] Windows + bitsandbytes 4-bit is disabled by default; "
            "falling back to CPU. Set VLM_ALLOW_WIN_GPU=1 to force GPU quantization.",
            flush=True,
        )
        DEVICE = "cpu"
        LOAD_IN_4BIT = False
if DEVICE == "cpu":
    LOAD_IN_4BIT = False

app = FastAPI(title="AdaptiveReward Local LLaVA-NeXT Server")

print("=" * 60)
print(f"正在加载 {MODEL_ID} ...")
print(
    f"  配置 -> 设备={DEVICE} | 4-bit量化={int(LOAD_IN_4BIT)} | "
    f"离线模式={LOCAL_ONLY} | max_new_tokens={MAX_NEW_TOKENS}"
)
print("=" * 60)

load_kwargs: Dict[str, Any] = {
    "local_files_only": LOCAL_ONLY,
    "low_cpu_mem_usage": True,
}
processor = LlavaNextProcessor.from_pretrained(
    MODEL_ID, local_files_only=LOCAL_ONLY
)

if DEVICE == "cpu":
    model = LlavaNextForConditionalGeneration.from_pretrained(
        MODEL_ID,
        torch_dtype=torch.float32,
        device_map="cpu",
        **load_kwargs,
    )
    INFER_DEVICE = "cpu"
elif LOAD_IN_4BIT:
    from transformers import BitsAndBytesConfig

    bnb_config = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_compute_dtype=torch.float16,
        bnb_4bit_use_double_quant=True,
        bnb_4bit_quant_type="nf4",
    )
    model = LlavaNextForConditionalGeneration.from_pretrained(
        MODEL_ID,
        quantization_config=bnb_config,
        device_map="auto",
        **load_kwargs,
    )
    INFER_DEVICE = "cuda"
else:
    model = LlavaNextForConditionalGeneration.from_pretrained(
        MODEL_ID,
        torch_dtype=torch.float16,
        device_map="auto",
        **load_kwargs,
    )
    INFER_DEVICE = "cuda"

model.eval()
print(
    f"模型加载完成！推理设备: {INFER_DEVICE}。监听端口: 127.0.0.1:{PORT}",
    flush=True,
)

_FALLBACK_SIGNAL_TEACHER = {
    "recommended_phase": -1, "confidence": 0.0, "valid": 0.0,
    "visual_event": "none", "reason": "fallback",
}
_FALLBACK_SIGNAL = {
    "lane_blockage": 0.0, "spillback": 0.0, "incident_obstruction": 0.0,
    "roadwork": 0.0, "special_vehicle": 0.0, "unseen_scene": 1.0,
    "confidence": 0.0, "valid": 0.0,
}
_FALLBACK_LON = {
    "traffic_mode": "Free_Flow",
    "semantic_analysis": "fallback_zero_residual",
    "residual_risk": 0.0, "confidence": 0.0, "valid": 0.0,
    "safety_weight": 0.24, "efficiency_weight": 0.38,
    "comfort_weight": 0.18, "platoon_weight": 0.20,
}
_FALLBACK_LAT = {
    "traffic_mode": "Free_Flow",
    "semantic_analysis": "fallback_zero_residual",
    "residual_risk": 0.0, "confidence": 0.0, "valid": 0.0,
    "lane_weight": 0.22, "safe_lc_weight": 0.24, "eff_lc_weight": 0.22,
    "formation_weight": 0.20, "comfort_lc_weight": 0.12,
}


def _fallback_content(messages: List[Dict[str, Any]]) -> str:
    fragments = []
    for message in messages if isinstance(messages, list) else []:
        content = message.get("content", "") if isinstance(message, dict) else ""
        if isinstance(content, str):
            fragments.append(content)
        elif isinstance(content, list):
            fragments.extend(
                str(part.get("text", ""))
                for part in content
                if isinstance(part, dict) and part.get("type") == "text"
            )
    joined = "\n".join(fragments).lower()
    if "recommended_phase" in joined or "legal_phases" in joined:
        payload = _FALLBACK_SIGNAL_TEACHER
    elif "lane_blockage" in joined and "unseen_scene" in joined:
        payload = _FALLBACK_SIGNAL
    elif "stage-lat" in joined or "formation_opportunity" in joined or "lane_weight" in joined:
        payload = _FALLBACK_LAT
    else:
        payload = _FALLBACK_LON
    return json.dumps(payload, ensure_ascii=False, separators=(",", ":"))


def _parse_generation_params(data: Dict[str, Any]) -> Dict[str, Any]:
    extra = data.get("extra_body") if isinstance(data.get("extra_body"), dict) else {}
    raw_max = data.get("max_tokens", data.get("max_completion_tokens", MAX_NEW_TOKENS))
    try:
        max_new = min(MAX_NEW_TOKENS_CAP, max(1, int(raw_max)))
    except (TypeError, ValueError, OverflowError):
        max_new = MAX_NEW_TOKENS

    raw_temp = data.get("temperature", 0.0)
    try:
        temp = max(0.0, min(2.0, float(raw_temp)))
    except (TypeError, ValueError, OverflowError):
        temp = 0.0

    raw_top_p = data.get("top_p", 1.0)
    try:
        top_p = max(0.05, min(1.0, float(raw_top_p)))
    except (TypeError, ValueError, OverflowError):
        top_p = 1.0

    raw_rep = data.get("repetition_penalty", extra.get("repetition_penalty", 1.0))
    try:
        rep_pen = max(0.5, min(2.5, float(raw_rep)))
    except (TypeError, ValueError, OverflowError):
        rep_pen = 1.0

    gen_kwargs: Dict[str, Any] = {"max_new_tokens": max_new, "use_cache": True}
    if abs(rep_pen - 1.0) > 1e-4:
        gen_kwargs["repetition_penalty"] = rep_pen
    if temp > 0.15:
        gen_kwargs["do_sample"] = True
        gen_kwargs["temperature"] = temp
        gen_kwargs["top_p"] = top_p
    else:
        gen_kwargs["do_sample"] = False
    return gen_kwargs


def _load_image(url: str) -> Image.Image:
    url = str(url or "").strip()
    if not url:
        raise ValueError("Empty image URL.")
    if url.startswith("data:image"):
        try:
            raw = base64.b64decode(url.split(",", 1)[-1], validate=True)
        except Exception as exc:
            raise ValueError("Malformed base64 image data URI.") from exc
        with Image.open(io.BytesIO(raw)) as image:
            return image.convert("RGB")
    if url.startswith(("http://", "https://")):
        import requests

        response = requests.get(url, timeout=(5, 30))
        response.raise_for_status()
        with Image.open(io.BytesIO(response.content)) as image:
            return image.convert("RGB")
    with Image.open(url) as image:
        return image.convert("RGB")


def _openai_to_llava(
    messages: List[Dict[str, Any]],
) -> Tuple[List[Dict[str, Any]], List[Image.Image]]:
    conversation: List[Dict[str, Any]] = []
    images: List[Image.Image] = []

    for message in messages:
        if not isinstance(message, dict):
            continue
        role = str(message.get("role", "user")).strip().lower()
        if role not in {"system", "user", "assistant"}:
            role = "user"
        content = message.get("content", "")
        if isinstance(content, str):
            parts = [{"type": "text", "text": content}]
        elif isinstance(content, list):
            parts = []
            for item in content:
                if not isinstance(item, dict):
                    continue
                kind = item.get("type")
                if kind == "text":
                    parts.append({"type": "text", "text": str(item.get("text", ""))})
                elif kind in {"image_url", "image"}:
                    image_spec = item.get("image_url")
                    url = item.get("image")
                    if not url:
                        url = image_spec.get("url", "") if isinstance(image_spec, dict) else image_spec
                    if url:
                        image = _load_image(str(url))
                        images.append(image)
                        parts.append({"type": "image"})
            if not parts:
                parts = [{"type": "text", "text": ""}]
        else:
            parts = [{"type": "text", "text": str(content or "")}]
        conversation.append({"role": role, "content": parts})

    if not conversation:
        raise ValueError("No usable messages were supplied.")
    return conversation, images


def _input_device():
    device = getattr(model, "device", None)
    if device is not None:
        return device
    try:
        return next(model.parameters()).device
    except StopIteration:
        return torch.device(INFER_DEVICE)


def _safe_cuda_empty_cache() -> None:
    if INFER_DEVICE != "cuda" or _CUDA_POISONED:
        return
    try:
        torch.cuda.empty_cache()
    except Exception as exc:
        print(f"[VLM Server] CUDA cache cleanup failed: {exc}", flush=True)


def _mark_cuda_poisoned(exc: BaseException) -> None:
    global _CUDA_POISONED
    message = str(exc).lower()
    if any(token in message for token in (
        "device-side assert", "illegal memory access", "unspecified launch failure"
    )):
        _CUDA_POISONED = True
        print(
            "[VLM Server] CUDA context may be poisoned. Restart this process; "
            "VLM_DEVICE=cpu is the safest recovery.",
            flush=True,
        )


def _run_inference_sync(messages: List[Dict[str, Any]], gen_kwargs: Dict[str, Any]) -> str:
    with _INFER_LOCK:
        conversation, images = _openai_to_llava(messages)
        prompt = processor.apply_chat_template(
            conversation, add_generation_prompt=True, tokenize=False
        )
        if images:
            inputs = processor(images=images, text=prompt, return_tensors="pt")
        else:
            inputs = processor(text=prompt, return_tensors="pt")

        device = _input_device()
        inputs = {
            key: value.to(device) if hasattr(value, "to") else value
            for key, value in inputs.items()
        }
        with torch.inference_mode():
            generated_ids = model.generate(**inputs, **gen_kwargs)

        input_ids = inputs.get("input_ids")
        if input_ids is not None:
            trimmed = [
                output_ids[len(input_row):]
                for input_row, output_ids in zip(input_ids, generated_ids)
            ]
        else:
            trimmed = generated_ids

        if hasattr(processor, "batch_decode"):
            result_text = processor.batch_decode(
                trimmed,
                skip_special_tokens=True,
                clean_up_tokenization_spaces=False,
            )[0].strip()
        else:
            tokenizer = getattr(processor, "tokenizer", None)
            if tokenizer is None:
                raise RuntimeError("Processor exposes neither batch_decode nor tokenizer.")
            result_text = tokenizer.decode(trimmed[0], skip_special_tokens=True).strip()
        if not result_text:
            raise RuntimeError("Model returned an empty completion.")
        _safe_cuda_empty_cache()
        return result_text


@app.post("/v1/chat/completions")
async def generate(request: Request):
    try:
        data = await request.json()
    except Exception as exc:
        raise HTTPException(status_code=400, detail="Request body must be valid JSON.") from exc
    if not isinstance(data, dict) or not isinstance(data.get("messages"), list) or not data["messages"]:
        raise HTTPException(status_code=400, detail="'messages' must be a non-empty list.")

    messages = data["messages"]

    req_model = str(data.get("model") or "").strip()

    if req_model and req_model != MODEL_ID:

        # v4: the server ignores the requested name; make mismatches visible.

        print(f"[VLM Server] WARNING: request model={req_model!r} != served MODEL_ID={MODEL_ID!r}", flush=True)
    gen_kwargs = _parse_generation_params(data)
    print(
        f"\n[VLM Server] 收到推理请求，messages={len(messages)} "
        f"max_new_tokens={gen_kwargs['max_new_tokens']}...",
        flush=True,
    )
    if _CUDA_POISONED and INFER_DEVICE == "cuda":
        detail = "CUDA context poisoned; restart the VLM server (or set VLM_DEVICE=cpu)."
        if ALLOW_FALLBACK:
            return {"choices": [{"message": {"content": _fallback_content(messages)}}]}
        raise HTTPException(status_code=500, detail=detail)

    try:
        result_text = await run_in_threadpool(_run_inference_sync, messages, gen_kwargs)
        print(f"[VLM Server] 推理成功，返回结果: {result_text[:200]}", flush=True)
        return {"model": MODEL_ID, "choices": [{"message": {"content": result_text}, "finish_reason": "stop"}]}
    except Exception as exc:
        print(f"[VLM Server] 推理报错: {exc}", flush=True)
        _mark_cuda_poisoned(exc)
        _safe_cuda_empty_cache()
        if ALLOW_FALLBACK:
            return {"choices": [{"message": {"content": _fallback_content(messages)}}]}
        raise HTTPException(
            status_code=500, detail=f"VLM inference failed: {exc}"
        ) from exc


if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=PORT)
