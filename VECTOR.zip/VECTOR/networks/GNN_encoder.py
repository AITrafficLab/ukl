"""Graph-attention encoder for centralized traffic-state value estimation."""
from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GATConv, global_add_pool, global_mean_pool

SIGNAL_NODE_TYPE_INDEX = 6
SIGNAL_NODE_THRESHOLD = -0.5
VEHICLE_COUNT_NORM_SCALE = 32.0


class TrafficGraphEncoder(nn.Module):
    """Encode vehicle nodes and interaction edges into graph-level embeddings.

    Dual-channel + cardinality-aware readout:
      1) Mean-pool over vehicle nodes (intensive state quality) plus a scaled
         sum-pool residual ``scale_proj`` (extensive queue/congestion volume,
         eliminating mean-pool blindness to total vehicle count N).
      2) Vectorized ``global_mean_pool`` over signal nodes fused via ``fuse`` so
         TLS features are never diluted by 1/(N+1) vehicle pooling.

    ``conv1``/``conv2``/``fuse`` names and shapes remain compatible with legacy
    checkpoints; ``load_state_dict`` transparently backfills ``scale_proj`` when
    loading older checkpoints even under ``strict=True``.
    """

    def __init__(self, node_feature_dim=10, hidden_dim=32, output_dim=16, heads=4):
        super().__init__()
        if min(int(node_feature_dim), int(hidden_dim), int(output_dim), int(heads)) <= 0:
            raise ValueError("node_feature_dim, hidden_dim, output_dim and heads must be positive.")
        self.node_feature_dim = int(node_feature_dim)
        self.hidden_dim = int(hidden_dim)
        self.output_dim = int(output_dim)
        self.heads = int(heads)

        self.conv1 = GATConv(
            self.node_feature_dim, self.hidden_dim, heads=self.heads, concat=True
        )
        self.conv2 = GATConv(
            self.hidden_dim * self.heads, self.output_dim, heads=1, concat=False
        )
        # Cardinality-aware extensive projection (near-zero init preserves legacy behavior at step 0).
        self.scale_proj = nn.Linear(self.output_dim, self.output_dim)
        nn.init.orthogonal_(self.scale_proj.weight, gain=0.01)
        nn.init.zeros_(self.scale_proj.bias)

        # Project [veh_repr || signal] -> output_dim (identity-friendly init).
        self.fuse = nn.Linear(self.output_dim * 2, self.output_dim)
        nn.init.zeros_(self.fuse.bias)
        nn.init.eye_(self.fuse.weight[:, : self.output_dim])
        nn.init.zeros_(self.fuse.weight[:, self.output_dim :])

    def load_state_dict(self, state_dict, strict: bool = True, assign: bool = False):
        if isinstance(state_dict, dict):
            patched = dict(state_dict)
            own = self.state_dict()
            for opt_key in ("scale_proj.weight", "scale_proj.bias", "fuse.weight", "fuse.bias"):
                if opt_key not in patched and opt_key in own:
                    patched[opt_key] = own[opt_key]
            state_dict = patched
        return super().load_state_dict(state_dict, strict=strict, assign=assign)

    def _prepare_inputs(self, node_features, edge_index, batch_index=None):
        if not torch.is_tensor(node_features):
            node_features = torch.as_tensor(node_features, dtype=torch.float32)
        param = next(self.parameters())
        node_features = node_features.to(device=param.device, dtype=param.dtype)

        if node_features.ndim == 1:
            if node_features.numel() == 0:
                node_features = node_features.reshape(0, self.node_feature_dim)
            else:
                node_features = node_features.unsqueeze(0)
        if node_features.ndim != 2:
            raise ValueError(
                f"node_features must have shape [N, F]; got {tuple(node_features.shape)}."
            )
        if node_features.shape[-1] != self.node_feature_dim:
            raise ValueError(
                f"TrafficGraphEncoder expected {self.node_feature_dim} node features, "
                f"got {node_features.shape[-1]}."
            )
        node_features = torch.nan_to_num(
            node_features, nan=0.0, posinf=1e6, neginf=-1e6
        )

        if edge_index is None:
            edge_index = torch.empty((2, 0), dtype=torch.long, device=param.device)
        elif not torch.is_tensor(edge_index):
            edge_index = torch.as_tensor(edge_index, dtype=torch.long, device=param.device)
        else:
            edge_index = edge_index.to(device=param.device, dtype=torch.long)

        if edge_index.numel() == 0:
            edge_index = torch.empty((2, 0), dtype=torch.long, device=param.device)
        else:
            if edge_index.ndim != 2:
                raise ValueError(
                    f"edge_index must have shape [2, E]; got {tuple(edge_index.shape)}."
                )
            if edge_index.shape[0] != 2 and edge_index.shape[1] == 2:
                edge_index = edge_index.t().contiguous()
            if edge_index.shape[0] != 2:
                raise ValueError(
                    f"edge_index must have shape [2, E]; got {tuple(edge_index.shape)}."
                )
            n_nodes = int(node_features.shape[0])
            valid_edges = (
                (edge_index[0] >= 0)
                & (edge_index[1] >= 0)
                & (edge_index[0] < n_nodes)
                & (edge_index[1] < n_nodes)
            )
            edge_index = edge_index[:, valid_edges].contiguous()

        inferred_empty_graphs = 1
        if batch_index is not None:
            if not torch.is_tensor(batch_index):
                batch_index = torch.as_tensor(batch_index, dtype=torch.long, device=param.device)
            else:
                batch_index = batch_index.to(device=param.device, dtype=torch.long)
            batch_index = batch_index.reshape(-1)
            if node_features.shape[0] == 0 and batch_index.numel() > 0:
                max_b = int(batch_index.max().item())
                if max_b >= 0:
                    inferred_empty_graphs = max_b + 1
                batch_index = None
            elif batch_index.numel() != node_features.shape[0] or bool((batch_index < 0).any().item()):
                batch_index = None

        return node_features, edge_index, batch_index, inferred_empty_graphs

    @staticmethod
    def _signal_mask(node_features: torch.Tensor) -> torch.Tensor:
        """TLS rows use node-type tag -1.0 at SIGNAL_NODE_TYPE_INDEX (see marl_env)."""
        if node_features.shape[0] == 0 or node_features.shape[1] <= SIGNAL_NODE_TYPE_INDEX:
            return torch.zeros(
                node_features.shape[0], dtype=torch.bool, device=node_features.device
            )
        return node_features[:, SIGNAL_NODE_TYPE_INDEX] < SIGNAL_NODE_THRESHOLD

    def forward(self, node_features, edge_index, batch_index=None):
        node_features, edge_index, batch_index, empty_graphs = self._prepare_inputs(
            node_features, edge_index, batch_index
        )

        if node_features.shape[0] == 0:
            return torch.zeros(
                (max(1, int(empty_graphs)), self.output_dim),
                device=node_features.device,
                dtype=node_features.dtype,
            )

        x = F.elu(self.conv1(node_features, edge_index))
        x = F.elu(self.conv2(x, edge_index))

        if batch_index is None:
            batch_index = torch.zeros(
                node_features.shape[0], dtype=torch.long, device=node_features.device
            )
        graph_count = max(1, int(batch_index.max().item()) + 1 if batch_index.numel() else 1)

        sig_mask = self._signal_mask(node_features)
        veh_mask = ~sig_mask
        if not bool(veh_mask.any().item()):
            sig_only = global_mean_pool(x, batch_index, size=graph_count)
            zeros = torch.zeros_like(sig_only)
            return self.fuse(torch.cat([zeros, sig_only], dim=-1))

        veh_batch = batch_index[veh_mask]
        veh_x = x[veh_mask]
        veh_mean = global_mean_pool(veh_x, veh_batch, size=graph_count)
        veh_sum_scaled = global_add_pool(veh_x, veh_batch, size=graph_count) / float(
            VEHICLE_COUNT_NORM_SCALE
        )
        veh_repr = veh_mean + torch.tanh(self.scale_proj(veh_sum_scaled))

        if bool(sig_mask.any().item()):
            sig_batch = batch_index[sig_mask]
            sig_x = x[sig_mask]
            sig_pool = global_mean_pool(sig_x, sig_batch, size=graph_count)
        else:
            sig_pool = torch.zeros_like(veh_repr)

        fused = self.fuse(torch.cat([veh_repr, sig_pool], dim=-1))
        return fused
