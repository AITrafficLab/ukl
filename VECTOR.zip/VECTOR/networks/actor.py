"""Actor networks for hierarchical MAPPO traffic control.

Public class names and parameter names are kept compatible with the original
implementation so existing checkpoints can be loaded when dimensions match.
"""
from __future__ import annotations

import math
from typing import Any, Mapping, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions import Categorical, Normal

RAW_ACTION_LIMIT = math.atanh(1.0 - 1e-4)


def _extract_vector(obs: Any, module: nn.Module) -> torch.Tensor:
    """Return a finite float tensor from either an observation dict or tensor."""
    if isinstance(obs, Mapping):
        if "vector" not in obs:
            raise KeyError("Actor observation dict must contain the key 'vector'.")
        vector = obs["vector"]
    else:
        vector = obs

    param = next(module.parameters())
    if not torch.is_tensor(vector):
        vector = torch.as_tensor(vector, dtype=param.dtype, device=param.device)
    else:
        vector = vector.to(device=param.device, dtype=param.dtype)

    if vector.ndim < 1:
        raise ValueError(
            f"Observation vector must have at least 1 dimension; got {tuple(vector.shape)}."
        )
    return torch.nan_to_num(vector, nan=0.0, posinf=1e6, neginf=-1e6)


def _orthogonal_linear(linear: nn.Linear, gain: float) -> None:
    """PPO-friendly initialization without changing parameter names or shapes."""
    nn.init.orthogonal_(linear.weight, gain=gain)
    if linear.bias is not None:
        nn.init.zeros_(linear.bias)


class ContinuousActor(nn.Module):
    """Squashed-Gaussian actor for continuous CAV acceleration control."""

    def __init__(
        self,
        obs_dim,
        action_dim,
        hidden_dim=64,
        action_scale=3.0,
        action_low: Optional[float] = None,
        action_high: Optional[float] = None,
    ):
        super().__init__()
        if int(obs_dim) <= 0 or int(action_dim) <= 0 or int(hidden_dim) <= 0:
            raise ValueError("obs_dim, action_dim and hidden_dim must all be positive.")
        if action_low is not None and action_high is not None:
            low = float(action_low)
            high = float(action_high)
            if not (math.isfinite(low) and math.isfinite(high)) or high <= low:
                raise ValueError("action_low/action_high must be finite with high > low.")
            self.action_center = 0.5 * (low + high)
            self.action_scale = 0.5 * (high - low)
        else:
            if not math.isfinite(float(action_scale)) or float(action_scale) <= 0.0:
                raise ValueError("action_scale must be a finite positive number.")
            self.action_center = 0.0
            self.action_scale = float(action_scale)

        self.obs_dim = int(obs_dim)
        self.action_dim = int(action_dim)

        self.net = nn.Sequential(
            nn.Linear(self.obs_dim, int(hidden_dim)),
            nn.ReLU(),
            nn.Linear(int(hidden_dim), int(hidden_dim)),
            nn.ReLU(),
        )
        self.mean_layer = nn.Linear(int(hidden_dim), self.action_dim)
        self.log_std_layer = nn.Parameter(torch.full((1, self.action_dim), -0.7))

        _orthogonal_linear(self.net[0], math.sqrt(2.0))
        _orthogonal_linear(self.net[2], math.sqrt(2.0))
        _orthogonal_linear(self.mean_layer, 0.01)
        neutral_ratio = max(-0.95, min(0.95, (0.0 - self.action_center) / max(self.action_scale, 1e-6)))
        nn.init.constant_(self.mean_layer.bias, math.atanh(neutral_ratio))

    def forward(self, obs_dict) -> Tuple[torch.Tensor, torch.Tensor]:
        obs_vector = _extract_vector(obs_dict, self)
        if obs_vector.shape[-1] != self.obs_dim:
            raise ValueError(
                f"ContinuousActor expected observation dim {self.obs_dim}, "
                f"got {obs_vector.shape[-1]}."
            )
        features = self.net(obs_vector)
        mean = self.mean_layer(features)
        mean = torch.nan_to_num(
            mean, nan=0.0, posinf=RAW_ACTION_LIMIT, neginf=-RAW_ACTION_LIMIT
        ).clamp(-RAW_ACTION_LIMIT, RAW_ACTION_LIMIT)
        log_std = torch.clamp(self.log_std_layer, -2.3, 0.5).expand_as(mean)
        std = torch.exp(log_std)
        return mean, std

    def _log_abs_det_jacobian(self, raw_action: torch.Tensor) -> torch.Tensor:
        log_tanh_derivative = 2.0 * (
            math.log(2.0) - raw_action - F.softplus(-2.0 * raw_action)
        )
        return math.log(self.action_scale) + log_tanh_derivative

    def _align_actions(self, actions: torch.Tensor, mean: torch.Tensor) -> torch.Tensor:
        if not torch.is_tensor(actions):
            actions = torch.as_tensor(actions, dtype=mean.dtype, device=mean.device)
        else:
            actions = actions.to(dtype=mean.dtype, device=mean.device)
        if mean.ndim >= 2 and actions.ndim == mean.ndim - 1 and self.action_dim == 1:
            actions = actions.unsqueeze(-1)
        if actions.shape != mean.shape:
            if actions.numel() == mean.numel():
                actions = actions.reshape_as(mean)
            else:
                raise ValueError(
                    f"Action shape {tuple(actions.shape)} is incompatible with policy "
                    f"output shape {tuple(mean.shape)}."
                )
        low = self.action_center - self.action_scale
        high = self.action_center + self.action_scale
        return torch.nan_to_num(actions, nan=self.action_center, posinf=high, neginf=low)

    def get_action(self, obs_dict, deterministic: bool = False):
        mean, std = self.forward(obs_dict)
        dist = Normal(mean, std)
        raw_action = mean if deterministic else dist.sample()
        raw_action = raw_action.clamp(-RAW_ACTION_LIMIT, RAW_ACTION_LIMIT)
        action = self.action_center + self.action_scale * torch.tanh(raw_action)
        log_prob = (dist.log_prob(raw_action) - self._log_abs_det_jacobian(raw_action)).sum(dim=-1)
        return action, log_prob

    def evaluate_actions(self, obs_dict, actions):
        mean, std = self.forward(obs_dict)
        actions = self._align_actions(actions, mean)
        dist = Normal(mean, std)
        lim = math.tanh(RAW_ACTION_LIMIT)
        squashed = torch.clamp((actions - self.action_center) / self.action_scale, -lim, lim)
        raw_action = torch.atanh(squashed)
        log_prob = (dist.log_prob(raw_action) - self._log_abs_det_jacobian(raw_action)).sum(dim=-1)
        entropy = dist.entropy().sum(dim=-1)
        return log_prob, entropy


class DiscreteActor(nn.Module):
    """Masked categorical actor for signal-phase and lane-change decisions."""

    FALLBACK_ACTION: int = 0

    def __init__(self, obs_dim, action_dim, hidden_dim=64):
        super().__init__()
        if int(obs_dim) <= 0 or int(action_dim) <= 0 or int(hidden_dim) <= 0:
            raise ValueError("obs_dim, action_dim and hidden_dim must all be positive.")
        self.obs_dim = int(obs_dim)
        self.action_dim = int(action_dim)
        self.net = nn.Sequential(
            nn.Linear(self.obs_dim, int(hidden_dim)),
            nn.ReLU(),
            nn.Linear(int(hidden_dim), int(hidden_dim)),
            nn.ReLU(),
            nn.Linear(int(hidden_dim), self.action_dim),
        )
        _orthogonal_linear(self.net[0], math.sqrt(2.0))
        _orthogonal_linear(self.net[2], math.sqrt(2.0))
        _orthogonal_linear(self.net[4], 0.01)

    def _apply_action_mask(
        self, logits: torch.Tensor, action_mask: Optional[torch.Tensor]
    ) -> torch.Tensor:
        if action_mask is None:
            return logits

        if not torch.is_tensor(action_mask):
            action_mask = torch.as_tensor(action_mask, device=logits.device)
        else:
            action_mask = action_mask.to(device=logits.device)
        action_mask = torch.nan_to_num(
            action_mask.to(dtype=logits.dtype), nan=0.0, posinf=1.0, neginf=0.0
        )

        if logits.ndim == 1:
            if action_mask.ndim == 2 and action_mask.shape[0] == 1:
                action_mask = action_mask.squeeze(0)
            if action_mask.ndim != 1:
                raise ValueError(
                    f"Single observation expects a 1-D action mask; got {tuple(action_mask.shape)}."
                )
        elif logits.ndim == 2:
            if action_mask.ndim == 1:
                action_mask = action_mask.unsqueeze(0)
            elif action_mask.ndim > 2:
                action_mask = action_mask.reshape(action_mask.shape[0], -1)
            if action_mask.ndim != 2:
                raise ValueError(
                    f"Batched observations expect a 2-D action mask; got {tuple(action_mask.shape)}."
                )
        else:
            raise ValueError(f"DiscreteActor expects 1-D or 2-D logits; got {tuple(logits.shape)}.")

        if action_mask.shape[-1] != logits.shape[-1]:
            aligned = logits.new_zeros((*action_mask.shape[:-1], logits.shape[-1]))
            n_copy = min(int(logits.shape[-1]), int(action_mask.shape[-1]))
            aligned[..., :n_copy] = action_mask[..., :n_copy]
            action_mask = aligned

        if logits.ndim == 2 and action_mask.shape[0] not in (1, logits.shape[0]):
            if action_mask.numel() == logits.shape[0] * action_mask.shape[-1]:
                action_mask = action_mask.reshape(logits.shape[0], -1)
            else:
                raise ValueError(
                    f"Action-mask batch size {action_mask.shape[0]} does not match "
                    f"observation batch size {logits.shape[0]}."
                )
        if logits.ndim == 2 and action_mask.shape[0] == 1 and logits.shape[0] > 1:
            action_mask = action_mask.expand(logits.shape[0], -1)

        valid = action_mask > 0.0
        fb = min(max(0, int(self.FALLBACK_ACTION)), int(logits.shape[-1]) - 1)
        if logits.ndim == 1:
            if not bool(valid.any().item()):
                valid = valid.clone()
                valid[fb] = True
        else:
            empty_rows = ~valid.any(dim=-1)
            if bool(empty_rows.any().item()):
                valid = valid.clone()
                valid[empty_rows, fb] = True

        return logits.masked_fill(~valid, torch.finfo(logits.dtype).min)

    def forward(self, obs_dict):
        obs_vector = _extract_vector(obs_dict, self)
        if obs_vector.shape[-1] != self.obs_dim:
            raise ValueError(
                f"DiscreteActor expected observation dim {self.obs_dim}, got {obs_vector.shape[-1]}."
            )
        logits = self.net(obs_vector)
        action_mask = obs_dict.get("action_mask") if isinstance(obs_dict, Mapping) else None
        return self._apply_action_mask(logits, action_mask)

    def get_action(self, obs_dict, deterministic: bool = False):
        logits = self.forward(obs_dict)
        dist = Categorical(logits=logits)
        action = torch.argmax(logits, dim=-1) if deterministic else dist.sample()
        log_prob = dist.log_prob(action)
        return action, log_prob

    def evaluate_actions(self, obs_dict, actions):
        logits = self.forward(obs_dict)
        dist = Categorical(logits=logits)
        action = torch.as_tensor(actions, dtype=torch.long, device=logits.device)
        if logits.ndim == 1:
            if action.numel() != 1:
                raise ValueError("A single observation requires exactly one action.")
            action = action.reshape(())
        else:
            if action.ndim > 1 and action.shape[-1] == 1:
                action = action.squeeze(-1)
            if action.shape != logits.shape[:-1] and action.numel() == logits.shape[0]:
                action = action.reshape(logits.shape[:-1])
        return dist.log_prob(action), dist.entropy()
