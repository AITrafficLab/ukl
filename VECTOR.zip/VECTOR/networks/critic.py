"""Centralized dual-head graph critic for CTDE/MAPPO."""
from __future__ import annotations

import math
from collections.abc import Mapping

import torch
import torch.nn as nn

from .GNN_encoder import TrafficGraphEncoder


class CentralizedCritic(nn.Module):
    """Estimate team/CAV and long-horizon signal values from a global traffic graph.

    Architecture:
      - ``self.gnn``: shared cardinality-aware ``TrafficGraphEncoder``.
      - ``self.net``: team / CAV value head (trained at ``gamma=0.99``). Kept
        under the exact legacy attribute name so ``critic(graph)`` callers in
        ``mappo.py`` and older checkpoints remain 100% compatible.
      - ``self.signal_head``: dedicated signal value head (trained at
        ``SIGNAL_GAE_GAMMA=0.998``), eliminating cross-discount and cross-reward
        TD bias during ``JointLonSig`` and ``JointAll`` stages.
    """

    def __init__(
        self,
        hidden_dim=128,
        node_feature_dim=10,
        gnn_hidden_dim=32,
        gnn_output_dim=32,
        gnn_heads=4,
    ):
        super().__init__()
        if int(hidden_dim) <= 0:
            raise ValueError("hidden_dim must be positive.")
        self.hidden_dim = int(hidden_dim)
        self.gnn_output_dim = int(gnn_output_dim)
        self.gnn = TrafficGraphEncoder(
            node_feature_dim=int(node_feature_dim),
            hidden_dim=int(gnn_hidden_dim),
            output_dim=int(gnn_output_dim),
            heads=int(gnn_heads),
        )
        self.net = self._make_mlp_head(self.gnn_output_dim, self.hidden_dim)
        self.signal_head = self._make_mlp_head(self.gnn_output_dim, self.hidden_dim)
        # v6-P1 individual value V(g(s) ⊕ o_i). Unused unless individual_critic is on.
        self.local_dim = 32
        self.local_proj = nn.Linear(self.local_dim, self.local_dim)
        self.indiv_head = self._make_mlp_head(self.gnn_output_dim + self.local_dim, self.hidden_dim)
        nn.init.orthogonal_(self.local_proj.weight, gain=1.0)
        nn.init.zeros_(self.local_proj.bias)

    @staticmethod
    def _make_mlp_head(in_dim: int, hidden_dim: int) -> nn.Sequential:
        head = nn.Sequential(
            nn.Linear(int(in_dim), int(hidden_dim)),
            nn.ReLU(),
            nn.Linear(int(hidden_dim), int(hidden_dim)),
            nn.ReLU(),
            nn.Linear(int(hidden_dim), 1),
        )
        for layer in (head[0], head[2]):
            nn.init.orthogonal_(layer.weight, gain=math.sqrt(2.0))
            nn.init.zeros_(layer.bias)
        nn.init.orthogonal_(head[4].weight, gain=1.0)
        nn.init.zeros_(head[4].bias)
        return head

    def reset_team_head(self) -> None:
        """Reinitialize ``self.net`` orthogonally while preserving ``gnn`` and ``signal_head``."""
        for layer in (self.net[0], self.net[2]):
            if isinstance(layer, nn.Linear):
                nn.init.orthogonal_(layer.weight, gain=math.sqrt(2.0))
                nn.init.zeros_(layer.bias)
        if isinstance(self.net[4], nn.Linear):
            nn.init.orthogonal_(self.net[4].weight, gain=1.0)
            nn.init.zeros_(self.net[4].bias)

    def load_state_dict(self, state_dict, strict: bool = True, assign: bool = False):
        """Transparently load legacy single-head checkpoints even with strict=True."""
        if isinstance(state_dict, Mapping):
            patched = dict(state_dict)
            own = self.state_dict()
            # Backfill new GNN scale_proj / fuse keys if loading an older checkpoint.
            for k, v in own.items():
                if k.startswith(("gnn.scale_proj.", "gnn.fuse.")) and k not in patched:
                    patched[k] = v
                elif k.startswith("signal_head.") and k not in patched:
                    # Warm-start missing signal_head from legacy net if shapes match.
                    mirror_key = "net." + k[len("signal_head.") :]
                    patched[k] = patched.get(mirror_key, v)
                elif k.startswith(("local_proj.", "indiv_head.")) and k not in patched:
                    patched[k] = v
            state_dict = patched
        return super().load_state_dict(state_dict, strict=strict, assign=assign)

    def encode(self, graph_data) -> torch.Tensor:
        if not isinstance(graph_data, Mapping):
            raise TypeError("graph_data must be a mapping containing node_features and edge_index.")
        if "node_features" not in graph_data:
            raise KeyError("graph_data is missing required key 'node_features'.")
        if "edge_index" not in graph_data:
            raise KeyError("graph_data is missing required key 'edge_index'.")

        node_features = graph_data["node_features"]
        edge_index = graph_data["edge_index"]
        batch_index = graph_data.get("batch_index")
        return self.gnn(node_features, edge_index, batch_index)

    def forward(self, graph_data) -> torch.Tensor:
        """Return team/CAV value estimate (legacy default head)."""
        graph_embed = self.encode(graph_data)
        return self.net(graph_embed)

    def forward_signal(self, graph_data) -> torch.Tensor:
        """Return dedicated long-horizon signal value estimate (gamma=0.998)."""
        graph_embed = self.encode(graph_data)
        return self.signal_head(graph_embed)

    def forward_dual(self, graph_data) -> tuple[torch.Tensor, torch.Tensor]:
        """Single GNN pass returning (team_value, signal_value)."""
        graph_embed = self.encode(graph_data)
        return self.net(graph_embed), self.signal_head(graph_embed)

    def _fit_local(self, local_obs) -> torch.Tensor:
        reference = next(self.parameters())
        if not torch.is_tensor(local_obs):
            local_obs = torch.as_tensor(local_obs, dtype=reference.dtype, device=reference.device)
        else:
            local_obs = local_obs.to(device=reference.device, dtype=reference.dtype)
        if local_obs.ndim == 1:
            local_obs = local_obs.unsqueeze(0)
        width = int(self.local_dim)
        if local_obs.shape[-1] < width:
            pad = torch.zeros(
                *local_obs.shape[:-1], width - int(local_obs.shape[-1]),
                dtype=local_obs.dtype, device=local_obs.device,
            )
            local_obs = torch.cat([local_obs, pad], dim=-1)
        elif local_obs.shape[-1] > width:
            local_obs = local_obs[..., :width]
        return torch.nan_to_num(local_obs, nan=0.0, posinf=1e3, neginf=-1e3)

    def forward_individual(self, graph_data, local_obs) -> torch.Tensor:
        """V(g(s) ⊕ o_i) for one shared graph and a batch of local observations."""
        graph_embed = self.encode(graph_data)
        if graph_embed.ndim == 1:
            graph_embed = graph_embed.unsqueeze(0)
        local = self.local_proj(self._fit_local(local_obs))
        if graph_embed.shape[0] == 1 and local.shape[0] > 1:
            graph_embed = graph_embed.expand(local.shape[0], -1)
        return self.indiv_head(torch.cat([graph_embed, local], dim=-1))
