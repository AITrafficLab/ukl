Run logs and --sumo-diag-dir outputs go here (PowerShell Out-File needs this folder to exist).
