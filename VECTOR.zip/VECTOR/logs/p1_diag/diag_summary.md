# P1 diagnostic (G3 residual vs G2)

seeds=[7, 8, 9, 10, 11]
G2 TIS=199.08 ± 0.86 (n=5)
G3 TIS=200.02 ± 3.15 (n=5)
GATE-P1-diag: FAIL  (TIS +0.5%, bootstrap [-0.2%, +1.2%]; safety=FAIL)

PASS → replace landable with this G3 checkpoint and only then start formal training.
FAIL → keep G2; do not open VLM / full curriculum / P3.
