# Landable slim eval

Demand = shipped routes (scale 1.0). Penetration = mix in those route files.
Mean and 95% t-interval over eval seeds.

| scenario | method | n | TIS | waiting | stops | fuel | coll | tele | backlog |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| 3-leg | G2 | 5 | 175 ± 2.95 | 27.2 ± 1.19 | 1.81e+03 ± 66 | 9.75 ± 0.124 | 0 ± 0 | 0 ± 0 | 0.2 ± 0.555 |

## Per-seed TIS

| scenario | method | seed | TIS | coll | backlog |
|---|---|---:|---:|---:|---:|
| 3-leg | G2 | 7 | 172.82492673992692 | 0 | 0.0 |
| 3-leg | G2 | 8 | 176.51096715328484 | 0 | 0.0 |
| 3-leg | G2 | 9 | 171.8770539798722 | 0 | 0.0 |
| 3-leg | G2 | 10 | 177.31555758683731 | 0 | 1.0 |
| 3-leg | G2 | 11 | 175.70907593778605 | 0 | 0.0 |
