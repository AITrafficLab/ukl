| config | lon_eps | speed_mps | TIS_s | backlog | teleports | collisions | ctrlCAV_jstall_events | stack_res | realized_res | pos_exec_ratio | stack_cut |
|---|---|---|---|---|---|---|---|---|---|---|---|
| G0_native | 6 | 7.16 | 168.7 | 1 | 2.7 | 1.3 | 0.0 | 0.000 | 0.000 | 0.00 | 0.00 |
| G1_v524 | 6 | 3.82 | 242.5 | 1 | 16.3 | 3.8 | 10.5 | -0.194 | -0.012 | 0.00 | 0.41 |
| G2_p0 | 6 | 7.56 | 160.6 | 1 | 0.7 | 0.7 | 0.0 | -0.614 | -0.104 | 0.00 | 0.53 |
| G3_p0_rl | 6 | 7.10 | 169.5 | 1 | 2.2 | 0.7 | 0.0 | -0.576 | -0.093 | 0.23 | 0.60 |

GATE-1 feasibility (G2 vs G0): PASS  (TIS -4.8% vs G0_native; TIS=ok, Backlog=ok, Teleports=ok, Collisions=ok)
GATE-2 learning    (G3 vs G2): FAIL  (TIS +5.5% vs G2_p0; TIS=FAIL, Backlog=ok, Teleports=ok, Collisions=ok)
info   v5.2.4 stack (G1 vs G0): FAIL  (TIS +43.7% vs G0_native; TIS=FAIL, Backlog=ok, Teleports=FAIL, Collisions=FAIL)
-> Stack is feasible but the residual RL degrades it: proceed to P1 (individual critic, target-speed action); keep the RL residual off for any paper run until then.
