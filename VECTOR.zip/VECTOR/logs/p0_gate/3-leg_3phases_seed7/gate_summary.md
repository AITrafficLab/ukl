| config | lon_eps | speed_mps | TIS_s | backlog | teleports | collisions | ctrlCAV_jstall_events | stack_res | realized_res | pos_exec_ratio | stack_cut |
|---|---|---|---|---|---|---|---|---|---|---|---|
| G0_native | 6 | 9.26 | 150.3 | 4 | 0.0 | 0.0 | 0.0 | 0.000 | 0.000 | 0.00 | 0.00 |
| G1_v524 | 6 | 5.95 | 207.4 | 4 | 1.8 | 0.0 | 2.2 | -0.168 | -0.066 | 0.00 | 0.29 |
| G2_p0 | 6 | 9.13 | 151.8 | 4 | 0.0 | 0.0 | 0.0 | -0.673 | -0.103 | 0.00 | 0.53 |
| G3_p0_rl | 6 | 9.10 | 152.2 | 4 | 0.0 | 0.0 | 0.0 | -0.666 | -0.118 | 0.21 | 0.60 |

GATE-1 feasibility (G2 vs G0): PASS  (TIS +1.0% vs G0_native; TIS=ok, Backlog=ok, Teleports=ok, Collisions=ok)
GATE-2 learning    (G3 vs G2): PASS  (TIS +0.3% vs G2_p0; TIS=ok, Backlog=ok, Teleports=ok, Collisions=ok)
info   v5.2.4 stack (G1 vs G0): FAIL  (TIS +38.0% vs G0_native; TIS=FAIL, Backlog=ok, Teleports=ok, Collisions=ok)
-> P0 accepted. Repeat on 3-leg and 5-leg (and seeds 7/11/13), then start P1.
