| config | lon_eps | speed_mps | TIS_s | backlog | teleports | collisions | ctrlCAV_jstall_events | stack_res | realized_res | pos_exec_ratio | stack_cut |
|---|---|---|---|---|---|---|---|---|---|---|---|
| G0_native | 6 | 8.76 | 162.0 | 44 | 0.5 | 0.5 | 0.0 | 0.000 | 0.000 | 0.00 | 0.00 |
| G1_v524 | 6 | 3.05 | 280.3 | 61 | 17.5 | 2.0 | 8.3 | -0.172 | -0.030 | 0.00 | 0.33 |
| G2_p0 | 6 | 8.67 | 163.3 | 44 | 1.0 | 1.0 | 0.0 | -0.622 | -0.079 | 0.00 | 0.55 |
| G3_p0_rl | 6 | 8.66 | 162.9 | 44 | 0.8 | 0.8 | 0.0 | -0.594 | -0.083 | 0.32 | 0.57 |
| G5_p1 | 6 | 8.58 | 164.0 | 44 | 2.0 | 2.0 | 0.0 | -0.397 | -0.042 | 0.32 | 0.84 |

GATE-1 feasibility (G2 vs G0): PASS  (TIS +0.9% vs G0_native; TIS=ok, Backlog=ok, Teleports=ok, Collisions=ok)
GATE-2 learning    (G3 vs G2): PASS  (TIS -0.3% vs G2_p0; TIS=ok, Backlog=ok, Teleports=ok, Collisions=ok)
info   v5.2.4 stack (G1 vs G0): FAIL  (TIS +73.1% vs G0_native; TIS=FAIL, Backlog=FAIL, Teleports=FAIL, Collisions=FAIL)
-> P0 accepted. Repeat on 3-leg and 5-leg (and seeds 7/11/13), then start P1.
GATE-P1 vs G2: FAIL  (TIS +0.4%, bootstrap 95% [-1.1%, +1.4%]; safety=FAIL)
-> P1 not accepted yet: keep the P0 rule stack for paper runs; inspect G5_p1 logs.
