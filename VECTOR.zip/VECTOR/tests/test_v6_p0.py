"""v6-P0: gap policy, Lon RL zone, signal-reward saturation, authority audit,
rule signal controllers, profile precedence and the gate schedule.

Run:  python -m unittest tests/test_v6_p0.py -v
(no SUMO / torch: uses the fake traci of test_sumo_interface_offline)
"""
import ast
import argparse
import math
import os
import sys
import unittest

import numpy as np

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "tests"))

from test_sumo_interface_offline import SI  # noqa: E402

from environment import gap_policy as gp  # noqa: E402
from environment import platoon_manager as pm  # noqa: E402
from environment import cav_state_builder as csb  # noqa: E402
from reward import signal_reward as sr  # noqa: E402


class _Env:
    """Temporarily set / clear environment variables."""

    def __init__(self, **kv):
        self.kv = kv
        self.old = {}

    def __enter__(self):
        for k, v in self.kv.items():
            self.old[k] = os.environ.get(k)
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = str(v)
        return self

    def __exit__(self, *exc):
        for k, v in self.old.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v


SPEEDS = [-1.0, 0.0, 0.3, 1.0, 2.5, 5.0, 8.33, 12.0, 16.67, 25.0]


class TestGapPolicyLegacy(unittest.TestCase):
    """Default mode must reproduce the v5.2.4 expressions bit-for-bit."""

    def test_safe_and_platoon_gap(self):
        with _Env(GAP_POLICY=None):
            for v in SPEEDS:
                self.assertEqual(pm.safe_gap(v), max(0.15, 0.45 * v))
                self.assertEqual(pm.platoon_gap(v), max(4.5, 0.95 * v))
            self.assertEqual(pm.safe_gap(float("nan")), 0.15)
            self.assertEqual(pm.platoon_gap("bad"), 4.5)

    def test_cacc_target_ignores_leader_type(self):
        with _Env(GAP_POLICY=None):
            for v in SPEEDS:
                ref = 0.65 + 0.60 * max(v, 0.0)
                self.assertEqual(gp.cacc_target_gap(v, True), ref)
                self.assertEqual(gp.cacc_target_gap(v, False), ref)

    def test_shield_trigger(self):
        with _Env(GAP_POLICY=None):
            rng = np.random.default_rng(0)
            for _ in range(2000):
                g, h, t = rng.uniform(-1, 30), rng.uniform(0, 3), rng.uniform(0, 10)
                ref = bool(g < 4.5 or h < 0.85 or t < 2.2)
                self.assertEqual(gp.shield_caps_to_idm(g, h, t), ref)

    def test_reward_bands_unchanged(self):
        from reward import longitudinal_reward as lr

        self.assertEqual(tuple(lr.V2_HEADWAY_CAV_S), (0.6, 1.0))
        self.assertEqual(tuple(lr.V2_HEADWAY_HDV_S), (1.2, 2.0))


class TestGapPolicyUnified(unittest.TestCase):
    def test_ordering_invariants(self):
        # shield < CACC(CAV) = band low(CAV); CACC(HDV) = band low(HDV); platoon = band high.
        self.assertLess(gp.UNIFIED_SHIELD_HEADWAY_S, gp.UNIFIED_H_CAV_S)
        self.assertEqual(gp.UNIFIED_H_CAV_S, gp.REWARD_BAND_CAV_S[0])
        self.assertEqual(gp.UNIFIED_H_HDV_S, gp.REWARD_BAND_HDV_S[0])
        self.assertLess(gp.UNIFIED_SAFE_GAP_H_S, gp.UNIFIED_H_CAV_S)
        self.assertEqual(gp.UNIFIED_PLATOON_GAP_H_S, gp.REWARD_BAND_CAV_S[1])

    def test_controller_target_never_triggers_shield(self):
        """A CAV exactly at its CACC target (TTC safe) must not be capped."""
        with _Env(GAP_POLICY="unified"):
            for v in [1.0, 3.0, 8.0, 12.0, 16.67]:
                for lead_cav in (True, False):
                    g = gp.cacc_target_gap(v, lead_cav)
                    self.assertFalse(gp.shield_caps_to_idm(g, g / max(v, 0.5), 99.0), (v, lead_cav))
        with _Env(GAP_POLICY=None):
            # v5.2.4 conflict reproduced: at 10 m/s the CACC target (6.65 m) is capped.
            g = gp.cacc_target_gap(10.0, True)
            self.assertTrue(gp.shield_caps_to_idm(g, g / 10.0, 99.0))

    def test_hdv_leader_gets_acc_gap(self):
        with _Env(GAP_POLICY="unified"):
            self.assertAlmostEqual(gp.cacc_target_gap(10.0, True), 0.65 + 6.0)
            self.assertAlmostEqual(gp.cacc_target_gap(10.0, False), 0.65 + 12.0)
            self.assertAlmostEqual(gp.cacc_target_gap(10.0, None), 0.65 + 12.0)

    def test_platoon_band_is_consistent(self):
        with _Env(GAP_POLICY="unified"):
            for v in [0.0, 2.0, 8.0, 16.67]:
                self.assertLess(pm.safe_gap(v), pm.platoon_gap(v))
                self.assertLessEqual(pm.safe_gap(v), gp.cacc_target_gap(v, True))
                self.assertGreaterEqual(pm.platoon_gap(v), gp.cacc_target_gap(v, True))


class TestLonRlZone(unittest.TestCase):
    def _elig(self, d, junction=False):
        return csb.lon_rl_eligible(
            {"is_leader": True, "is_in_junction": junction, "dist_to_stopline": d},
            require_leader=False,
        )

    def test_defaults_match_v524(self):
        with _Env(LON_RL_MAX_DIST_M=None, LON_RL_MIN_DIST_M=None, LON_RL_IN_JUNCTION=None):
            self.assertTrue(self._elig(0.0))
            self.assertTrue(self._elig(300.0))
            self.assertFalse(self._elig(300.1))
            self.assertFalse(self._elig(-1.0))
            self.assertTrue(self._elig(-1.0, junction=True))

    def test_v6p0_zone(self):
        with _Env(LON_RL_MAX_DIST_M="200", LON_RL_MIN_DIST_M="20", LON_RL_IN_JUNCTION="0"):
            self.assertFalse(self._elig(19.9))
            self.assertTrue(self._elig(20.0))
            self.assertTrue(self._elig(200.0))
            self.assertFalse(self._elig(200.1))
            self.assertFalse(self._elig(-1.0, junction=True))

    def test_explicit_max_dist_argument_still_wins(self):
        with _Env(LON_RL_MAX_DIST_M="200", LON_RL_MIN_DIST_M=None, LON_RL_IN_JUNCTION=None):
            ok = csb.lon_rl_eligible(
                {"is_in_junction": False, "dist_to_stopline": 250.0},
                require_leader=False, max_dist_m=300.0,
            )
            self.assertTrue(ok)


class TestSignalRewardSaturation(unittest.TestCase):
    def _formal(self, ql_m, wt_s):
        state = {"stats": {"lane_queue_lengths_m": {"a": ql_m, "b": ql_m}}}
        orig = sr._collect_phase_waits_s
        sr._collect_phase_waits_s = lambda *_a, **_k: [wt_s, wt_s]
        try:
            return sr.signal_ql_wt_formal(state)[0]
        finally:
            sr._collect_phase_waits_s = orig

    def test_default_saturates_at_minus_one(self):
        with _Env(SIGNAL_REWARD_SAT=None):
            self.assertEqual(sr.signal_reward_saturation(), 1.0)
            self.assertAlmostEqual(self._formal(660.0, 180.0), -1.0)
            self.assertAlmostEqual(self._formal(880.0, 240.0), -1.0)  # flat: no gradient

    def test_unsaturated_keeps_gradient(self):
        with _Env(SIGNAL_REWARD_SAT="4"):
            a = self._formal(660.0, 180.0)
            b = self._formal(880.0, 240.0)
            self.assertLess(b, a)
            self.assertAlmostEqual(a, -3.0)
            self.assertGreaterEqual(b, -4.0)
            # Light traffic identical to v5.2.4.
            self.assertAlmostEqual(self._formal(55.0, 15.0), -(0.75 * 0.25 + 0.25 * 0.25))

    def test_bad_values_fall_back(self):
        for raw in ("0.5", "nan", "x", ""):
            with _Env(SIGNAL_REWARD_SAT=raw):
                self.assertEqual(sr.signal_reward_saturation(), 1.0)


def _bare_env():
    env = object.__new__(SI.SUMOEnvironment)
    env.step_length = 0.2
    env._auth_reset()
    return env


class TestAuthorityAudit(unittest.TestCase):
    def test_one_sided_cut_is_measured(self):
        env = _bare_env()
        a_idm = 0.5
        rng = np.random.default_rng(1)
        sampled = rng.normal(0.0, 0.36, size=4000)
        for i, r in enumerate(sampled):
            stack = min(r, 0.0)  # positive residual never executed
            env._auth_record(f"v{i}", a_idm + r, a_idm + stack, a_idm)
        st = env.auth_stats()
        self.assertEqual(st["auth_n"], 4000.0)
        self.assertAlmostEqual(st["auth_policy_res_mean"], float(np.mean(sampled)), places=6)
        # E[min(X, 0)] = -0.4 sigma ~= -0.144 m/s^2
        self.assertAlmostEqual(st["auth_stack_res_mean"], -0.36 / math.sqrt(2 * math.pi), delta=0.02)
        self.assertLess(st["auth_pos_exec_ratio"], 0.01)
        self.assertGreater(st["auth_stack_cut_frac"], 0.4)

    def test_realization_against_sumo(self):
        env = _bare_env()
        tc = SI.tc
        env._auth_record("a", 1.0, 1.0, 0.0)
        env._auth_record("b", -1.0, -1.0, 0.0)
        env.sub_results = {
            "a": {tc.VAR_ACCELERATION: 0.4},   # SUMO cut the request
            "b": {tc.VAR_ACCELERATION: -1.0},  # executed
        }
        env._auth_realize()
        st = env.auth_stats()
        self.assertEqual(st["auth_sumo_cut_frac"], 0.5)
        self.assertAlmostEqual(st["auth_realized_res_mean"], (0.4 - 1.0) / 2)
        self.assertAlmostEqual(st["auth_requested_res_mean"], 0.0)
        self.assertEqual(env._auth_pending, {})

    def test_reset_via_jstall_reset(self):
        env = _bare_env()
        env._auth_record("a", 1.0, 0.0, 0.0)
        env._jstall_reset()
        self.assertEqual(env.auth_stats()["auth_n"], 0.0)

    def test_kpi_keys_forwarded(self):
        from environment.marl_env import V6_AUTH_KPI_KEYS

        env = _bare_env()
        self.assertEqual(set(V6_AUTH_KPI_KEYS), set(env.auth_stats().keys()))


class TestRuleSignal(unittest.TestCase):
    def _env(self, scores, cur_g=0, mask=(1, 1, 1, 1)):
        env = _bare_env()
        env._last_signal_mask = {"J": (7, np.asarray(mask, dtype=np.float32))}
        env._green_index_of_phase = lambda tls, ph: cur_g
        env._phase_pressure = lambda tls, g: float(scores[g])
        env._queue_length_for_green = lambda tls, g: float(-scores[g])
        return env

    def test_maxpressure_picks_argmax_among_legal(self):
        env = self._env([1.0, 5.0, 9.0, 3.0], mask=(1, 1, 0, 1))
        self.assertEqual(env._rule_signal_choice("J", 7, "maxpressure"), 1)

    def test_tie_keeps_current(self):
        env = self._env([4.0, 4.0, 1.0, 4.0], cur_g=3)
        self.assertEqual(env._rule_signal_choice("J", 7, "maxpressure"), 3)

    def test_no_choice_when_mask_is_forced_or_stale(self):
        env = self._env([1, 2, 3, 4], mask=(0, 1, 0, 0))
        self.assertIsNone(env._rule_signal_choice("J", 7, "maxpressure"))
        env = self._env([1, 2, 3, 4])
        self.assertIsNone(env._rule_signal_choice("J", 8, "maxpressure"))

    def test_longest_queue(self):
        env = self._env([3.0, 1.0, 2.0, 5.0])  # queue = -score
        self.assertEqual(env._rule_signal_choice("J", 7, "longest_queue"), 1)

    def test_rule_name_parsing(self):
        env = _bare_env()
        with _Env(SIGNAL_RULE="MaxPressure"):
            self.assertEqual(env._signal_rule_name(), "maxpressure")
        with _Env(SIGNAL_RULE="none"):
            self.assertEqual(env._signal_rule_name(), "")
        with _Env(SIGNAL_RULE="fixed"):
            self.assertEqual(env._signal_rule_name(), "fixed")
        with _Env(SIGNAL_RULE=None):
            self.assertEqual(env._signal_rule_name(), "")

    def test_step_logs_agent_action_not_rule(self):
        with open(os.path.join(ROOT, "environment", "SUMO_interface.py"), encoding="utf-8") as fh:
            src = fh.read()
        self.assertIn("_req_g = int(_agent_action)", src)
        self.assertLess(src.index("_agent_action = int(raw_action)"), src.index("_rule_signal_choice(tls_id, current_phase, _rule)"))


def _load_profile_funcs():
    """Exec V6P0_PROFILE / _flag_given / apply_profile from train_RL without torch."""
    path = os.path.join(ROOT, "train", "train_RL.py")
    with open(path, encoding="utf-8") as fh:
        tree = ast.parse(fh.read())
    keep = []
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(
            isinstance(t, ast.Name) and t.id in ("V6P0_PROFILE", "V6P1_PROFILE", "LANDABLE_PROFILE")
            for t in node.targets
        ):
            keep.append(node)
        elif isinstance(node, ast.FunctionDef) and node.name in ("_flag_given", "apply_profile"):
            keep.append(node)
    ns = {}
    exec(compile(ast.Module(body=keep, type_ignores=[]), path, "exec"), ns)
    return ns


class TestProfile(unittest.TestCase):
    def setUp(self):
        self.ns = _load_profile_funcs()

    def _args(self, **kw):
        base = dict(
            profile="v524", lon_no_floors=False, lon_handback_near_m=0.0, lon_actuation="accel",
            lon_rl_max_dist_m=300.0, lon_rl_min_dist_m=0.0, lon_rl_in_junction=True,
            gap_policy="legacy", signal_reward_sat=1.0, lon_imitation_scale=0.10,
            cacc_ppo_authority_min=0.20,
            ablate_zero_lon_residual=False,
            signal_rule="none",
        )
        base.update(kw)
        return argparse.Namespace(**base)

    def test_v524_profile_changes_nothing(self):
        a = self._args()
        before = dict(vars(a))
        self.ns["apply_profile"](a, [])
        after = dict(vars(a))
        after.pop("_profile_applied")
        self.assertEqual(before, after)

    def test_v6p0_sets_everything(self):
        a = self._args(profile="v6p0")
        self.ns["apply_profile"](a, ["--profile", "v6p0"])
        self.assertTrue(a.lon_no_floors)
        self.assertEqual(a.lon_handback_near_m, 20.0)
        self.assertEqual(a.lon_actuation, "speed")
        self.assertEqual(a.lon_rl_max_dist_m, 200.0)
        self.assertEqual(a.lon_rl_min_dist_m, 20.0)
        self.assertFalse(a.lon_rl_in_junction)
        self.assertEqual(a.gap_policy, "unified")
        self.assertEqual(a.signal_reward_sat, 4.0)
        self.assertEqual(a.lon_imitation_scale, 0.0)
        self.assertEqual(a.cacc_ppo_authority_min, 0.5)
        self.assertEqual(len(a._profile_applied), len(self.ns["V6P0_PROFILE"]))

    def test_explicit_cli_wins(self):
        a = self._args(profile="v6p0", lon_actuation="accel", gap_policy="legacy")
        self.ns["apply_profile"](
            a, ["--profile", "v6p0", "--lon-actuation", "accel", "--gap-policy=legacy"]
        )
        self.assertEqual(a.lon_actuation, "accel")
        self.assertEqual(a.gap_policy, "legacy")
        self.assertEqual(a.lon_rl_max_dist_m, 200.0)
        self.assertNotIn("lon_actuation", a._profile_applied)

    def test_landable_is_g2_stack(self):
        a = self._args(profile="landable")
        self.ns["apply_profile"](a, ["--profile", "landable"])
        self.assertTrue(a.lon_no_floors)
        self.assertEqual(a.lon_actuation, "speed")
        self.assertEqual(a.gap_policy, "unified")
        self.assertTrue(a.ablate_zero_lon_residual)
        self.assertEqual(a.signal_rule, "maxpressure")
        self.assertEqual(a.lon_rl_max_dist_m, 200.0)
        self.assertFalse(a.lon_rl_in_junction)
        self.assertIn("ablate_zero_lon_residual", a._profile_applied)
        self.assertIn("signal_rule", a._profile_applied)

    def test_trainer_wiring_present(self):
        with open(os.path.join(ROOT, "train", "train_RL.py"), encoding="utf-8") as fh:
            src = fh.read()
        for needle in (
            "apply_profile(args, sys.argv[1:])",
            'os.environ["GAP_POLICY"]',
            'os.environ["LON_RL_MAX_DIST_M"]',
            'os.environ["SIGNAL_RULE"]',
            'os.environ["SIGNAL_REWARD_SAT"]',
            '"lon_imitation_scale", 0.10',
            "[Diag-Auth]",
            "tuple(V6_AUTH_KPI_KEYS)",
            'choices=[\'v524\', \'v6p0\', \'v6p1\', \'landable\']',
            '"landable": LANDABLE_PROFILE',
        ):
            self.assertIn(needle, src, needle)


class TestGateSchedule(unittest.TestCase):
    def _args(self, **kw):
        base = dict(
            quick=False, smoke=False, episodes=850, joint_lon_sig_episodes=0,
            joint_all_episodes=170, step_length=0.2, control_seconds=300.0,
            warmup_seconds=300.0, max_steps=4500, vlm_warmup_episodes=None,
            schedule_overrides=None, gate_lon_episodes=0,
        )
        base.update(kw)
        return argparse.Namespace(**base)

    def test_gate_schedule(self):
        from baselines.episode_timing import apply_episode_timing

        a = apply_episode_timing(self._args(gate_lon_episodes=6))
        self.assertEqual((a.stage_s_episodes, a.stage_lon_episodes, a.stage_lat_episodes), (2, 6, 1))
        self.assertEqual(a.joint_all_episodes, 0)
        self.assertEqual(a.episodes, 9)
        self.assertEqual(a.max_steps, 1500)

    def test_off_by_default(self):
        from baselines.episode_timing import apply_episode_timing

        a = apply_episode_timing(self._args())
        self.assertEqual(a.stage_s_episodes, 250)


if __name__ == "__main__":
    unittest.main()


# ---------------------------------------------------------------------------
# End-to-end SUMOEnvironment.step() on a stubbed instance: exercises the edited
# CAV control branch (CACC + gap policy, shield, audit, actuation, perf guards)
# and the signal rule hook, so a NameError in step() cannot slip through.
# ---------------------------------------------------------------------------
import types  # noqa: E402

from test_sumo_interface_offline import TRACI  # noqa: E402


class _Rec:
    def __init__(self, ret=None):
        self.calls = []
        self.ret = ret or {}

    def __getattr__(self, name):
        def _f(*args):
            self.calls.append((name,) + tuple(args))
            v = self.ret.get(name)
            return v(*args) if callable(v) else v
        return _f

    def names(self):
        return [c[0] for c in self.calls]


def _vd(lane, speed, accel=0.0, vtype="CAV"):
    tc = SI.tc
    return {tc.VAR_LANE_ID: lane, tc.VAR_ROAD_ID: lane.rsplit("_", 1)[0], tc.VAR_SPEED: speed,
            tc.VAR_ACCELERATION: accel, tc.VAR_TYPE: vtype, tc.VAR_ACCUMULATED_WAITING_TIME: 0.0}


class TestStepIntegration(unittest.TestCase):
    KEYS = ("LON_NO_FLOORS", "LON_HANDBACK_NEAR_M", "LON_HANDBACK_JUNCTION", "LON_ACTUATION",
            "SPAT_SYNTH_FIX", "GAP_POLICY", "SIGNAL_RULE", "LON_RL_MAX_DIST_M",
            "LON_RL_MIN_DIST_M", "LON_RL_IN_JUNCTION")

    def setUp(self):
        self._saved_env = {k: os.environ.get(k) for k in self.KEYS}
        self._saved_traci = {k: getattr(TRACI, k, None) for k in ("vehicle", "trafficlight", "simulation", "simulationStep")}

    def tearDown(self):
        for k, v in self._saved_env.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        for k, v in self._saved_traci.items():
            if v is None:
                try:
                    delattr(TRACI, k)
                except AttributeError:
                    pass
            else:
                setattr(TRACI, k, v)

    def _build(self, env_vars, cav_junction=False):
        for k in self.KEYS:
            os.environ.pop(k, None)
        for k, v in env_vars.items():
            os.environ[k] = str(v)
        lane_c = ":J_3_0" if cav_junction else "e1_0"
        subs0 = {"c1": _vd(lane_c, 10.0, 0.3), "h1": _vd("e1_0", 9.0, 0.0, "HDV")}
        subs1 = {"c1": _vd(lane_c, 10.1, -0.2), "h1": _vd("e1_0", 9.0, 0.0, "HDV")}
        self.veh = _Rec({"getAllSubscriptionResults": lambda: subs1, "getMaxSpeed": lambda *_: 16.67})
        self.tl = _Rec({"getPhase": lambda *_: 0})
        TRACI.vehicle = self.veh
        TRACI.trafficlight = self.tl
        TRACI.simulation = types.SimpleNamespace(getTime=lambda: 100.2, getDepartedIDList=lambda: [])
        TRACI.simulationStep = lambda *a: None

        env = object.__new__(SI.SUMOEnvironment)
        env.step_length = 0.2
        env.MAX_SPEED = 16.67
        env._load_v524_switches()
        env._speed_capped = {}
        env._jstall_reset()
        env.sub_results = subs0
        env.controlled_cavs = set()
        env.vehicle_lane_mode_cache = {}
        env.platoon_tracker = types.SimpleNamespace(cluster_of={})
        env._leader_vids = set()
        env.CAV_RL_ENABLED = True
        env._in_control_zone = lambda vd: not cav_junction
        env._in_platoon_zone = lambda vd: True
        env._vehicle_type = lambda vid, vd=None: (vd or {}).get(SI.tc.VAR_TYPE, "HDV")
        env._corridor_route_target_and_lane_map = lambda vid, e: (None, None)
        env._force_cav_onto_route_lane = lambda *a: False
        env._step_hdv_rescue = lambda *a: None
        env._dist_to_stopline_from_vdata = lambda vd: -1.0 if cav_junction else 120.0
        env._vtype_limits = lambda vt: (3.0, 4.0)
        env._zone_detail = {"c1": {
            "speed_without_traci": 10.2, "leader_id": "h1", "leader_gap": 9.0, "leader_speed": 9.0,
            "follower_gap": 100.0, "follower_id": None, "next_link_open": True, "has_foe": False,
            "red_light_ahead": False, "tls_distance": 120.0, "tls_state": "g", "time_to_green": -1.0,
        }}
        # signal side
        env.tls_ids = ["J"]
        env.signal_programs = {}
        env._signals = {"J": {"phase": 0, "remaining_time": 10.0}}
        env.last_signal_phase = {"J": 0}
        env.phase_started_at = {"J": 80.0}
        env._sim_time = 100.0
        env._green_last_served, env._cycle_served = {}, {}
        env._maybe_complete_cycle = lambda *a: None
        env._phase_kind = lambda tls, ph: "green" if ph in (0, 3, 6, 9) else "yellow"
        env._green_phase_indices = lambda tls: [0, 3, 6, 9]
        env._planned_green_for = lambda tls, g: 40.0
        env._min_green_for = lambda tls, g: 10.0
        env._starve_may_force = lambda *a: False
        env._last_signal_mask = {"J": (0, np.ones(4, dtype=np.float32))}
        env._phase_pressure = lambda tls, g: [1.0, 2.0, 9.0, 3.0][g]
        self.transitions = []
        env._begin_phase_transition = lambda tls, cur, nxt, now: self.transitions.append(nxt)
        # post-step plumbing
        env._zone_subscribed = set()
        env._sync_zone_subscriptions = lambda: None
        env._subscribe_vehicle = lambda *a, **k: None
        env._update_episode_kpis = lambda: None
        env._sig_junction_ids = set()
        env.get_state = lambda: {"stats": {}}
        env.get_reward = lambda: 0.0
        env.is_done = lambda: False
        env._control_steps = 0
        env._done_reason = ""
        return env

    def test_legacy_step_runs_and_audits(self):
        env = self._build({})
        _s, _r, _d, info = env.step({"c1": [0.4]}, {"J": 1}, {})
        self.assertIn("setAcceleration", self.veh.names())
        self.assertNotIn("setMaxSpeed", self.veh.names())
        st = env.auth_stats()
        self.assertEqual(st["auth_n"], 1.0)
        self.assertEqual(env._signal_exec_log["J"], (1, 1))
        self.assertEqual(self.transitions, [3])
        self.assertIn("c1", env.controlled_cavs)
        self.assertEqual(st["auth_realized_res_mean"] != 0.0, True)

    def test_speed_mode_sent_once(self):
        env = self._build({})
        env.step({"c1": [0.0]}, None, {})
        n1 = self.veh.names().count("setSpeedMode")
        env.sub_results = dict(env.sub_results)
        env.step({"c1": [0.0]}, None, {})
        self.assertEqual(n1, 1)
        self.assertEqual(self.veh.names().count("setSpeedMode"), 1)

    def test_v6p0_profile_step(self):
        env = self._build({
            "LON_NO_FLOORS": "1", "LON_HANDBACK_NEAR_M": "20", "LON_ACTUATION": "speed",
            "GAP_POLICY": "unified", "SIGNAL_RULE": "maxpressure",
            "LON_RL_MAX_DIST_M": "200", "LON_RL_MIN_DIST_M": "20", "LON_RL_IN_JUNCTION": "0",
        })
        env.step({"c1": [-1.0]}, {"J": 1}, {})
        self.assertNotIn("setAcceleration", self.veh.names())
        self.assertIn("setMaxSpeed", self.veh.names())         # braking request -> speed cap
        self.assertEqual(env._signal_exec_log["J"], (1, 2))     # agent 1 logged, rule picked 2
        self.assertEqual(self.transitions, [6])
        self.assertEqual(env.auth_stats()["auth_n"], 1.0)

    def test_v6p0_junction_cav_not_controlled(self):
        env = self._build({"LON_RL_IN_JUNCTION": "0", "LON_RL_MIN_DIST_M": "20"}, cav_junction=True)
        env.step({"c1": [0.5]}, None, {})
        self.assertNotIn("setAcceleration", self.veh.names())
        self.assertNotIn("c1", env.controlled_cavs)
        self.assertEqual(env.auth_stats()["auth_n"], 0.0)
        # never controlled -> no redundant release calls
        self.assertNotIn("setSpeed", self.veh.names())

    def test_legacy_junction_cav_controlled(self):
        env = self._build({}, cav_junction=True)
        env.step({"c1": [0.5]}, None, {})
        self.assertIn("c1", env.controlled_cavs)


class TestGateRunner(unittest.TestCase):
    @staticmethod
    def _format_episode_log():
        """baselines.reward_tb.format_episode_log without importing torch.

        reward_tb imports torch at module level; the formatter itself is pure
        Python, so it is exec'd from the source to test against the REAL format.
        """
        path = os.path.join(ROOT, "baselines", "reward_tb.py")
        with open(path, encoding="utf-8") as fh:
            tree = ast.parse(fh.read())
        keep = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "format_episode_log"]
        ns = {"Optional": __import__("typing").Optional}
        exec(compile(ast.Module(body=keep, type_ignores=[]), path, "exec"), ns)
        return ns["format_episode_log"]

    def _log(self, path, tis, speed=6.0, stack=-0.05):
        format_episode_log = self._format_episode_log()

        with open(path, "w", encoding="utf-8") as fh:
            for ep, st in ((1, "S"), (2, "S"), (3, "Lon"), (4, "Lon")):
                fh.write(format_episode_log(
                    ep, 9, avg_speed=speed, stage=st,
                    extra=f"TIS: {tis:.1f}s | Backlog: 3 | Teleports: 0 | Collisions: 0",
                ) + "\n")
                fh.write(f"[Diag-JStall] ep={ep} stage={st} sig_box_standstill_s ctrlCAV=4 freeCAV=1 HDV=2 "
                         f"| >=10s events ctrlCAV=1 freeCAV=0 HDV=0 | unsig_box_s=0 | lon_noop=0.10 "
                         f"handback(idm_fol=0 native=0 near=3 junc=2) ppo_noop_dropped=0\n")
                fh.write(f"[Diag-Auth] ep={ep} stage={st} n=900 res(policy=+0.010 stack={stack:+.3f} "
                         f"realized=-0.020) stack_cut=0.40 stack_lift=0.01 pos_policy=0.50 "
                         f"pos_exec_ratio=0.05 sumo_cut=0.10 sumo_lift=0.02\n")

    def test_parse_and_verdict(self):
        import importlib.util
        import tempfile

        spec = importlib.util.spec_from_file_location("p0_gate", os.path.join(ROOT, "scripts", "p0_gate.py"))
        g = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(g)
        d = tempfile.mkdtemp()
        self._log(os.path.join(d, "G0_native.log"), 200.0)
        self._log(os.path.join(d, "G2_p0.log"), 203.0)
        self._log(os.path.join(d, "G3_p0_rl.log"), 230.0)
        r = g.parse_log(os.path.join(d, "G2_p0.log"))
        self.assertEqual(r["n_ep"], 2.0)
        self.assertAlmostEqual(r["tis"], 203.0)
        self.assertAlmostEqual(r["ctrl_ev"], 1.0)
        self.assertAlmostEqual(r["stack"], -0.05)
        self.assertAlmostEqual(r["posx"], 0.05)
        res = {c: g.parse_log(os.path.join(d, f"{c}.log")) for c in ("G0_native", "G2_p0", "G3_p0_rl", "G1_v524")}
        out = "\n".join(g.verdict(res, 0.02))
        self.assertIn("GATE-1 feasibility (G2 vs G0): PASS", out)
        self.assertIn("GATE-2 learning    (G3 vs G2): FAIL", out)
        self.assertIn("NOT EVALUATED", out)  # G1 log missing
