"""FROZEN v5.1 reference of enrich_formation_state (pre-index). Do not edit."""
from __future__ import annotations

from typing import Any, Dict, Mapping, Optional

import numpy as np

from environment.platoon_manager import (
    _finite_float, _lane_index, _same_approach, gap_band_reward, platoon_gap, safe_gap,
)


def enrich_formation_state(
    ego: Mapping[str, Any],
    peers: Mapping[str, Mapping[str, Any]],
) -> Dict[str, float]:
    """Build lateral platoon-formation features for one ego vehicle."""
    ego_lane = str(ego.get("lane", "") or "")
    ego_edge = str(ego.get("edge", "") or "")
    raw_ego = ego.get("dist_to_stopline", -1.0)
    ego_d = -1.0 if raw_ego is None else _finite_float(raw_ego, -1.0)
    ego_v = _finite_float(ego.get("speed", 0.0), 0.0)
    ego_lane_idx = _lane_index(ego_lane)

    nearest_cav = 100.0
    nearest_hdv = 100.0
    best_partner: Optional[Mapping[str, Any]] = None
    best_dist = 1e9
    rel_speed = 0.0
    rel_lane = 0.0
    cand_type = 0.0  # 0 HDV, 1 CAV
    # Driver-relative lane offset: + = partner toward driver-left.
    # Raw index delta flips meaning between LHT and RHT.
    try:
        from environment.cav_state_builder import lane_index_sign

        _lane_sign = int(lane_index_sign(ego))
    except Exception:
        _lane_sign = 1

    for oid, o in peers.items():
        if oid == ego.get("_id"):
            continue
        raw_o = o.get("dist_to_stopline", -1.0)
        od = -1.0 if raw_o is None else _finite_float(raw_o, -1.0)
        if od < 0.0 or ego_d < 0.0:
            continue
        # Same approach corridor heuristic: same edge prefix or same stop-line side
        o_edge = str(o.get("edge", "") or "")
        if ego_edge and o_edge and not _same_approach(ego_edge, o_edge):
            continue
        gap = abs(od - ego_d)
        is_cav = bool(o.get("is_cav", False))
        if is_cav:
            nearest_cav = min(nearest_cav, gap)
        else:
            nearest_hdv = min(nearest_hdv, gap)
        if gap < best_dist and gap < 80.0:
            best_dist = gap
            best_partner = o
            rel_speed = ego_v - _finite_float(o.get("speed", 0.0), 0.0)
            rel_lane = float(
                (_lane_index(str(o.get("lane", "") or "")) - ego_lane_idx) * _lane_sign
            )
            cand_type = 1.0 if is_cav else 0.0

    in_plat = bool(ego.get("is_in_platoon") or ego.get("cluster_id"))
    cluster = str(ego.get("cluster_id") or "")
    quality = 0.0
    if in_plat and cluster and not cluster.startswith("solo"):
        quality = 1.0
    elif best_partner is not None:
        rd = gap_band_reward(best_dist, ego_v)
        quality = max(0.0, rd)

    # Soft probability of joining: close gap + similar speed + quality
    form_p = 0.0
    if best_partner is not None:
        ds, dp = safe_gap(ego_v), platoon_gap(ego_v)
        gap_term = float(np.clip(1.0 - abs(best_dist - 0.5 * (ds + dp)) / max(dp, 1e-3), 0.0, 1.0))
        spd_term = float(np.clip(1.0 - abs(rel_speed) / 5.0, 0.0, 1.0))
        form_p = 0.5 * gap_term + 0.5 * spd_term

    return {
        "nearest_cav_distance": float(nearest_cav),
        "nearest_hdv_distance": float(nearest_hdv),
        "relative_speed": float(rel_speed),
        "relative_lane": float(rel_lane),
        "candidate_vehicle_type": float(cand_type),
        "platoon_quality": float(quality),
        "formation_probability": float(form_p),
    }
