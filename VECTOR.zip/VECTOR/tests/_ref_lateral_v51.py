"""FROZEN v5.1 reference implementations (pre-index) for equivalence tests.

Copied verbatim from environment/cav_state_builder.py and platoon_manager.py
before the v5.2 per-step peer index. Do not edit.
"""
from __future__ import annotations

from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

import numpy as np

from environment.cav_state_builder import _finite_float, _lane_index


def lane_queue_counts(
    edge_id: str,
    vehicles: Mapping[str, Mapping[str, Any]],
    n_lanes: int = 3,
    approach_edges: Optional[Sequence[str]] = None,
    *,
    include_rolling: bool = False,
) -> List[float]:
    """Count lane load per lane index along one approach chain.

    When ``include_rolling=False`` (default for legacy callers), counts strictly
    halted vehicles (``speed < 0.5 m/s``) as integers.
    When ``include_rolling=True`` (used by ``build_lane_features`` for Stage-Lat),
    combines halted vehicles (weight 1.0) with slow/rolling approach platoons
    (``0.5 <= speed < 8.0 m/s`` within 450 m of the stop line, linearly weighted up
    to 0.55) so lateral RL proactively balances moving congestion waves before
    they come to a dead stop.
    """
    edges = {str(edge_id or "")}
    if approach_edges:
        edges.update(str(e) for e in approach_edges if e)
    edges.discard("")
    if not include_rolling:
        counts_int = [0] * max(int(n_lanes), 1)
        for v in vehicles.values():
            if str(v.get("edge", "") or "") not in edges:
                continue
            if _finite_float(v.get("speed", 0.0), 0.0) >= 0.5:
                continue
            idx = _lane_index(str(v.get("lane", "") or ""))
            if 0 <= idx < len(counts_int):
                counts_int[idx] += 1
        return counts_int

    loads = [0.0] * max(int(n_lanes), 1)
    for v in vehicles.values():
        if str(v.get("edge", "") or "") not in edges:
            continue
        spd = _finite_float(v.get("speed", 0.0), 0.0)
        idx = _lane_index(str(v.get("lane", "") or ""))
        if not (0 <= idx < len(loads)):
            continue
        if spd < 0.5:
            loads[idx] += 1.0
        elif spd < 8.0:
            raw_d = v.get("dist_to_stopline", -1.0)
            dist = -1.0 if raw_d is None else _finite_float(raw_d, -1.0)
            if dist < 0.0 or dist <= 450.0:
                w_roll = 0.55 * max(0.0, 1.0 - (spd - 0.5) / 7.5)
                loads[idx] += float(w_roll)
    return [round(float(x), 4) for x in loads]


def _nearest_gap_on_lane(
    ego: Mapping[str, Any],
    peers: Mapping[str, Mapping[str, Any]],
    target_lane: int,
    ahead: bool,
) -> tuple:
    """Nearest physical bumper-to-bumper gap (m) and closing speed (m/s) on target lane.

    Supports multi-edge approach chains (e.g. 4-leg 850 m upstream + 29 m junction
    edge) via continuous ``dist_to_stopline`` coordinates when peers are on adjacent
    segments of the same ``approach_edges`` corridor.
    """
    edge = str(ego.get("edge") or "")
    app_edges = {edge} if edge else set()
    raw_chain = ego.get("approach_edges")
    if raw_chain:
        app_edges.update(str(e) for e in raw_chain if e)
    app_edges.discard("")
    ego_id = str(ego.get("_id") or "")
    ego_pos = _finite_float(ego.get("lane_position", 0.0), 0.0)
    ego_v = _finite_float(ego.get("speed", 0.0), 0.0)
    ego_len = _finite_float(ego.get("length", 5.0), 5.0)
    raw_ed = ego.get("dist_to_stopline", -1.0)
    ego_d = -1.0 if raw_ed is None else _finite_float(raw_ed, -1.0)
    best_gap = None
    best_closing = None
    for oid, o in (peers or {}).items():
        if ego_id and str(oid) == ego_id:
            continue
        o_edge = str(o.get("edge") or "")
        same_edge = (o_edge == edge)
        if not same_edge and (not app_edges or o_edge not in app_edges):
            continue
        if _lane_index(str(o.get("lane") or "")) != int(target_lane):
            continue
        ov = _finite_float(o.get("speed", 0.0), 0.0)
        o_len = _finite_float(o.get("length", 5.0), 5.0)
        if same_edge:
            opos = _finite_float(o.get("lane_position", 0.0), 0.0)
            delta_front = opos - ego_pos  # >0 means o is ahead of ego
        else:
            raw_od = o.get("dist_to_stopline", -1.0)
            od = -1.0 if raw_od is None else _finite_float(raw_od, -1.0)
            if ego_d < 0.0 or od < 0.0:
                continue
            # Smaller dist_to_stopline is closer to the stop line (ahead).
            delta_front = ego_d - od
        if ahead:
            if delta_front <= 0.0:
                continue
            gap = max(0.05, delta_front - o_len) if delta_front > 0.2 else 0.0
            if gap <= 0.0:
                continue
            closing = ego_v - ov
        else:
            delta_rear = -delta_front
            if delta_rear <= 0.0:
                continue
            gap = max(0.05, delta_rear - ego_len) if delta_rear > 0.2 else 0.0
            if gap <= 0.0:
                continue
            closing = ov - ego_v
        if best_gap is None or gap < best_gap:
            best_gap = float(gap)
            best_closing = float(closing)
    return best_gap, best_closing


def nearest_target_lane_partner(
    ego: Mapping[str, Any],
    peers: Mapping[str, Mapping[str, Any]],
    target_lane: int,
    approach_edges: Optional[Sequence[str]] = None,
) -> tuple:
    """Longitudinal gap (m) and CAV flag of the nearest front/rear vehicle.

    Only vehicles on ``target_lane`` of this approach count. A vehicle sitting
    beside the ego on another lane index is not a partner, so side-by-side
    driving is not scored as a rear-end.
    """
    edges = {str(ego.get("edge") or "")}
    if approach_edges:
        edges.update(str(e) for e in approach_edges if e)
    edges.discard("")
    ego_id = str(ego.get("_id") or "")
    raw_ego = ego.get("dist_to_stopline", -1.0)
    ego_d = -1.0 if raw_ego is None else _finite_float(raw_ego, -1.0)
    best_gap = None
    best_cav = None
    for oid, o in (peers or {}).items():
        if ego_id and str(oid) == ego_id:
            continue
        if _lane_index(str(o.get("lane") or "")) != int(target_lane):
            continue
        o_edge = str(o.get("edge") or "")
        if edges and o_edge not in edges:
            continue
        raw_o = o.get("dist_to_stopline", -1.0)
        od = -1.0 if raw_o is None else _finite_float(raw_o, -1.0)
        if od < 0.0 or ego_d < 0.0:
            continue
        o_len = max(_finite_float(o.get("length", 5.0), 5.0), 0.0)
        gap = max(0.0, abs(ego_d - od) - o_len)
        if best_gap is None or gap < best_gap:
            best_gap = float(gap)
            best_cav = bool(o.get("is_cav", False))
    if best_gap is None:
        return 100.0, None
    return float(best_gap), best_cav
