"""Unit tests for VECTOR v4 changes that run WITHOUT SUMO / torch.

Run:  python -m unittest tests/test_v4_optimizations.py -v
"""
import os
import sys
import tempfile
import unittest

import numpy as np

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, ROOT)

from agents.gae_utils import smdp_gae  # noqa: E402
from train.credit_utils import (  # noqa: E402
    coop_xapp_deltas, relative_deltas, rollout_fallback_mean, step_deltas,
)
from environment.demand_randomizer import DemandRandomizer, read_trip_departs  # noqa: E402
from environment.zone_lc import FREE_LC_MODE, KEEP_LANE_MODE, desired_lc_mode  # noqa: E402


def _standard_gae(r, v, d, nv, g, lam):
    adv = np.zeros(len(r)); gae = 0.0; following = nv
    for t in reversed(range(len(r))):
        nd = 1.0 - d[t]
        delta = r[t] + g * following * nd - v[t]
        gae = delta + g * lam * nd * gae
        adv[t] = gae; following = v[t]
    return adv


class TestSMDPGAE(unittest.TestCase):
    def setUp(self):
        rng = np.random.default_rng(0)
        self.n = 40
        self.r = rng.normal(size=self.n)
        self.v = rng.normal(size=self.n)
        self.d = np.zeros(self.n)
        self.nv = 0.7
        self.g, self.lam = 0.98, 0.9

    def test_no_mask_equals_standard(self):
        _, adv = smdp_gae(self.r, self.v, self.d, self.nv, self.g, self.lam, None)
        np.testing.assert_allclose(adv, _standard_gae(self.r, self.v, self.d, self.nv, self.g, self.lam), rtol=1e-5, atol=1e-5)

    def test_option_level_equivalence(self):
        dec = np.zeros(self.n, dtype=bool)
        starts = [0, 5, 6, 13, 20, 31]
        dec[starts] = True
        _, adv = smdp_gae(self.r, self.v, self.d, self.nv, self.g, self.lam, dec)
        bounds = starts + [self.n]
        a_next = 0.0
        ref = {}
        for i in reversed(range(len(starts))):
            t0, t1 = bounds[i], bounds[i + 1]
            tau = t1 - t0
            v_next = self.v[t1] if t1 < self.n else self.nv
            disc = sum(self.g ** k * self.r[t0 + k] for k in range(tau))
            delta_opt = disc + self.g ** tau * v_next - self.v[t0]
            lam_eff = self.lam if t1 < self.n else 0.0
            a = delta_opt + self.g ** tau * lam_eff * a_next
            ref[t0] = a
            a_next = a
        for t0 in starts:
            self.assertAlmostEqual(float(adv[t0]), float(ref[t0]), places=4)

    def test_lambda_one_is_mc(self):
        dec = np.zeros(self.n, dtype=bool); dec[::7] = True
        _, a1 = smdp_gae(self.r, self.v, self.d, self.nv, self.g, 1.0, dec)
        np.testing.assert_allclose(a1, _standard_gae(self.r, self.v, self.d, self.nv, self.g, 1.0), atol=1e-5)


class TestCredit(unittest.TestCase):
    def _entries(self, follower_reward):
        # ego and its follower on approach N, two cars on approach E
        return [("cav_lon_ego", "N", 0.5, 0.5), ("cav_lon_fol", "N", follower_reward, follower_reward),
                ("cav_lon_e1", "E", 0.2, 0.2), ("cav_lon_e2", "E", 0.3, 0.3)]

    def test_relative_is_anti_cooperative(self):
        hi = relative_deltas(self._entries(0.8))["cav_lon_ego"]
        lo = relative_deltas(self._entries(-0.8))["cav_lon_ego"]
        self.assertGreater(lo, hi)  # hurting the follower RAISES ego credit (v3 bug)

    def test_coop_is_cooperative(self):
        hi = coop_xapp_deltas(self._entries(0.8), kappa=0.5)["cav_lon_ego"]
        lo = coop_xapp_deltas(self._entries(-0.8), kappa=0.5)["cav_lon_ego"]
        self.assertGreater(hi, lo)  # hurting the follower LOWERS ego credit

    def test_baseline_ignores_same_approach(self):
        e = self._entries(0.1)
        base_a = 0.5 + 0.5 * 0.1 - coop_xapp_deltas(e, kappa=0.5)["cav_lon_ego"]
        e2 = [("cav_lon_ego", "N", 0.5, 0.5), ("cav_lon_fol", "N", 0.1, 0.1),
              ("cav_lon_x", "N", -3.0, -3.0), ("cav_lon_e1", "E", 0.2, 0.2), ("cav_lon_e2", "E", 0.3, 0.3)]
        d2 = coop_xapp_deltas(e2, kappa=0.5)["cav_lon_ego"]
        base_b = 0.5 + 0.5 * np.mean([0.1, -3.0]) - d2
        self.assertAlmostEqual(base_a, base_b, places=6)

    def test_fallback_and_dispatch(self):
        only_n = [("a", "N", 1.0, 1.0), ("b", "N", 0.0, 0.0)]
        fb = rollout_fallback_mean([only_n], kappa=0.5)
        d = step_deltas(only_n, mode="coop_xapp", kappa=0.5, fallback_mean=fb)
        self.assertAlmostEqual(d["a"], 1.0 - fb, places=6)
        self.assertEqual(set(step_deltas(only_n, mode="relative")), {"a", "b"})


class TestDemandRandomizer(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.base = os.path.join(self.tmp, "base.rou.xml")
        lines = ['<routes>', '  <vType id="HDV" accel="2.2"/>']
        for i in range(200):
            lines.append(f'  <trip id="t{i}" type="HDV" depart="{i * 5.0:.2f}" from="a" to="b"/>')
        lines.append('</routes>')
        with open(self.base, "w", encoding="utf-8") as fh:
            fh.write("\n".join(lines))

    def test_deterministic_sorted_unique(self):
        r1 = DemandRandomizer(True, 60.0, 0.9, 1.2, out_dir=os.path.join(self.tmp, "o1"))
        r2 = DemandRandomizer(True, 60.0, 0.9, 1.2, out_dir=os.path.join(self.tmp, "o2"))
        p1, p2 = r1.generate(self.base, 123), r2.generate(self.base, 123)
        d1, d2 = read_trip_departs(p1), read_trip_departs(p2)
        self.assertEqual(d1, d2)
        deps = list(d1.values())
        self.assertEqual(deps, sorted(deps))
        self.assertTrue(min(deps) >= 0.0 and max(deps) <= 995.0)
        with open(p1, encoding="utf-8") as fh:
            txt = fh.read()
        self.assertLess(txt.find("vType"), txt.find("<trip"))

    def test_disabled_returns_none(self):
        self.assertIsNone(DemandRandomizer(False).generate(self.base, 1))


class TestZoneLC(unittest.TestCase):
    def test_hdv_free_cav_keep_in_control_zone(self):
        kw = dict(in_control_zone=True, in_platoon_zone=True, is_in_junction=False)
        self.assertEqual(desired_lc_mode(is_cav=True, **kw), KEEP_LANE_MODE)
        self.assertEqual(desired_lc_mode(is_cav=False, **kw), FREE_LC_MODE)
        self.assertEqual(desired_lc_mode(is_cav=False, control_keep_lane_hdv=True, **kw), KEEP_LANE_MODE)


class TestTeacherSeverity(unittest.TestCase):
    def test_visual_label_alone_is_routine(self):
        try:
            from VLM.signal_vision import teacher_sample_severity
        except Exception as exc:  # optional deps missing
            self.skipTest(f"signal_vision import failed: {exc}")
        self.assertAlmostEqual(teacher_sample_severity("blockage", 0.0), 0.30)
        self.assertAlmostEqual(teacher_sample_severity("none", 0.9), 1.0)


if __name__ == "__main__":
    unittest.main()
