"""Offline tests for VECTOR v5 batch 1 (no SUMO / torch needed).

Run:  python -m unittest tests/test_v5_batch1.py -v
"""
import argparse
import ast
import csv
import os
import sys
import tempfile
import unittest

import numpy as np

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "scripts"))
sys.path.insert(0, os.path.join(ROOT, "tools"))

from agents.signal_buffer import SIGNAL_SAMPLE_KEYS, SignalSampleBuffer  # noqa: E402
import baselines.episode_timing as ET  # noqa: E402
import calibrate_schedule as CAL  # noqa: E402
import evaluate_policy as EV  # noqa: E402


def _load_funcs(names):
    path = os.path.join(ROOT, "train", "train_RL.py")
    with open(path, encoding="utf-8") as fh:
        src = fh.read()
    tree = ast.parse(src)
    ns = {"np": np, "os": os}
    for node in tree.body:
        if isinstance(node, ast.FunctionDef) and node.name in names:
            exec(compile(ast.get_source_segment(src, node), path, "exec"), ns)
    return ns


def _flush(n, stage_tag=0):
    return {
        "signal_obs": [{"action_mask": [1, 1, 0], "i": stage_tag * 100 + i} for i in range(n)],
        "signal_actions": np.arange(n) % 2,
        "signal_log_probs": np.full(n, -0.7, dtype=np.float32),
        "signal_ind_advantages": np.linspace(-1, 1, n).astype(np.float32),
        "signal_step_indices": np.arange(n),
    }


class TestSignalBuffer(unittest.TestCase):
    def test_accumulate_release_alignment(self):
        buf = SignalSampleBuffer(64)
        buf.add(_flush(30), "S")
        self.assertFalse(buf.ready())
        buf.add(_flush(30), "S")
        self.assertFalse(buf.ready())
        buf.add(_flush(10), "S")
        self.assertTrue(buf.ready())
        out = buf.release()
        self.assertEqual(len(out["signal_obs"]), 70)
        for k in SIGNAL_SAMPLE_KEYS[1:]:
            self.assertEqual(len(out[k]), 70, k)
        self.assertTrue((out["signal_teacher_actions"] == -1).all())   # filled defaults
        self.assertEqual(len(buf), 0)

    def test_stage_change_drops_stale_samples(self):
        buf = SignalSampleBuffer(50)
        buf.add(_flush(40), "S")
        buf.add(_flush(5), "JointAll")
        self.assertEqual(len(buf), 5)

    def test_misaligned_required_key_raises(self):
        bad = _flush(5)
        bad["signal_log_probs"] = np.zeros(3)
        with self.assertRaises(ValueError):
            SignalSampleBuffer(8).add(bad, "S")


class TestSchedule(unittest.TestCase):
    def setUp(self):
        self._saved = {k: v for k, v in vars(ET).items() if k.startswith(("FULL_", "QUICK_"))}

    def tearDown(self):
        vars(ET).update(self._saved)

    def test_v5_default_full(self):
        self.assertEqual(ET.FULL_TOTAL_EPISODES, 850)
        self.assertEqual(ET.FULL_STAGE_LON_EPISODES - ET.FULL_JOINT_LON_SIG_EPISODES, 180)
        self.assertEqual(ET.FULL_STAGE_LAT_EPISODES - ET.FULL_JOINT_ALL_EPISODES, 250)
        self.assertEqual(ET.FULL_JOINT_ALL_EPISODES - ET.FULL_JOINT_ALL_ANNEAL_EPISODES, 50)

    def test_override_applies_and_validates(self):
        ok = ET.apply_schedule_overrides({"full": {"stage_lon": 240, "joint_lon_sig": 60}})
        self.assertTrue(ok)
        self.assertEqual(ET.FULL_TOTAL_EPISODES, 250 + 240 + 420)
        with self.assertRaises(ValueError):
            ET.apply_schedule_overrides({"full": {"joint_all": 500}})
        with self.assertRaises(ValueError):
            ET.apply_schedule_overrides({"full": {"stage_x": 1}})

    def test_none_is_noop(self):
        self.assertFalse(ET.apply_schedule_overrides(None))


class TestTrainHelpers(unittest.TestCase):
    def test_build_control_kwargs_extracted(self):
        ns = _load_funcs({"_build_control_kwargs"})
        args = argparse.Namespace(green_k=0.35, dbscan_eps=0.8, warmup_seconds=300.0, queue_mode="halted",
                                  demand_randomize=True)
        co = {"green_glide_decouple_enabled": True, "in_memory_follower_lookup": True,
              "cacc_soft_platoon_enabled": True, "cacc_full_gap_m": 8.0, "cacc_free_gap_m": 30.0,
              "cacc_rl_authority_floor": 0.25, "cacc_leader_accel_gain": 0.5}
        kw = ns["_build_control_kwargs"](args, co, True)
        for key in ("green_duration_k", "top3_phase_mask", "cav_rl_leaders_only", "lon_residual_idm",
                    "queue_mode", "max_depart_delay", "allow_od_rewrite", "demand_randomize",
                    "ablate_zero_lon_residual", "cacc_rl_authority_floor"):
            self.assertIn(key, kw)
        self.assertFalse(kw["allow_od_rewrite"])
        self.assertEqual(kw["max_depart_delay"], -1.0)

    def test_selection_score_and_seeds(self):
        ns = _load_funcs({"_best_score", "_selection_score", "_resolve_eval_seeds"})
        legacy = ns["_selection_score"](argparse.Namespace(select_score="legacy"), 8.0, 10.0, [{"avg_time_in_system": 180.0}])
        self.assertAlmostEqual(legacy, 8.0 - 1.5)
        tis = ns["_selection_score"](argparse.Namespace(select_score="tis"), 8.0, 10.0,
                                     [{"avg_time_in_system": 180.0}, {"avg_time_in_system": 240.0}])
        self.assertAlmostEqual(tis, -3.5)
        self.assertEqual(len(ns["_resolve_eval_seeds"]("validation")), 10)
        self.assertEqual(ns["_resolve_eval_seeds"]("5,6"), [5, 6])
        train_seeds = {s * 10000 + ep for s in range(7, 12) for ep in range(0, 2000)}
        self.assertFalse(train_seeds & set(ns["_resolve_eval_seeds"]("test")))


class TestSmokeSchedule(unittest.TestCase):
    def test_smoke_visits_every_stage(self):
        ns = _load_funcs({"_carve_joint_tail"})
        carve = ns["_carve_joint_tail"]
        self.assertEqual(carve(4, joint_n=2, tail_frac=0.0, min_main=8), (4, 0))   # v5 smoke bug
        self.assertEqual(carve(4, joint_n=2, tail_frac=0.0, min_main=1), (2, 2))   # v5.1 --smoke

    def test_smoke_flag_in_timing(self):
        src = open(os.path.join(ROOT, "baselines", "episode_timing.py"), encoding="utf-8").read()
        self.assertIn('getattr(args, "smoke", False)', src)
        tr = open(os.path.join(ROOT, "train", "train_RL.py"), encoding="utf-8").read()
        self.assertEqual(tr.count('min_main=(1 if bool(getattr(args, "smoke", False)) else 8)'), 2)


class TestCalibration(unittest.TestCase):
    def test_plateau_detection(self):
        rng = np.random.default_rng(0)
        x = np.arange(200)
        y = 100.0 + 60.0 * np.exp(-x / 25.0) + rng.normal(0, 0.5, 200)
        idx = CAL.plateau_index(y, window=10, tol=0.02)
        self.assertIsNotNone(idx)
        self.assertTrue(60 <= idx <= 140, idx)
        res = CAL.calibrate(np.concatenate([y, y]), CAL.segments_from_boundaries("S:200,Lon:200", 400),
                            mins={"S": 10, "Lon": 10})
        self.assertEqual([r["stage"] for r in res], ["S", "Lon"])
        self.assertTrue(all(r["suggested_length"] for r in res))

    def test_ragged_episode_means(self):
        m = CAL.episode_means(np.array([[1.0, 3.0], [np.nan, 4.0], [5.0, 7.0]]))
        np.testing.assert_allclose(m, [2.0, 4.0, 6.0])


class TestEvaluator(unittest.TestCase):
    def test_aggregate_and_gate(self):
        tmp = tempfile.mkdtemp()
        p = os.path.join(tmp, "x.csv")
        rows = []
        for ck, base, coll in (("a.pt", 200.0, 0.0), ("b.pt", 180.0, 2.0), ("c.pt", 190.0, 0.0)):
            for s in range(5):
                rows.append({"checkpoint_path": ck, "avg_time_in_system": base + s, "collisions_total": coll})
        with open(p, "w", newline="") as fh:
            w = csv.DictWriter(fh, fieldnames=list(rows[0]))
            w.writeheader()
            w.writerows(rows)
        summary, best = EV.aggregate(EV.read_rows([p]), max_collisions=0.5)
        self.assertEqual(best["checkpoint"], "c.pt")       # b is faster but fails the collision gate
        _, best2 = EV.aggregate(EV.read_rows([p]))
        self.assertEqual(best2["checkpoint"], "b.pt")
        ci = EV.mean_ci([1.0, 2.0, 3.0])
        self.assertAlmostEqual(ci["mean"], 2.0)
        self.assertGreater(ci["ci95"], 0.0)

    def test_seed_presets(self):
        self.assertEqual(len(EV.resolve_seeds("test")), 10)
        self.assertFalse(set(EV.resolve_seeds("test")) & set(EV.resolve_seeds("validation")))


if __name__ == "__main__":
    unittest.main()
