"""Run the REAL compute_gae_for_rollout (v3 and v4 sources) on synthetic rollouts.

* relative mode + all-decision ticks: v4 must reproduce v3 bit-for-bit.
* coop_xapp mode: finite advantages for every CAV agent; cooperative sign.
Run:  python -m unittest tests/test_credit_integration.py -v
"""
import ast
import os
import sys
import types
import unittest

import numpy as np

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, ROOT)
from agents.gae_utils import smdp_gae  # noqa: E402
from train.credit_utils import rollout_fallback_mean, step_deltas  # noqa: E402

V3_SRC = os.environ.get("VECTOR_V3_TRAIN_RL", "")  # optional path to the v3 train_RL.py


def _load_fn(path):
    with open(path, encoding="utf-8") as fh:
        src = fh.read()
    tree = ast.parse(src)
    node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "compute_gae_for_rollout")
    code = ast.get_source_segment(src, node)
    fake = types.ModuleType("agents.mappo")
    fake.SIGNAL_GAE_GAMMA, fake.SIGNAL_GAE_LAMBDA = 0.998, 0.98
    sys.modules["agents.mappo"] = fake
    ns = {"np": np, "credit_step_deltas": step_deltas, "rollout_fallback_mean": rollout_fallback_mean,
          "_evaluate_critic_values": lambda a, g: (0.0, 0.0), "graph_from_obs": lambda o: None}
    exec(compile(code, path, "exec"), ns)
    return ns["compute_gae_for_rollout"]


class _Agent:
    gamma, gae_lambda, training_stage = 0.99, 0.95, "Lon"
    cross_approach_baseline, action_blend_beta = True, 1.0

    def __init__(self, mode):
        self.cav_credit_mode, self.coop_kappa = mode, 0.5

    def compute_gae(self, rewards, values, dones, next_value=0.0, gamma=None, gae_lambda=None, decision_mask=None):
        return smdp_gae(rewards, values, dones, next_value,
                        self.gamma if gamma is None else gamma,
                        self.gae_lambda if gae_lambda is None else gae_lambda, decision_mask)


def _rollout(follower_scale=1.0, hold_every=None, n=8, seed=0):
    rng = np.random.default_rng(seed)
    ids = ["cav_lon_a", "cav_lon_b", "cav_lon_c", "cav_lon_d"]
    app = {"cav_lon_a": "N", "cav_lon_b": "N", "cav_lon_c": "E", "cav_lon_d": "E"}
    ro = {"global_obs": [None] * n, "values": list(rng.normal(size=n)), "signal_values": [0.0] * n,
          "dones": [0.0] * n, "team_rewards": list(rng.normal(size=n)), "rewards": [], "obs": [],
          "actions": [], "agent_dones": [{} for _ in range(n)]}
    for t in range(n):
        r = {k: float(rng.normal()) for k in ids}
        r["cav_lon_b"] *= follower_scale
        r["signal_J"] = -0.2
        ro["rewards"].append(r)
        ro["obs"].append({k: {"approach_key": app[k]} for k in ids})
        hold = hold_every is not None and t % hold_every != 0
        ro["actions"].append({k: (None if hold else 0.1) for k in ids})
    return ro


class TestCreditIntegration(unittest.TestCase):
    def test_v4_relative_matches_v3_exactly(self):
        if not V3_SRC or not os.path.isfile(V3_SRC):
            self.skipTest("set VECTOR_V3_TRAIN_RL=/path/to/v3/train/train_RL.py to compare")
        f3, f4 = _load_fn(V3_SRC), _load_fn(os.path.join(ROOT, "train", "train_RL.py"))
        a3 = f3(_Agent("relative"), _rollout(), None, True)["advantages"]
        a4 = f4(_Agent("relative"), _rollout(), None, True)["advantages"]
        for s3, s4 in zip(a3, a4):
            self.assertEqual(set(s3), set(s4))
            for k in s3:
                self.assertAlmostEqual(s3[k], s4[k], places=9)

    def test_coop_runs_with_hold_ticks(self):
        f4 = _load_fn(os.path.join(ROOT, "train", "train_RL.py"))
        out = f4(_Agent("coop_xapp"), _rollout(hold_every=2), None, True)["advantages"]
        self.assertEqual(len(out), 8)
        for step in out:
            for k, v in step.items():
                self.assertTrue(np.isfinite(v), k)
            for k in ("cav_lon_a", "cav_lon_b", "cav_lon_c", "cav_lon_d"):
                self.assertIn(k, step)


if __name__ == "__main__":
    unittest.main()
