"""v5.2: bit-identity of the indexed lateral helpers + reward v2 properties.

Run:  python -m unittest tests/test_v52_perf_reward.py -v
"""
import json
import os
import sys
import time
import unittest

import numpy as np

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "tests"))

import _ref_formation_v51 as REF_PM  # noqa: E402
import _ref_lateral_v51 as REF  # noqa: E402
from environment import cav_state_builder as CSB  # noqa: E402
from environment import platoon_manager as PM  # noqa: E402
from environment.peer_index import get_peer_index, shared_peers  # noqa: E402

EDGES = ["A#0", "A#1", "A.ext", "A#2.ext", "-A#0", "B", "B#1", "C#3", ""]


def _vehicle(rng):
    e = EDGES[int(rng.integers(len(EDGES)))]
    v = {
        "edge": e,
        "lane": (f"{e}_{int(rng.integers(0, 3))}" if e and rng.random() > 0.05
                 else ["", "x", None][int(rng.integers(3))]),
        "speed": (float(np.round(rng.uniform(0, 16))) if rng.random() > 0.05 else None),
        "length": float([5.0, 4.5, 12.0][int(rng.integers(3))]),
        "lane_position": float(np.round(rng.uniform(0, 120))),      # coarse -> many exact ties
        "dist_to_stopline": (float(np.round(rng.uniform(-5, 300))) if rng.random() > 0.1 else None),
        "is_cav": bool(rng.random() < 0.3),
    }
    if rng.random() < 0.05:
        v.pop("speed", None)
    return v


def _scene(rng, n):
    peers = {}
    for i in range(n):
        oid = f"v{i}"
        peers[oid] = _vehicle(rng)
        peers[oid]["_id"] = oid
    return peers


def _ego(rng, peers):
    oid = list(peers)[int(rng.integers(len(peers)))]
    ego = dict(peers[oid])
    if rng.random() < 0.7:
        ego["approach_edges"] = [EDGES[int(k)] for k in rng.integers(0, len(EDGES), size=int(rng.integers(0, 4)))]
    if rng.random() < 0.1:
        ego["_id"] = None
    return ego


class TestBitIdentity(unittest.TestCase):
    def test_lateral_helpers_identical(self):
        rng = np.random.default_rng(1234)
        checks = 0
        for _ in range(250):
            peers = _scene(rng, int(rng.integers(5, 90)))
            for _ in range(6):
                ego = _ego(rng, peers)
                for lane in (-1, 0, 1, 2, 3):
                    for ahead in (True, False):
                        self.assertEqual(REF._nearest_gap_on_lane(ego, peers, lane, ahead),
                                         CSB._nearest_gap_on_lane(ego, peers, lane, ahead))
                    app = ego.get("approach_edges")
                    self.assertEqual(REF.nearest_target_lane_partner(ego, peers, lane, app),
                                     CSB.nearest_target_lane_partner(ego, peers, lane, app))
                for roll in (False, True):
                    self.assertEqual(
                        REF.lane_queue_counts(ego.get("edge"), peers, 4, ego.get("approach_edges"), include_rolling=roll),
                        CSB.lane_queue_counts(ego.get("edge"), peers, 4, ego.get("approach_edges"), include_rolling=roll))
                self.assertEqual(REF_PM.enrich_formation_state(ego, peers), PM.enrich_formation_state(ego, peers))
                checks += 1
        self.assertGreater(checks, 1000)

    def test_cache_alternation_and_shared_peers(self):
        rng = np.random.default_rng(7)
        a, b = _scene(rng, 40), _scene(rng, 40)
        ego_a, ego_b = _ego(rng, a), _ego(rng, b)
        for _ in range(3):
            self.assertEqual(REF._nearest_gap_on_lane(ego_a, a, 1, True), CSB._nearest_gap_on_lane(ego_a, a, 1, True))
            self.assertEqual(REF._nearest_gap_on_lane(ego_b, b, 1, True), CSB._nearest_gap_on_lane(ego_b, b, 1, True))
        state = {"cavs": {"x": {"edge": "A#0"}, "y": {"edge": "B"}}, "hdvs": {"y": {"edge": "C#3"}, "z": {}}}
        p1 = shared_peers(state)
        self.assertIs(p1, shared_peers(state))
        manual = {}
        for g in ("cavs", "hdvs"):
            for oid, o in state[g].items():
                manual[oid] = dict(o)
                manual[oid]["_id"] = oid
        self.assertEqual(p1, manual)
        self.assertEqual(list(p1), list(manual))
        self.assertIsNone(get_peer_index({}))

    def test_speedup_report(self):
        rng = np.random.default_rng(3)
        peers = _scene(rng, 1500)
        egos = [_ego(rng, peers) for _ in range(400)]

        def bundle(mod_gap, mod_q, mod_form):
            for ego in egos:
                mod_form(ego, peers)
                mod_q(ego.get("edge"), peers, 4, ego.get("approach_edges"), include_rolling=True)
                for lane in (0, 2):
                    mod_gap(ego, peers, lane, True)
                    mod_gap(ego, peers, lane, False)
                    mod_gap(ego, peers, lane, True)
                    mod_gap(ego, peers, lane, False)

        t0 = time.perf_counter()
        bundle(REF._nearest_gap_on_lane, REF.lane_queue_counts, REF_PM.enrich_formation_state)
        t_ref = time.perf_counter() - t0
        t0 = time.perf_counter()
        bundle(CSB._nearest_gap_on_lane, CSB.lane_queue_counts, PM.enrich_formation_state)
        t_new = time.perf_counter() - t0
        print(f"\n[v5.2 perf] 1500 vehicles x 400 lateral agents, one step: v5.1 {t_ref:.2f}s -> v5.2 {t_new:.2f}s "
              f"(x{t_ref / max(t_new, 1e-9):.1f})")
        self.assertLess(t_new, t_ref)


class TestRewardV2(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with open(os.path.join(ROOT, "tests", "_golden_lon_reward_v1.json"), encoding="utf-8") as fh:
            cls.g = json.load(fh)

    def _rf(self, version):
        from reward.longitudinal_reward import LongitudinalReward
        old = os.environ.get("LON_REWARD_VERSION")
        os.environ["LON_REWARD_VERSION"] = version
        try:
            return LongitudinalReward()
        finally:
            if old is None:
                os.environ.pop("LON_REWARD_VERSION", None)
            else:
                os.environ["LON_REWARD_VERSION"] = old

    def _total(self, rf, key):
        v, s = self.g["states"][key]
        return rf.compute(v, s)

    def test_v1_unchanged(self):
        rf = self._rf("v1")
        for key, (tot, comps) in self.g["v1"].items():
            t, c = self._total(rf, key)
            self.assertAlmostEqual(t, tot, places=7, msg=key)
            for k, val in comps.items():
                self.assertAlmostEqual(c[k], val, places=7, msg=f"{key}.{k}")

    def test_v2_prices_delay_and_gaps(self):
        rf = self._rf("v2")
        tot = {k: self._total(rf, k)[0] for k in self.g["states"]}
        self.assertTrue(all(v <= 0.0 for v in tot.values()), tot)
        self.assertGreater(tot["cruise_free"], tot["queued_red_gap1"])          # v1 had the opposite order
        self.assertGreater(tot["queued_red_gap1"], tot["queued_red_gap5"])      # wasted queue storage costs
        self.assertGreater(tot["follow_hdv_15s"], tot["follow_hdv_06s"])        # no tailgating HDVs
        self.assertEqual(self._total(rf, "follow_cav_08s")[1]["platoon"], 0.0)  # CACC band behind a CAV
        self.assertLess(self._total(rf, "follow_hdv_06s")[1]["platoon"], 0.0)

    def test_glosa_floor_runtime(self):
        from reward.longitudinal_reward import glosa_min_speed
        os.environ.pop("LON_GLOSA_MIN_SPEED", None)
        self.assertAlmostEqual(glosa_min_speed(), 3.5)
        os.environ["LON_GLOSA_MIN_SPEED"] = "7"
        try:
            self.assertAlmostEqual(glosa_min_speed(), 7.0)
        finally:
            os.environ.pop("LON_GLOSA_MIN_SPEED", None)


if __name__ == "__main__":
    unittest.main()
