"""v5.2.4: control-stack bisection switches, junction-stall diagnostics,
SPaT during synthesized transitions, and the Lon no-op PPO filter.

Run:  python -m unittest tests/test_v524_bisection.py -v
(no SUMO / torch needed: uses the fake traci of test_sumo_interface_offline)
"""
import os
import sys
import types
import unittest

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "tests"))

from test_sumo_interface_offline import TRACI, SI, tc  # noqa: E402
from train.credit_utils import is_lon_noop, lon_agent_vid  # noqa: E402


class _VehicleRecorder:
    """Records traci.vehicle calls."""

    def __init__(self, max_speed=16.67):
        self.calls = []
        self._max = max_speed

    def __getattr__(self, name):
        def _f(*args):
            self.calls.append((name,) + tuple(args))
            if name == "getMaxSpeed":
                return self._max
            return None
        return _f

    def names(self):
        return [c[0] for c in self.calls]


def _env(**switches):
    env = object.__new__(SI.SUMOEnvironment)
    for k in ("LON_NO_FLOORS", "LON_HANDBACK_NEAR_M", "LON_HANDBACK_JUNCTION",
              "LON_ACTUATION", "SPAT_SYNTH_FIX"):
        os.environ.pop(k, None)
    for k, v in switches.items():
        os.environ[k] = str(v)
    env._load_v524_switches()
    for k in switches:
        os.environ.pop(k, None)
    env.step_length = 0.2
    env.MAX_SPEED = 16.67
    env._speed_capped = {}
    env._lon_noop_vids_step = []
    env._jstall_reset()
    env.tls_ids = ["J"]
    return env


class TestSwitchDefaults(unittest.TestCase):
    def test_defaults_are_v523(self):
        env = _env()
        self.assertFalse(env.LON_NO_FLOORS)
        self.assertEqual(env.LON_HANDBACK_NEAR_M, 0.0)
        self.assertFalse(env.LON_HANDBACK_JUNCTION)
        self.assertEqual(env.LON_ACTUATION, "accel")
        self.assertTrue(env.SPAT_SYNTH_FIX)
        self.assertEqual(env._lon_handback_reason(True, -1.0), "")
        self.assertEqual(env._lon_handback_reason(False, 5.0), "")

    def test_handback_near_and_junction(self):
        env = _env(LON_HANDBACK_NEAR_M=20)
        self.assertEqual(env._lon_handback_reason(True, None), "junction")
        self.assertEqual(env._lon_handback_reason(False, 19.9), "near_stopline")
        self.assertEqual(env._lon_handback_reason(False, 0.0), "near_stopline")
        self.assertEqual(env._lon_handback_reason(False, 20.0), "")
        self.assertEqual(env._lon_handback_reason(False, -3.0), "")      # past the line
        self.assertEqual(env._lon_handback_reason(False, None), "")
        env = _env(LON_HANDBACK_JUNCTION=1)
        self.assertEqual(env._lon_handback_reason(True, None), "junction")
        self.assertEqual(env._lon_handback_reason(False, 5.0), "")

    def test_bad_values_fall_back(self):
        env = _env(LON_HANDBACK_NEAR_M="abc", LON_ACTUATION="weird")
        self.assertEqual(env.LON_HANDBACK_NEAR_M, 0.0)
        self.assertEqual(env.LON_ACTUATION, "accel")


class TestActuation(unittest.TestCase):
    def setUp(self):
        self._old = getattr(TRACI, "vehicle", None)
        self.rec = _VehicleRecorder()
        TRACI.vehicle = self.rec

    def tearDown(self):
        TRACI.vehicle = self._old

    def test_accel_mode_is_setacceleration(self):
        env = _env()
        env._actuate_cav("c1", -1.0, 0.5, 10.0)
        self.assertEqual(self.rec.calls, [("setAcceleration", "c1", -1.0, 0.2)])

    def test_speed_mode_caps_only_when_braking_below_idm(self):
        env = _env(LON_ACTUATION="speed")
        env._actuate_cav("c1", -1.0, 0.5, 10.0)           # brake below IDM -> cap 9.8
        self.assertIn(("setSpeed", "c1", -1), self.rec.calls)
        self.assertIn(("setMaxSpeed", "c1", 9.8), self.rec.calls)
        self.assertNotIn("setAcceleration", self.rec.names())
        self.rec.calls.clear()
        env._actuate_cav("c1", -1.0, 0.5, 10.0)           # same cap -> no redundant call
        self.assertEqual(self.rec.calls, [])
        env._actuate_cav("c1", 0.8, 0.5, 10.0)            # wants >= IDM -> restore max
        self.assertEqual(self.rec.calls, [("setMaxSpeed", "c1", 16.67)])
        self.rec.calls.clear()
        env._actuate_cav("c2", -4.0, 0.0, 0.1)            # never below the floor
        self.assertIn(("setMaxSpeed", "c2", env.SPEED_ADV_MIN_MS), self.rec.calls)

    def test_release_restores_max_speed(self):
        env = _env(LON_ACTUATION="speed")
        env._actuate_cav("c1", -1.0, 0.5, 10.0)
        self.rec.calls.clear()
        env._release_cav_to_sumo("c1")
        self.assertEqual(
            self.rec.calls,
            [("setSpeedMode", "c1", 31), ("setSpeed", "c1", -1), ("setMaxSpeed", "c1", 16.67)],
        )
        self.assertNotIn("c1", env._speed_capped)

    def test_note_handback_marks_noop(self):
        env = _env()
        applied, shield = {}, {}
        env._note_handback("c9", "idm_follower", applied, shield)
        env._jstall["lon_exec"] += 3
        self.assertEqual(env._lon_noop_vids_step, ["c9"])
        self.assertEqual(applied["c9"], 0.0)
        st = env.jstall_stats()
        self.assertAlmostEqual(st["lon_noop_frac"], 0.25)
        self.assertEqual(st["lon_handback_idm_follower"], 1.0)
        self.assertEqual(st["lon_handback_near_stopline"], 0.0)


class TestJunctionStall(unittest.TestCase):
    def test_internal_lane_parse(self):
        f = SI.SUMOEnvironment._junction_of_internal_lane
        self.assertEqual(f(":cluster_1_2_3_11_0"), "cluster_1_2_3")
        self.assertEqual(f(":J_3_0"), "J")
        self.assertEqual(f("edge_0"), "")
        self.assertEqual(f(None), "")

    def test_accumulate_and_events(self):
        env = _env()
        env._sig_junction_ids = {"J"}

        def v(lane, speed, vtype):
            return {tc.VAR_LANE_ID: lane, tc.VAR_SPEED: speed, tc.VAR_TYPE: vtype}

        env.sub_results = {
            "c_ctrl": v(":J_1_0", 0.0, "CAV"),
            "c_free": v(":J_2_0", 0.05, "CAV_SW"),
            "h": v(":J_3_0", 0.0, "HDV"),
            "moving": v(":J_4_0", 5.0, "CAV"),
            "unsig": v(":K_1_0", 0.0, "HDV"),
            "road": v("e1_0", 0.0, "CAV"),
        }
        for k in range(60):                      # 60 x 0.2 s = 12 s standstill
            env._jstall_accumulate({"c_ctrl"}, 300.0 + 0.2 * k)
        st = env.jstall_stats()
        self.assertAlmostEqual(st["jstall_sig_ctrl_cav_s"], 12.0, places=6)
        self.assertAlmostEqual(st["jstall_sig_free_cav_s"], 12.0, places=6)
        self.assertAlmostEqual(st["jstall_sig_hdv_s"], 12.0, places=6)
        self.assertAlmostEqual(st["jstall_unsig_s"], 12.0, places=6)
        self.assertEqual(st["jstall_ctrl_cav_events"], 1.0)    # counted once per vehicle
        self.assertEqual(st["jstall_free_cav_events"], 1.0)
        self.assertEqual(st["jstall_hdv_events"], 1.0)

    def test_standstill_clock_resets_when_moving(self):
        env = _env()
        env._sig_junction_ids = {"J"}
        stopped = {"c": {tc.VAR_LANE_ID: ":J_1_0", tc.VAR_SPEED: 0.0, tc.VAR_TYPE: "CAV"}}
        moving = {"c": {tc.VAR_LANE_ID: ":J_1_0", tc.VAR_SPEED: 3.0, tc.VAR_TYPE: "CAV"}}
        t = 0.0
        for seq in (stopped, moving, stopped):
            env.sub_results = seq
            for _ in range(30):                  # 6 s each, never 10 s continuous
                env._jstall_accumulate({"c"}, t)
                t += 0.2
        self.assertEqual(env.jstall_stats()["jstall_ctrl_cav_events"], 0.0)


class _Ph:
    def __init__(self, state, duration):
        self.state, self.duration = state, duration


class TestSynthSpat(unittest.TestCase):
    """Program: G0 (link0 green) / y / G1 (link1 green) / y / G2 (link2 green) / y."""

    def _env(self, fix):
        env = _env(SPAT_SYNTH_FIX=int(fix))
        env.YELLOW_DURATION, env.ALL_RED_DURATION = 3.0, 2.0
        env.signal_programs = {"J": [
            _Ph("Grr", 30.0), _Ph("yrr", 3.0),
            _Ph("rGr", 20.0), _Ph("ryr", 3.0),
            _Ph("rrG", 25.0), _Ph("rry", 3.0),
        ]}
        env._signals = {}
        return env

    def test_synth_remaining(self):
        env = self._env(True)
        self.assertAlmostEqual(env._synth_remaining({"mode": "yellow", "started_at": 100.0}, 101.0), 4.0)
        self.assertAlmostEqual(env._synth_remaining({"mode": "allred", "started_at": 100.0}, 101.5), 0.5)

    def test_next_green_known_during_transition(self):
        # Jump G0 -> G2 (skipping G1). 1 s into yellow: 4 s of transition left.
        info = {"phase": 0, "remaining_time": 4.0, "synth_next": 4}
        env = self._env(True)
        self.assertAlmostEqual(env._time_to_green("J", 2, "r", info), 4.0)      # link2 gets green next
        self.assertAlmostEqual(env._time_to_green("J", 1, "r", info), 4.0 + 25 + 3 + 30 + 3)
        # v5.2.3 behaviour walks from the OLD green: link2 looked 26 s away.
        old = self._env(False)
        self.assertAlmostEqual(old._time_to_green("J", 2, "r", info), 4.0 + 3 + 20 + 3)

    def test_phase_index_zero_is_valid_next_green(self):
        info = {"phase": 4, "remaining_time": 2.0, "synth_next": 0}
        self.assertAlmostEqual(self._env(True)._time_to_green("J", 0, "r", info), 2.0)

    def test_no_transition_unchanged(self):
        info = {"phase": 0, "remaining_time": 10.0, "synth_next": -1}
        a = self._env(True)._time_to_green("J", 1, "r", info)
        b = self._env(False)._time_to_green("J", 1, "r", info)
        self.assertAlmostEqual(a, b)
        self.assertAlmostEqual(a, 10.0 + 3.0)


class TestNoopFilter(unittest.TestCase):
    def test_vid_parse(self):
        self.assertEqual(lon_agent_vid("cav_lon_12"), "12")
        self.assertEqual(lon_agent_vid("cav_7__dup1"), "7__dup1")

    def test_is_lon_noop(self):
        steps = [frozenset({"12"}), frozenset(), None]
        self.assertTrue(is_lon_noop(steps, 0, "cav_lon_12"))
        self.assertFalse(is_lon_noop(steps, 0, "cav_lon_13"))
        self.assertFalse(is_lon_noop(steps, 1, "cav_lon_12"))
        self.assertFalse(is_lon_noop(steps, 2, "cav_lon_12"))
        self.assertFalse(is_lon_noop(steps, 9, "cav_lon_12"))       # out of range
        self.assertFalse(is_lon_noop(None, 0, "cav_lon_12"))        # --keep-lon-noop-samples


class TestWiring(unittest.TestCase):
    """Source-level checks that the switches are actually wired into step()/train."""

    @classmethod
    def setUpClass(cls):
        with open(os.path.join(ROOT, "environment", "SUMO_interface.py"), encoding="utf-8") as f:
            cls.si = f.read()
        with open(os.path.join(ROOT, "train", "train_RL.py"), encoding="utf-8") as f:
            cls.tr = f.read()
        with open(os.path.join(ROOT, "environment", "marl_env.py"), encoding="utf-8") as f:
            cls.me = f.read()

    def test_step_uses_helpers(self):
        self.assertEqual(self.si.count("traci.vehicle.setAcceleration("), 1)   # only in _actuate_cav
        self.assertIn("self._actuate_cav(vid, accel, a_idm, current_speed)", self.si)
        self.assertEqual(self.si.count("_floors_on"), 5)                       # def + 4 floors
        for reason in ("native_idm", "idm_follower"):
            self.assertIn(f'vid, "{reason}", applied_cav_actions', self.si)
        self.assertIn("'lon_noop_vids': list(self._lon_noop_vids_step)", self.si)

    def test_train_and_env_plumbing(self):
        self.assertIn("is_lon_noop(_noop_steps, step_idx, agent_id)", self.tr)
        self.assertIn("rollout.setdefault('lon_noop_vids', []).append(", self.tr)
        for flag in ("--lon-no-floors", "--lon-handback-near-m", "--lon-handback-junction",
                     "--lon-actuation", "--spat-synth-fix", "--keep-lon-noop-samples"):
            self.assertIn(flag, self.tr)
        self.assertIn('"lon_noop_vids": list(env_info.get("lon_noop_vids") or ())', self.me)
        self.assertIn("if str(vid) in lon_noop:", self.me)


class TestRewardDefault(unittest.TestCase):
    def test_module_default_is_v2(self):
        from reward.longitudinal_reward import lon_reward_version
        old = os.environ.pop("LON_REWARD_VERSION", None)
        try:
            self.assertEqual(lon_reward_version(), "v2")
            os.environ["LON_REWARD_VERSION"] = "v1"
            self.assertEqual(lon_reward_version(), "v1")
        finally:
            os.environ.pop("LON_REWARD_VERSION", None)
            if old is not None:
                os.environ["LON_REWARD_VERSION"] = old


if __name__ == "__main__":
    unittest.main()
