"""v6-P1 mechanism tests. No SUMO and no training loop."""
import os
import unittest

import numpy as np

from environment.p1_control import (
    LaneChangeLedger,
    accel_for_target_speed,
    commitment_action_mask,
    target_speed_from_action,
)
from reward.lateral_reward import LateralReward
from train.credit_utils import step_deltas


class TestTargetSpeed(unittest.TestCase):
    def test_bounds(self):
        self.assertAlmostEqual(target_speed_from_action(-2.2, 10.0), 0.0)
        self.assertAlmostEqual(target_speed_from_action(1.0, 10.0), 10.0)

    def test_accel_sign(self):
        # raw = 1 requests the speed limit, so a slow vehicle is told to accelerate.
        self.assertGreater(accel_for_target_speed(1.0, 2.0, 10.0), 0.0)
        self.assertLess(accel_for_target_speed(-2.2, 8.0, 10.0), 0.0)


class TestCommitment(unittest.TestCase):
    def test_phases(self):
        early = commitment_action_mask(4, 1, elapsed=2.0, gmin=6.0, gmax=40.0, next_g=2, is_green=True)
        self.assertEqual(list(early), [0, 1, 0, 0])
        mid = commitment_action_mask(4, 1, elapsed=10.0, gmin=6.0, gmax=40.0, next_g=2, is_green=True)
        self.assertEqual(list(mid), [0, 1, 1, 0])
        late = commitment_action_mask(4, 1, elapsed=40.0, gmin=6.0, gmax=40.0, next_g=2, is_green=True)
        self.assertEqual(list(late), [0, 0, 1, 0])


class TestIndividualCredit(unittest.TestCase):
    def test_own_reward_only(self):
        entries = [("a", "N", 1.0, 1.0), ("b", "S", 3.0, 9.0)]
        self.assertEqual(step_deltas(entries, mode="individual"), {"a": 1.0, "b": 3.0})


class TestLaneChangeOutcome(unittest.TestCase):
    def test_faster_change_is_negative_delta(self):
        book = LaneChangeLedger(delay_s=15.0)
        book.observe("v", 0.0, "e_0", 100.0, 5.0, 0.0)
        book.observe("v", 1.0, "e_1", 95.0, 8.0, 2.0)
        out = book.observe("v", 16.0, "e_1", 20.0, 8.0, 0.0)
        # Covered 80 m in 15 s; the old 5 m/s would have needed 16 s.
        self.assertAlmostEqual(out["p1_tt_delta"], 15.0 - 80.0 / 5.0)
        self.assertLess(out["p1_mobil"], 0.0)

    def test_reward_uses_measured_delta(self):
        reward, comps = LateralReward().compute(
            {"zone_type": "platoon", "speed": 8.0, "dist_to_stopline": 80.0, "lane": "e_1"},
            0,
            meta={"p1_tt_delta": -4.0, "p1_mobil": -0.4, "current_lane_queue": 1.0},
        )
        self.assertGreater(comps["eff_lc"], 0.0)
        self.assertAlmostEqual(comps["net_ext"], -0.4)
        self.assertTrue(np.isfinite(reward))


class TestProfile(unittest.TestCase):
    def test_v6p1_extends_p0(self):
        import ast
        root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
        path = os.path.join(root, "train", "train_RL.py")
        tree = ast.parse(open(path, encoding="utf-8").read())
        keep = []
        for node in tree.body:
            if isinstance(node, ast.Assign) and any(
                isinstance(t, ast.Name) and t.id in ("V6P0_PROFILE", "V6P1_PROFILE", "LANDABLE_PROFILE")
                for t in node.targets
            ):
                keep.append(node)
            elif isinstance(node, ast.FunctionDef) and node.name in ("_flag_given", "apply_profile"):
                keep.append(node)
        ns = {}
        exec(compile(ast.Module(body=keep, type_ignores=[]), path, "exec"), ns)
        args = type("A", (), {})()
        for key, value in {
            "profile": "v6p1",
            "lon_no_floors": False,
            "lon_handback_near_m": 0.0,
            "lon_actuation": "accel",
            "lon_rl_max_dist_m": 300.0,
            "lon_rl_min_dist_m": 0.0,
            "lon_rl_in_junction": True,
            "gap_policy": "legacy",
            "signal_reward_sat": 1.0,
            "lon_imitation_scale": 0.1,
            "cacc_ppo_authority_min": 0.2,
            "lon_action_mode": "residual",
            "cav_action_interval": 0.4,
            "gamma_seconds": None,
            "cav_credit_mode": "coop_xapp",
            "cross_approach_baseline": True,
            "individual_critic": False,
            "signal_commitment": False,
            "p1_obs_on_decision": False,
            "p1_lat_delayed": False,
        }.items():
            setattr(args, key, value)
        ns["apply_profile"](args, ["--profile", "v6p1"])
        self.assertEqual(args.lon_action_mode, "target_speed")
        self.assertEqual(args.cav_action_interval, 1.0)
        self.assertAlmostEqual(args.gamma_seconds, 0.98)
        self.assertEqual(args.cav_credit_mode, "individual")
        self.assertFalse(args.cross_approach_baseline)
        self.assertTrue(args.individual_critic)
        self.assertTrue(args.signal_commitment)
        self.assertEqual(args.lon_rl_min_dist_m, 20.0)
        self.assertFalse(args.lon_rl_in_junction)


if __name__ == "__main__":
    unittest.main()
