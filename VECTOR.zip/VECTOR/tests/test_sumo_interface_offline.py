"""Offline tests of v4 SUMO_interface logic with a FAKE traci (no SUMO needed).

Run:  python -m unittest tests/test_sumo_interface_offline.py -v
"""
import os
import sys
import tempfile
import types
import unittest

import numpy as np

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, ROOT)


def _install_fake_traci():
    if "traci" in sys.modules and getattr(sys.modules["traci"], "_vector_fake", False):
        return sys.modules["traci"]
    os.environ.setdefault("SUMO_HOME", tempfile.mkdtemp())
    os.environ["USE_LIBSUMO"] = "0"
    tc = types.ModuleType("traci.constants")
    for i, name in enumerate(["VAR_LANE_ID", "VAR_SPEED", "VAR_ACCUMULATED_WAITING_TIME", "VAR_ROAD_ID",
                              "VAR_NEXT_TLS", "VAR_LANEPOSITION", "VAR_POSITION", "VAR_ANGLE",
                              "VAR_ACCELERATION", "VAR_TYPE", "VAR_LENGTH", "VAR_LEADER",
                              "VAR_NEXT_LINKS", "VAR_SPEED_WITHOUT_TRACI", "VAR_FUELCONSUMPTION",
                              "VAR_CO2EMISSION", "VAR_ROUTE_INDEX", "VAR_LANE_INDEX"]):
        setattr(tc, name, 0x40 + i)
    tc.INVALID_DOUBLE_VALUE = -1073741824.0
    tc.INVALID_INT_VALUE = -1073741824
    tc.__getattr__ = lambda name: 0x7F  # any other TraCI constant
    tr = types.ModuleType("traci")
    tr._vector_fake = True
    tr.constants = tc
    tr.simulation = types.SimpleNamespace(getPendingVehicles=lambda: ["p1", "p2"], getTime=lambda: 0.0)
    tr.__getattr__ = lambda name: types.SimpleNamespace()
    sys.modules["traci"] = tr
    sys.modules["traci.constants"] = tc
    sl = types.ModuleType("sumolib"); mu = types.ModuleType("sumolib.miscutils")
    mu.getFreeSocketPort = lambda: 12345
    sl.miscutils = mu
    sys.modules["sumolib"] = sl; sys.modules["sumolib.miscutils"] = mu
    return tr


TRACI = _install_fake_traci()
from environment import SUMO_interface as SI  # noqa: E402
tc = sys.modules["traci.constants"]


def _veh(lane, speed, dist, wait=0.0):
    return {tc.VAR_LANE_ID: lane, tc.VAR_ROAD_ID: lane.rsplit("_", 1)[0], tc.VAR_SPEED: speed,
            tc.VAR_ACCUMULATED_WAITING_TIME: wait, tc.VAR_NEXT_TLS: [("J", 0, dist, "r")],
            tc.VAR_LANEPOSITION: 0.0}


def _env():
    env = object.__new__(SI.SUMOEnvironment)
    env._approach_cardinal, env._approach_chains = {}, {}
    env._phase_incoming_lanes = {"J": {0: ["e1_0", "e1_1"], 1: ["e2_0"]}}
    env._permissive_only_lanes = {"J": ["e3_0"]}
    env.INCLUDE_PERMISSIVE_LANES = True
    env.QUEUE_MODE, env.QUEUE_HALT_SPEED_MS = "halted", 0.5
    env.GREEN_ARRIVAL_AWARE, env.GREEN_ARRIVAL_K, env.GREEN_ARRIVAL_WINDOW_S = True, 2.0, 10.0
    env.GREEN_DURATION_K = 0.35
    env._last_green_T, env._last_green_lv, env._last_green_index, env._last_green_arr = {}, {}, {}, {}
    env._min_green_for = lambda t, g: 10.0
    env._max_green_for = lambda t, g: 40.0
    env.platoon_tracker = None
    env._lane_index_cache = (None, None, None)
    env.sub_results = {
        "h1": _veh("e1_0", 0.0, 2.0, 30.0), "h2": _veh("e1_0", 0.2, 9.0, 20.0), "h3": _veh("e1_0", 0.1, 16.0, 10.0),
        "m1": _veh("e1_0", 10.0, 60.0), "m2": _veh("e1_0", 10.0, 300.0),          # m1 ETA 6 s, m2 ETA 30 s
        "p1": _veh("e1_1", 12.0, 50.0), "p2": _veh("e1_1", 12.0, 70.0), "p3": _veh("e1_1", 12.0, 90.0),
        "q1": _veh("e3_0", 0.0, 3.0, 50.0),
    }
    return env


class TestQueueAndGreen(unittest.TestCase):
    def test_halted_queue_ignores_moving_platoon(self):
        env = _env()
        self.assertAlmostEqual(env._queue_length_for_lane("e1_0"), 3 * 7.5)
        self.assertAlmostEqual(env._queue_length_for_lane("e1_1"), 0.0)  # moving platoon != queue

    def test_permissive_lane_in_reward_set(self):
        q = _env()._approach_lane_queue_lengths_m("J")
        self.assertIn("e3_0", q)
        self.assertAlmostEqual(q["e3_0"], 7.5)

    def test_arrival_aware_green(self):
        env = _env()
        self.assertEqual(env._arrivals_for_green("J", 0), 3)   # e1_1: three vehicles ETA<=10 s
        T = env._compute_green_duration("J", 0)
        self.assertAlmostEqual(T, min(40.0, 10.0 + 0.35 * 22.5 + 2.0 * 3))

    def test_waits_and_near_count(self):
        env = _env()
        self.assertAlmostEqual(env._max_wait_for_green("J", 0), 30.0)
        self.assertEqual(env._near_count_for_green("J", 0, horizon_m=100.0), 7)

    def test_lane_index_cache_rebuilds_on_new_dict(self):
        env = _env()
        a = env._lane_vehicle_index()
        self.assertIs(a, env._lane_vehicle_index())
        env.sub_results = dict(env.sub_results)
        self.assertIsNot(a, env._lane_vehicle_index())


class TestTimeInSystem(unittest.TestCase):
    def test_tis(self):
        env = _env()
        env._scheduled_depart = {"a": 0.0, "b": 100.0, "c": 400.0}
        env._warmup_arrived = {"a"}
        env._tis_init(300.0)
        env._tis_release(450.0)
        env._tis_on_arrival("b", 350.0)
        self.assertAlmostEqual(env._tis_value(500.0), (50.0 + 100.0) / 2.0)
        self.assertEqual(env._insertion_backlog(), 2)


class TestRuntimeOptions(unittest.TestCase):
    def test_options_and_randomized_route(self):
        from environment.demand_randomizer import DemandRandomizer
        tmp = tempfile.mkdtemp()
        base = os.path.join(tmp, "b.rou.xml")
        with open(base, "w", encoding="utf-8") as fh:
            fh.write('<routes><vType id="HDV"/>' + "".join(
                f'<trip id="t{i}" type="HDV" depart="{i}.0" from="a" to="b"/>' for i in range(50)) + "</routes>")
        env = _env()
        env.route_file = base
        env.max_depart_delay = -1.0
        env.collision_check_junctions = True
        env.demand_randomizer = DemandRandomizer(True, 5.0, 0.9, 1.1, out_dir=os.path.join(tmp, "o"))
        opts = env._runtime_sumo_options(7)
        self.assertEqual(opts[:4], ["--max-depart-delay", "100000", "--collision.check-junctions", "true"])
        self.assertIn("--route-files", opts)
        self.assertGreater(len(env._scheduled_depart), 30)

    def test_configure_control_v4(self):
        env = _env()
        env.allow_deadlock_retarget = True
        env.configure_control(queue_mode="legacy", allow_od_rewrite=False, demand_randomize=True,
                              demand_jitter_s=30.0, control_keep_lane_hdv=True)
        self.assertEqual(env.QUEUE_MODE, "legacy")
        self.assertFalse(env.allow_deadlock_retarget)
        self.assertTrue(env.demand_randomizer.enabled)
        self.assertTrue(env.CONTROL_ZONE_KEEP_LANE_HDV)
        env.configure_control(eval_mode=True)
        self.assertFalse(env.demand_randomizer.enabled)


if __name__ == "__main__":
    unittest.main()


class TestSignalMaskContract(unittest.TestCase):
    """v5.1: actions legal in the observed mask are executed as chosen."""

    def _clamp_env(self, starving=False):
        env = object.__new__(SI.SUMOEnvironment)
        env._green_phase_indices = lambda t: [0, 3, 6]
        env._green_index_of_phase = lambda t, p: {0: 0, 3: 1, 6: 2}.get(int(p), 0)
        env._planned_green_for = lambda t, g: 30.0
        env._phase_kind = lambda t, p: "green"
        env._min_green_for = lambda t, g: 10.0
        env._starve_may_force = lambda *a: bool(starving)
        env._starving_green_phase = lambda t, g: 1
        env._fallback_switch_index = lambda t, g, n: (g + 1) % n
        env.SIGNAL_MASK_CONTRACT = True
        env._last_signal_mask = {}
        return env

    def _mask(self, env, phase, legal):
        m = np.zeros(3, dtype=np.float32)
        m[list(legal)] = 1.0
        env._last_signal_mask["J"] = (phase, m)

    def test_starvation_set_choice_is_kept(self):
        env = self._clamp_env(starving=True)
        self._mask(env, 0, [1, 2])
        self.assertEqual(env._clamp_signal_action("J", 2, 0, 20.0), 2)   # v4 forced phase 1

    def test_keep_across_T_boundary_is_kept(self):
        env = self._clamp_env()
        self._mask(env, 0, [0, 1, 2])
        self.assertEqual(env._clamp_signal_action("J", 0, 0, 30.1), 0)   # v4 forced a switch

    def test_illegal_action_falls_back_to_rules(self):
        env = self._clamp_env()
        self._mask(env, 0, [1, 2])
        self.assertEqual(env._clamp_signal_action("J", 0, 0, 30.1), 1)

    def test_phase_mismatch_uses_rules(self):
        env = self._clamp_env(starving=True)
        self._mask(env, 3, [0, 1, 2])
        self.assertEqual(env._clamp_signal_action("J", 2, 0, 20.0), 1)

    def test_min_green_always_first(self):
        env = self._clamp_env()
        self._mask(env, 0, [0, 1, 2])
        self.assertEqual(env._clamp_signal_action("J", 2, 0, 5.0), 0)

    def test_contract_off_restores_v4(self):
        env = self._clamp_env(starving=True)
        env.SIGNAL_MASK_CONTRACT = False
        self._mask(env, 0, [1, 2])
        self.assertEqual(env._clamp_signal_action("J", 2, 0, 20.0), 1)

    def test_runtime_options_diag_and_override(self):
        tmp = tempfile.mkdtemp()
        env = _env()
        env.route_file = None
        env.sumocfg_file = os.path.join(tmp, "none.sumocfg")
        env.max_depart_delay, env.collision_check_junctions = -1.0, True
        env.demand_randomizer = None
        env.sumo_diag_dir = os.path.join(tmp, "diag")
        opts = env._runtime_sumo_options(5)
        self.assertIn("--collision-output", opts)
        self.assertEqual(opts[opts.index("--no-warnings") + 1], "false")
        self.assertEqual(len(opts) % 2, 0)
