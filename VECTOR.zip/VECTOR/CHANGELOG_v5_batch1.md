# CHANGELOG v4 → v5（批次 1：正确性与基础设施）

总体方案与实施状态见 `docs/OPTIMIZATION_PLAN_v5.md`；逐行差异见 `docs/v4_to_v5_batch1.diff`。
本批次没有改变优化目标、奖励或网络结构；只有 Full 排程的默认值变了，所以 v5 需要从头训练，结果不能与 v4 的 Full 直接对比。

## 1.1 信号"采样动作 = 执行动作"
- `environment/SUMO_interface.py`：在 `_clamp_signal_action` 之后，记录每个路口"请求相位 → 实际执行相位"。
- `environment/marl_env.py`：通过 `info['__all__']['signal_exec']` 返回这份记录。
- `train/train_RL.py`：
  - 比对采样相位与执行相位，被替换的样本记入 `rollout['signal_overridden']`，在 `merge_and_update` 中不参与 PPO；
  - TensorBoard 新增 `Signal/override_rate`，超过 1% 时打印警告。
- 掩码与钳位规则的逐条对齐：先看实测覆盖率再决定是否需要。覆盖率接近 0 就不改，以免引入新风险。

## 1.2 独立评估
- `train/train_RL.py --eval-only`：
  - 加载 `--eval-checkpoint`，按 `--eval-stage` 配置阶段（默认取检查点自带的阶段）；
  - 使用确定性动作，`eval_mode`（禁止 OD 改写）；
  - 在 `--eval-seeds` 上逐回合写出 CSV（`--eval-out`）；
  - 输出目录的方法名自动加 `__eval`，不会触碰训练目录；
  - 结束后直接退出，不执行训练收尾。
- 环境构建与逐步的动作逻辑与训练完全相同；`control_kwargs` 已抽成 `_build_control_kwargs`，训练与评估共用。
- `--eval-demand-randomize`：使用由评估种子生成的留出需求实例。
- `scripts/evaluate_policy.py`：并行调度"检查点 × 种子"，汇总均值与 95% 置信区间，按碰撞门限在验证集上选出最佳模型。
- `baselines/experiment_seeds.py`：新增 `VALIDATION_SEEDS`（900001–900010）和 `TEST_SEEDS`（990001–990010），与训练种子不相交。

## 1.3 信号批量累积更新
- `agents/signal_buffer.py` 与 `agents/mappo.py`：信号 actor 的样本跨 flush 累积，满 `--signal-min-batch`（默认 128；设为 0 即恢复 v4）才更新一次，跑满全部 epoch。
- 换阶段时清空缓冲区。
- 延迟更新的 flush 上，教师相关统计记为 0，属于正常现象。

## 1.4 排程
- Full 默认值改为 850 回合：

  | 阶段 | Stage-S | Lon | JointLonSig | Lat 主体 | JointAll |
  |---|---|---|---|---|---|
  | 回合数 | 250 | 180 | 0 | 250 | 170（退火 120） |

  Quick 保持 480 不变。
- `training.schedule.{full,quick}` 可覆盖排程，带一致性校验（见 `config.yaml` 中的注释示例）。
- `tools/calibrate_schedule.py`：读取 `episode_metrics.npz`，给出各阶段的平台期和建议长度。
- `num_envs > 1` 时打印提示：固定窗口按迭代计数。

## 1.5 选优分数（开关）
- `--select-score legacy|tis`，默认 `legacy`，行为不变。`tis` 用 −avg_time_in_system/60。
- 联合阶段的中止逻辑仍使用 legacy 分数，因为它的阈值是按这个单位标定的。

## 1.6 小修
- 纵向观测中的 VLM 残差特征改为除以 0.05，与实际残差系数一致。
- `--gamma-seconds`：按秒定义折扣，默认不启用。
- 插入积压超过 100 辆或单回合传送超过 20 次时打印告警（针对 4-leg 的 `HDV_SW` 车辆）。

## 用法
```bash
# 在验证集上评估并选模型（-- 之后的参数必须与训练时一致）
python scripts/evaluate_policy.py --checkpoints "<run>/checkpoints/best_*.pt" \
    --seeds validation --workers 4 --max-collisions 0.5 --out-dir results/eval/<run>_val -- \
    --sumocfg "environment/sumo_net/4-leg(4phases)/4-leg(4phases).sumocfg" --no-vision
# 在测试集上报告选中的模型
python scripts/evaluate_policy.py --checkpoints <best.pt> --seeds test --out-dir results/eval/<run>_test -- ...
# 用已有训练曲线估计各阶段平台期
python tools/calibrate_schedule.py <run>/episode_metrics.npz --boundaries "S:250,Lon:300,Lat:300,JointAll:150"
```

## 验证
- 33 项离线测试全部通过：v4 原有 21 项 + 本批新增 12 项。
- `tools/static_check.py` 报告 0 个问题。
- 需要 SUMO 或 torch 的路径（评估回合、信号执行记录、批量更新）请按冒烟测试的方法验证。
