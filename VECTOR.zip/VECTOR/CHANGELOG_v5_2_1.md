# CHANGELOG v5.2 → v5.2.1（诊断补丁，控制与奖励逐位不变）

依据：v5.2 消融 A1–A5。

## 1. 红灯间距诊断拆分（只观测）
旧的 `[Diag-RedGap]` 把三类样本混在一起：
- 真正的静止排队间距；
- 排头车：前车已越过停车线，"间距"是到路口对面那辆车的距离（VAR_LEADER 前视 100 m）；
- 仍在低速蠕行（<1.5 m/s）的车。

新增一行 `[Diag-RedGap2]`（TB：`Diag/RedGap2_*`）：
- `QUEUE`：自车与前车都慢、前车仍在停车线上游 → 真正占用排队空间的间距；
- `creep`：QUEUE 样本中自车仍以 ≥0.1 m/s 行驶且间距 >2.8 m 的比例；
- `HEAD n`：排头车样本数（前车已过线）。
旧行保留不变；注意旧行的 `gt4.5` 实际阈值是 2.8 m（IDLE_LEADER_EXEMPT_M）。

## 2. 消融 A0：`--ablate-cav-native-idm`
Lon/Lat/Joint 中本应由控制栈驾驶的 CAV 交还 SUMO 原生 IDM（与 Stage-S 相同），
记录零残差以保持 rollout 结构。用于与 A1 在同一需求种子上配对比较。

## 3. VehFuel 指标
逐车平均油耗跳过窗口内行驶不足 50 m 的车辆（此前怠速车给出上千 L/100km，
例如 A2 JointAll ep7 的 1286 L/100km）。FleetFuel 不受影响。旧日志的 VehFuel 不可与新值直接比较。
