"""Pure-numpy advantage helpers (unit-tested without torch / SUMO).

VECTOR v4 optimization: SMDP (option-level) lambda placement.
"""
from __future__ import annotations

import numpy as np


def smdp_gae(rewards, values, dones, next_value=0.0, gamma=0.99, gae_lambda=0.95,
             decision_mask=None):
    """GAE with lambda applied only at option boundaries.

    ``decision_mask[t]`` is True when step ``t`` starts a real decision (option).
    Steps between two decisions are hold steps of the same option. Inside an
    option the recursion propagates pure discount ``gamma`` (an n-step return
    over the option); the ``lambda`` contraction is applied when step ``t+1``
    starts the next decision. This equals option-level GAE exactly:

        A(t0) = sum_{k<tau} gamma^k delta_{t0+k} + gamma^tau * lambda * A(t0+tau)

    v3 applied lambda at the decision step itself (one step too early), which
    scaled every intra-option TD error by lambda. With ``decision_mask=None`` this
    function reduces to standard per-step GAE(gamma, lambda).

    Returns ``(returns, advantages)`` as float32 arrays.
    """
    r = np.asarray(rewards, dtype=np.float64).reshape(-1)
    v = np.asarray(values, dtype=np.float64).reshape(-1)
    d = np.asarray(dones, dtype=np.float64).reshape(-1)
    n = int(r.shape[0])
    if not (v.shape[0] == n and d.shape[0] == n):
        raise ValueError("smdp_gae expects rewards, values and dones of equal length")
    if not (np.isfinite(r).all() and np.isfinite(v).all() and np.isfinite(d).all()):
        raise ValueError("smdp_gae received non-finite rollout data")
    gamma = float(gamma)
    lam = float(gae_lambda)
    dec = None
    if decision_mask is not None:
        dm = np.asarray(decision_mask, dtype=bool).reshape(-1)
        if dm.shape[0] == n:
            dec = dm
    adv = np.zeros(n, dtype=np.float64)
    gae = 0.0
    try:
        following = float(next_value)
    except (TypeError, ValueError, OverflowError):
        following = 0.0
    if not np.isfinite(following):
        following = 0.0
    for t in range(n - 1, -1, -1):
        not_done = 1.0 - d[t]
        delta = r[t] + gamma * following * not_done - v[t]
        if dec is None:
            lam_t = lam
        else:
            lam_t = lam if (t + 1 >= n or bool(dec[t + 1])) else 1.0
        gae = delta + gamma * lam_t * not_done * gae
        adv[t] = gae
        following = v[t]
    ret = adv + v
    return ret.astype(np.float32), adv.astype(np.float32)
