"""Facade for CAV lateral policy (discrete lane change)."""
from models.lateral_actor import LateralActor


def build_lateral_actor(obs_dim, hidden_dim=128):
    return LateralActor(obs_dim, action_dim=3, hidden_dim=hidden_dim)
