"""Facade for traffic-signal discrete policy."""
from models.signal_network import SignalActor


def build_signal_actor(obs_dim, action_dim=5, hidden_dim=128):
    return SignalActor(obs_dim, action_dim=action_dim, hidden_dim=hidden_dim)
