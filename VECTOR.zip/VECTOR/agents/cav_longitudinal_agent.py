"""Facade for CAV longitudinal policy (IDM-residual delta or absolute accel)."""
from __future__ import annotations

import os
from typing import Optional

from models.longitudinal_actor import LongitudinalActor

# Symmetric magnitude kept for backward-compatible imports; asymmetric bounds
# retain full -2.2 m/s^2 eco-glide braking authority while capping positive
# surge above SUMO IDM at +1.0 m/s^2 so RL cannot overpower safety braking.
RESIDUAL_ACCEL_BOUND = 2.2
RESIDUAL_ACCEL_LOW = -2.2
RESIDUAL_ACCEL_HIGH = 1.0
ABSOLUTE_ACCEL_LOW = -4.0
ABSOLUTE_ACCEL_HIGH = 2.8


def lon_residual_idm_default() -> bool:
    raw = os.environ.get("LON_RESIDUAL_IDM", "1")
    return str(raw).strip().lower() not in ("0", "false", "no", "off")


def build_longitudinal_actor(
    obs_dim: int,
    hidden_dim: int = 128,
    action_low: Optional[float] = None,
    action_high: Optional[float] = None,
    *,
    residual_idm: Optional[bool] = None,
) -> LongitudinalActor:
    """Build longitudinal actor.

    When ``residual_idm`` is True (default), policy outputs ``delta_a`` in
    ``[-2.2, +1.0]`` m/s^2 centered at neutral ``0.0`` m/s^2 on top of SUMO's
    IDM baseline acceleration so entering Stage-Lon causes zero car-following
    shock and prevents aggressive positive lunge collisions.
    """
    use_res = lon_residual_idm_default() if residual_idm is None else bool(residual_idm)
    if action_low is None:
        action_low = RESIDUAL_ACCEL_LOW if use_res else ABSOLUTE_ACCEL_LOW
    if action_high is None:
        action_high = RESIDUAL_ACCEL_HIGH if use_res else ABSOLUTE_ACCEL_HIGH
    return LongitudinalActor(
        obs_dim,
        action_dim=1,
        hidden_dim=hidden_dim,
        action_low=float(action_low),
        action_high=float(action_high),
    )
