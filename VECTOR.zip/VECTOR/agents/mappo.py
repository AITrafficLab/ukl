"""MAPPO with hierarchical CAV: Signal + Lateral + Longitudinal (no residual)."""
from __future__ import annotations

import copy
import math

import numpy as np

from agents.gae_utils import smdp_gae
from agents.signal_buffer import SIGNAL_SAMPLE_KEYS, SignalSampleBuffer
import torch
import torch.multiprocessing as mp
import torch.nn.functional as F
import torch.optim as optim
from torch.distributions import Categorical
from torch_geometric.data import Batch, Data

# Stage-S signal GAE: longer effective horizon across 10 s decision gaps.
SIGNAL_GAE_GAMMA = 0.998
SIGNAL_GAE_LAMBDA = 0.98
TEACHER_CONFIDENCE_THRESHOLD = 0.60

# Curriculum order including late weak joint fine-tunes.
CURRICULUM_STAGES = ("S", "Lon", "JointLonSig", "Lat", "JointAll")
JOINT_STAGES = frozenset(("JointLonSig", "JointAll"))
# Relative LR for weakly-unfrozen heads (vs active actor_lr * episode scale).
DEFAULT_JOINT_SIGNAL_LR_SCALE = 0.08
DEFAULT_JOINT_LON_LR_SCALE = 1.0
DEFAULT_JOINT_ALL_SIGNAL_LR_SCALE = 0.05
DEFAULT_JOINT_ALL_LON_LR_SCALE = 0.10
DEFAULT_JOINT_ALL_LAT_LR_SCALE = 1.0
# Keep joint phase exploration low; BC/KL anchors + temperature sharpening prevent random phase cuts.
DEFAULT_JOINT_SIGNAL_ENTROPY_SCALE = 0.20
DEFAULT_JOINT_SIGNAL_ADV_SCALE = 0.5
DEFAULT_JOINT_SIGNAL_TEMPERATURE = 0.65
DEFAULT_ANCHOR_BC_SIGNAL = 0.50
DEFAULT_ANCHOR_BC_LON = 0.25
DEFAULT_ANCHOR_BC_LAT = 0.25

# mp.set_start_method("spawn") belongs in train_RL main — not at import time.


class MAPPOAgent:
    """CTDE MAPPO: S → Lon → JointLonSig → Lat → JointAll."""

    def __init__(
        self,
        lon_actor=None,
        lat_actor=None,
        signal_actor=None,
        critic=None,
        # Legacy kwargs accepted for older call sites
        cav_actor=None,
        cav_residual_actor=None,
        actor_lr=3e-4,
        critic_lr=1e-4,
        gamma=0.99,
        gae_lambda=0.95,
        clip_param=0.2,
        ppo_epochs=4,
        minibatch_size=256,
        entropy_coef=0.01,
        device="cpu",
        delta_max=1.5,
        coop_on=False,
        lambda_mode="fixed",
        target_kl=0.02,
        max_grad_norm=0.5,
    ):
        del cav_residual_actor, delta_max, coop_on, lambda_mode
        self.device = torch.device(device) if not isinstance(device, torch.device) else device
        self.lon_actor = lon_actor if lon_actor is not None else cav_actor
        self.lat_actor = lat_actor
        self.signal_actor = signal_actor
        self.critic = critic
        # Legacy alias
        self.cav_actor = self.lon_actor
        self.cav_residual_actor = None
        self.actor_lr = float(actor_lr)
        self.critic_lr = float(critic_lr)

        self.lon_optimizer = (
            optim.Adam(self.lon_actor.parameters(), lr=self.actor_lr) if self.lon_actor else None
        )
        self.cav_optimizer = self.lon_optimizer
        self.cav_residual_optimizer = None
        self.lat_optimizer = (
            optim.Adam(self.lat_actor.parameters(), lr=self.actor_lr) if self.lat_actor else None
        )
        self.signal_optimizer = (
            optim.Adam(self.signal_actor.parameters(), lr=self.actor_lr) if self.signal_actor else None
        )
        self.critic_optimizer = (
            optim.Adam(self.critic.parameters(), lr=self.critic_lr) if self.critic else None
        )
        self.gamma = float(gamma)
        self.gae_lambda = float(gae_lambda)
        self.clip_param = float(clip_param)
        self.ppo_epochs = max(1, int(ppo_epochs))
        # Schulman-style non-negative approximate-KL early stop.
        try:
            target_kl = float(target_kl)
        except (TypeError, ValueError, OverflowError):
            target_kl = 0.02
        self.TARGET_KL = target_kl if np.isfinite(target_kl) and target_kl > 0.0 else 0.02
        try:
            max_grad_norm = float(max_grad_norm)
        except (TypeError, ValueError, OverflowError):
            max_grad_norm = 0.5
        self.max_grad_norm = (
            max_grad_norm if np.isfinite(max_grad_norm) and max_grad_norm > 0.0 else 0.5
        )
        self._last_approx_kl = 0.0
        self._force_signal_one_epoch = False
        self.minibatch_size = max(1, int(minibatch_size))
        self.entropy_coef = float(entropy_coef)
        self.training_stage = "S"
        # Lon/Lat staggered soft-start: Lon β∈[0.3,1], Lat β∈[0.5,1] via train_RL.
        self.action_blend_beta = 1.0
        # Soft-start / shield imitation toward executed accel (set by train_RL).
        self.imitation_coef = 0.0
        # Ablation gates (set by train_RL): when False, never train that head.
        self.enable_lateral = True
        self.enable_longitudinal = True
        # Running return stats for dual-head critic:
        #   - _ret_rms_* tracks team/CAV returns (gamma=0.99; resets on stage switch)
        #   - _sig_ret_rms_* tracks pure signal returns (gamma=0.998; continuous across stages)
        self._ret_rms_mean = 0.0
        self._ret_rms_var = 1.0
        self._ret_rms_count = 1e-4
        self._sig_ret_rms_mean = 0.0
        self._sig_ret_rms_var = 1.0
        self._sig_ret_rms_count = 1e-4
        # VLM-teacher aux loss weight for Stage-S (set by train_RL each episode).
        self.teacher_beta = 0.0
        self.signal_teacher_beta = 0.0  # alias kept for older callers / TB
        self.teacher_conf_threshold = float(TEACHER_CONFIDENCE_THRESHOLD)
        self._last_teacher_stats = {
            "valid_samples": 0,
            "teacher_valid_samples": 0.0,
            "teacher_loss": 0.0,
            "teacher_beta": 0.0,
            "teacher_severity_mean": 0.0,
            "agreement_rate": 0.0,
            "teacher_agreement_rate": 0.0,
            "entropy": 0.0,
            "signal_entropy": 0.0,
            "grad_norm": 0.0,
            "signal_grad_norm": 0.0,
        }
        # Late joint fine-tune knobs (train_RL may override).
        self.joint_signal_lr_scale = float(DEFAULT_JOINT_SIGNAL_LR_SCALE)
        self.joint_lon_lr_scale = float(DEFAULT_JOINT_LON_LR_SCALE)
        self.joint_all_signal_lr_scale = float(DEFAULT_JOINT_ALL_SIGNAL_LR_SCALE)
        self.joint_all_lon_lr_scale = float(DEFAULT_JOINT_ALL_LON_LR_SCALE)
        self.joint_all_lat_lr_scale = float(DEFAULT_JOINT_ALL_LAT_LR_SCALE)
        self.joint_signal_entropy_scale = float(DEFAULT_JOINT_SIGNAL_ENTROPY_SCALE)
        self.joint_signal_adv_scale = float(DEFAULT_JOINT_SIGNAL_ADV_SCALE)
        self.anchor_bc_coef_signal = float(DEFAULT_ANCHOR_BC_SIGNAL)
        self.anchor_bc_coef_lon = float(DEFAULT_ANCHOR_BC_LON)
        self.anchor_bc_coef_lat = float(DEFAULT_ANCHOR_BC_LAT)
        # Frozen policy anchors for BC/KL during joint stages.
        self._anchor_signal = None
        self._anchor_lon = None
        self._anchor_lat = None
        # KPI abort: re-freeze signal (and weak heads) for the rest of the joint block.
        self.joint_abort = False
        # Co-optimization flags (wired from experiments/config.yaml & CLI):
        self.freeze_team_critic_in_stage_s = True
        self.cross_approach_baseline = True
        self.cacc_soft_platoon_enabled = True
        self.cacc_rl_authority_floor = 0.25
        self.cacc_ppo_authority_min = 0.20

    @staticmethod
    def _normalize_stage(stage):
        """Map to S / Lon / JointLonSig / Lat / JointAll."""
        if stage in (1, "1", "S", "s", "stage-s", "STAGE-S"):
            return "S"
        if stage in (
            "Lon", "lon", "stage-lon", "STAGE-LON",
            "L2", "l2", "stage-l2", "STAGE-L2",
            2, "2", "V1", "v1", "stage-v1", "STAGE-V1",
        ):
            return "Lon"
        if stage in (
            "JointLonSig", "jointlonsig", "joint_lon_sig", "JOINT_LON_SIG",
            "JLS", "jls", "joint-lon-sig",
        ):
            return "JointLonSig"
        if stage in (
            "JointAll", "jointall", "joint_all", "JOINT_ALL",
            "JA", "ja", "joint-all",
        ):
            return "JointAll"
        if stage in (
            "Lat", "lat", "stage-lat", "STAGE-LAT",
            "L1", "l1", "stage-l1", "STAGE-L1",
            3, "3", "V2", "v2", "stage-v2", "STAGE-V2",
            "T", "t", "Transition", "TRANSITION", "transition",
            "stage-transition", "STAGE-TRANSITION",
        ):
            return "Lat"
        key = str(stage).strip().upper().replace("-", "").replace("_", "")
        aliases = {
            "S": "S", "STAGES": "S", "SIGNAL": "S",
            "LON": "Lon", "STAGELON": "Lon", "L2": "Lon", "STAGEL2": "Lon",
            "V1": "Lon", "STAGEV1": "Lon",
            "JOINTLONSIG": "JointLonSig", "JLS": "JointLonSig",
            "JOINTALL": "JointAll", "JA": "JointAll",
            "LAT": "Lat", "STAGELAT": "Lat", "L1": "Lat", "STAGEL1": "Lat",
            "V2": "Lat", "STAGEV2": "Lat", "TRANSITION": "Lat", "T": "Lat",
        }
        if key in aliases:
            return aliases[key]
        raise ValueError(f"Invalid training stage: {stage}")

    @staticmethod
    def is_joint_stage(stage) -> bool:
        try:
            return MAPPOAgent._normalize_stage(stage) in JOINT_STAGES
        except (TypeError, ValueError):
            return False

    @staticmethod
    def cav_env_stage(stage) -> str:
        """Map training stage → env control mode (S / Lon / Lat)."""
        st = MAPPOAgent._normalize_stage(stage)
        if st in ("Lon", "JointLonSig"):
            return "Lon"
        if st in ("Lat", "JointAll"):
            return "Lat"
        return "S"

    @staticmethod
    def eval_stage(stage) -> str:
        """Checkpoint / eval stage: joint maps to last pure CAV stage."""
        st = MAPPOAgent._normalize_stage(stage)
        if st == "JointLonSig":
            return "Lon"
        if st == "JointAll":
            return "Lat"
        return st

    @staticmethod
    def stage_train_flags(stage, enable_lon=True, enable_lat=True, joint_abort=False):
        """Which actor heads train under ``stage`` (respects joint abort)."""
        st = MAPPOAgent._normalize_stage(stage)
        enable_lon = bool(enable_lon)
        enable_lat = bool(enable_lat)
        if joint_abort and st == "JointLonSig":
            # Abort → lon-only (signal re-frozen), like pure Lon.
            return {"signal": False, "lon": enable_lon, "lat": False}
        if joint_abort and st == "JointAll":
            # Abort → lat-only (lon/signal re-frozen).
            return {"signal": False, "lon": False, "lat": enable_lat}
        if st == "S":
            return {"signal": True, "lon": False, "lat": False}
        if st == "Lon":
            return {"signal": False, "lon": enable_lon, "lat": False}
        if st == "JointLonSig":
            return {"signal": True, "lon": enable_lon, "lat": False}
        if st == "Lat":
            return {"signal": False, "lon": False, "lat": enable_lat}
        if st == "JointAll":
            return {"signal": True, "lon": enable_lon, "lat": enable_lat}
        return {"signal": False, "lon": False, "lat": False}

    def clear_policy_anchors(self):
        self._anchor_signal = None
        self._anchor_lon = None
        self._anchor_lat = None

    def set_policy_anchors(self, signal_state=None, lon_state=None, lat_state=None):
        """Freeze-copy actors used as BC/KL anchors during joint fine-tune."""

        def _clone(module, state):
            if module is None or state is None:
                return None
            twin = copy.deepcopy(module)
            twin.load_state_dict(state)
            twin.to(self.device)
            twin.eval()
            for p in twin.parameters():
                p.requires_grad = False
            return twin

        if signal_state is not None:
            self._anchor_signal = _clone(self.signal_actor, signal_state)
        if lon_state is not None:
            self._anchor_lon = _clone(self.lon_actor, lon_state)
        if lat_state is not None:
            self._anchor_lat = _clone(self.lat_actor, lat_state)

    def set_training_stage(self, stage, coop_on=None, lambda_mode=None):
        del coop_on, lambda_mode
        stage = self._normalize_stage(stage)
        prev = getattr(self, "training_stage", None)
        self.training_stage = stage
        if stage not in JOINT_STAGES:
            self.joint_abort = False
            self.clear_policy_anchors()

        flags = self.stage_train_flags(
            stage,
            enable_lon=bool(getattr(self, "enable_longitudinal", True)),
            enable_lat=bool(getattr(self, "enable_lateral", True)),
            joint_abort=bool(getattr(self, "joint_abort", False)),
        )
        train_signal = bool(flags["signal"])
        train_lat = bool(flags["lat"])
        train_lon = bool(flags["lon"])
        train_critic = True

        def _set_req(module, flag):
            if module is None:
                return
            for p in module.parameters():
                p.requires_grad = flag

        _set_req(self.signal_actor, train_signal)
        _set_req(self.lat_actor, train_lat)
        _set_req(self.lon_actor, train_lon)
        _set_req(self.critic, train_critic)
        if (
            self.critic is not None
            and hasattr(self.critic, "net")
            and hasattr(self.critic, "signal_head")
        ):
            freeze_team_s = bool(getattr(self, "freeze_team_critic_in_stage_s", True))
            if stage == "S" and freeze_team_s:
                _set_req(self.critic.net, False)
                _set_req(self.critic.signal_head, True)
            elif prev == "S" and stage != "S" and freeze_team_s:
                self.reset_team_value_head()

        # Base LRs; apply_active_actor_lr_scale applies episode scale + joint ratios.
        self.apply_active_actor_lr_scale(1.0)
        if self.critic_optimizer:
            for g in self.critic_optimizer.param_groups:
                g["lr"] = self.critic_lr if train_critic else 0.0

        if prev != stage:
            # Preserve team return RMS when entering a same-reward-scale joint stage
            # (Lon -> JointLonSig and Lat -> JointAll share identical team reward scales);
            # resetting to (0, 1) caused uncalibrated advantages during the 15-ep grace window!
            same_team_scale = (
                (prev == "Lon" and stage == "JointLonSig")
                or (prev == "Lat" and stage == "JointAll")
                or (prev == "JointLonSig" and stage == "Lon")
                or (prev == "JointAll" and stage == "Lat")
            )
            if prev is not None and not same_team_scale:
                self._ret_rms_mean = 0.0
                self._ret_rms_var = 1.0
                self._ret_rms_count = 1e-4
            # Clear stale Adam first/second moments on newly activated actor heads.
            active_heads = [h for h, f in (("signal", train_signal), ("lon", train_lon), ("lat", train_lat)) if f]
            self.reset_actor_optimizer_states(heads=active_heads)
            print(
                f"[MAPPO] Enter stage {stage} "
                f"(signal={train_signal}, lat={train_lat}, lon={train_lon}, "
                f"critic={train_critic}, keep_rms={same_team_scale}, "
                f"joint_abort={bool(self.joint_abort)})"
            )

    def reset_actor_optimizer_states(self, heads=None):
        """Clear Adam exp_avg / exp_avg_sq buffers after weight rollback or head unfreeze."""
        target = set(heads or ("signal", "lon", "lat"))
        mapping = (
            ("signal", self.signal_optimizer),
            ("lon", self.lon_optimizer),
            ("lat", self.lat_optimizer),
        )
        for name, opt in mapping:
            if name in target and opt is not None:
                opt.state.clear()

    def _effective_signal_logits(self, raw_logits: torch.Tensor) -> torch.Tensor:
        """Apply low-temperature sharpening to legal signal logits during joint fine-tuning.

        Shared identically by ``select_actions`` and ``_update_signal_actor`` so Epoch-0
        importance ratios remain exact 1.0 while suppressing accidental low-probability
        early phase cuts that disrupt CAV GLOSA / green-wave platoons.
        """
        if self.training_stage not in JOINT_STAGES:
            return raw_logits
        temp = float(
            getattr(self, "joint_signal_temperature", DEFAULT_JOINT_SIGNAL_TEMPERATURE)
            or DEFAULT_JOINT_SIGNAL_TEMPERATURE
        )
        if not np.isfinite(temp) or temp <= 0.05 or abs(temp - 1.0) < 1e-4:
            return raw_logits
        neg_huge = torch.finfo(raw_logits.dtype).min / 4.0
        legal = raw_logits > neg_huge
        scaled = raw_logits / float(temp)
        return torch.where(legal, scaled, raw_logits)

    def apply_active_actor_lr_scale(self, scale: float):
        """Scale active-stage actor LRs; inactive stay at 0.

        Joint stages use small relative LR for weakly-unfrozen heads.
        """
        try:
            scale = float(scale)
        except (TypeError, ValueError, OverflowError):
            scale = 0.0
        scale = max(0.0, scale) if np.isfinite(scale) else 0.0
        stage = str(getattr(self, "training_stage", "S") or "S")
        base = float(self.actor_lr)
        flags = self.stage_train_flags(
            stage,
            enable_lon=bool(getattr(self, "enable_longitudinal", True)),
            enable_lat=bool(getattr(self, "enable_lateral", True)),
            joint_abort=bool(getattr(self, "joint_abort", False)),
        )

        def _rel(head: str) -> float:
            if stage == "JointLonSig":
                if head == "signal":
                    return float(getattr(self, "joint_signal_lr_scale", DEFAULT_JOINT_SIGNAL_LR_SCALE))
                if head == "lon":
                    return float(getattr(self, "joint_lon_lr_scale", DEFAULT_JOINT_LON_LR_SCALE))
            if stage == "JointAll":
                if head == "signal":
                    return float(
                        getattr(self, "joint_all_signal_lr_scale", DEFAULT_JOINT_ALL_SIGNAL_LR_SCALE)
                    )
                if head == "lon":
                    return float(
                        getattr(self, "joint_all_lon_lr_scale", DEFAULT_JOINT_ALL_LON_LR_SCALE)
                    )
                if head == "lat":
                    return float(
                        getattr(self, "joint_all_lat_lr_scale", DEFAULT_JOINT_ALL_LAT_LR_SCALE)
                    )
            return 1.0

        if self.signal_optimizer:
            for g in self.signal_optimizer.param_groups:
                g["lr"] = (base * scale * _rel("signal")) if flags["signal"] else 0.0
        if self.lat_optimizer:
            for g in self.lat_optimizer.param_groups:
                g["lr"] = (base * scale * _rel("lat")) if flags["lat"] else 0.0
        if self.lon_optimizer:
            for g in self.lon_optimizer.param_groups:
                g["lr"] = (base * scale * _rel("lon")) if flags["lon"] else 0.0

    def _single_observation(self, obs):
        result = {
            "vector": torch.as_tensor(obs["vector"], dtype=torch.float32, device=self.device).unsqueeze(0),
            "graph": {
                "node_features": torch.as_tensor(
                    obs["graph"]["node_features"], dtype=torch.float32, device=self.device
                ),
                "edge_index": torch.as_tensor(
                    obs["graph"]["edge_index"], dtype=torch.long, device=self.device
                ),
            },
        }
        if "action_mask" in obs:
            result["action_mask"] = torch.as_tensor(
                obs["action_mask"], dtype=torch.float32, device=self.device
            ).unsqueeze(0)
        return result

    @staticmethod
    def _to_graph_data(graph):
        return Data(
            x=torch.as_tensor(graph["node_features"], dtype=torch.float32),
            edge_index=torch.as_tensor(graph["edge_index"], dtype=torch.long),
        )

    def _batch_graphs(self, graphs):
        graph_batch = Batch.from_data_list([self._to_graph_data(g) for g in graphs]).to(self.device)
        # Clip unnormalized physics (e.g. pressure ~390) so one congested
        # rollout cannot explode the critic (was: Loss/critic up to 1.8e9).
        x = torch.nan_to_num(graph_batch.x, nan=0.0, posinf=10.0, neginf=-10.0)
        x = torch.clamp(x, -10.0, 10.0)
        return {
            "node_features": x,
            "edge_index": graph_batch.edge_index,
            "batch_index": graph_batch.batch,
        }

    def _batch_observations(self, observations, need_graph=False):
        if len(observations) == 0:
            raise ValueError("_batch_observations requires at least one observation")
        vector_array = np.stack([obs["vector"] for obs in observations]).astype(
            np.float32, copy=False
        )
        vector_array = np.nan_to_num(
            vector_array, nan=0.0, posinf=10.0, neginf=-10.0
        )
        vectors = torch.as_tensor(
            vector_array, dtype=torch.float32, device=self.device
        )
        vectors = torch.clamp(vectors, -10.0, 10.0)
        result = {"vector": vectors}
        # v4 perf: actors never read the graph; v3 built a PyG batch for every
        # actor forward and minibatch. Critic paths batch graphs directly.
        if need_graph or bool(getattr(self, "actor_needs_graph", False)):
            result["graph"] = self._batch_graphs([obs["graph"] for obs in observations])
        if all("action_mask" in obs for obs in observations):
            mask_array = np.stack([obs["action_mask"] for obs in observations]).astype(
                np.float32, copy=False
            )
            mask_array = np.nan_to_num(
                mask_array, nan=0.0, posinf=0.0, neginf=0.0
            )
            result["action_mask"] = torch.as_tensor(
                mask_array, dtype=torch.float32, device=self.device
            )
        return result

    def select_actions(
        self,
        obs_dict,
        deterministic=False,
        *,
        cav_decision=True,
        cav_action_cache=None,
        cav_logp_cache=None,
    ):
        """Sample actions; on CAV hold ticks skip cached lon/lat actor forwards.

        Signal + full CAV sample when ``cav_decision`` is True (default).
        On hold steps (``cav_decision=False``):
          - lon/legacy: forward only agents missing from ``cav_action_cache``;
            cached ids are injected so env rewards stay continuous
          - lat: discrete keep (1), no lat_actor forward
          - signal: always sampled
        Critic ``get_value`` is separate and must still run every sim step.
        """
        actions = {}
        log_probs = {}
        lon_ids = [aid for aid in obs_dict if aid.startswith("cav_lon_")]
        lat_ids = [aid for aid in obs_dict if aid.startswith("cav_lat_")]
        # Legacy cav_ without suffix → lon
        legacy = [
            aid
            for aid in obs_dict
            if aid.startswith("cav_") and not aid.startswith("cav_lon_") and not aid.startswith("cav_lat_")
        ]
        signal_ids = [aid for aid in obs_dict if aid.startswith("signal_")]
        stage = self.training_stage
        cache_a = cav_action_cache if isinstance(cav_action_cache, dict) else {}
        cache_lp = cav_logp_cache if isinstance(cav_logp_cache, dict) else {}
        # Frozen heads must not keep exploring: stochastic TLS in Lon (esp. with
        # healthy Stage-S entropy) causes unpredictable phase cuts → rear-ends.
        flags = self.stage_train_flags(
            stage,
            enable_lon=bool(getattr(self, "enable_longitudinal", True)),
            enable_lat=bool(getattr(self, "enable_lateral", True)),
            joint_abort=bool(getattr(self, "joint_abort", False)),
        )
        det_signal = bool(deterministic) or (not bool(flags.get("signal", False)))
        det_lon = bool(deterministic) or (not bool(flags.get("lon", False)))
        det_lat = bool(deterministic) or (not bool(flags.get("lat", False)))

        with torch.no_grad():
            env_st = self.cav_env_stage(stage)
            emit_lon = env_st in ("Lon", "Lat") and bool(
                getattr(self, "enable_longitudinal", True)
            )
            emit_lat = env_st == "Lat" and bool(getattr(self, "enable_lateral", True))

            if self.lon_actor and (lon_ids or legacy) and emit_lon:
                ids = lon_ids or legacy
                if cav_decision:
                    to_sample = list(ids)
                else:
                    to_sample = [aid for aid in ids if aid not in cache_a]
                    for agent_id in ids:
                        if agent_id not in cache_a:
                            continue
                        actions[agent_id] = cache_a[agent_id]
                        if agent_id in cache_lp:
                            log_probs[agent_id] = cache_lp[agent_id]
                if to_sample:
                    batch_obs = self._batch_observations(
                        [obs_dict[aid] for aid in to_sample]
                    )
                    action_tensor, log_prob_tensor = self.lon_actor.get_action(
                        batch_obs, deterministic=det_lon
                    )
                    action_np = action_tensor.cpu().numpy()
                    log_np = log_prob_tensor.cpu().numpy()
                    for index, agent_id in enumerate(to_sample):
                        actions[agent_id] = action_np[index]
                        log_probs[agent_id] = float(log_np[index])

            if self.lat_actor and lat_ids and emit_lat:
                if cav_decision:
                    batch_obs = self._batch_observations(
                        [obs_dict[aid] for aid in lat_ids]
                    )
                    beta = float(getattr(self, "action_blend_beta", 1.0) or 1.0)
                    eff_beta = float(np.clip(beta, 0.0, 1.0)) if stage == "Lat" else 1.0
                    if hasattr(self.lat_actor, "get_action"):
                        action_tensor, log_prob_tensor = self.lat_actor.get_action(
                            batch_obs,
                            deterministic=det_lat,
                            soft_start_beta=eff_beta,
                        )
                    else:
                        logits = self.lat_actor(batch_obs)
                        dist = Categorical(logits=logits)
                        action_tensor = (
                            torch.argmax(logits, dim=-1) if det_lat else dist.sample()
                        )
                        log_prob_tensor = dist.log_prob(action_tensor)
                    action_np = action_tensor.detach().cpu().numpy()
                    log_np = log_prob_tensor.detach().cpu().numpy()
                    for index, agent_id in enumerate(lat_ids):
                        actions[agent_id] = int(action_np[index])
                        log_probs[agent_id] = float(log_np[index])
                else:
                    # Hold tick: execute keep-lane; PPO labels are None upstream.
                    for agent_id in lat_ids:
                        actions[agent_id] = 1

            if self.signal_actor and signal_ids:
                batch_obs = self._batch_observations([obs_dict[aid] for aid in signal_ids])
                logits = self._effective_signal_logits(self.signal_actor(batch_obs))
                dist = Categorical(logits=logits)
                action_tensor = (
                    torch.argmax(logits, dim=-1) if det_signal else dist.sample()
                )
                log_prob_tensor = dist.log_prob(action_tensor)
                action_np = action_tensor.detach().cpu().numpy()
                log_np = log_prob_tensor.detach().cpu().numpy()
                for index, agent_id in enumerate(signal_ids):
                    actions[agent_id] = int(action_np[index])
                    log_probs[agent_id] = float(log_np[index])

        return actions, log_probs

    def reset_team_value_head(self) -> None:
        """Reset ``critic.net`` and team return RMS before CAV stages (keep GNN + signal_head)."""
        if self.critic is not None and hasattr(self.critic, "reset_team_head"):
            self.critic.reset_team_head()
            if hasattr(self.critic, "net"):
                for p in self.critic.net.parameters():
                    p.requires_grad = True
        self._ret_rms_mean = 0.0
        self._ret_rms_var = 1.0
        self._ret_rms_count = 1e-4

    def _ret_rms_std(self) -> float:
        return float(math.sqrt(max(float(self._ret_rms_var), 1e-8)))

    def _update_ret_rms(self, returns) -> None:
        """EMA update of running return mean/variance so early stage shocks decay fast."""
        batch = np.asarray(returns, dtype=np.float64).reshape(-1)
        if batch.size == 0 or not np.isfinite(batch).all():
            return
        batch_mean = float(batch.mean())
        batch_var = max(float(batch.var(ddof=0)), 1e-4)
        if float(self._ret_rms_count) <= 1e-3:
            self._ret_rms_mean = batch_mean
            self._ret_rms_var = batch_var
            self._ret_rms_count = float(batch.size)
            return
        _old_mean, _old_std = float(self._ret_rms_mean), float(self._ret_rms_std())
        alpha = 0.15  # ~7-episode memory window; forgets ep-121 transition shock quickly
        delta = batch_mean - float(self._ret_rms_mean)
        self._ret_rms_mean = float((1.0 - alpha) * float(self._ret_rms_mean) + alpha * batch_mean)
        self._ret_rms_var = float(
            max((1.0 - alpha) * float(self._ret_rms_var) + alpha * batch_var + alpha * (1.0 - alpha) * (delta ** 2), 1e-4)
        )
        self._ret_rms_count = float(min(1e6, float(self._ret_rms_count) + float(batch.size)))
        # v4 PopArt: keep raw-scale value predictions invariant to the statistic update.
        self._popart_preserve(
            getattr(getattr(self, "critic", None), "net", None),
            _old_mean, _old_std, float(self._ret_rms_mean), float(self._ret_rms_std()),
        )

    def _popart_preserve(self, head, old_mean, old_std, new_mean, new_std) -> None:
        """PopArt output preservation (van Hasselt et al., 2016).

        Rescale the final Linear of ``head`` so that sigma*y + mu (the raw-scale
        value) is unchanged when (mu, sigma) move. v3 shifted the raw-scale
        values after every flush (EMA alpha=0.15), injecting noise into GAE.
        """
        if not bool(getattr(self, "popart_enabled", True)) or head is None:
            return
        try:
            layer = head[-1] if isinstance(head, torch.nn.Sequential) else head
            if not isinstance(layer, torch.nn.Linear):
                return
            new_std = max(float(new_std), 1e-8)
            scale = float(old_std) / new_std
            shift = (float(old_mean) - float(new_mean)) / new_std
            if not (np.isfinite(scale) and np.isfinite(shift)):
                return
            with torch.no_grad():
                layer.weight.mul_(scale)
                layer.bias.mul_(scale).add_(shift)
        except Exception as exc:
            print(f"[PopArt] skip rescale: {exc}", flush=True)

    def _sig_ret_rms_std(self) -> float:
        return float(math.sqrt(max(float(self._sig_ret_rms_var), 1e-8)))

    def _update_sig_ret_rms(self, signal_returns) -> None:
        """EMA update of signal-head return statistics (gamma=0.998 scale)."""
        batch = np.asarray(signal_returns, dtype=np.float64).reshape(-1)
        if batch.size == 0 or not np.isfinite(batch).all():
            return
        batch_mean = float(batch.mean())
        batch_var = max(float(batch.var(ddof=0)), 1e-4)
        if float(self._sig_ret_rms_count) <= 1e-3:
            self._sig_ret_rms_mean = batch_mean
            self._sig_ret_rms_var = batch_var
            self._sig_ret_rms_count = float(batch.size)
            return
        _old_mean, _old_std = float(self._sig_ret_rms_mean), float(self._sig_ret_rms_std())
        alpha = 0.12
        delta = batch_mean - float(self._sig_ret_rms_mean)
        self._sig_ret_rms_mean = float(
            (1.0 - alpha) * float(self._sig_ret_rms_mean) + alpha * batch_mean
        )
        self._sig_ret_rms_var = float(
            max(
                (1.0 - alpha) * float(self._sig_ret_rms_var)
                + alpha * batch_var
                + alpha * (1.0 - alpha) * (delta ** 2),
                1e-4,
            )
        )
        self._sig_ret_rms_count = float(
            min(1e6, float(self._sig_ret_rms_count) + float(batch.size))
        )
        self._popart_preserve(
            getattr(getattr(self, "critic", None), "signal_head", None),
            _old_mean, _old_std, float(self._sig_ret_rms_mean), float(self._sig_ret_rms_std()),
        )

    def _denormalize_value(self, raw_val: float) -> float:
        return float(raw_val * self._ret_rms_std() + float(self._ret_rms_mean))

    def _denormalize_signal_value(self, raw_sig_val: float) -> float:
        return float(raw_sig_val * self._sig_ret_rms_std() + float(self._sig_ret_rms_mean))

    def get_value(self, global_graph):
        if self.critic is None:
            return 0.0
        graph_data = self._batch_graphs([global_graph])
        with torch.no_grad():
            value = self.critic(graph_data).reshape(-1)
            if value.numel() == 0 or not bool(torch.isfinite(value).all()):
                return 0.0
            raw = float(value[0].detach().cpu().item())
            if not np.isfinite(raw):
                return 0.0
            # Critic is trained in normalized return space; GAE needs raw scale.
            return self._denormalize_value(raw)

    def get_signal_value(self, global_graph):
        if self.critic is None:
            return 0.0
        if not hasattr(self.critic, "forward_signal"):
            return self.get_value(global_graph)
        graph_data = self._batch_graphs([global_graph])
        with torch.no_grad():
            value = self.critic.forward_signal(graph_data).reshape(-1)
            if value.numel() == 0 or not bool(torch.isfinite(value).all()):
                return 0.0
            raw = float(value[0].detach().cpu().item())
            if not np.isfinite(raw):
                return 0.0
            return self._denormalize_signal_value(raw)

    def get_dual_values(self, global_graph):
        """Single-pass GNN evaluation returning (team_value, signal_value) in raw scale."""
        if self.critic is None:
            return 0.0, 0.0
        if not hasattr(self.critic, "forward_dual"):
            vt = self.get_value(global_graph)
            return vt, vt
        graph_data = self._batch_graphs([global_graph])
        with torch.no_grad():
            v_team, v_sig = self.critic.forward_dual(graph_data)
            vt_t = v_team.reshape(-1)
            vs_t = v_sig.reshape(-1)
            vt = (
                self._denormalize_value(float(vt_t[0].detach().cpu().item()))
                if vt_t.numel() > 0 and bool(torch.isfinite(vt_t).all())
                else 0.0
            )
            vs = (
                self._denormalize_signal_value(float(vs_t[0].detach().cpu().item()))
                if vs_t.numel() > 0 and bool(torch.isfinite(vs_t).all())
                else vt
            )
            return vt, vs

    def individual_values(self, obs) -> dict:
        """V(g(s) ⊕ o_i) for each CAV observation. Empty when the head is off."""
        if self.critic is None or not hasattr(self.critic, "forward_individual"):
            return {}
        if not isinstance(obs, dict):
            return {}
        keys, rows = [], []
        for key, item in obs.items():
            if not str(key).startswith("cav_"):
                continue
            vector = (item or {}).get("vector") if isinstance(item, dict) else None
            if vector is None:
                continue
            keys.append(str(key))
            rows.append(np.asarray(vector, dtype=np.float32).reshape(-1))
        if not keys:
            return {}
        graph = obs.get("__graph__")
        if not isinstance(graph, dict):
            graph = {
                "node_features": obs.get("node_features"),
                "edge_index": obs.get("edge_index"),
                "batch_index": obs.get("batch_index"),
            }
        if graph.get("node_features") is None:
            return {}
        graph_data = self._batch_graphs([graph])
        width = max(int(r.size) for r in rows)
        packed = np.zeros((len(rows), width), dtype=np.float32)
        for i, row in enumerate(rows):
            packed[i, : row.size] = row
        with torch.no_grad():
            values = self.critic.forward_individual(graph_data, packed).reshape(-1)
            values = values.detach().cpu().numpy()
        out = {}
        for key, raw in zip(keys, values):
            raw = float(raw)
            out[key] = self._denormalize_value(raw) if np.isfinite(raw) else 0.0
        return out

    def fit_individual(self, samples, max_samples=64) -> float:
        """One regression step of V(g ⊕ o_i) toward per-agent returns."""
        if (
            self.critic is None
            or not getattr(self, "individual_critic", False)
            or not samples
        ):
            return 0.0
        batch = list(samples)[: int(max_samples)]
        vectors = [np.asarray(s[0], dtype=np.float32).reshape(-1) for s in batch]
        targets = [float(s[1]) for s in batch]
        graphs = [s[2] for s in batch]
        width = max(int(v.size) for v in vectors)
        packed = np.zeros((len(vectors), width), dtype=np.float32)
        for i, row in enumerate(vectors):
            packed[i, : row.size] = row
        # One shared graph is enough for a single-intersection rollout.
        graph_data = self._batch_graphs([graphs[0]])
        target = torch.as_tensor(targets, dtype=torch.float32, device=self.device).reshape(-1, 1)
        mean = float(self._ret_rms_mean)
        std = float(self._ret_rms_std())
        target = (target - mean) / max(std, 1e-3)
        self.critic_optimizer.zero_grad()
        pred = self.critic.forward_individual(graph_data, packed)
        loss = torch.mean((pred - target) ** 2)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.critic.parameters(), self.max_grad_norm)
        self.critic_optimizer.step()
        return float(loss.detach().cpu().item())

    def compute_gae(
        self,
        rewards,
        values,
        dones,
        next_value=0.0,
        gamma=None,
        gae_lambda=None,
        decision_mask=None,
    ):
        rewards = np.asarray(rewards, dtype=np.float32).reshape(-1)
        values = np.asarray(values, dtype=np.float32).reshape(-1)
        dones = np.asarray(dones, dtype=np.float32).reshape(-1)
        if not (len(rewards) == len(values) == len(dones)):
            raise ValueError(
                "compute_gae expects rewards, values, and dones with equal lengths"
            )
        if not (np.isfinite(rewards).all() and np.isfinite(values).all() and np.isfinite(dones).all()):
            raise ValueError("compute_gae received non-finite rollout data")
        try:
            gamma = float(self.gamma if gamma is None else gamma)
        except (TypeError, ValueError, OverflowError):
            gamma = float(self.gamma)
        try:
            gae_lambda = float(self.gae_lambda if gae_lambda is None else gae_lambda)
        except (TypeError, ValueError, OverflowError):
            gae_lambda = float(self.gae_lambda)
        if not np.isfinite(gamma) or gamma <= 0.0:
            gamma = float(self.gamma)
        if not np.isfinite(gae_lambda) or gae_lambda <= 0.0:
            gae_lambda = float(self.gae_lambda)
        dec_arr = None
        if decision_mask is not None and len(decision_mask) == len(rewards):
            dec_arr = np.asarray(decision_mask, dtype=bool).reshape(-1)
        # v4: SMDP lambda applied at option boundaries (agents/gae_utils.py,
        # unit-tested). v3 applied lambda at the decision step itself.
        return smdp_gae(
            rewards, values, dones, next_value=next_value, gamma=gamma,
            gae_lambda=gae_lambda, decision_mask=dec_arr,
        )

    def _minibatches(self, size):
        size = max(0, int(size))
        indices = np.random.permutation(size)
        for start in range(0, size, self.minibatch_size):
            yield indices[start : start + self.minibatch_size]

    @staticmethod
    def _pick_rollout(rollouts, *keys):
        """Fetch first non-empty rollout field; safe for ndarray (no truth-value tests)."""
        for key in keys:
            val = rollouts.get(key)
            if val is None:
                continue
            if isinstance(val, np.ndarray) and val.size == 0:
                continue
            if isinstance(val, (list, tuple)) and len(val) == 0:
                continue
            return val
        return []

    @staticmethod
    def _signal_epoch_cap(n_sig, ppo_epochs, force_one=False):
        """Limit PPO epochs on tiny signal flushes to slow entropy collapse."""
        n = int(n_sig)
        epochs = max(1, int(ppo_epochs))
        if force_one or (0 < n < 8):
            return 1
        if 0 < n < 32:
            return min(2, epochs)
        return epochs

    def _dual_clip_loss(self, new_log_probs, old_log_probs, advantages, entropy_term):
        """PPO clip plus Dual-Clip (Ye et al., AAAI 2020) on negative advantages.

        When A < 0 and ratio > 1+eps, min(ratio*A, clip(ratio)*A) selects the
        unclipped term and the surrogate explodes. Cap that side at
        (1+2*eps)*A.
        """
        log_ratio = new_log_probs - old_log_probs
        # Bound only pathological log-ratios to avoid exp overflow; ordinary PPO
        # ratios remain unchanged. This also keeps the KL monitor finite.
        log_ratio = torch.clamp(log_ratio, min=-20.0, max=20.0)
        ratio = torch.exp(log_ratio)
        s1 = ratio * advantages
        s2 = torch.clamp(ratio, 1.0 - self.clip_param, 1.0 + self.clip_param) * advantages
        surr = torch.min(s1, s2)
        # v4: dual-clip c=3 (Ye et al., 2020); v3 used 1+2*eps=1.4, zeroing many gradients.
        dual_clip = max(1.0 + float(self.clip_param) + 1e-3, float(getattr(self, "dual_clip_c", 3.0)))
        surr = torch.where(
            advantages < 0,
            torch.max(surr, dual_clip * advantages),
            surr,
        )
        loss = -surr.mean() - self.entropy_coef * entropy_term
        # Non-negative second-order KL estimator: E[(r - 1) - log(r)].
        approx_kl = float(((ratio - 1.0) - log_ratio).mean().detach().item())
        return loss, approx_kl

    def _train_flags(self):
        return self.stage_train_flags(
            self.training_stage,
            enable_lon=bool(getattr(self, "enable_longitudinal", True)),
            enable_lat=bool(getattr(self, "enable_lateral", True)),
            joint_abort=bool(getattr(self, "joint_abort", False)),
        )

    def _anchor_bc_discrete(self, logits, anchor_module, batch_obs, coef: float):
        """Full-support KL: D_KL(π_anchor(·|s) ‖ π_θ(·|s)) on legal mask only."""
        if anchor_module is None or coef <= 0.0:
            return None
        with torch.no_grad():
            a_logits = anchor_module(batch_obs)
            if not bool(torch.isfinite(a_logits).all()):
                return None
            # Legal support = positions that are not masked to -inf on either side.
            neg_huge = torch.finfo(a_logits.dtype).min / 4.0
            legal = (a_logits > neg_huge) & (logits.detach() > neg_huge)
            if not bool(legal.any()):
                return None
            # Softmax only on legal actions; illegal get zero mass.
            a_masked = a_logits.masked_fill(~legal, float("-inf"))
            p = F.softmax(a_masked, dim=-1)
        q_logits = logits.masked_fill(~legal, float("-inf"))
        log_q = F.log_softmax(q_logits, dim=-1)
        log_q = torch.where(legal, log_q, torch.zeros_like(log_q))
        # Illegal mass is exactly 0; do not multiply it by -inf log_q (0 * inf = nan).
        contrib = p * (torch.log(p.clamp_min(1e-8)) - log_q)
        kl = contrib.sum(dim=-1).mean()
        if not bool(torch.isfinite(kl)):
            return None
        return float(coef) * kl

    def _anchor_bc_continuous(self, batch_obs, batch_actions, coef: float):
        """Bounded Smooth-L1 + latent W2 toward frozen lon anchor (no -logp blow-up)."""
        del batch_actions  # unused; anchor provides its own targets
        if self._anchor_lon is None or coef <= 0.0 or self.lon_actor is None:
            return None
        if not hasattr(self.lon_actor, "anchor_loss"):
            return None
        try:
            bc = self.lon_actor.anchor_loss(batch_obs, self._anchor_lon)
        except Exception:
            return None
        if bc is None or not bool(torch.isfinite(bc)):
            return None
        return float(coef) * bc

    @staticmethod
    def _filter_zero_dof_discrete(observations, actions, old_log_probs, advantages):
        """Drop samples whose action_mask has ≤1 legal action (zero freedom)."""
        keep = []
        for i, obs in enumerate(observations):
            mask = None
            if isinstance(obs, dict):
                mask = obs.get("action_mask")
            if mask is None:
                keep.append(i)
                continue
            m = np.asarray(mask, dtype=np.float32).reshape(-1)
            if int(np.sum(m > 0)) <= 1:
                continue
            keep.append(i)
        if not keep:
            return [], np.zeros(0, dtype=actions.dtype), np.zeros(0, dtype=np.float32), np.zeros(0, dtype=np.float32)
        if len(keep) == len(observations):
            return observations, actions, old_log_probs, advantages
        idx = np.asarray(keep, dtype=np.int64)
        return (
            [observations[i] for i in idx],
            actions[idx],
            old_log_probs[idx],
            advantages[idx],
        )

    def _update_lon_actor(self, rollouts):
        self._last_approx_kl = 0.0
        if (
            not self._train_flags()["lon"]
            or self.lon_actor is None
            or self.lon_optimizer is None
        ):
            return 0.0

        observations = self._pick_rollout(rollouts, "lon_obs", "cav_obs")
        if len(observations) == 0:
            return 0.0
        actions = np.asarray(
            self._pick_rollout(rollouts, "lon_actions", "cav_actions"), dtype=np.float32
        ).reshape(-1, 1)
        old_log_probs = np.asarray(
            self._pick_rollout(rollouts, "lon_log_probs", "cav_log_probs"), dtype=np.float32
        ).reshape(-1)
        sample_advantages = np.asarray(
            self._pick_rollout(rollouts, "lon_ind_advantages", "ind_advantages"),
            dtype=np.float32,
        ).reshape(-1)
        n = len(observations)
        if not (len(actions) == len(old_log_probs) == len(sample_advantages) == n):
            return 0.0
        if not (
            np.isfinite(actions).all()
            and np.isfinite(old_log_probs).all()
            and np.isfinite(sample_advantages).all()
        ):
            return 0.0

        bc_coef = (
            float(getattr(self, "anchor_bc_coef_lon", 0.0) or 0.0)
            if self.training_stage in JOINT_STAGES and self._anchor_lon is not None
            else 0.0
        )
        losses = []
        for batch_indices in self._minibatches(n):
            batch_obs = self._batch_observations([observations[i] for i in batch_indices])
            batch_actions = torch.as_tensor(actions[batch_indices], dtype=torch.float32, device=self.device)
            batch_old_logs = torch.as_tensor(old_log_probs[batch_indices], dtype=torch.float32, device=self.device)
            batch_advantages = torch.as_tensor(sample_advantages[batch_indices], dtype=torch.float32, device=self.device)
            new_log_probs, entropy = self.lon_actor.evaluate_actions(batch_obs, batch_actions)
            if not bool(torch.isfinite(new_log_probs).all() and torch.isfinite(entropy).all()):
                continue
            loss, approx_kl = self._dual_clip_loss(
                new_log_probs, batch_old_logs, batch_advantages, entropy.mean()
            )
            self._last_approx_kl = max(self._last_approx_kl, approx_kl)
            if approx_kl > self.TARGET_KL:
                # Skip this minibatch step and stop further lon epochs.
                break
            bc = self._anchor_bc_continuous(batch_obs, batch_actions, bc_coef)
            if bc is not None:
                loss = loss + bc
            # Optional shield/soft-start imitation (rollout may carry applied actions).
            im_coef = float(getattr(self, "imitation_coef", 0.0) or 0.0)
            applied = self._pick_rollout(rollouts, "lon_applied_actions", "applied_cav_actions")
            if (
                im_coef > 0.0
                and hasattr(self.lon_actor, "imitation_loss")
                and len(applied) == len(observations)
            ):
                try:
                    app_t = torch.as_tensor(
                        np.asarray([applied[i] for i in batch_indices], dtype=np.float32),
                        dtype=torch.float32,
                        device=self.device,
                    )
                    im = self.lon_actor.imitation_loss(batch_obs, app_t)
                    if im is not None:
                        loss = loss + im_coef * im
                except Exception:
                    pass
            if not bool(torch.isfinite(loss)):
                continue
            self.lon_optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(self.lon_actor.parameters(), self.max_grad_norm)
            self.lon_optimizer.step()
            losses.append(float(loss.detach().item()))
        return float(np.mean(losses)) if losses else 0.0

    def _update_lat_actor(self, rollouts):
        self._last_approx_kl = 0.0
        if (
            not self._train_flags()["lat"]
            or self.lat_actor is None
            or self.lat_optimizer is None
        ):
            return 0.0
        observations = self._pick_rollout(rollouts, "lat_obs")
        if len(observations) == 0:
            return 0.0
        actions = np.asarray(self._pick_rollout(rollouts, "lat_actions"), dtype=np.int64).reshape(-1)
        old_log_probs = np.asarray(
            self._pick_rollout(rollouts, "lat_log_probs"), dtype=np.float32
        ).reshape(-1)
        sample_advantages = np.asarray(
            self._pick_rollout(rollouts, "lat_ind_advantages"), dtype=np.float32
        ).reshape(-1)
        n = len(observations)
        if not (len(actions) == len(old_log_probs) == len(sample_advantages) == n):
            return 0.0
        if not (np.isfinite(old_log_probs).all() and np.isfinite(sample_advantages).all()):
            return 0.0
        observations, actions, old_log_probs, sample_advantages = self._filter_zero_dof_discrete(
            observations, actions, old_log_probs, sample_advantages
        )
        n = len(observations)
        if n == 0:
            return 0.0

        bc_coef = (
            float(getattr(self, "anchor_bc_coef_lat", 0.0) or 0.0)
            if self.training_stage in JOINT_STAGES and self._anchor_lat is not None
            else 0.0
        )
        losses = []
        for batch_indices in self._minibatches(n):
            batch_obs = self._batch_observations([observations[i] for i in batch_indices])
            logits = self.lat_actor(batch_obs)
            if not bool(torch.isfinite(logits).all()):
                continue
            dist = Categorical(logits=logits)
            batch_actions = torch.as_tensor(actions[batch_indices], dtype=torch.long, device=self.device)
            batch_old_logs = torch.as_tensor(old_log_probs[batch_indices], dtype=torch.float32, device=self.device)
            batch_advantages = torch.as_tensor(sample_advantages[batch_indices], dtype=torch.float32, device=self.device)
            new_log_probs = dist.log_prob(batch_actions)
            entropy = dist.entropy()
            if not bool(torch.isfinite(new_log_probs).all() and torch.isfinite(entropy).all()):
                continue
            loss, approx_kl = self._dual_clip_loss(
                new_log_probs, batch_old_logs, batch_advantages, entropy.mean()
            )
            self._last_approx_kl = max(self._last_approx_kl, approx_kl)
            if approx_kl > self.TARGET_KL:
                break
            bc = self._anchor_bc_discrete(logits, self._anchor_lat, batch_obs, bc_coef)
            if bc is not None:
                loss = loss + bc
            if not bool(torch.isfinite(loss)):
                continue
            self.lat_optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(self.lat_actor.parameters(), self.max_grad_norm)
            self.lat_optimizer.step()
            losses.append(float(loss.detach().item()))
        return float(np.mean(losses)) if losses else 0.0

    def _update_signal_actor(self, rollouts):
        self._last_approx_kl = 0.0
        beta_t = float(
            getattr(self, "teacher_beta", None)
            if getattr(self, "teacher_beta", None) is not None
            else getattr(self, "signal_teacher_beta", 0.0)
            or 0.0
        )
        if not np.isfinite(beta_t) or beta_t < 0.0:
            beta_t = 0.0
        conf_thr = float(
            getattr(self, "teacher_conf_threshold", TEACHER_CONFIDENCE_THRESHOLD)
            or TEACHER_CONFIDENCE_THRESHOLD
        )
        empty_stats = {
            "valid_samples": 0,
            "teacher_valid_samples": 0.0,
            "teacher_loss": 0.0,
            "teacher_beta": float(beta_t),
            "teacher_severity_mean": 0.0,
            "agreement_rate": 0.0,
            "teacher_agreement_rate": 0.0,
            "entropy": 0.0,
            "signal_entropy": 0.0,
            "grad_norm": 0.0,
            "signal_grad_norm": 0.0,
        }
        if (
            not self._train_flags()["signal"]
            or self.signal_actor is None
            or self.signal_optimizer is None
        ):
            self._last_teacher_stats = empty_stats
            return 0.0
        observations = self._pick_rollout(rollouts, "signal_obs")
        if len(observations) == 0:
            self._last_teacher_stats = empty_stats
            return 0.0
        actions = np.asarray(self._pick_rollout(rollouts, "signal_actions"), dtype=np.int64).reshape(-1)
        old_log_probs = np.asarray(
            self._pick_rollout(rollouts, "signal_log_probs"), dtype=np.float32
        ).reshape(-1)
        sample_advantages = np.asarray(
            self._pick_rollout(rollouts, "signal_ind_advantages"), dtype=np.float32
        ).reshape(-1)
        # Joint: down-weight signal advantages so lon/lat noise does not yank TLS.
        if self.training_stage in JOINT_STAGES:
            adv_scale = float(
                getattr(self, "joint_signal_adv_scale", DEFAULT_JOINT_SIGNAL_ADV_SCALE) or 1.0
            )
            if np.isfinite(adv_scale) and adv_scale != 1.0:
                sample_advantages = sample_advantages * adv_scale
        raw_t_actions = self._pick_rollout(rollouts, "signal_teacher_actions")
        raw_t_confs = self._pick_rollout(rollouts, "signal_teacher_confs")
        raw_t_sevs = self._pick_rollout(rollouts, "signal_teacher_severities")
        n = len(observations)
        if len(raw_t_actions) == n and len(raw_t_confs) == n:
            teacher_actions = np.asarray(raw_t_actions, dtype=np.int64).reshape(-1)
            teacher_confs = np.asarray(raw_t_confs, dtype=np.float32).reshape(-1)
        else:
            teacher_actions = np.full(n, -1, dtype=np.int64)
            teacher_confs = np.zeros(n, dtype=np.float32)
        if len(raw_t_sevs) == n:
            teacher_sevs = np.asarray(raw_t_sevs, dtype=np.float32).reshape(-1)
            teacher_sevs = np.where(np.isfinite(teacher_sevs), teacher_sevs, 0.0)
            teacher_sevs = np.clip(teacher_sevs, 0.0, 1.0)
        else:
            # Backward compatible: treat valid teacher samples as full weight.
            teacher_sevs = np.where(
                (teacher_actions >= 0) & (teacher_confs >= conf_thr), 1.0, 0.0
            ).astype(np.float32)
        if not (len(actions) == len(old_log_probs) == len(sample_advantages) == n):
            self._last_teacher_stats = empty_stats
            return 0.0
        if not (np.isfinite(old_log_probs).all() and np.isfinite(sample_advantages).all()):
            self._last_teacher_stats = empty_stats
            return 0.0

        # Filter zero-DoF masks (locked keep / forced single switch) before teacher stats.
        keep_idx = []
        for i, obs in enumerate(observations):
            mask = obs.get("action_mask") if isinstance(obs, dict) else None
            if mask is None:
                keep_idx.append(i)
                continue
            if int(np.sum(np.asarray(mask, dtype=np.float32).reshape(-1) > 0)) <= 1:
                continue
            keep_idx.append(i)
        if keep_idx and len(keep_idx) < n:
            idx = np.asarray(keep_idx, dtype=np.int64)
            observations = [observations[i] for i in idx]
            actions = actions[idx]
            old_log_probs = old_log_probs[idx]
            sample_advantages = sample_advantages[idx]
            teacher_actions = teacher_actions[idx]
            teacher_confs = teacher_confs[idx]
            teacher_sevs = teacher_sevs[idx]
            n = len(observations)
        elif not keep_idx:
            self._last_teacher_stats = empty_stats
            return 0.0

        valid_mask_np = (teacher_actions >= 0) & (teacher_confs >= conf_thr)
        valid_total = int(np.sum(valid_mask_np))
        agree_total = int(
            np.sum(valid_mask_np & (actions == teacher_actions))
        )
        sev_mean = (
            float(np.mean(teacher_sevs[valid_mask_np])) if valid_total > 0 else 0.0
        )
        losses = []
        teacher_losses = []
        entropies = []
        grad_norms = []
        joint_mode = self.training_stage in JOINT_STAGES
        bc_coef = (
            float(getattr(self, "anchor_bc_coef_signal", 0.0) or 0.0)
            if joint_mode and self._anchor_signal is not None
            else 0.0
        )
        ent_scale = (
            float(getattr(self, "joint_signal_entropy_scale", DEFAULT_JOINT_SIGNAL_ENTROPY_SCALE) or 1.0)
            if joint_mode
            else 1.0
        )
        saved_ent = float(self.entropy_coef)
        if joint_mode and np.isfinite(ent_scale):
            self.entropy_coef = saved_ent * max(0.0, ent_scale)

        for batch_indices in self._minibatches(n):
            batch_obs = self._batch_observations([observations[i] for i in batch_indices])
            raw_logits = self.signal_actor(batch_obs)
            if not bool(torch.isfinite(raw_logits).all()):
                continue
            logits = self._effective_signal_logits(raw_logits)
            dist = Categorical(logits=logits)
            batch_actions = torch.as_tensor(actions[batch_indices], dtype=torch.long, device=self.device)
            batch_old_logs = torch.as_tensor(old_log_probs[batch_indices], dtype=torch.float32, device=self.device)
            batch_advantages = torch.as_tensor(sample_advantages[batch_indices], dtype=torch.float32, device=self.device)
            new_log_probs = dist.log_prob(batch_actions)
            entropy = dist.entropy()
            if not bool(torch.isfinite(new_log_probs).all() and torch.isfinite(entropy).all()):
                continue
            ppo_loss, approx_kl = self._dual_clip_loss(
                new_log_probs, batch_old_logs, batch_advantages, entropy.mean()
            )
            self._last_approx_kl = max(self._last_approx_kl, approx_kl)
            if approx_kl > self.TARGET_KL:
                break
            if not bool(torch.isfinite(ppo_loss)):
                continue

            loss = ppo_loss
            bc = self._anchor_bc_discrete(logits, self._anchor_signal, batch_obs, bc_coef)
            if bc is not None:
                loss = loss + bc
            if beta_t > 0.0:
                b_t_act = torch.as_tensor(
                    teacher_actions[batch_indices], dtype=torch.long, device=self.device
                )
                b_t_conf = torch.as_tensor(
                    teacher_confs[batch_indices], dtype=torch.float32, device=self.device
                )
                b_t_sev = torch.as_tensor(
                    teacher_sevs[batch_indices], dtype=torch.float32, device=self.device
                )
                valid_mask = (b_t_act >= 0) & (b_t_conf >= conf_thr) & (b_t_sev > 0.0)
                if bool(valid_mask.any()):
                    # logits already action-masked in SignalActor; log_prob is
                    # log pi_theta(a_teacher | s_t) under the legal support.
                    # Severity down-weights routine queue_imbalance vs hard events.
                    t_log_probs = dist.log_prob(torch.clamp(b_t_act, min=0))[valid_mask]
                    w = b_t_sev[valid_mask]
                    w_sum = torch.clamp(w.sum(), min=1e-8)
                    teacher_loss = -(w * t_log_probs).sum() / w_sum
                    if bool(torch.isfinite(teacher_loss)):
                        loss = loss + beta_t * teacher_loss
                        teacher_losses.append(float(teacher_loss.detach().item()))

            if not bool(torch.isfinite(loss)):
                continue
            self.signal_optimizer.zero_grad(set_to_none=True)
            loss.backward()
            grad_norm = torch.nn.utils.clip_grad_norm_(
                self.signal_actor.parameters(), self.max_grad_norm
            )
            try:
                grad_norms.append(
                    float(grad_norm.detach().item())
                    if torch.is_tensor(grad_norm)
                    else float(grad_norm)
                )
            except (TypeError, ValueError, OverflowError):
                pass
            self.signal_optimizer.step()
            losses.append(float(loss.detach().item()))
            entropies.append(float(entropy.mean().detach().item()))

        self.entropy_coef = saved_ent
        agree_rate = (
            float(agree_total) / float(valid_total) if valid_total > 0 else 0.0
        )
        ent = float(np.mean(entropies)) if entropies else 0.0
        gnorm = float(np.mean(grad_norms)) if grad_norms else 0.0
        t_loss = float(np.mean(teacher_losses)) if teacher_losses else 0.0
        self._last_teacher_stats = {
            "valid_samples": int(valid_total),
            "teacher_valid_samples": float(valid_total),
            "teacher_loss": t_loss,
            "teacher_beta": float(beta_t),
            "teacher_severity_mean": float(sev_mean),
            "agreement_rate": float(agree_rate),
            "teacher_agreement_rate": float(agree_rate),
            "entropy": ent,
            "signal_entropy": ent,
            "grad_norm": gnorm,
            "signal_grad_norm": gnorm,
        }
        return float(np.mean(losses)) if losses else 0.0

    def _update_critic(self, global_graphs, returns, signal_returns=None):
        self._last_sig_critic_loss = 0.0
        if self.critic is None or self.critic_optimizer is None:
            return 0.0
        if not any(p.requires_grad for p in self.critic.parameters()):
            return 0.0
        returns = np.asarray(returns, dtype=np.float32).reshape(-1)
        n = len(global_graphs)
        if n == 0 or len(returns) != n or not np.isfinite(returns).all():
            return 0.0
        std = self._ret_rms_std()
        normed = (returns - float(self._ret_rms_mean)) / (std + 1e-8)

        use_dual = False
        sig_normed = None
        if signal_returns is not None and hasattr(self.critic, "forward_dual"):
            sig_arr = np.asarray(signal_returns, dtype=np.float32).reshape(-1)
            if len(sig_arr) == n and np.isfinite(sig_arr).all():
                sig_std = self._sig_ret_rms_std()
                sig_normed = (sig_arr - float(self._sig_ret_rms_mean)) / (sig_std + 1e-8)
                use_dual = True

        losses = []
        sig_losses = []
        for batch_indices in self._minibatches(n):
            graphs = [global_graphs[i] for i in batch_indices]
            batched = self._batch_graphs(graphs)
            targets = torch.clamp(
                torch.as_tensor(normed[batch_indices], dtype=torch.float32, device=self.device),
                -10.0,
                10.0,
            )
            if use_dual and sig_normed is not None:
                pred_team_raw, pred_sig_raw = self.critic.forward_dual(batched)
                predicted = pred_team_raw.reshape(-1)
                pred_sig = pred_sig_raw.reshape(-1)
                if (
                    predicted.numel() != len(batch_indices)
                    or pred_sig.numel() != len(batch_indices)
                    or not bool(torch.isfinite(predicted).all())
                    or not bool(torch.isfinite(pred_sig).all())
                ):
                    continue
                sig_tgt = torch.clamp(
                    torch.as_tensor(
                        sig_normed[batch_indices], dtype=torch.float32, device=self.device
                    ),
                    -10.0,
                    10.0,
                )
                loss_sig = F.smooth_l1_loss(pred_sig, sig_tgt, beta=1.0)
                team_frozen = (
                    str(getattr(self, "training_stage", "")) == "S"
                    and bool(getattr(self, "freeze_team_critic_in_stage_s", True))
                ) or (
                    hasattr(self.critic, "net")
                    and not any(p.requires_grad for p in self.critic.net.parameters())
                )
                if team_frozen:
                    loss = loss_sig
                else:
                    loss_team = F.smooth_l1_loss(predicted, targets, beta=1.0)
                    loss = loss_team + 0.5 * loss_sig
                if not bool(torch.isfinite(loss)):
                    continue
                sig_losses.append(float(loss_sig.detach().item()))
            else:
                predicted = self.critic(batched).reshape(-1)
                if predicted.numel() != len(batch_indices) or not bool(torch.isfinite(predicted).all()):
                    continue
                loss = F.smooth_l1_loss(predicted, targets, beta=1.0)
                if not bool(torch.isfinite(loss)):
                    continue
            self.critic_optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(self.critic.parameters(), self.max_grad_norm)
            self.critic_optimizer.step()
            losses.append(float(loss.detach().item()))
        self._last_sig_critic_loss = float(np.mean(sig_losses)) if sig_losses else 0.0
        return float(np.mean(losses)) if losses else 0.0

    def update(self, rollouts):
        global_graphs = self._pick_rollout(rollouts, "global_obs")
        empty = {
            "lon_actor": 0.0,
            "lat_actor": 0.0,
            "signal_actor": 0.0,
            "critic": 0.0,
            "signal_critic": 0.0,
            "cav_actor": 0.0,
            "teacher_valid_samples": 0.0,
            "teacher_loss": 0.0,
            "teacher_beta": float(
                getattr(self, "teacher_beta", getattr(self, "signal_teacher_beta", 0.0))
                or 0.0
            ),
            "teacher_severity_mean": 0.0,
            "teacher_agreement_rate": 0.0,
            "signal_entropy": 0.0,
            "signal_grad_norm": 0.0,
        }
        if len(global_graphs) == 0:
            return empty

        returns = np.asarray(
            self._pick_rollout(rollouts, "team_returns", "returns"), dtype=np.float32
        ).reshape(-1)
        raw_sig_returns = self._pick_rollout(rollouts, "signal_returns")
        sig_returns = (
            np.asarray(raw_sig_returns, dtype=np.float32).reshape(-1)
            if len(raw_sig_returns) == len(global_graphs)
            else None
        )
        # One RMS update per rollout flush (not once per PPO epoch).
        # Skip team return RMS update in Stage-S when team head is frozen so
        # _ret_rms stays uncalibrated to long-horizon negative signal returns.
        if not (
            str(getattr(self, "training_stage", "")) == "S"
            and bool(getattr(self, "freeze_team_critic_in_stage_s", True))
        ):
            self._update_ret_rms(returns)
        if sig_returns is not None:
            self._update_sig_ret_rms(sig_returns)
        # Drop zero-DoF discrete samples before advantage standardization so
        # locked keep / forced single-switch steps cannot pollute mean/std.
        for kind, obs_key, keys in (
            (
                "lat",
                "lat_obs",
                ("lat_obs", "lat_actions", "lat_log_probs", "lat_ind_advantages"),
            ),
            (
                "signal",
                "signal_obs",
                (
                    "signal_obs",
                    "signal_actions",
                    "signal_log_probs",
                    "signal_ind_advantages",
                    "signal_teacher_actions",
                    "signal_teacher_confs",
                    "signal_teacher_severities",
                    "signal_step_indices",
                ),
            ),
        ):
            obs_list = self._pick_rollout(rollouts, obs_key)
            if not obs_list:
                continue
            keep = []
            for i, obs in enumerate(obs_list):
                mask = obs.get("action_mask") if isinstance(obs, dict) else None
                if mask is None:
                    keep.append(i)
                    continue
                if int(np.sum(np.asarray(mask, dtype=np.float32).reshape(-1) > 0)) <= 1:
                    continue
                keep.append(i)
            if len(keep) == len(obs_list):
                continue
            if not keep:
                for k in keys:
                    if k in rollouts:
                        rollouts[k] = []
                continue
            idx = np.asarray(keep, dtype=np.int64)
            for k in keys:
                raw = self._pick_rollout(rollouts, k)
                if not raw:
                    continue
                if k.endswith("_obs") or k == obs_key:
                    rollouts[k] = [raw[i] for i in idx]
                else:
                    arr = np.asarray(raw)
                    if arr.ndim == 0 or len(arr) != len(obs_list):
                        continue
                    rollouts[k] = arr[idx]
        # v5 (1.3): accumulate signal-actor samples across flushes until
        # signal_min_batch decisions exist (agents/signal_buffer.py).
        _smb = int(getattr(self, "signal_min_batch", 0) or 0)
        if _smb > 0 and bool(self._train_flags().get("signal", False)):
            _buf = getattr(self, "_signal_buffer", None)
            if _buf is None or int(_buf.min_batch) != _smb:
                _buf = SignalSampleBuffer(_smb)
                self._signal_buffer = _buf
            _buf.add(rollouts, str(getattr(self, "training_stage", "")), pick=self._pick_rollout)
            if _buf.ready():
                rollouts.update(_buf.release())
                self._signal_deferred = False
            else:
                for _k in SIGNAL_SAMPLE_KEYS:
                    rollouts[_k] = []
                self._signal_deferred = True
        else:
            self._signal_buffer = None
            self._signal_deferred = False
        for key in ("ind_advantages", "lon_ind_advantages", "lat_ind_advantages", "signal_ind_advantages"):
            raw_adv = self._pick_rollout(rollouts, key)
            adv = np.asarray(raw_adv, dtype=np.float32).reshape(-1)
            if adv.size > 1 and np.isfinite(adv).all():
                rollouts[key] = (adv - adv.mean()) / (adv.std(ddof=0) + 1e-8)
            elif adv.size:
                rollouts[key] = adv

        # NOTE: no torch.cuda.empty_cache() here on purpose — it forces a
        # device-wide sync on every rollout flush and measurably slows
        # training; allocator reuse across minibatches is sufficient and
        # numerically identical.

        hist = {"lon_actor": [], "lat_actor": [], "signal_actor": [], "critic": [], "signal_critic": []}
        # Approx-KL early stop (Schulman): actors skip backward when KL exceeds
        # TARGET_KL inside the minibatch loop, then stop further epochs here.
        kl_stop = {"lon_actor": False, "lat_actor": False, "signal_actor": False}
        n_sig = len(self._pick_rollout(rollouts, "signal_obs"))
        signal_epoch_cap = self._signal_epoch_cap(
            n_sig,
            self.ppo_epochs,
            force_one=bool(getattr(self, "_force_signal_one_epoch", False)),
        )
        teacher_acc = {
            "teacher_valid_samples": [],
            "teacher_loss": [],
            "teacher_beta": [],
            "teacher_severity_mean": [],
            "teacher_agreement_rate": [],
            "signal_entropy": [],
            "signal_grad_norm": [],
        }
        for epoch in range(self.ppo_epochs):
            if not kl_stop["lon_actor"]:
                hist["lon_actor"].append(self._update_lon_actor(rollouts))
                if float(getattr(self, "_last_approx_kl", 0.0)) > self.TARGET_KL:
                    kl_stop["lon_actor"] = True
            if not kl_stop["lat_actor"]:
                hist["lat_actor"].append(self._update_lat_actor(rollouts))
                if float(getattr(self, "_last_approx_kl", 0.0)) > self.TARGET_KL:
                    kl_stop["lat_actor"] = True
            if epoch < signal_epoch_cap and not kl_stop["signal_actor"]:
                hist["signal_actor"].append(self._update_signal_actor(rollouts))
                stats = getattr(self, "_last_teacher_stats", {}) or {}
                for key in teacher_acc:
                    teacher_acc[key].append(float(stats.get(key, 0.0)))
                if float(getattr(self, "_last_approx_kl", 0.0)) > self.TARGET_KL:
                    kl_stop["signal_actor"] = True
            hist["critic"].append(
                self._update_critic(global_graphs, returns, signal_returns=sig_returns)
            )
            hist["signal_critic"].append(float(getattr(self, "_last_sig_critic_loss", 0.0)))

        out = {k: float(np.mean(v)) if v else 0.0 for k, v in hist.items()}
        for key, vals in teacher_acc.items():
            if key == "teacher_valid_samples":
                out[key] = float(vals[0]) if vals else 0.0
            else:
                out[key] = float(np.mean(vals)) if vals else 0.0
        # TB Loss/cav_actor: lon in Lon/JointLonSig; lat in Lat/JointAll.
        env_st = self.cav_env_stage(self.training_stage)
        if env_st == "Lat":
            out["cav_actor"] = out["lat_actor"]
        else:
            out["cav_actor"] = out["lon_actor"]
        return out
