#!/usr/bin/env python3
"""Estimate per-stage plateau episodes from episode_metrics.npz (VECTOR v5, 1.4).

  python tools/calibrate_schedule.py results/train/.../episode_metrics.npz --list
  python tools/calibrate_schedule.py RUN/episode_metrics.npz --metric avg_travel_time \
      --boundaries "S:250,Lon:300,Lat:300,JointAll:150"

Plateau = first episode where the rolling mean enters a +-tol band around the
stage's final level (mean of its last 20 %) and stays inside for >= 90 % of
the remaining episodes. Suggested length = ceil(margin * plateau), floored by
per-stage minimums. Use it on several seeds and take the maximum.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

DEFAULT_MIN = {"S": 120, "Lon": 80, "JointLonSig": 40, "Lat": 100, "JointAll": 60}
METRIC_PREFERENCE = ("avg_time_in_system", "uncensored_avg_travel_time", "avg_travel_time",
                     "avg_waiting_time", "avg_speed")


def episode_means(raw) -> np.ndarray:
    """Per-episode mean over envs; tolerant to ragged / object arrays."""
    out: List[float] = []
    for row in np.asarray(raw, dtype=object).reshape(-1) if np.ndim(raw) <= 1 else raw:
        try:
            vals = np.asarray(row, dtype=np.float64).reshape(-1)
            vals = vals[np.isfinite(vals)]
            out.append(float(vals.mean()) if vals.size else float("nan"))
        except (TypeError, ValueError):
            out.append(float("nan"))
    return np.asarray(out, dtype=np.float64)


def plateau_index(y: Sequence[float], window: int = 10, tol: float = 0.02,
                  hold_frac: float = 0.9) -> Optional[int]:
    arr = np.asarray(y, dtype=np.float64)
    arr = arr[np.isfinite(arr)]
    n = int(arr.size)
    if n < 6:
        return None
    w = max(1, min(int(window), n // 3))
    roll = np.convolve(arr, np.ones(w) / w, mode="valid")
    final = float(np.mean(arr[-max(w, n // 5):]))
    band = max(abs(final) * float(tol), 1e-9)
    inside = np.abs(roll - final) <= band
    for i in range(len(roll)):
        if float(inside[i:].mean()) >= float(hold_frac):
            return int(i + w - 1)
    return None


def segments_from_boundaries(spec: str, n: int) -> List[Tuple[str, int, int]]:
    segs, start = [], 0
    for part in [p for p in str(spec).split(",") if p.strip()]:
        name, cnt = part.split(":")
        end = min(n, start + int(cnt))
        segs.append((name.strip(), start, end))
        start = end
    if start < n:
        segs.append(("rest", start, n))
    return segs


def segments_from_labels(labels: Sequence) -> List[Tuple[str, int, int]]:
    segs: List[Tuple[str, int, int]] = []
    for i, lab in enumerate(labels):
        lab = str(lab)
        if segs and segs[-1][0] == lab:
            segs[-1] = (lab, segs[-1][1], i + 1)
        else:
            segs.append((lab, i, i + 1))
    return segs


def calibrate(series: np.ndarray, segs, margin: float = 1.3, mins: Optional[Dict[str, int]] = None,
              window: int = 10, tol: float = 0.02) -> List[Dict[str, object]]:
    mins = dict(DEFAULT_MIN if mins is None else mins)
    out = []
    for name, a, b in segs:
        idx = plateau_index(series[a:b], window=window, tol=tol)
        length = b - a
        suggest = None
        if idx is not None:
            suggest = int(max(mins.get(name, 1), math.ceil(margin * (idx + 1))))
        out.append({"stage": name, "episodes": int(length),
                    "plateau_episode": None if idx is None else int(idx + 1),
                    "suggested_length": suggest})
    return out


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("npz")
    ap.add_argument("--metric", default="")
    ap.add_argument("--stage-key", default="")
    ap.add_argument("--boundaries", default="", help='e.g. "S:250,Lon:300,Lat:300,JointAll:150"')
    ap.add_argument("--margin", type=float, default=1.3)
    ap.add_argument("--window", type=int, default=10)
    ap.add_argument("--tol", type=float, default=0.02)
    ap.add_argument("--list", action="store_true")
    a = ap.parse_args(argv)
    data = np.load(a.npz, allow_pickle=True)
    keys = list(data.keys())
    if a.list:
        print("\n".join(keys))
        return 0
    metric = a.metric or next((k for k in METRIC_PREFERENCE if k in keys), "")
    if metric not in keys:
        print(f"metric not found; available: {keys}", file=sys.stderr)
        return 2
    series = episode_means(data[metric])
    if a.boundaries:
        segs = segments_from_boundaries(a.boundaries, len(series))
    else:
        skey = a.stage_key or next((k for k in ("stage", "stages", "training_stage") if k in keys), "")
        segs = segments_from_labels(data[skey]) if skey else [("all", 0, len(series))]
    res = calibrate(series, segs, margin=a.margin, window=a.window, tol=a.tol)
    print(json.dumps({"metric": metric, "stages": res}, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
