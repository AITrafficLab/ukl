#!/usr/bin/env python3
"""Static checks that need neither SUMO nor torch.

1) py_compile every .py file.
2) Flag locals that are READ before their first assignment in straight-line
   code of the same function (the v3 ``env_done_bool`` crash class).
Usage:  python tools/static_check.py [project_root]
"""
from __future__ import annotations

import ast
import os
import py_compile
import sys


class _FuncChecker(ast.NodeVisitor):
    def __init__(self, func: ast.AST):
        self.func = func
        self.stores = {}
        self.loads = []
        self.declared = set()
        self.loop_spans = []

    def run(self):
        for arg in ast.walk(self.func.args):
            if isinstance(arg, ast.arg):
                self.stores.setdefault(arg.arg, 0)
        for stmt in self.func.body:
            self.visit(stmt)
        issues = []
        for name, line in self.loads:
            first = self.stores.get(name)
            if first is None or name in self.declared or first <= line:
                continue
            if any(lo <= line <= hi and lo <= first <= hi for lo, hi in self.loop_spans):
                continue
            issues.append((line, name, first))
        return issues

    def _store_target(self, node):
        for n in ast.walk(node):
            if isinstance(n, ast.Name):
                self.stores[n.id] = min(self.stores.get(n.id, 10 ** 9), n.lineno)

    def visit_FunctionDef(self, node):
        self.stores.setdefault(node.name, node.lineno)

    visit_AsyncFunctionDef = visit_FunctionDef

    def visit_ClassDef(self, node):
        self.stores.setdefault(node.name, node.lineno)

    def visit_Lambda(self, node):
        return

    def visit_ListComp(self, node):
        return

    visit_SetComp = visit_DictComp = visit_GeneratorExp = visit_ListComp

    def visit_Global(self, node):
        self.declared.update(node.names)

    visit_Nonlocal = visit_Global

    def visit_Name(self, node):
        if isinstance(node.ctx, ast.Store):
            self.stores[node.id] = min(self.stores.get(node.id, 10 ** 9), node.lineno)
        elif isinstance(node.ctx, ast.Load):
            self.loads.append((node.id, node.lineno))

    def _loop(self, node):
        end = getattr(node, "end_lineno", node.lineno)
        self.loop_spans.append((node.lineno, end))
        self.generic_visit(node)

    visit_For = visit_AsyncFor = visit_While = _loop

    def visit_Import(self, node):
        for a in node.names:
            nm = (a.asname or a.name).split(".")[0]
            self.stores[nm] = min(self.stores.get(nm, 10 ** 9), node.lineno)

    visit_ImportFrom = visit_Import

    def visit_ExceptHandler(self, node):
        if node.name:
            self.stores[node.name] = min(self.stores.get(node.name, 10 ** 9), node.lineno)
        self.generic_visit(node)


def check_file(path: str):
    with open(path, "r", encoding="utf-8") as fh:
        tree = ast.parse(fh.read(), filename=path)
    issues = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            for line, name, first in _FuncChecker(node).run():
                issues.append(f"{path}:{line}: '{name}' read before first assignment (line {first}) in {node.name}()")
    return issues


def main(root: str) -> int:
    bad = 0
    for dirpath, _dirs, files in os.walk(root):
        if "__pycache__" in dirpath:
            continue
        for fn in sorted(files):
            if not fn.endswith(".py"):
                continue
            p = os.path.join(dirpath, fn)
            try:
                py_compile.compile(p, doraise=True)
            except py_compile.PyCompileError as exc:
                print(f"[compile] {exc}")
                bad += 1
                continue
            for msg in check_file(p):
                print(f"[use-before-assign] {msg}")
                bad += 1
    print(f"static_check: {bad} issue(s)")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else "."))
