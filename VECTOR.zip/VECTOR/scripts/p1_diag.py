#!/usr/bin/env python3
"""Short diagnostic toward a *learned* landable stack.

Does **not** re-run the v6p1 bundle (GATE-P1 already failed). Trains the only
learner that previously matched G2 on 4-leg (v6-P0 Lon residual = G3), then
evaluates the checkpoint on the same seeds as the slim G2 table.

  python scripts/p1_diag.py --dry-run
  python scripts/p1_diag.py --lon-episodes 16 --control-seconds 900 --seeds 7,8,9,10,11
  python scripts/p1_diag.py --compare-only

Pass bar (same as GATE-P1): TIS <= -1% vs G2, bootstrap 95% upper < 0, collisions
and teleports not worse. Fail → keep G2; do not start VLM or full curriculum.
"""
from __future__ import annotations

import argparse
import csv
import math
import os
import subprocess
import sys
import time
from typing import Dict, List, Optional, Sequence, Tuple

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
TRAIN = os.path.join(ROOT, "train", "train_RL.py")
SUMOCFG = "environment/sumo_net/4-leg(4phases)/4-leg(4phases).sumocfg"
METHOD = "p1diag_G3"

_T975 = {
    1: 12.706, 2: 4.303, 3: 3.182, 4: 2.776, 5: 2.571, 6: 2.447, 7: 2.365,
    8: 2.306, 9: 2.262, 10: 2.228,
}


def _t975(df: int) -> float:
    if df <= 0:
        return float("nan")
    for k in sorted(_T975):
        if df <= k:
            return _T975[k]
    return 1.96


def mean_ci(vals: Sequence[float]) -> Tuple[float, float, int]:
    xs = [float(v) for v in vals if v is not None and math.isfinite(float(v))]
    n = len(xs)
    if n == 0:
        return float("nan"), float("nan"), 0
    m = sum(xs) / n
    if n == 1:
        return m, float("nan"), 1
    sd = math.sqrt(sum((v - m) ** 2 for v in xs) / (n - 1))
    return m, _t975(n - 1) * sd / math.sqrt(n), n


def paired_bootstrap_rel(a: Sequence[float], b: Sequence[float], n_boot: int = 2000, seed: int = 0):
    import random

    aa, bb = list(a), list(b)
    n = min(len(aa), len(bb))
    if n < 2:
        return None
    aa, bb = aa[:n], bb[:n]
    rng = random.Random(seed)
    rels = []
    for _ in range(n_boot):
        idx = [rng.randrange(n) for _ in range(n)]
        ma = sum(aa[i] for i in idx) / n
        mb = sum(bb[i] for i in idx) / n
        if mb == 0:
            continue
        rels.append(ma / mb - 1.0)
    if len(rels) < 20:
        return None
    rels.sort()
    lo = rels[int(0.025 * (len(rels) - 1))]
    hi = rels[int(0.975 * (len(rels) - 1))]
    return (sum(rels) / len(rels), lo, hi)


def _read_metric(path: str, key: str) -> Dict[int, float]:
    out: Dict[int, float] = {}
    if not os.path.isfile(path):
        return out
    with open(path, newline="", encoding="utf-8") as fh:
        for r in csv.DictReader(fh):
            try:
                sd = int(float(r.get("seed", "nan")))
                out[sd] = float(r.get(key, "nan"))
            except (TypeError, ValueError):
                continue
    return out


def _find_ckpt(results_method: str, seed: int) -> Optional[str]:
    sys.path.insert(0, ROOT)
    from baselines.result_paths import train_ckpt_dir
    from baselines.fixed_timing.scenarios import canonical_scenario_key

    scenario = canonical_scenario_key(SUMOCFG)
    ckdir = train_ckpt_dir(results_method, scenario, seed)
    for name in ("best_stage_lon.pt", "latest.pt", "best.pt"):
        p = os.path.join(str(ckdir), name)
        if os.path.isfile(p):
            return p
    if os.path.isdir(str(ckdir)):
        pts = [os.path.join(str(ckdir), f) for f in os.listdir(str(ckdir)) if f.endswith(".pt")]
        if pts:
            pts.sort(key=os.path.getmtime, reverse=True)
            return pts[0]
    return None


def _run(cmd: List[str], log_path: str, dry: bool) -> int:
    os.makedirs(os.path.dirname(log_path), exist_ok=True)
    with open(log_path.replace(".log", ".cmd.txt"), "w", encoding="utf-8") as fh:
        fh.write(" ".join(f'"{c}"' if " " in c or "(" in c else c for c in cmd) + "\n")
    if dry:
        print(f"[dry-run] {' '.join(cmd)}")
        return 0
    env = dict(os.environ)
    env.setdefault("PYTHONUNBUFFERED", "1")
    t0 = time.time()
    print(f"[p1-diag] start -> {log_path}", flush=True)
    with open(log_path, "w", encoding="utf-8") as fh:
        rc = subprocess.call(cmd, cwd=ROOT, stdout=fh, stderr=subprocess.STDOUT, env=env)
    print(f"[p1-diag] done rc={rc} in {(time.time() - t0) / 60.0:.1f} min", flush=True)
    return rc


def train_cmd(a) -> List[str]:
    return [
        sys.executable, TRAIN,
        "--profile", "v6p0",
        "--sumocfg", SUMOCFG,
        "--seed", str(a.train_seed),
        "--gate-lon-episodes", str(a.lon_episodes),
        "--control-seconds", str(a.control_seconds),
        "--signal-rule", "maxpressure",
        "--no-vision",
        "--num-envs", "1",
        "--results-method", METHOD,
        "--torch-threads", str(max(1, int(a.torch_threads))),
    ]


def eval_cmd(a, ckpt: str, out_csv: str) -> List[str]:
    return [
        sys.executable, TRAIN,
        "--profile", "v6p0",
        "--sumocfg", SUMOCFG,
        "--signal-rule", "maxpressure",
        "--no-vision",
        "--eval-only",
        "--eval-stage", "Lon",
        "--eval-checkpoint", ckpt,
        "--eval-seeds", a.seeds,
        "--eval-out", out_csv,
        "--control-seconds", str(a.control_seconds),
        "--num-envs", "1",
        "--results-method", f"{METHOD}_eval",
        "--seed", str(a.train_seed),
        "--torch-threads", str(max(1, int(a.torch_threads))),
    ]


def compare(g3_csv: str, g2_csv: str, out_md: str) -> int:
    tis3 = _read_metric(g3_csv, "avg_time_in_system")
    tis2 = _read_metric(g2_csv, "avg_time_in_system")
    c3 = _read_metric(g3_csv, "collisions_total")
    c2 = _read_metric(g2_csv, "collisions_total")
    t3 = _read_metric(g3_csv, "teleports_total")
    t2 = _read_metric(g2_csv, "teleports_total")
    seeds = sorted(set(tis3) & set(tis2))
    lines = ["# P1 diagnostic (G3 residual vs G2)", ""]
    if not seeds:
        lines.append("No overlapping seeds. Need G3 eval CSV and `logs/landable/4leg_G2.csv`.")
        with open(out_md, "w", encoding="utf-8") as fh:
            fh.write("\n".join(lines) + "\n")
        print("\n".join(lines), flush=True)
        return 2
    a = [tis3[s] for s in seeds]
    b = [tis2[s] for s in seeds]
    m3, ci3, n3 = mean_ci(a)
    m2, ci2, n2 = mean_ci(b)
    rel = m3 / m2 - 1.0 if m2 else float("nan")
    boot = paired_bootstrap_rel(a, b)
    coll_ok = (sum(c3.get(s, 0.0) for s in seeds) / n3) <= (sum(c2.get(s, 0.0) for s in seeds) / n2) + 0.5
    tele_ok = (sum(t3.get(s, 0.0) for s in seeds) / n3) <= (sum(t2.get(s, 0.0) for s in seeds) / n2) + 2.0
    safer = coll_ok and tele_ok
    ci_ok = boot is not None and boot[2] < 0.0
    improve = rel <= -0.01
    passed = bool(improve and ci_ok and safer)
    ci_txt = "-" if boot is None else f"[{100.0 * boot[1]:+.1f}%, {100.0 * boot[2]:+.1f}%]"
    lines += [
        f"seeds={seeds}",
        f"G2 TIS={m2:.2f} ± {ci2:.2f} (n={n2})",
        f"G3 TIS={m3:.2f} ± {ci3:.2f} (n={n3})",
        f"GATE-P1-diag: {'PASS' if passed else 'FAIL'}  (TIS {100.0 * rel:+.1f}%, bootstrap {ci_txt}; "
        f"safety={'ok' if safer else 'FAIL'})",
        "",
        "PASS → replace landable with this G3 checkpoint and only then start formal training.",
        "FAIL → keep G2; do not open VLM / full curriculum / P3.",
    ]
    with open(out_md, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")
    print("\n".join(lines), flush=True)
    return 0 if passed else 1


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--train-seed", type=int, default=7)
    ap.add_argument("--lon-episodes", type=int, default=16)
    ap.add_argument("--control-seconds", type=float, default=900.0)
    ap.add_argument("--seeds", default="7,8,9,10,11")
    ap.add_argument("--torch-threads", type=int, default=1)
    ap.add_argument("--out-dir", default="")
    ap.add_argument("--g2-csv", default="")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--skip-train", action="store_true")
    ap.add_argument("--compare-only", action="store_true")
    a = ap.parse_args()
    a.out_dir = a.out_dir or os.path.join(ROOT, "logs", "p1_diag")
    os.makedirs(a.out_dir, exist_ok=True)
    g3_csv = os.path.join(a.out_dir, "G3_eval.csv")
    g2_csv = a.g2_csv or os.path.join(ROOT, "logs", "landable", "4leg_G2.csv")
    md = os.path.join(a.out_dir, "diag_summary.md")

    if a.compare_only:
        return compare(g3_csv, g2_csv, md)

    if not a.skip_train:
        rc = _run(train_cmd(a), os.path.join(a.out_dir, "G3_train.log"), a.dry_run)
        if rc != 0:
            return rc

    if a.dry_run:
        print("[dry-run] skip eval/compare")
        return 0

    ckpt = _find_ckpt(METHOD, a.train_seed)
    if not ckpt:
        print("[p1-diag] no checkpoint after train", flush=True)
        return 2
    print(f"[p1-diag] eval checkpoint {ckpt}", flush=True)
    rc = _run(eval_cmd(a, ckpt, g3_csv), os.path.join(a.out_dir, "G3_eval.log"), False)
    if rc != 0:
        return rc
    if not os.path.isfile(g2_csv):
        print(f"[p1-diag] G2 csv not ready ({g2_csv}); later: python scripts/p1_diag.py --compare-only", flush=True)
        return 0
    return compare(g3_csv, g2_csv, md)


if __name__ == "__main__":
    raise SystemExit(main())
