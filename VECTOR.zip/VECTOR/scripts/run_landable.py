#!/usr/bin/env python3
"""Evaluate the gate-accepted landable stack (G2) and two in-repo baselines.

G2  --profile landable                 Max-Pressure + v6-P0 CAV rules, Lon residual = 0
G0  Max-Pressure + SUMO native IDM     same signal envelope, no CAV stack
FT  SUMO TLS program + native IDM      warmup program continues through control

Shipped route files (demand 1.0, mixed CAV/HDV). No VLM, no residual RL, no checkpoint.

  python scripts/run_landable.py --dry-run
  python scripts/run_landable.py --methods G2 --scenarios 4-leg --seeds 7 --control-seconds 120
  python scripts/run_landable.py --scenarios 3-leg,4-leg,5-leg --seeds 7,8,9,10,11 --workers 3
"""
from __future__ import annotations

import argparse
import csv
import math
import os
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from typing import Dict, List, Sequence

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
TRAIN = os.path.join(ROOT, "train", "train_RL.py")

SCENARIOS = {
    "3-leg": "environment/sumo_net/3-leg(3phases)/3-leg(3phases).sumocfg",
    "4-leg": "environment/sumo_net/4-leg(4phases)/4-leg(4phases).sumocfg",
    "5-leg": "environment/sumo_net/5-leg(5phases)/5-leg(5phases).sumocfg",
}

# Extra flags after the shared landable/eval envelope. G2 uses the landable profile.
METHODS = {
    "G2": ["--profile", "landable"],
    "G0": [
        "--profile", "v6p0",
        "--ablate-zero-lon-residual",
        "--ablate-cav-native-idm",
        "--signal-rule", "maxpressure",
    ],
    "FT": [
        "--profile", "v6p0",
        "--ablate-zero-lon-residual",
        "--ablate-cav-native-idm",
        "--signal-rule", "fixed",
    ],
}

KPI = (
    "avg_time_in_system",
    "avg_waiting_time",
    "num_stops",
    "avg_fuel",
    "collisions_total",
    "teleports_total",
    "insertion_backlog",
)

_T975 = {
    1: 12.706, 2: 4.303, 3: 3.182, 4: 2.776, 5: 2.571, 6: 2.447, 7: 2.365,
    8: 2.306, 9: 2.262, 10: 2.228, 12: 2.179, 15: 2.131, 20: 2.086, 25: 2.060, 30: 2.042,
}


def _tag(name: str) -> str:
    return name.replace("-", "")


def _t975(df: int) -> float:
    if df <= 0:
        return float("nan")
    for k in sorted(_T975):
        if df <= k:
            return _T975[k]
    return 1.96


def mean_ci(values: Sequence[float]) -> Dict[str, float]:
    vals = [float(v) for v in values if v is not None and math.isfinite(float(v))]
    n = len(vals)
    if n == 0:
        return {"n": 0, "mean": float("nan"), "ci95": float("nan")}
    m = sum(vals) / n
    if n == 1:
        return {"n": 1, "mean": m, "ci95": float("nan")}
    sd = math.sqrt(sum((v - m) ** 2 for v in vals) / (n - 1))
    return {"n": n, "mean": m, "ci95": _t975(n - 1) * sd / math.sqrt(n)}


def build_cmd(scenario: str, method: str, a, extra: List[str]) -> List[str]:
    sumocfg = SCENARIOS[scenario]
    out_csv = os.path.join(a.out_dir, f"{_tag(scenario)}_{method}.csv")
    cmd = [
        sys.executable, TRAIN,
        *METHODS[method],
        "--sumocfg", sumocfg,
        "--no-vision",
        "--eval-only",
        "--eval-stage", "Lon",
        "--eval-seeds", a.seeds,
        "--eval-out", out_csv,
        "--control-seconds", str(a.control_seconds),
        "--num-envs", "1",
        "--results-method", f"landable_{method}",
        "--seed", str(int(str(a.seeds).split(",")[0].strip() or 7)),
        "--torch-threads", str(max(1, int(a.torch_threads))),
    ]
    if a.gui:
        cmd.append("--gui")
    cmd.extend(extra)
    return cmd


def run_one(scenario: str, method: str, a, extra: List[str]) -> int:
    stem = f"{_tag(scenario)}_{method}"
    log_path = os.path.join(a.out_dir, f"{stem}.log")
    cmd = build_cmd(scenario, method, a, extra)
    with open(os.path.join(a.out_dir, f"{stem}.cmd.txt"), "w", encoding="utf-8") as fh:
        fh.write(" ".join(f'"{c}"' if " " in c or "(" in c else c for c in cmd) + "\n")
    if a.dry_run:
        print(f"[dry-run] {scenario} {method}: {' '.join(cmd)}")
        return 0
    csv_path = os.path.join(a.out_dir, f"{stem}.csv")
    if a.skip_existing and os.path.isfile(csv_path) and os.path.getsize(csv_path) > 32:
        print(f"[landable] skip {scenario} {method} (csv exists)", flush=True)
        return 0
    env = dict(os.environ)
    env.setdefault("PYTHONUNBUFFERED", "1")
    t0 = time.time()
    print(f"[landable] start {scenario} {method} -> {log_path}", flush=True)
    with open(log_path, "w", encoding="utf-8") as fh:
        rc = subprocess.call(cmd, cwd=ROOT, stdout=fh, stderr=subprocess.STDOUT, env=env)
    print(
        f"[landable] done  {scenario} {method} rc={rc} in {(time.time() - t0) / 60.0:.1f} min",
        flush=True,
    )
    return rc


def summarize(out_dir: str, scenarios: List[str], methods: List[str]) -> None:
    rows = []
    for sc in scenarios:
        for method in methods:
            path = os.path.join(out_dir, f"{_tag(sc)}_{method}.csv")
            if not os.path.isfile(path):
                continue
            with open(path, newline="", encoding="utf-8") as fh:
                for r in csv.DictReader(fh):
                    r["_scenario"] = sc
                    r["_method"] = method
                    rows.append(r)
    if not rows:
        return

    def col(rs, k):
        out = []
        for r in rs:
            try:
                out.append(float(r.get(k, "nan")))
            except (TypeError, ValueError):
                pass
        return out

    md_path = os.path.join(out_dir, "landable_summary.md")
    lines = [
        "# Landable slim eval",
        "",
        "Demand = shipped routes (scale 1.0). Penetration = mix in those route files.",
        "Mean and 95% t-interval over eval seeds.",
        "",
        "| scenario | method | n | TIS | waiting | stops | fuel | coll | tele | backlog |",
        "|---|---|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for sc in scenarios:
        for method in methods:
            rs = [r for r in rows if r.get("_scenario") == sc and r.get("_method") == method]
            if not rs:
                continue
            cells = [sc, method, str(len(rs))]
            for k in KPI:
                st = mean_ci(col(rs, k))
                if st["n"] == 0:
                    cells.append("—")
                elif st["n"] == 1:
                    cells.append(f"{st['mean']:.3g}")
                else:
                    cells.append(f"{st['mean']:.3g} ± {st['ci95']:.3g}")
            lines.append("| " + " | ".join(cells) + " |")

    lines.extend(["", "## Per-seed TIS", "", "| scenario | method | seed | TIS | coll | backlog |", "|---|---|---:|---:|---:|---:|"])
    for r in rows:
        lines.append(
            "| {sc} | {m} | {sd} | {tis} | {c} | {b} |".format(
                sc=r.get("_scenario", ""),
                m=r.get("_method", ""),
                sd=r.get("seed", ""),
                tis=r.get("avg_time_in_system", ""),
                c=r.get("collisions_total", ""),
                b=r.get("insertion_backlog", ""),
            )
        )
    with open(md_path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")
    print(f"[landable] summary -> {md_path}", flush=True)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--scenarios", default="3-leg,4-leg,5-leg", help="comma list from " + ",".join(SCENARIOS))
    ap.add_argument("--methods", default="G2,G0,FT", help="comma list from " + ",".join(METHODS))
    ap.add_argument("--seeds", default="7,8,9,10,11", help="eval seeds, comma-separated")
    ap.add_argument("--control-seconds", type=float, default=900.0)
    ap.add_argument("--workers", type=int, default=3)
    ap.add_argument("--torch-threads", type=int, default=2)
    ap.add_argument("--out-dir", default="")
    ap.add_argument("--gui", action="store_true")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--skip-existing", action="store_true")
    argv = sys.argv[1:]
    extra: List[str] = []
    if "--" in argv:
        i = argv.index("--")
        argv, extra = argv[:i], argv[i + 1:]
    a = ap.parse_args(argv)
    scenarios = [s.strip() for s in a.scenarios.split(",") if s.strip()]
    methods = [s.strip() for s in a.methods.split(",") if s.strip()]
    for s in scenarios:
        if s not in SCENARIOS:
            ap.error(f"unknown scenario {s}")
    for m in methods:
        if m not in METHODS:
            ap.error(f"unknown method {m}")
    a.out_dir = a.out_dir or os.path.join(ROOT, "logs", "landable")
    os.makedirs(a.out_dir, exist_ok=True)
    jobs = [(sc, m) for m in methods for sc in scenarios]
    with ThreadPoolExecutor(max_workers=max(1, int(a.workers))) as ex:
        rcs = list(ex.map(lambda jm: run_one(jm[0], jm[1], a, extra), jobs))
    bad = {f"{sc}/{m}": rc for (sc, m), rc in zip(jobs, rcs) if rc != 0}
    if bad:
        print(f"[landable] WARNING non-zero exit codes: {bad}", flush=True)
    if not a.dry_run:
        summarize(a.out_dir, scenarios, methods)
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
