#!/usr/bin/env python3
"""Evaluate checkpoints on held-out seeds; pick the best on VALIDATION seeds (v5, 1.2).

Each (checkpoint, seed) runs `train/train_RL.py --eval-only` in its own process,
so the environment, stage configuration and per-step action glue are exactly
those of training. Arguments after `--` are forwarded to train_RL.py and MUST
match the training run (scenario, method flags such as --no-vision, ...).

  python scripts/evaluate_policy.py \
      --checkpoints "results/train/<run>/checkpoints/best_*.pt" \
      --seeds validation --workers 4 --out-dir results/eval/<run>_val -- \
      --sumocfg "environment/sumo_net/4-leg(4phases)/4-leg(4phases).sumocfg" --no-vision

Then report the selected checkpoint on `--seeds test`.
"""
from __future__ import annotations

import argparse
import csv
import glob
import json
import math
import os
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from typing import Dict, List, Optional, Sequence

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, ROOT)

_T975 = {1: 12.706, 2: 4.303, 3: 3.182, 4: 2.776, 5: 2.571, 6: 2.447, 7: 2.365, 8: 2.306,
         9: 2.262, 10: 2.228, 12: 2.179, 15: 2.131, 20: 2.086, 25: 2.060, 30: 2.042}


def t975(df: int) -> float:
    if df <= 0:
        return float("nan")
    keys = sorted(_T975)
    for k in keys:
        if df <= k:
            return _T975[k]
    return 1.96


def mean_ci(values: Sequence[float]) -> Dict[str, float]:
    vals = [float(v) for v in values if v is not None and math.isfinite(float(v))]
    n = len(vals)
    if n == 0:
        return {"n": 0, "mean": float("nan"), "ci95": float("nan")}
    m = sum(vals) / n
    if n == 1:
        return {"n": 1, "mean": m, "ci95": float("nan")}
    sd = math.sqrt(sum((v - m) ** 2 for v in vals) / (n - 1))
    return {"n": n, "mean": m, "ci95": t975(n - 1) * sd / math.sqrt(n)}


def resolve_seeds(spec: str) -> List[int]:
    s = str(spec or "").strip().lower()
    from baselines.experiment_seeds import TEST_SEEDS, VALIDATION_SEEDS
    if s in ("", "validation", "val"):
        return [int(x) for x in VALIDATION_SEEDS]
    if s == "test":
        return [int(x) for x in TEST_SEEDS]
    return [int(x) for x in s.replace(";", ",").split(",") if x.strip()]


def read_rows(paths: Sequence[str]) -> List[Dict[str, str]]:
    rows: List[Dict[str, str]] = []
    for p in paths:
        if os.path.isfile(p):
            with open(p, newline="", encoding="utf-8") as fh:
                rows.extend(csv.DictReader(fh))
    return rows


def aggregate(rows: Sequence[Dict[str, str]], metric: str = "avg_time_in_system",
              lower_is_better: bool = True, max_collisions: Optional[float] = None,
              extra: Sequence[str] = ("collisions_total", "teleports_total", "insertion_backlog",
                                      "od_rewrites", "avg_travel_time", "uncensored_avg_travel_time")):
    groups: Dict[str, List[Dict[str, str]]] = {}
    for r in rows:
        groups.setdefault(r.get("checkpoint_path") or r.get("checkpoint", "?"), []).append(r)

    def col(rs, k):
        out = []
        for r in rs:
            try:
                out.append(float(r.get(k, "nan")))
            except (TypeError, ValueError):
                pass
        return out

    summary = []
    for ck, rs in sorted(groups.items()):
        entry = {"checkpoint": ck, "episodes": len(rs), metric: mean_ci(col(rs, metric))}
        for k in extra:
            entry[k] = mean_ci(col(rs, k))
        summary.append(entry)
    eligible = [e for e in summary if math.isfinite(e[metric]["mean"]) and (
        max_collisions is None or not math.isfinite(e["collisions_total"]["mean"])
        or e["collisions_total"]["mean"] <= float(max_collisions))]
    best = None
    if eligible:
        best = (min if lower_is_better else max)(eligible, key=lambda e: e[metric]["mean"])
    return summary, best


def main(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    passthrough: List[str] = []
    if "--" in argv:
        k = argv.index("--")
        argv, passthrough = argv[:k], argv[k + 1:]
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--checkpoints", nargs="+", required=True, help="paths or glob patterns")
    ap.add_argument("--seeds", default="validation")
    ap.add_argument("--workers", type=int, default=2)
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--metric", default="avg_time_in_system")
    ap.add_argument("--higher-is-better", action="store_true")
    ap.add_argument("--max-collisions", type=float, default=None,
                    help="collision gate on the per-episode mean (e.g. 0 for Stage-S comparisons)")
    ap.add_argument("--demand-randomize", action="store_true",
                    help="held-out randomized demand instances (seeded by the eval seed)")
    ap.add_argument("--python", default=sys.executable)
    ap.add_argument("--aggregate-only", action="store_true")
    a = ap.parse_args(argv)
    ckpts: List[str] = []
    for pat in a.checkpoints:
        ckpts.extend(sorted(glob.glob(pat)) or ([pat] if os.path.isfile(pat) else []))
    ckpts = list(dict.fromkeys(os.path.abspath(c) for c in ckpts))
    seeds = resolve_seeds(a.seeds)
    os.makedirs(a.out_dir, exist_ok=True)
    tasks = []
    for ck in ckpts:
        tag = os.path.splitext(os.path.basename(ck))[0]
        for sd in seeds:
            out_csv = os.path.join(a.out_dir, f"{tag}__seed{sd}.csv")
            log = os.path.join(a.out_dir, f"{tag}__seed{sd}.log")
            cmd = [a.python, os.path.join(ROOT, "train", "train_RL.py"), *passthrough,
                   "--num-envs", "1", "--eval-only", "--eval-checkpoint", ck,
                   "--eval-seeds", str(sd), "--eval-out", out_csv]
            if a.demand_randomize:
                cmd.append("--eval-demand-randomize")
            tasks.append((cmd, out_csv, log))

    def run(task):
        cmd, out_csv, log = task
        if os.path.isfile(out_csv):
            return 0
        with open(log, "w", encoding="utf-8") as fh:
            return subprocess.run(cmd, stdout=fh, stderr=subprocess.STDOUT, cwd=ROOT).returncode

    if not a.aggregate_only and tasks:
        print(f"[evaluate] {len(ckpts)} checkpoint(s) x {len(seeds)} seed(s) = {len(tasks)} run(s), "
              f"workers={a.workers}", flush=True)
        with ThreadPoolExecutor(max_workers=max(1, int(a.workers))) as pool:
            codes = list(pool.map(run, tasks))
        failed = sum(1 for c in codes if c != 0)
        if failed:
            print(f"[evaluate] {failed} run(s) failed; see *.log in {a.out_dir}", flush=True)
    rows = read_rows([t[1] for t in tasks] or glob.glob(os.path.join(a.out_dir, "*.csv")))
    summary, best = aggregate(rows, metric=a.metric, lower_is_better=not a.higher_is_better,
                              max_collisions=a.max_collisions)
    with open(os.path.join(a.out_dir, "summary.json"), "w", encoding="utf-8") as fh:
        json.dump({"metric": a.metric, "seeds": seeds, "summary": summary, "best": best}, fh, indent=2)
    for e in summary:
        m = e[a.metric]
        print(f"{os.path.basename(e['checkpoint'])}: {a.metric}={m['mean']:.2f} +- {m['ci95']:.2f} "
              f"(n={m['n']}), collisions={e['collisions_total']['mean']:.2f}")
    if best:
        print(f"[evaluate] BEST: {best['checkpoint']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
