#!/usr/bin/env python3
"""Cleanly roll back a VECTOR / no_vlm training run to Stage-S Best before Stage-Lon.

Supports the exact same path & vision flags as ``train/train_RL.py``:
  - ``--sumocfg environment/sumo_net/3-leg(3phases)/3-leg(3phases).sumocfg``
    (or ``--scenario 3-leg(3phases)`` / ``3leg_3phases`` / ``4leg_4phases`` / ``5leg_5phases``)
  - ``--no-vlm`` / ``--no-vision`` → automatically maps to flat ``results/train/no_vlm/<scenario>/seed_<N>``
  - ``--all-cav-soft-platoon`` → maps to ``allcav_softplatoon`` / ``allcav_softplatoon_no_vlm``
  - ``--seed <N>`` (auto-detects single existing ``seed_*`` folder if omitted, or defaults to 7)
  - ``--checkpoint-dir`` / ``--tb-root`` explicit overrides

Note: ``train/train_RL.py --restart-stage-lon`` now also performs full downstream checkpoint
archiving natively in-process, so this standalone script is an optional pre-flight / dry-run tool.
"""
from __future__ import annotations

import argparse
import datetime as _dt
import os
import re
import shutil
import sys
from pathlib import Path
from typing import List, Optional, Tuple

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import numpy as np
import yaml

from baselines.allcav_softplatoon import apply_allcav_soft_platoon_args, is_allcav_mode
from baselines.fixed_timing.scenarios import canonical_scenario_key, resolve_sumocfg
from baselines.result_paths import (
    RESULTS_ROOT,
    VISION_MODE_FULL,
    VISION_MODE_NONE,
    VISION_MODE_ONLY_LAT,
    VISION_MODE_ONLY_LON,
    VISION_MODE_ONLY_SIGNAL,
    discover_tb_run_for_resume,
    infer_scenario_key,
    migrate_flat_tb_events_into_run,
    resolve_results_method,
    train_ckpt_dir,
    train_run_dir,
    train_tb_dir,
)
from baselines.tb_curve_sanitize import (
    patch_checkpoint_tb_run,
    sanitize_tb_for_resume,
)
from baselines.train_resume import (
    read_resume_meta,
    resume_tb_run_name,
    write_resume_meta,
)

STAGE_S_CANDIDATES: Tuple[str, ...] = (
    "best_stage_s.pt",
    "pre_tail_best_stage_s.pt",
    "temp_ungated_best_stage_s.pt",
)

DOWNSTREAM_CHECKPOINT_FILES: Tuple[str, ...] = (
    "best_stage_lon.pt",
    "best_joint_lon_sig.pt",
    "best_stage_lat.pt",
    "best_joint_all.pt",
    "best_final.pt",
    "pre_joint_lon_sig.pt",
    "pre_joint_all.pt",
    "temp_ungated_best_stage_lon.pt",
    "temp_ungated_best_stage_jointlonsig.pt",
    "temp_ungated_best_stage_lat.pt",
    "temp_ungated_best_stage_jointall.pt",
    "superseded_best_stage_lon.pt",
    "superseded_best_stage_jointlonsig.pt",
    "superseded_best_stage_lat.pt",
    "superseded_best_stage_jointall.pt",
)

_EP_RE = re.compile(r"^episode_(\d+)\.pt$")
_SEED_RE = re.compile(r"^seed_(\d+)$")


def _load_config() -> dict:
    cfg_path = PROJECT_ROOT / "experiments" / "config.yaml"
    if cfg_path.is_file():
        with cfg_path.open("r", encoding="utf-8") as fh:
            return yaml.safe_load(fh) or {}
    return {}


def _load_default_stage_s_episodes(quick: bool = False) -> int:
    if quick:
        return 120
    tr = (_load_config().get("training") or {})
    if tr.get("stage_s_episodes") is not None:
        return int(tr["stage_s_episodes"])
    return 250


def _load_default_vlm_model() -> str:
    vlm = (_load_config().get("vlm") or {})
    if vlm.get("model"):
        return str(vlm["model"])
    return "Qwen/Qwen2.5-VL-7B-Instruct"


def resolve_target_paths(
    *,
    method: str = "",
    scenario: str = "",
    sumocfg: str = "",
    seed: Optional[int] = None,
    no_vlm: bool = False,
    no_vision: bool = False,
    only_signal_vlm_vision: bool = False,
    only_lon_vlm_vision: bool = False,
    only_lat_vlm_vision: bool = False,
    all_cav_soft_platoon: bool = False,
    vlm_model: str = "",
    checkpoint_dir: Optional[Path] = None,
    tb_root_override: Optional[Path] = None,
    root: Optional[Path] = None,
) -> dict:
    """Resolve (method, scenario_key, seed, sumocfg, ckpt_dir, run_dir, tb_root) identically to train_RL.py."""
    vlm_model_eff = str(vlm_model or _load_default_vlm_model()).strip()

    if checkpoint_dir is not None:
        ckpt_p = Path(checkpoint_dir).resolve()
        run_p = ckpt_p.parent
        tb_p = Path(tb_root_override).resolve() if tb_root_override is not None else (run_p / "tb")
        inferred_seed = int(seed) if seed is not None and int(seed) > 0 else 7
        m_s = _SEED_RE.match(run_p.name)
        if m_s:
            inferred_seed = int(m_s.group(1))
        scen_guess = canonical_scenario_key(scenario or sumocfg or run_p.parent.name)
        sumocfg_eff = sumocfg or _default_sumocfg_for_scenario(scen_guess)
        return {
            "method": method or ("no_vlm" if (no_vlm or no_vision) else "VECTOR"),
            "scenario_key": scen_guess,
            "seed": inferred_seed,
            "sumocfg": sumocfg_eff,
            "vlm_model": vlm_model_eff,
            "no_vlm": bool(no_vlm or no_vision),
            "ckpt_dir": ckpt_p,
            "run_dir": run_p,
            "tb_root": tb_p,
        }

    # Resolve vision mode identically to train_RL.resolve_vision_mode
    if only_signal_vlm_vision:
        vision_mode, use_vlm, sig_vis = VISION_MODE_ONLY_SIGNAL, False, True
    elif only_lon_vlm_vision:
        vision_mode, use_vlm, sig_vis = VISION_MODE_ONLY_LON, True, False
    elif only_lat_vlm_vision:
        vision_mode, use_vlm, sig_vis = VISION_MODE_ONLY_LAT, True, False
    elif no_vision or no_vlm:
        vision_mode, use_vlm, sig_vis = VISION_MODE_NONE, False, False
    else:
        vision_mode, use_vlm, sig_vis = VISION_MODE_FULL, True, True

    raw_method = str(method or "").strip()
    dummy_ns = argparse.Namespace(
        all_cav_soft_platoon=bool(all_cav_soft_platoon),
        results_method=raw_method or "VECTOR",
        leaders_only=False,
        cav_rl_leaders_only=None,
    )
    if is_allcav_mode(dummy_ns):
        apply_allcav_soft_platoon_args(dummy_ns, use_vlm=bool(use_vlm or sig_vis))
        raw_method = str(dummy_ns.results_method)

    # Auto-discover from results/train if user omitted method/scenario/sumocfg and only 1 run exists
    results_base = Path(root).resolve() if root is not None else RESULTS_ROOT
    if not raw_method and not scenario and not sumocfg and not (
        no_vlm or no_vision or only_signal_vlm_vision or only_lon_vlm_vision or only_lat_vlm_vision
    ):
        found_ckpts = sorted(
            p.parent for p in (results_base / "train").rglob("best_stage_s.pt")
            if "_archive_" not in str(p)
        ) if (results_base / "train").is_dir() else []
        if len(found_ckpts) == 1:
            ckpt_p = found_ckpts[0].resolve()
            run_p = ckpt_p.parent
            tb_p = Path(tb_root_override).resolve() if tb_root_override is not None else (run_p / "tb")
            m_s = _SEED_RE.match(run_p.name)
            det_seed = int(m_s.group(1)) if m_s else (int(seed) if seed else 7)
            scen_key = canonical_scenario_key(run_p.parent.name)
            rel_parts = run_p.relative_to(results_base / "train").parts
            det_method = rel_parts[0] if rel_parts else "no_vlm"
            return {
                "method": det_method,
                "scenario_key": scen_key,
                "seed": det_seed,
                "sumocfg": _default_sumocfg_for_scenario(scen_key),
                "vlm_model": vlm_model_eff,
                "no_vlm": det_method.endswith("no_vlm"),
                "ckpt_dir": ckpt_p,
                "run_dir": run_p,
                "tb_root": tb_p,
            }

    eff_method = resolve_results_method(
        raw_method or "VECTOR",
        use_vlm=use_vlm,
        vlm_model=vlm_model_eff,
        vision_mode=vision_mode,
    )
    if scenario:
        scen_key = canonical_scenario_key(scenario)
    elif sumocfg:
        scen_key = infer_scenario_key(sumocfg)
    else:
        cfg_sumo = str((_load_config().get("simulation") or {}).get("sumocfg", "") or "")
        scen_key = infer_scenario_key(cfg_sumo) if cfg_sumo else "3leg_3phases"

    sumocfg_eff = sumocfg or _default_sumocfg_for_scenario(scen_key)

    # Seed resolution: if seed is None or <= 0, auto-detect single seed_* dir or default to 7 (train_RL default)
    eff_seed = int(seed) if (seed is not None and int(seed) > 0) else 0
    if eff_seed <= 0:
        probe_ckpt = train_ckpt_dir(eff_method, scen_key, 7, vlm_model=vlm_model_eff, root=results_base)
        scen_dir = probe_ckpt.parent.parent
        if scen_dir.is_dir():
            seed_dirs = sorted(
                int(_SEED_RE.match(d.name).group(1))
                for d in scen_dir.iterdir()
                if d.is_dir() and _SEED_RE.match(d.name)
            )
            if len(seed_dirs) == 1:
                eff_seed = seed_dirs[0]
            elif 7 in seed_dirs:
                eff_seed = 7
            elif seed_dirs:
                raise ValueError(
                    f"Multiple seeds found under {scen_dir}: {seed_dirs}. "
                    f"Please pass --seed <N> explicitly."
                )
        if eff_seed <= 0:
            eff_seed = 7

    ckpt_p = train_ckpt_dir(eff_method, scen_key, eff_seed, vlm_model=vlm_model_eff, root=results_base)
    run_p = train_run_dir(eff_method, scen_key, eff_seed, vlm_model=vlm_model_eff, root=results_base)
    tb_p = (
        Path(tb_root_override).resolve()
        if tb_root_override is not None
        else train_tb_dir(eff_method, scen_key, eff_seed, vlm_model=vlm_model_eff, root=results_base)
    )
    return {
        "method": eff_method,
        "scenario_key": scen_key,
        "seed": eff_seed,
        "sumocfg": sumocfg_eff,
        "vlm_model": vlm_model_eff,
        "no_vlm": (vision_mode == VISION_MODE_NONE),
        "ckpt_dir": ckpt_p,
        "run_dir": run_p,
        "tb_root": tb_p,
    }


def _default_sumocfg_for_scenario(scenario_key: str) -> str:
    try:
        abs_p = Path(resolve_sumocfg(scenario_key))
        return str(abs_p.relative_to(PROJECT_ROOT)).replace("\\", "/")
    except Exception:
        return "environment/sumo_net/3-leg(3phases)/3-leg(3phases).sumocfg"


def _pick_stage_s_checkpoint(ckpt_dir: Path, explicit_name: str = "") -> Path:
    if explicit_name:
        cand = Path(explicit_name)
        if not cand.is_absolute():
            cand = ckpt_dir / explicit_name
        if not cand.is_file():
            raise FileNotFoundError(f"Explicit Stage-S checkpoint not found: {cand}")
        return cand
    for fname in STAGE_S_CANDIDATES:
        cand = ckpt_dir / fname
        if cand.is_file():
            return cand
    raise FileNotFoundError(
        f"No Stage-S best checkpoint found in {ckpt_dir}; looked for {STAGE_S_CANDIDATES}"
    )


def _trim_episode_metrics_npz(run_dir: Path, archive_dir: Path, keep_episodes: int, dry_run: bool) -> bool:
    npz_path = run_dir / "episode_metrics.npz"
    if not npz_path.is_file():
        return False
    with np.load(npz_path, allow_pickle=False) as data:
        arrays = {k: data[k] for k in data.files}
    if "episode_index" in arrays:
        ep_idx = np.asarray(arrays["episode_index"]).reshape(-1)
        mask = ep_idx <= int(keep_episodes)
        if bool(np.all(mask)):
            return False
        n_rows = len(ep_idx)
        trimmed = {
            k: (arr[mask] if arr.ndim >= 1 and arr.shape[0] == n_rows else arr)
            for k, arr in arrays.items()
        }
    else:
        total = arrays.get("total_reward")
        if total is None or total.shape[0] <= int(keep_episodes):
            return False
        n_rows = total.shape[0]
        trimmed = {
            k: (arr[: int(keep_episodes)] if arr.ndim >= 1 and arr.shape[0] == n_rows else arr)
            for k, arr in arrays.items()
        }
    if dry_run:
        return True
    archive_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(npz_path, archive_dir / "episode_metrics.before_lon_restart.npz")
    tmp_npz = npz_path.with_suffix(".tmp.npz")
    np.savez_compressed(tmp_npz, **trimmed)
    os.replace(tmp_npz, npz_path)
    return True


def prepare_stage_lon_restart(
    *,
    method: str = "",
    scenario: str = "",
    sumocfg: str = "",
    seed: Optional[int] = None,
    no_vlm: bool = False,
    no_vision: bool = False,
    only_signal_vlm_vision: bool = False,
    only_lon_vlm_vision: bool = False,
    only_lat_vlm_vision: bool = False,
    all_cav_soft_platoon: bool = False,
    vlm_model: str = "",
    checkpoint_dir: Optional[Path] = None,
    tb_root_override: Optional[Path] = None,
    stage_s_episodes: Optional[int] = None,
    source_ckpt_name: str = "",
    quick: bool = False,
    dry_run: bool = False,
    root: Optional[Path] = None,
) -> dict:
    resolved = resolve_target_paths(
        method=method,
        scenario=scenario,
        sumocfg=sumocfg,
        seed=seed,
        no_vlm=no_vlm,
        no_vision=no_vision,
        only_signal_vlm_vision=only_signal_vlm_vision,
        only_lon_vlm_vision=only_lon_vlm_vision,
        only_lat_vlm_vision=only_lat_vlm_vision,
        all_cav_soft_platoon=all_cav_soft_platoon,
        vlm_model=vlm_model,
        checkpoint_dir=checkpoint_dir,
        tb_root_override=tb_root_override,
        root=root,
    )
    ckpt_dir: Path = resolved["ckpt_dir"]
    run_dir: Path = resolved["run_dir"]
    tb_root: Path = resolved["tb_root"]
    eff_method: str = resolved["method"]
    scen_key: str = resolved["scenario_key"]
    eff_seed: int = resolved["seed"]
    vlm_model_eff: str = resolved["vlm_model"]

    completed_s_eps = (
        int(stage_s_episodes)
        if stage_s_episodes is not None
        else _load_default_stage_s_episodes(quick=quick)
    )
    if completed_s_eps <= 0:
        raise ValueError(f"stage_s_episodes must be positive; got {completed_s_eps}")

    if not ckpt_dir.is_dir():
        hint_dirs = []
        train_base = (Path(root).resolve() if root is not None else RESULTS_ROOT) / "train"
        if train_base.is_dir():
            hint_dirs = sorted(str(p.parent) for p in train_base.rglob("best_stage_s.pt") if "_archive_" not in str(p))
        hint_msg = f" Discovered Stage-S checkpoint dirs: {hint_dirs}" if hint_dirs else ""
        raise FileNotFoundError(f"Checkpoint directory does not exist: {ckpt_dir}.{hint_msg}")

    src_s_ckpt = _pick_stage_s_checkpoint(ckpt_dir, explicit_name=source_ckpt_name)
    import torch

    s_payload = torch.load(str(src_s_ckpt), map_location="cpu", weights_only=False)
    prev_meta = read_resume_meta(ckpt_dir)

    tb_run = resume_tb_run_name(ckpt_dir, ckpt=s_payload if isinstance(s_payload, dict) else None)
    if not tb_run and tb_root.is_dir():
        tb_run = discover_tb_run_for_resume(
            eff_method, scen_key, int(eff_seed), vlm_model=vlm_model_eff, root=root
        )
        if not tb_run:
            subdirs = sorted(
                [d.name for d in tb_root.iterdir() if d.is_dir() and not d.name.startswith(".")]
            )
            if subdirs:
                tb_run = subdirs[-1]

    stamp = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    archive_dir = ckpt_dir / f"_archive_before_lon_restart_{stamp}"
    archived_files: List[str] = []

    to_move: List[Path] = []
    latest_pt = ckpt_dir / "latest.pt"
    if latest_pt.is_file() and latest_pt.resolve() != src_s_ckpt.resolve():
        to_move.append(latest_pt)
    for fname in DOWNSTREAM_CHECKPOINT_FILES:
        p = ckpt_dir / fname
        if p.is_file() and p.resolve() != src_s_ckpt.resolve():
            to_move.append(p)
    for p in sorted(ckpt_dir.iterdir()):
        if not p.is_file():
            continue
        m = _EP_RE.match(p.name)
        if m and int(m.group(1)) > completed_s_eps and p.resolve() != src_s_ckpt.resolve():
            to_move.append(p)

    if not dry_run:
        archive_dir.mkdir(parents=True, exist_ok=True)
        prev_resume_json = ckpt_dir / "resume.json"
        if prev_resume_json.is_file():
            shutil.copy2(prev_resume_json, archive_dir / "resume.before_lon_restart.json")
        for p in to_move:
            dst = archive_dir / p.name
            shutil.move(str(p), str(dst))
            archived_files.append(p.name)
        shutil.copy2(src_s_ckpt, latest_pt)
        patch_checkpoint_tb_run(
            latest_pt,
            tb_run=tb_run or "",
            episode=completed_s_eps,
        )
        write_resume_meta(ckpt_dir, completed_s_eps, tb_run=tb_run)
    else:
        archived_files = [p.name for p in to_move]

    tb_result = {"ok": True, "skipped": True, "tb_run": tb_run}
    if tb_run and tb_root.is_dir():
        if not dry_run:
            tb_run_dir = tb_root / tb_run
            tb_run_dir.mkdir(parents=True, exist_ok=True)
            migrate_flat_tb_events_into_run(tb_root, tb_run_dir)
            tb_result = sanitize_tb_for_resume(
                tb_root,
                str(tb_run),
                completed_episodes=int(completed_s_eps),
            )
        else:
            tb_result = {
                "ok": True,
                "dry_run": True,
                "tb_run": str(tb_run),
                "completed_episodes": int(completed_s_eps),
            }

    trimmed_npz = _trim_episode_metrics_npz(
        run_dir, archive_dir, keep_episodes=completed_s_eps, dry_run=dry_run
    )

    return {
        "ok": True,
        "dry_run": bool(dry_run),
        "method": eff_method,
        "scenario_key": scen_key,
        "seed": int(eff_seed),
        "sumocfg": resolved["sumocfg"],
        "no_vlm": resolved["no_vlm"],
        "vlm_model": vlm_model_eff,
        "checkpoint_dir": str(ckpt_dir),
        "source_stage_s_ckpt": src_s_ckpt.name,
        "previous_resume_meta": prev_meta,
        "new_episode": int(completed_s_eps),
        "next_episode_1based": int(completed_s_eps) + 1,
        "tb_root": str(tb_root),
        "tb_run": tb_run,
        "tb_sanitize": tb_result,
        "archived_files": archived_files,
        "archive_dir": str(archive_dir),
        "trimmed_episode_metrics_npz": bool(trimmed_npz),
    }


def print_ablation_matrix(sumocfg: str, seed: int, vlm_model: str, *, is_no_vlm: bool = False) -> None:
    base = f"python train/train_RL.py --sumocfg \"{sumocfg}\" --seed {int(seed)}"
    resume_flag = "--restart-stage-lon"
    if is_no_vlm:
        print("\n=== Recommended Direct Resume Command for Your Active no_vlm Run ===")
        print(f"    {base} --no-vision {resume_flag}")
    print("\n=== 4-Tier Runnable Ablation Commands (matching your scenario & seed) ===")
    print(
        "  [Tier-1 Legacy MAPPO Baseline (all P0/P1 off, no VLM)]\n"
        f"    {base} --no-vision --results-method legacy_mappo "
        "--no-crash-attribution --no-green-glide-fix --no-lagrangian-safety "
        "--no-cacc-soft-platoon --no-goal-speed-cond --no-cross-approach-baseline "
        "--no-freeze-team-critic-in-s"
    )
    print(
        "  [Tier-2 P0 Bugfixes Only (Crash Attribution + Green-Glide + Shield-Only Dual + Freeze-S, P1 off)]\n"
        f"    {base} --no-vision --results-method mappo_p0 "
        "--crash-attribution --green-glide-fix --lagrangian-safety --freeze-team-critic-in-s "
        "--no-cacc-soft-platoon --no-goal-speed-cond --no-cross-approach-baseline"
    )
    print(
        "  [Tier-3 P0 + P1 Full Mechanism (CACC w/ 0.25 Floor & IDM Cap + Continuous Glide Goal + Approach Baseline, no VLM)]\n"
        f"    {base} --no-vision {resume_flag}"
    )
    print(
        "  [Tier-4 Full VECTOR v3 (P0 + P1 + VLM Scene/Signal Semantics, thinking_mode=off)]\n"
        f"    {base} --results-method VECTOR --vlm-model \"{vlm_model}\" --vlm-thinking-mode off "
        f"{resume_flag}"
    )


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Reset checkpoints/resume.json, latest.pt, and TensorBoard to Stage-S Best for Stage-Lon."
    )
    parser.add_argument("--method", "--results-method", dest="method", type=str, default="")
    parser.add_argument("--scenario", type=str, default="")
    parser.add_argument("--sumocfg", type=str, default="")
    parser.add_argument("--seed", type=int, default=0, help="Run seed (0 = auto-detect single seed_* dir or default 7)")
    parser.add_argument("--no-vlm", action="store_true", help="Target flat results/train/no_vlm/<scenario>/seed_<N>")
    parser.add_argument("--no-vision", action="store_true", help="Alias for --no-vlm")
    parser.add_argument("--only-signal-vlm-vision", action="store_true")
    parser.add_argument("--only-lon-vlm-vision", action="store_true")
    parser.add_argument("--only-lat-vlm-vision", action="store_true")
    parser.add_argument("--all-cav-soft-platoon", action="store_true")
    parser.add_argument("--vlm-model", type=str, default="")
    parser.add_argument("--checkpoint-dir", type=str, default="")
    parser.add_argument("--tb-root", type=str, default="")
    parser.add_argument("--stage-s-episodes", type=int, default=0)
    parser.add_argument("--source-ckpt", type=str, default="")
    parser.add_argument("--quick", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    res = prepare_stage_lon_restart(
        method=args.method,
        scenario=args.scenario,
        sumocfg=args.sumocfg,
        seed=args.seed if args.seed > 0 else None,
        no_vlm=bool(args.no_vlm),
        no_vision=bool(args.no_vision),
        only_signal_vlm_vision=bool(args.only_signal_vlm_vision),
        only_lon_vlm_vision=bool(args.only_lon_vlm_vision),
        only_lat_vlm_vision=bool(args.only_lat_vlm_vision),
        all_cav_soft_platoon=bool(args.all_cav_soft_platoon),
        vlm_model=args.vlm_model,
        checkpoint_dir=Path(args.checkpoint_dir) if args.checkpoint_dir else None,
        tb_root_override=Path(args.tb_root) if args.tb_root else None,
        stage_s_episodes=args.stage_s_episodes if args.stage_s_episodes > 0 else None,
        source_ckpt_name=args.source_ckpt,
        quick=bool(args.quick),
        dry_run=bool(args.dry_run),
    )
    print("[restart_from_stage_s_best] Summary:")
    for k, v in res.items():
        print(f"  {k}: {v}")
    print_ablation_matrix(
        sumocfg=res["sumocfg"],
        seed=res["seed"],
        vlm_model=res["vlm_model"],
        is_no_vlm=bool(res["no_vlm"]),
    )


if __name__ == "__main__":
    main()
