# VECTOR v4 最优修改方案（基于 v3 全量代码审阅）

> 本文是对 VECTOR_optimal_v3 的完整诊断（共四轮）落地后的修改方案与实施说明。
> 原则：先保证"代码能正确运行、度量与评估可信"，再做"算法机理修正"，最后才是"需要重新设计与调参的研究性改动"。
> 每一项改动都有开关，可单独回退到 v3 行为，方便做消融。

---

## 一、总体策略：三个阶段

| 阶段 | 目标 | 本次状态 |
|---|---|---|
| 阶段 1 | 正确性 + 度量/评估有效性 + 低风险机理修正 + 性能 | **已实施**（默认开启） |
| 阶段 2 | 关键消融能力（检验 RL 与 VLM 的真实贡献） | **已实施**（开关提供，默认关闭） |
| 阶段 3 | 需要重新设计与重新调参的研究性改动 | **给出设计，未改默认训练路径**（见第五节） |

阶段 3 没有直接写进默认训练路径，原因是：这些改动会改变动作空间、价值函数结构或奖励语义，必须配合重新调参与对照实验，不能在无法运行 SUMO/torch 的条件下"盲改"。

---

## 二、阶段 1：已实施的修改

### 2.1 P0 正确性修复（不可回退，属于 bug）

| 问题 | 位置 | 修改 |
|---|---|---|
| `env_done_bool` 在赋值前被读取，`step()` 每次都抛 `UnboundLocalError` | `environment/marl_env.py` | 在 `sumo_env.step()` 之后立即定义 |
| 拉格朗日安全乘子读取 `training_stage`（从未赋值），对偶更新永不执行 | `environment/marl_env.py` | 改读 `_training_stage` |
| 拉格朗日惩罚用 δ²，而对偶变量跟踪的是干预率（指示函数） | 同上 | 默认 `lagrangian_penalty_mode: indicator`（惩罚 = η·1[干预]），可选 `squared` |
| SMDP 中 λ 用在决策步本身（提前一步） | `agents/mappo.py`、`train/train_RL.py` | λ 只在"下一步是新决策"时施加；与选项级 GAE 严格相等（单元测试验证） |
| 视觉语义缓存无年龄检查，过期结果可留存整个回合 | `environment/marl_env.py` | 统一走 `scheduler.features(t)`（带 `cache_max_age_s` 检查） |
| `get_state` 中残留的一行掩码构建（缩进错误） | `environment/SUMO_interface.py` | 删除（掩码在车队跟踪后统一重建） |

### 2.2 度量与评估有效性（默认开启，可回退）

| 问题（v3） | 修改（v4 默认） | 回退开关 |
|---|---|---|
| 排队长度 = max(DBSCAN 簇长度, 停驶车×7.5)，**移动车队被当作排队**，信号奖励惩罚 CAV 编队 | 只统计停驶车辆（v<0.5 m/s） | `--queue-mode legacy` |
| 5-leg 有 4 条仅由许可 `g` 链接服务的车道，信号奖励/观测完全看不到 | 纳入奖励车道集合 | `--no-include-permissive-lanes` |
| 绿灯预算 T 借 DBSCAN 副作用"顺带"为车队延长，且与到达时间无关 | T = clip(g1 + k·Lq + k_arr·N_arr)，N_arr = 关键车道上 10 s 内到达停车线的行驶车辆数 | `--green-arrival-k 0` |
| `--max-depart-delay 30`：插入失败超过 30 s 的车被**静默丢弃**，拥堵越重 KPI 越"好看" | 永不丢弃（内部用 100000 s） | `--max-depart-delay 30` |
| SUMO 默认不检测路口内碰撞，而纵向 RL 在路口内同样生效 | `--collision.check-junctions true` | `--no-collision-check-junctions` |
| HDV 救援在**任何模式**下都会 `changeTarget` 改写目的地；CAV 训练时也会改写 | 默认禁止 OD 改写（训练 = 评估） | `--allow-od-rewrite` |
| 0–200 m 内对**所有车型**禁止策略换道（导致困车与改写 OD） | 仅 CAV 保持车道，HDV 恢复 SUMO 自主换道 | `--hdv-keep-lane-control-zone` |
| 每个场景只有一个固定 trip 文件，训练/评估同一需求实例 | 按回合种子随机化需求：总量 ×U[0.9,1.1]、出发时刻 ±60 s 抖动；结果可复现 | `--no-demand-randomize` |
| `best_final.pt` 可能导出更早阶段（甚至 Stage-S，即 IDM 驾驶的 CAV） | 固定导出最完整阶段，并写 `best_final_meta.json` | `--final-select score` |
| ATT 只算已完成行程（右删失），无插入积压、无 OD 改写计数 | 新增 KPI：`avg_time_in_system`（按计划出发时刻计、含插入延误与未完成车辆）、`insertion_backlog`、`od_rewrites`、`uncensored_avg_travel_time`、`TTC_Exposure_s` | —（新增，不影响旧指标） |
| 实验元数据写的选择器名与实际不符；需求时窗写 1500 s，实际 1200 s | 修正为 `roll5_phys_coll_gate`、1200 s | — |

**论文报告建议**：主指标用 `Metrics/avg_time_in_system`（v4 新增）；同时报告 `insertion_backlog`、`od_rewrites`、碰撞数（含路口）和 `TTC_Exposure_s`。旧的 `Average_Travel_Time` 语义未改（仅已完成行程），仅作参考。

### 2.3 算法机理修正（默认开启，可回退）

| 问题（v3） | 修改（v4 默认） | 回退开关 |
|---|---|---|
| **相对优势反合作**：基线 = 同进口道均值（含自车与后车），伤害后车会抬高自车优势（单元测试已复现） | `coop_xapp`：协作奖励 r̃ᵢ = rᵢ + κ·mean(同进口道同伴)；基线取**其他进口道**的 r̃（与自车动作无关），不足 2 车时用 rollout 常数基线 | `--cav-credit-mode relative` |
| Dual-clip 系数 c = 1+2ε = 1.4，大量负优势样本梯度被截断 | c = 3（原论文值） | `--dual-clip-c 1.4` |
| 回报归一化 EMA α=0.15 快速漂移，原尺度价值每次 flush 后跳变 | PopArt 输出保持（重标定 team/signal 头最后一层） | `--no-popart` |
| Lat 软启动用混合分布采样，PPO 比值初值 = 1/β，KL 早停使软启动期 Lat 几乎不更新 | 取消混合；改为 keep logit 偏置初始化（初始 P(keep)≈0.69），行为策略 = 目标策略 | 环境变量 `LAT_SOFT_START_MIXTURE=1`、`LAT_KEEP_LOGIT_BIAS_INIT=0` |
| 碰撞终止惩罚 −1（等于普通步奖励下限） | −5 | `--crash-terminal-penalty -1` |
| 信号教师：幻觉类视觉标签（blockage/special_vehicle）获得最高 CE 权重 1.0 | 只按仿真可验证的 `spill_proxy` 加权（≥0.5 → 1.0，否则 0.3） | `SIGNAL_TEACHER_SEVERITY_LEGACY=1` |
| VLM 输出缺 `confidence`/`valid` 时默认 0.85/1.0（高于 0.6 门限） | 缺失即视为无效（残差关闭） | — |
| 本地推理服务忽略请求的 `model` 字段，结果可能"标 7B 实跑 3B" | 服务端返回实际 `model` 并对不一致报警；客户端记录 `served_model` | — |
| 提示词写残差系数 0.02，代码用 0.05 | 提示词改为 0.05 | — |
| CLI `--joint-*-episodes` 被静默覆盖 | 显式给出时生效 | — |

### 2.4 性能

| 问题（v3） | 修改 |
|---|---|
| actor 从不使用图，却在每次前向/每个 minibatch 构建 PyG Batch | actor 路径不再构图（`_batch_observations(..., need_graph=False)`） |
| 排队/等待/近停车线统计每次调用都遍历全网车辆（每步数十次） | 每步构建一次"车道→车辆"索引，所有统计共用 |

---

## 三、阶段 2：已提供的关键消融开关

| 消融 | 命令 | 回答的问题 |
|---|---|---|
| 规则栈 Δa≡0 | `--ablate-zero-lon-residual`（或 `VECTOR_ABLATE_ZERO_LON_RESIDUAL=1`） | 纵向 RL 残差是否真有贡献？ |
| VLM vs 同规则启发式 | `--vlm-heuristic` | VLM 是否优于提示词里那张规则表？ |
| 规则教师 + 无视觉 | `--no-vision --rule-signal-teacher` | 主方法相对 no-VLM 的提升来自"视觉"还是"有教师"？ |
| v3 信用分配 | `--cav-credit-mode relative` | 协作信用分配的效果 |
| v3 排队定义 | `--queue-mode legacy --green-arrival-k 0` | 度量修正的影响 |

**完整 v3 兼容模式**（用于 A/B 对照；P0 bug 修复与 SMDP λ 修正不可回退）：

```bash
LAT_SOFT_START_MIXTURE=1 LAT_KEEP_LOGIT_BIAS_INIT=0 SIGNAL_TEACHER_SEVERITY_LEGACY=1 \
python train/train_RL.py --sumocfg <cfg> --seed 7 \
  --queue-mode legacy --no-include-permissive-lanes --green-arrival-k 0 \
  --max-depart-delay 30 --no-collision-check-junctions --allow-od-rewrite \
  --hdv-keep-lane-control-zone --no-demand-randomize --cav-credit-mode relative \
  --dual-clip-c 1.4 --no-popart --final-select score --crash-terminal-penalty -1 \
  --lagrangian-penalty-mode squared
```

---

## 四、实验协议建议

1. **从头重新训练**。v4 改变了奖励语义（排队定义、碰撞惩罚、信用分配），v3 的检查点结构可以加载，但结果不可比。
2. **训练**：保持需求随机化开启；每个场景 ≥5 个种子。
3. **评估**：对 SUMO 环境调用 `configure_control(eval_mode=True)`，即禁止 OD 改写、使用固定需求；若要评估留出需求，再加 `demand_randomize=True`，并使用与训练不相交的种子。按种子报告均值 ± 95% 置信区间。
4. **跨方法比较**：只比较物理 KPI。奖励曲线仅信号奖励可比（基线用的是旧版 `BaseReward`）。
5. **首次运行冒烟测试**：
   ```bash
   python tools/static_check.py .
   python -m unittest discover -s tests -v
   python train/train_RL.py --quick --episodes 6 --sumocfg "environment/sumo_net/4-leg(4phases)/4-leg(4phases).sumocfg"
   ```
   日志中应看到：`[v4] credit=coop_xapp ...`、`[SUMO] demand randomized seed=...`；在 5-leg 场景还应看到 `permissive-only approach lane(s)`。
6. **注意**：开启路口碰撞检测后，计入的碰撞数可能上升。Stage-S 的最佳模型门限是"0 碰撞"，如果 Stage-S 一直无法保存 `best_stage_s.pt`，请先检查碰撞日志，确认是否为路口几何造成的误报，再决定是否用 `--no-collision-check-junctions`。

---

## 五、阶段 3：需要重新设计的研究性改动（给出设计，未改默认路径）

### 5.1 SPaT 一致性与信号"承诺"
- **问题**：`_time_to_green` 按静态程序推算，而控制器是无序选相位、动态时长、每 5 s 可提前切换。
- **设计**：信号动作改为"(下一相位, 本相位时长档位)"的组合离散动作，在绿灯开始时承诺最短剩余绿灯与下一相位；把承诺的 SPaT 写入 CAV 观测和 GLOSA。
- **配套**：T 改为观测特征，只保留 gmax 作为硬约束；公平性改用约束（拉格朗日）处理。

### 5.2 智能体条件化 critic / HAPPO
- **设计**：critic 增加 agent 头 V(g(s) ⊕ oᵢ)。全局图嵌入在采集时计算并以 detach 方式存储，agent 头用每车的协作回报训练，并替换 `coop_xapp` 中的常数/跨进口道基线。
- 异构的信号与 CAV 智能体可考虑 HAPPO 的顺序更新，以替代手工课程和锚点/回滚补丁。

### 5.3 奖励重构
- 纵向奖励改为代价型：−Δ延误 − w_f·油耗 − w_j·jerk² − 安全代价，用以消除"正单步奖励 + 驶离即终止"带来的滞留激励。
- GLOSA 和滑行改用势函数整形 F = γΦ(s') − Φ(s)。
- 横向奖励改为"换道后 10–20 s 内自身旅行时间变化 + κ × 目标车道后车延误变化"。

### 5.4 折扣按秒定义
- γ_step = γ_sec^Δt。目标视野 40–60 s 时 γ_step ≈ 0.995–0.9967；需配合 λ 与学习率重新调参。

### 5.5 VLM 的定位
在当前场景中，VLM 没有超出状态向量的信息：场景中没有事件；BEV 只覆盖 ±90 m，并且会"美化"车距；提示词本质上是规则表。可选的方向：
- **(a)** 构造事故、抛锚车、车道封闭、特种车辆等事件场景，并让 RL 只使用现实可得的状态（检测线圈 + 30% V2X），使视觉通道获得真正的信息增益；
- **(b)** 把 VLM 移到离线做奖励与课程设计；
- **(c)** 保留在线调用，但改为同步、确定性推理，并用 GPU。

### 5.6 训练中的验证回合
- 每 N 回合用留出需求种子跑确定性回合，在验证集上选择最佳模型，替代"在训练回合上选择"。

---

## 六、本次修改的验证情况

- `tools/static_check.py`：全项目编译通过；"变量先读后赋值"检查为 0 问题。该工具在原版 v3 上恰好只报出 `env_done_bool` 一处，无误报。
- **21 个单元/集成测试全部通过**（无需 SUMO/torch）：
  - SMDP-GAE 与选项级公式严格相等；无掩码时等于标准 GAE；
  - v4 的 `compute_gae_for_rollout` 在 `relative` 模式下与 v3 源码**逐位一致**；`coop_xapp` 在含保持步的 rollout 上正常运行；
  - 协作信用分配的符号性质：伤害后车会降低自车优势（v3 中则会提高）；
  - 用伪 traci 加载真实的 `SUMO_interface.py`，验证停驶排队、许可车道、按到达延长绿灯、等待统计、车道索引缓存、在系统内时间、运行参数、`configure_control`；
  - 需求随机化的可复现性与排序；HDV 在控制区可换道；教师权重。
- **未做**：沙箱没有 SUMO 与 torch，无法端到端训练。请先按第四节第 5 条做冒烟测试。
