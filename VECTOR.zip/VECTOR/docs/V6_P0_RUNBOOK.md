# v6-P0 关口实验手册

## 1. 自检
    python tools/static_check.py .
    python -m unittest discover -s tests -v        # 期望 103 项，1 项按设计跳过

## 2. 4-leg 关口实验（先 --dry-run 看命令）
    python scripts/p0_gate.py --sumocfg "environment/sumo_net/4-leg(4phases)/4-leg(4phases).sumocfg" --dry-run
    python scripts/p0_gate.py --sumocfg "environment/sumo_net/4-leg(4phases)/4-leg(4phases).sumocfg" --lon-episodes 6 --control-seconds 600 --seed 7 --workers 4

`--` 之后的参数原样传给每组训练，例如 `-- --torch-threads 2 --sumo-diag-dir logs/diag`。
结果：`logs/p0_gate/<场景>_seed7/gate_summary.md`（另有 csv 与各组 .log / .cmd.txt）。
只重新解析已有日志：`python scripts/p0_gate.py --parse-only --out-dir logs/p0_gate/<场景>_seed7`。

## 3. 判读
- GATE-1 可行性：G2_p0 的 TIS ≤ 1.02 × G0_native，积压/传送/碰撞不变差。
- GATE-2 学习：G3_p0_rl 的 TIS ≤ 1.02 × G2_p0。
- 权限单边的证据：G1_v524 的 `pos_exec_ratio` 远低于 1，`stack_res` / `realized_res` 显著为负。

## 4. 分流
- GATE-1 FAIL：逐个回退（`--no-lon-no-floors` / `--lon-actuation accel` / `--gap-policy legacy`），每次一个，把日志发回分析。
- GATE-1 PASS、GATE-2 FAIL：规则栈可用、残差 RL 有害 → 进入 P1，论文实验暂关残差（`--ablate-zero-lon-residual`）。
- 都 PASS：在 3-leg、5-leg 与种子 7/11/13 上重复，全部通过后进入 P1。

## 5. 可落地版本（关口结论后的论文栈）

GATE-1 在 3/4/5-leg 通过；GATE-2 在 5-leg 失败；GATE-P1（v6p1）失败；G3 残差短训按 **GATE 不过** 处理（不替换 landable）。
正式实验用 **G2**：`--profile landable`（v6-P0 规则栈 + 纵向残差关死 + Max-Pressure）。不要开残差 RL、v6p1、VLM 或全量 curriculum。

Slim eval（需求 1.0，种子 7–11）：`logs/landable/landable_summary.md`。TIS 上 G2≈G0；**3-leg 输给固定配时**（173 vs 162），4/5-leg TIS 重叠。G0 与 G2 几乎打平，说明 3-leg 差距来自 **Max-Pressure 包络 vs 路网 90s 配时（34/16/25）**，不是 CAV 规则。5-leg 上 FT 积压为 0、G2/G0 约 22，同样指向信号而非车辆模型。下一步若要抬 G2，改 MP 绿时/公平性，不要再训。

    python scripts/run_landable.py --dry-run
    python scripts/run_landable.py --scenarios 3-leg,4-leg,5-leg --seeds 7,8,9,10,11 --workers 3
    python train/train_RL.py --profile landable --sumocfg "<cfg>" --no-vision --eval-only --eval-seeds 7

Slim paper table (not the full P3 matrix): G2 vs G0 (MP+IDM) vs FT (SUMO TLS+IDM) at shipped demand 1.0. Results: `logs/landable/landable_summary.md`.

G3 diagnostic was run then **rejected** (`scripts/p1_diag.py`). Do not promote that checkpoint.

3-leg MP: Gmax 34/16/25 did not help (TIS 175 vs G2 173 / FT 162); reverted.
Next one-change: gmin 34/16/25, original Gmax. Eval: `logs/landable/mp_gmin_3leg`.


## 6. 单独使用 P0 训练（残差仍学习，仅作对照）
    python train/train_RL.py --profile v6p0 --sumocfg "<cfg>" --no-vision --seed 7 --quick
