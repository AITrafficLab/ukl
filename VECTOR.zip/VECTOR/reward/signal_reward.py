"""Signal reward: unified queue/wait formal + VLM residual.

Default (all topologies: 3/4/5-leg):
``R = R_formal + R_res``
``R_formal = -(α·r̃_ql + β·r̃_wt) ∈ [-1, 0]`` with ``α:β = 3:1``
(``α=0.75``, ``β=0.25``), where
``r̃_ql = clip(mean_i L_i / L_ref, 0, 1)`` (``L_ref=220 m``),
``r̃_wt = clip(mean_p W_p / W_ref, 0, 1)`` (``W_ref=60 s``).

``L_i`` = approach-lane queue length (m); ``W_p`` = mean vehicle wait (s) on
lanes served by green phase ``p``. Fixed denominators ``n_lanes`` /
``n_phases`` come from topology (empty lanes/phases contribute 0).

Ablation via ``SIGNAL_FORMAL_MODE``:
  - ``ql_wt`` / empty (default): unified 3:1 queue+wait
  - ``pressure``: pure ``R_pressure``
  - ``hybrid`` / ``pw``: legacy ``α·R_pressure + β·R_wait-inc`` (3leg-style)

Pressure and waiting-increment remain TensorBoard diagnostics.
``R_res ∈ [-0.04, 0]`` is the shared VLM spillback residual
(Stage-S: ``spillback_risk`` may include a SUMO geometric spill_proxy
merged upstream so residual can fire beyond formal ``L_ref`` saturation).
"""
from __future__ import annotations

from typing import Any, Dict, List, Mapping, Optional, Sequence, Set, Tuple

import numpy as np

# queue, delay/fairness, progression, switch
DEFAULT_SIG_WEIGHTS = np.asarray([0.45, 0.22, 0.22, 0.11], dtype=np.float32)

# Waiting longer than this many nominal cycles → starvation (R_d) fallback.
STARVE_CYCLE_MULTIPLIER = 2.0
# Absolute wait for starve fraction / anti-teleport mask (prompt Rule 1 uses 95s).
STARVE_WAIT_S = 105.0
DEFAULT_CYCLE_S = 90.0
SWITCH_PENALTY = -0.05

# Unified formal: α·normalized mean lane queue + β·normalized mean phase wait.
SIGNAL_QL_ALPHA = 0.75
SIGNAL_WT_BETA = 0.25
# 220 m keeps mean-lane queue on corridor approaches (~80–140 m typical)
# inside the sensitive slope; 100 m saturated formal at ≈ −0.75 on full demand.
QUEUE_LENGTH_REF_M = 220.0
PHASE_WAIT_REF_S = 60.0
VEH_EQUIV_LEN_M = 7.5
WAIT_SPEED_MS_FALLBACK = 0.5
# Only near-stopline / slow vehicles contribute to phase wait (anti-dilution).
WAIT_INCLUDE_DIST_M = 250.0
WAIT_INCLUDE_SPEED_MS = 5.0

# Legacy 3-leg hybrid ablation: α·pressure + β·wait-inc (α + β = 1).
THREE_LEG_PRESSURE_ALPHA = 0.6
THREE_LEG_WAIT_BETA = 0.4
THREE_LEG_WAIT_ALPHA = THREE_LEG_PRESSURE_ALPHA  # historical name; not wait weight
THREE_LEG_SPEED_BETA = THREE_LEG_WAIT_BETA
THREE_LEG_SPEED_MIN_MS = 5.0
THREE_LEG_SPEED_REF_MS = 10.0


def signal_pressure_reward(
    state: Mapping[str, Any],
    incoming_edges: Optional[Set[str]] = None,
    outgoing_edges: Optional[Set[str]] = None,
    capacity: float = 160.0,
) -> float:
    """Intersection pressure (alias of R_q). Diagnostic / ablation only by default."""
    r_q, _ = _r_queue(state, incoming_edges, outgoing_edges, capacity)
    return float(r_q)


_EDGE_WARNED = False


def _r_queue(
    state: Mapping[str, Any],
    incoming_edges: Optional[Set[str]],
    outgoing_edges: Optional[Set[str]],
    capacity: float,
) -> Tuple[float, Dict[str, float]]:
    """Pure intersection pressure: clip(-(n_in-n_out)/max(c,1), -1, 1)."""
    global _EDGE_WARNED
    incoming = set(incoming_edges or ())
    outgoing = set(outgoing_edges or ())
    if not incoming and not outgoing:
        if not _EDGE_WARNED:
            print(
                "[signal_reward] incoming/outgoing edge sets are empty; "
                "pressure reward is 0 until topology edges are set. "
                "Refusing name-suffix matching.",
                flush=True,
            )
            _EDGE_WARNED = True
        return 0.0, {"pressure": 0.0, "n_in": 0.0, "n_out": 0.0, "capacity": 1.0}
    n_in = n_out = 0
    for group in ("cavs", "hdvs"):
        for v in (state.get(group) or {}).values():
            edge = str(v.get("edge", "") or "")
            if not edge or edge.startswith(":"):
                continue
            if edge in incoming:
                n_in += 1
            elif edge in outgoing:
                n_out += 1
    try:
        c_raw = float(capacity)
    except (TypeError, ValueError, OverflowError):
        c_raw = 1.0
    c = max(c_raw, 1.0) if np.isfinite(c_raw) else 1.0
    r_q = float(np.clip(-(n_in - n_out) / c, -1.0, 1.0))
    return r_q, {
        "pressure": r_q,
        "n_in": float(n_in),
        "n_out": float(n_out),
        "capacity": float(c),
    }


def _r_delay(
    state: Mapping[str, Any],
    cycle_s: float = DEFAULT_CYCLE_S,
) -> Tuple[float, Dict[str, float]]:
    # Align with Phase_Starvation absolute wait (STARVE_WAIT_S), not 2×cycle.
    thr = max(float(STARVE_WAIT_S), 1.0)
    del cycle_s  # kept for API compatibility
    n_veh = 0
    n_starve = 0
    for group in ("cavs", "hdvs"):
        for v in (state.get(group) or {}).values():
            edge = str(v.get("edge", "") or "")
            if not edge or edge.startswith(":"):
                continue
            if not (v.get("in_platoon_zone") or v.get("in_control_zone") or v.get("is_approaching")):
                # Still count any vehicle with waiting_time on approach edges.
                # 0.0 is a valid stopline distance — do not use `or -1.0`.
                raw_d = v.get("dist_to_stopline", -1.0)
                dist = -1.0 if raw_d is None else float(raw_d)
                if dist < 0.0:
                    continue
            n_veh += 1
            try:
                wt = float(v.get("waiting_time", 0.0) or 0.0)
            except (TypeError, ValueError):
                wt = 0.0
            if wt > thr:
                n_starve += 1
    # Prefer pre-aggregated fraction when present.
    stats = state.get("stats") or {}
    if "starve_fraction" in stats:
        frac = float(np.clip(float(stats.get("starve_fraction") or 0.0), 0.0, 1.0))
    else:
        frac = float(n_starve) / float(max(n_veh, 1))
    # Continuous delay term: peak waiting keeps a gradient when frac == 0.
    max_wait = 0.0
    try:
        max_wait = float(stats.get("max_wait_s", stats.get("max_wait", 0.0)) or 0.0)
    except (TypeError, ValueError):
        max_wait = 0.0
    if max_wait <= 0.0:
        for group in ("cavs", "hdvs"):
            for v in (state.get(group) or {}).values():
                try:
                    wt = float(v.get("waiting_time", 0.0) or 0.0)
                except (TypeError, ValueError):
                    continue
                if wt > max_wait:
                    max_wait = wt
    wait_term = float(np.clip(max_wait / 120.0, 0.0, 1.0))
    r_d = float(-0.5 * wait_term - 0.5 * frac)
    return r_d, {"starve_fraction": frac, "n_starve": float(n_starve), "n_veh": float(n_veh),
                 "max_wait_s": float(max_wait)}


def _r_progression(
    state: Mapping[str, Any],
    capacity: float = 160.0,
) -> Tuple[float, Dict[str, float]]:
    stats = state.get("stats") or {}
    n_prog = float(stats.get("green_wave_candidate_number", stats.get("n_prog", 0.0)) or 0.0)
    # Cap scale: modest absolute capacity so sparse scenes still give signal.
    n_cap = max(min(float(capacity or 40.0) * 0.15, 40.0), 5.0)
    r_p = float(min(n_prog, n_cap) / n_cap)
    return r_p, {"n_prog": n_prog, "n_cap": n_cap}


def _r_switch(switched: bool) -> Tuple[float, Dict[str, float]]:
    r_c = float(SWITCH_PENALTY) if switched else 0.0
    return r_c, {"switched": 1.0 if switched else 0.0}


WAIT_SPEED_MS = 0.1


def _finite_float(value: Any, default: float = 0.0) -> float:
    """Convert to a finite float; malformed values cannot poison reward logs."""
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError):
        return float(default)
    return result if np.isfinite(result) else float(default)


def signal_waiting_increment_reward(
    state: Mapping[str, Any],
    *,
    dt: float,
    incoming_edges: Optional[Set[str]] = None,
    v_wait: float = WAIT_SPEED_MS,
) -> Tuple[float, Dict[str, float]]:
    """Return normalized per-step waiting-time-increment reward.

    ``delta_waiting = n_wait * dt`` is the waiting time accrued this step by
    vehicles effectively stopped on this junction's incoming approaches.
    Normalize it by ``vehicle_time_exposure = n_vehicles * dt`` so the reward
    remains comparable across 3-leg, 4-leg, and 5-leg intersections:

        R_sig = -clip(delta_waiting / vehicle_time_exposure, 0, 1)

    If there are no eligible vehicles, return 0.0. When incoming edges are not
    configured, use explicit approach/control-zone indicators or a valid
    stop-line distance rather than accidentally scoring every vehicle in a
    multi-junction network.
    """
    step = max(_finite_float(dt, 0.0), 0.0)
    speed_threshold = max(_finite_float(v_wait, WAIT_SPEED_MS), 0.0)
    incoming = {str(edge) for edge in (incoming_edges or ()) if str(edge)}

    n_veh = 0
    n_wait = 0
    for group in ("cavs", "hdvs"):
        vehicles = state.get(group) or {}
        if not isinstance(vehicles, Mapping):
            continue
        for v in vehicles.values():
            if not isinstance(v, Mapping):
                continue
            edge = str(v.get("edge", "") or "")
            if not edge or edge.startswith(":"):
                continue

            if incoming:
                if edge not in incoming:
                    continue
            else:
                # Safe fallback for callers that have not wired topology yet:
                # don't count unrelated vehicles elsewhere in the network.
                raw_dist = v.get("dist_to_stopline", None)
                try:
                    valid_dist = raw_dist is not None and np.isfinite(float(raw_dist)) and float(raw_dist) >= 0.0
                except (TypeError, ValueError, OverflowError):
                    valid_dist = False
                if not (
                    bool(v.get("is_approaching", False))
                    or bool(v.get("in_control_zone", False))
                    or bool(v.get("in_platoon_zone", False))
                    or (valid_dist and bool(v.get("tls_id")))
                ):
                    continue

            n_veh += 1
            speed = _finite_float(v.get("speed", 0.0), 0.0)
            if speed < speed_threshold:
                n_wait += 1

    waiting_seconds = float(n_wait) * step
    exposure = float(n_veh) * step
    if exposure <= 1e-12:
        reward = 0.0
    else:
        reward = float(-np.clip(waiting_seconds / exposure, 0.0, 1.0))

    return reward, {
        "waiting_increment": reward,
        "waiting_seconds": waiting_seconds,
        "vehicle_time_exposure": exposure,
        "n_wait": float(n_wait),
        "n_veh": float(n_veh),
        "dt": float(step),
    }


def _is_three_leg_scenario(scenario_key: Optional[str]) -> bool:
    key = str(scenario_key or "").strip().lower().replace("-", "").replace("_", "")
    return key.startswith("3leg") or "3leg" in key


def _env_float(name: str, fallback: float) -> float:
    import os

    raw = os.environ.get(name, "").strip()
    if not raw:
        return float(fallback)
    try:
        v = float(raw)
    except (TypeError, ValueError):
        return float(fallback)
    return float(v) if np.isfinite(v) else float(fallback)


def _collect_lane_queues_m(
    state: Mapping[str, Any],
    incoming_edges: Optional[Set[str]] = None,
) -> List[float]:
    """Per-lane queue lengths (m). Prefer stats; else estimate from vehicles."""
    stats = state.get("stats") if isinstance(state, Mapping) else None
    raw = None
    if isinstance(stats, Mapping):
        raw = stats.get("lane_queue_lengths_m")
    if raw is None and isinstance(state, Mapping):
        raw = state.get("lane_queue_lengths_m")

    if isinstance(raw, Mapping) and len(raw) > 0:
        return [max(0.0, _finite_float(v, 0.0)) for v in raw.values()]
    if isinstance(raw, (list, tuple)) and len(raw) > 0:
        return [max(0.0, _finite_float(v, 0.0)) for v in raw]

    # Fallback for unit tests / offline: group by lane (else edge) on approaches.
    incoming = {str(e) for e in (incoming_edges or ()) if str(e)}
    buckets: Dict[str, float] = {}
    for group in ("cavs", "hdvs"):
        vehicles = state.get(group) or {}
        if not isinstance(vehicles, Mapping):
            continue
        for v in vehicles.values():
            if not isinstance(v, Mapping):
                continue
            edge = str(v.get("edge", "") or "")
            if not edge or edge.startswith(":"):
                continue
            if incoming and edge not in incoming:
                continue
            lane = str(v.get("lane", "") or edge)
            speed = _finite_float(v.get("speed", 0.0), 0.0)
            if speed >= WAIT_SPEED_MS_FALLBACK:
                buckets.setdefault(lane, 0.0)
                continue
            buckets[lane] = float(buckets.get(lane, 0.0)) + float(VEH_EQUIV_LEN_M)
    if incoming:
        # Ensure every known approach edge appears (empty → 0) when no lane ids.
        for e in incoming:
            buckets.setdefault(str(e), float(buckets.get(str(e), 0.0)))
    return [max(0.0, float(x)) for x in buckets.values()] if buckets else []


def _collect_phase_waits_s(
    state: Mapping[str, Any],
    incoming_edges: Optional[Set[str]] = None,
) -> List[float]:
    """Per-green-phase mean waits (s). Prefer stats; else one global mean."""
    stats = state.get("stats") if isinstance(state, Mapping) else None
    raw = None
    if isinstance(stats, Mapping):
        raw = stats.get("phase_avg_waits_s")
    if raw is None and isinstance(state, Mapping):
        raw = state.get("phase_avg_waits_s")

    if isinstance(raw, (list, tuple)) and len(raw) > 0:
        return [max(0.0, _finite_float(w, 0.0)) for w in raw]
    if isinstance(raw, Mapping) and len(raw) > 0:
        return [max(0.0, _finite_float(w, 0.0)) for w in raw.values()]

    # Fallback: per-approach mean wait so side-street starvation is not diluted
    # by high vehicle counts on main-line approaches.
    incoming = {str(e) for e in (incoming_edges or ()) if str(e)}
    by_approach: Dict[str, List[float]] = {e: [] for e in sorted(incoming)}
    for group in ("cavs", "hdvs"):
        vehicles = state.get(group) or {}
        if not isinstance(vehicles, Mapping):
            continue
        for v in vehicles.values():
            if not isinstance(v, Mapping):
                continue
            edge = str(v.get("edge", "") or "")
            if not edge or edge.startswith(":"):
                continue
            if incoming and edge not in incoming:
                continue
            dist = _finite_float(v.get("dist_to_stopline", 1e9), 1e9)
            speed = _finite_float(v.get("speed", 0.0), 0.0)
            if not (dist <= WAIT_INCLUDE_DIST_M or speed < WAIT_INCLUDE_SPEED_MS):
                continue
            by_approach.setdefault(edge, []).append(
                max(0.0, _finite_float(v.get("waiting_time", 0.0), 0.0))
            )
    if not by_approach:
        return []
    return [
        float(np.mean(vals)) if vals else 0.0
        for vals in by_approach.values()
    ]


def signal_reward_saturation() -> float:
    """Saturation of the normalised ql/wt formal (1.0 = v5.2.4 behaviour)."""
    import os as _os

    raw = _os.environ.get("SIGNAL_REWARD_SAT")
    if raw is None or not str(raw).strip():
        return 1.0
    try:
        val = float(str(raw).strip())
    except (TypeError, ValueError, OverflowError):
        return 1.0
    if not np.isfinite(val) or val < 1.0:
        return 1.0
    return float(min(val, 20.0))


def signal_ql_wt_formal(
    state: Mapping[str, Any],
    *,
    incoming_edges: Optional[Set[str]] = None,
    alpha_ql: Optional[float] = None,
    beta_wt: Optional[float] = None,
    l_ref: Optional[float] = None,
    w_ref: Optional[float] = None,
) -> Tuple[float, Dict[str, float]]:
    """Normalized 3:1 lane-queue + phase-wait formal in [-1, 0]."""
    a = _env_float("SIGNAL_QL_ALPHA", SIGNAL_QL_ALPHA if alpha_ql is None else float(alpha_ql))
    b = _env_float("SIGNAL_WT_BETA", SIGNAL_WT_BETA if beta_wt is None else float(beta_wt))
    if alpha_ql is not None:
        a = float(alpha_ql)
    if beta_wt is not None:
        b = float(beta_wt)
    if not (np.isfinite(a) and np.isfinite(b)) or (a + b) <= 1e-8:
        a, b = float(SIGNAL_QL_ALPHA), float(SIGNAL_WT_BETA)
    # Keep α:β = 3:1 scale if only one side overridden poorly — renormalize.
    s = float(a + b)
    a, b = float(a / s), float(b / s)

    lref = _env_float(
        "SIGNAL_QUEUE_LENGTH_REF_M",
        QUEUE_LENGTH_REF_M if l_ref is None else float(l_ref),
    )
    wref = _env_float(
        "SIGNAL_PHASE_WAIT_REF_S",
        PHASE_WAIT_REF_S if w_ref is None else float(w_ref),
    )
    if l_ref is not None:
        lref = float(l_ref)
    if w_ref is not None:
        wref = float(w_ref)
    lref = max(float(lref), 1e-3) if np.isfinite(lref) else float(QUEUE_LENGTH_REF_M)
    wref = max(float(wref), 1e-3) if np.isfinite(wref) else float(PHASE_WAIT_REF_S)

    lane_q = _collect_lane_queues_m(state, incoming_edges=incoming_edges)
    phase_w = _collect_phase_waits_s(state, incoming_edges=incoming_edges)
    n_lanes = max(1, len(lane_q))
    n_phas = max(1, len(phase_w))
    raw_ql = float(np.sum(lane_q) / float(n_lanes)) if lane_q else 0.0
    raw_wt = float(np.sum(phase_w) / float(n_phas)) if phase_w else 0.0
    # v6-P0: SIGNAL_REWARD_SAT (default 1.0 = v5.2.4) is the saturation level of
    # the normalised queue/wait terms. v5.2.4 clipped at 1, so an oversaturated
    # junction (mean queue > 220 m) produced a flat reward and zero gradient
    # exactly when control mattered most. --profile v6p0 uses 4.0; PopArt on the
    # signal value head absorbs the scale change.
    sat = signal_reward_saturation()
    norm_ql = float(np.clip(raw_ql / lref, 0.0, sat))
    norm_wt = float(np.clip(raw_wt / wref, 0.0, sat))
    formal = -float(np.clip(a * norm_ql + b * norm_wt, 0.0, sat))
    return formal, {
        "formal": float(formal),
        "r_ql_norm": float(norm_ql),
        "r_wt_norm": float(norm_wt),
        "raw_r_ql_m": float(raw_ql),
        "raw_r_wt_s": float(raw_wt),
        "queue_term": float(-a * norm_ql),
        "wait_term": float(-b * norm_wt),
        "alpha_ql": float(a),
        "beta_wt": float(b),
        "l_ref_m": float(lref),
        "w_ref_s": float(wref),
        "n_lanes": float(n_lanes),
        "n_phases": float(n_phas),
        "ql_wt_formal": 1.0,
    }


def _network_avg_speed_ms(state: Mapping[str, Any]) -> float:
    """Step instantaneous network mean speed for R_speed.

    Strict: only ``state['stats']['average_speed']`` (SUMO step KPI).
    Missing / invalid → 0.0. Never use episode-cumulative infos avg_speed,
    ``network_avg_speed``, or per-vehicle means.
    """
    stats = state.get("stats") if isinstance(state, Mapping) else None
    if not isinstance(stats, Mapping) or "average_speed" not in stats:
        return 0.0
    try:
        v = float(stats.get("average_speed"))
    except (TypeError, ValueError, OverflowError):
        return 0.0
    if not np.isfinite(v) or v < 0.0:
        return 0.0
    return float(v)


def signal_speed_term(
    state: Mapping[str, Any],
    *,
    v_min: float = THREE_LEG_SPEED_MIN_MS,
    v_ref: float = THREE_LEG_SPEED_REF_MS,
) -> Tuple[float, Dict[str, float]]:
    """Band-normalized non-positive speed term for 3-leg hybrid formal.

    ``R_speed = -clip((v_ref - v̄) / (v_ref - v_min), 0, 1) ∈ [-1, 0]``.
    Affine-equivalent (inside the band) to ``+clip((v̄-v_min)/(v_ref-v_min),0,1)``.
    """
    lo = float(v_min) if np.isfinite(float(v_min)) else THREE_LEG_SPEED_MIN_MS
    hi = float(v_ref) if np.isfinite(float(v_ref)) else THREE_LEG_SPEED_REF_MS
    if hi - lo <= 1e-6:
        lo, hi = THREE_LEG_SPEED_MIN_MS, THREE_LEG_SPEED_REF_MS
    avg = _network_avg_speed_ms(state)
    deficit = float(np.clip((hi - avg) / (hi - lo), 0.0, 1.0))
    term = float(-deficit)
    pos = float(1.0 + term)  # clip((avg-lo)/(hi-lo), 0, 1) when avg in [lo, hi]
    return term, {
        "speed_term": term,
        "speed_term_positive": pos,
        "avg_speed": float(avg),
        "v_min": float(lo),
        "v_ref": float(hi),
    }


# Geometric spill proxy: residual path when long corridors still exceed L_ref.
# Onset at 55% of lane length; full proxy at ~90%. Complements ql/wt formal.
SPILL_PROXY_ONSET = 0.55
SPILL_PROXY_SPAN = 0.35
SPILL_PROXY_DEFAULT_LANE_M = 300.0


def compute_spill_proxy(
    lane_queue_lengths_m: Optional[Mapping[str, Any]] = None,
    *,
    lane_lengths_m: Optional[Mapping[str, Any]] = None,
    default_length_m: float = SPILL_PROXY_DEFAULT_LANE_M,
    onset: float = SPILL_PROXY_ONSET,
    span: float = SPILL_PROXY_SPAN,
) -> float:
    """SUMO geometric spill risk in [0, 1] from queue/lane-length ratios.

    Does not use ``queue_imbalance`` labels. Returns 0 when queues are short
    relative to approach length (avoids double-counting formal ql/wt).
    """
    if not isinstance(lane_queue_lengths_m, Mapping) or not lane_queue_lengths_m:
        return 0.0
    try:
        onset_f = float(onset)
        span_f = float(span)
        default_L = float(default_length_m)
    except (TypeError, ValueError, OverflowError):
        return 0.0
    if not np.isfinite(span_f) or span_f <= 1e-6:
        return 0.0
    if not np.isfinite(default_L) or default_L <= 1.0:
        default_L = float(SPILL_PROXY_DEFAULT_LANE_M)
    lengths = lane_lengths_m if isinstance(lane_lengths_m, Mapping) else {}
    best = 0.0
    for lane_id, q_raw in lane_queue_lengths_m.items():
        try:
            q = float(q_raw)
        except (TypeError, ValueError, OverflowError):
            continue
        if not np.isfinite(q) or q <= 0.0:
            continue
        L = default_L
        if lane_id in lengths:
            try:
                L_cand = float(lengths.get(lane_id))
            except (TypeError, ValueError, OverflowError):
                L_cand = default_L
            if np.isfinite(L_cand) and L_cand > 1.0:
                L = L_cand
        ratio = float(q) / float(L)
        proxy = (ratio - onset_f) / span_f
        if np.isfinite(proxy):
            best = max(best, float(np.clip(proxy, 0.0, 1.0)))
    return float(best)


def compute_spill_proxy_from_state(
    state: Mapping[str, Any],
    *,
    lane_lengths_m: Optional[Mapping[str, Any]] = None,
    default_length_m: float = SPILL_PROXY_DEFAULT_LANE_M,
) -> float:
    """Read ``stats.lane_queue_lengths_m`` and compute spill_proxy."""
    if not isinstance(state, Mapping):
        return 0.0
    stats = state.get("stats")
    if not isinstance(stats, Mapping):
        return 0.0
    return compute_spill_proxy(
        stats.get("lane_queue_lengths_m"),
        lane_lengths_m=lane_lengths_m,
        default_length_m=default_length_m,
    )


def _vlm_signal_residual(state: Mapping[str, Any]) -> float:
    """Bounded CoRe residual in [-0.04, 0] from BEV spillback / blockage.

    Formal term stays the training target. This residual is zero unless a
    valid semantic dict is present with confidence >= 0.60.
    ``spillback_risk`` may already include a SUMO geometric spill_proxy
    (merged upstream in Stage-S) so residual can fire beyond formal L_ref.
    """
    stats = state.get("stats") if isinstance(state, Mapping) else None
    sem = None
    if isinstance(stats, Mapping):
        sem = stats.get("vlm_signal_semantic")
    if not isinstance(sem, Mapping) and isinstance(state, Mapping):
        sem = state.get("vlm_signal_semantic")
    if not isinstance(sem, Mapping):
        return 0.0
    try:
        valid = float(sem.get("valid", 1.0) or 0.0)
    except (TypeError, ValueError, OverflowError):
        valid = 0.0
    if valid < 0.5:
        return 0.0
    try:
        spill = float(sem.get("spillback_risk", sem.get("spillback", 0.0)) or 0.0)
    except (TypeError, ValueError, OverflowError):
        spill = 0.0
    spill = float(np.clip(spill, 0.0, 1.0))
    if "junction_blocked" in sem:
        blocked = 1.0 if bool(sem.get("junction_blocked")) else 0.0
    else:
        try:
            incident = float(sem.get("incident_obstruction", 0.0) or 0.0)
            blockage = float(sem.get("lane_blockage", 0.0) or 0.0)
        except (TypeError, ValueError, OverflowError):
            incident, blockage = 0.0, 0.0
        blocked = 1.0 if (incident >= 0.5 or blockage >= 0.7) else 0.0
    try:
        conf = float(sem.get("confidence", 0.0) or 0.0)
    except (TypeError, ValueError, OverflowError):
        conf = 0.0
    conf = float(np.clip(conf, 0.0, 1.0))
    if conf < 0.60:
        return 0.0
    return float(np.clip(-0.04 * conf * max(spill, blocked), -0.04, 0.0))


def compute_signal_reward(
    state: Mapping[str, Any],
    *,
    weights: Optional[Sequence[float]] = None,
    incoming_edges: Optional[Set[str]] = None,
    outgoing_edges: Optional[Set[str]] = None,
    capacity: float = 160.0,
    cycle_s: float = DEFAULT_CYCLE_S,
    switched: bool = False,
    dt: float = 0.2,
    scenario_key: Optional[str] = None,
    wait_alpha: Optional[float] = None,
    speed_beta: Optional[float] = None,
    speed_min_ms: Optional[float] = None,
    speed_ref_ms: Optional[float] = None,
) -> Tuple[float, Dict[str, float]]:
    """CoRe signal reward: unified ql/wt formal + bounded VLM residual.

    Default: ``R = -(α r̃_ql + β r̃_wt) + R_res`` with ``α:β = 3:1``.
    Ablation ``SIGNAL_FORMAL_MODE=pressure|hybrid`` restores legacy formals.
    ``wait_alpha`` / ``speed_beta`` still override hybrid ablation α/β.
    """
    import os

    del weights, cycle_s, speed_min_ms, speed_ref_ms

    vmin = float(THREE_LEG_SPEED_MIN_MS)
    vref = float(THREE_LEG_SPEED_REF_MS)

    sc_key = scenario_key
    if not sc_key and isinstance(state, Mapping):
        sc_key = state.get("scenario_key") or state.get("scenario")
        stats = state.get("stats")
        if not sc_key and isinstance(stats, Mapping):
            sc_key = stats.get("scenario_key") or stats.get("scenario")

    wait_r, wait_info = signal_waiting_increment_reward(
        state,
        dt=dt,
        incoming_edges=incoming_edges,
    )
    pressure, pressure_info = _r_queue(
        state, incoming_edges, outgoing_edges, capacity
    )
    use_three_leg = _is_three_leg_scenario(
        sc_key if isinstance(sc_key, str) else None
    )

    formal_mode = os.environ.get("SIGNAL_FORMAL_MODE", "").strip().lower()
    use_pressure = formal_mode in ("pressure", "p", "pure_pressure")
    use_hybrid = formal_mode in ("hybrid", "pressure_wait", "pw")
    # Explicit kwargs force hybrid ablation (legacy grid scripts).
    if wait_alpha is not None or speed_beta is not None:
        use_hybrid = True
        use_pressure = False

    ql_info: Dict[str, float] = {
        "r_ql_norm": 0.0,
        "r_wt_norm": 0.0,
        "raw_r_ql_m": 0.0,
        "raw_r_wt_s": 0.0,
        "queue_term": 0.0,
        "wait_term": 0.0,
        "alpha_ql": float(SIGNAL_QL_ALPHA),
        "beta_wt": float(SIGNAL_WT_BETA),
        "l_ref_m": float(QUEUE_LENGTH_REF_M),
        "w_ref_s": float(PHASE_WAIT_REF_S),
        "n_lanes": 0.0,
        "n_phases": 0.0,
        "ql_wt_formal": 0.0,
    }

    if use_pressure:
        formal = float(pressure)
        a, b = 1.0, 0.0
    elif use_hybrid:
        a_default = _env_float("THREE_LEG_PRESSURE_ALPHA", THREE_LEG_PRESSURE_ALPHA)
        b_default = _env_float(
            "THREE_LEG_WAIT_BETA",
            _env_float("THREE_LEG_SPEED_BETA", THREE_LEG_WAIT_BETA),
        )
        legacy_a = os.environ.get("THREE_LEG_WAIT_ALPHA", "").strip()
        if legacy_a and not os.environ.get("THREE_LEG_PRESSURE_ALPHA", "").strip():
            a_default = _env_float("THREE_LEG_WAIT_ALPHA", a_default)
        if use_three_leg or formal_mode in ("hybrid", "pressure_wait", "pw"):
            a = a_default if wait_alpha is None else float(wait_alpha)
            b = b_default if speed_beta is None else float(speed_beta)
        else:
            a = _env_float(
                "SIGNAL_PRESSURE_ALPHA",
                a_default if wait_alpha is None else float(wait_alpha),
            )
            b = _env_float(
                "SIGNAL_WAIT_BETA",
                b_default if speed_beta is None else float(speed_beta),
            )
            if wait_alpha is not None:
                a = float(wait_alpha)
            if speed_beta is not None:
                b = float(speed_beta)
        if not (np.isfinite(a) and np.isfinite(b)):
            a, b = a_default, b_default
        if wait_alpha is None and speed_beta is not None and np.isfinite(b):
            a = float(1.0 - b)
        elif speed_beta is None and wait_alpha is not None and np.isfinite(a):
            b = float(1.0 - a)
        if (a + b) <= 1e-8:
            a, b = a_default, b_default
        formal = float(a * pressure + b * wait_r)
    else:
        formal, ql_info = signal_ql_wt_formal(
            state, incoming_edges=incoming_edges
        )
        a = float(ql_info.get("alpha_ql", SIGNAL_QL_ALPHA))
        b = float(ql_info.get("beta_wt", SIGNAL_WT_BETA))

    speed_r = 0.0
    speed_info = {
        "speed_term": 0.0,
        "speed_term_positive": 0.0,
        "avg_speed": _network_avg_speed_ms(state),
        "v_min": float(vmin),
        "v_ref": float(vref),
    }

    sw_pen = _env_float("SIGNAL_SWITCH_PENALTY", SWITCH_PENALTY)
    switch_r = float(min(0.0, sw_pen)) if bool(switched) else 0.0
    residual = _vlm_signal_residual(state)
    # Widen lower bound to -1.15 so -0.05 switch penalty + -0.04 VLM residual
    # remain strictly active even when queue/wait formal reward saturates at -1.0.
    total = float(
        np.clip(formal + switch_r + residual, -(signal_reward_saturation() + 0.15), 0.0)
    )

    comps = {
        # Legacy component names retained for loggers / TB.
        "queue": float(formal),
        "delay": 0.0,
        "progression": float(speed_r),
        "switch": float(switch_r),
        "total": float(total),
        "formal": float(formal),
        "residual": float(residual),
        "waiting_increment": float(wait_info["waiting_increment"]),
        "speed_term": float(speed_info.get("speed_term", speed_r)),
        "speed_term_positive": float(speed_info.get("speed_term_positive", 0.0)),
        "avg_speed": float(speed_info.get("avg_speed", 0.0)),
        "v_min": float(speed_info.get("v_min", vmin)),
        "v_ref": float(speed_info.get("v_ref", vref)),
        "wait_alpha": float(a),
        "speed_beta": float(b),
        "pressure_alpha": float(a),
        "wait_beta": float(b),
        "alpha_ql": float(ql_info.get("alpha_ql", SIGNAL_QL_ALPHA)),
        "beta_wt": float(ql_info.get("beta_wt", SIGNAL_WT_BETA)),
        "r_ql_norm": float(ql_info.get("r_ql_norm", 0.0)),
        "r_wt_norm": float(ql_info.get("r_wt_norm", 0.0)),
        "raw_r_ql_m": float(ql_info.get("raw_r_ql_m", 0.0)),
        "raw_r_wt_s": float(ql_info.get("raw_r_wt_s", 0.0)),
        "queue_term": float(ql_info.get("queue_term", 0.0)),
        "wait_term": float(ql_info.get("wait_term", 0.0)),
        "n_lanes": float(ql_info.get("n_lanes", 0.0)),
        "n_phases": float(ql_info.get("n_phases", 0.0)),
        "ql_wt_formal": float(ql_info.get("ql_wt_formal", 0.0)),
        "three_leg_hybrid": 1.0 if use_hybrid else 0.0,
        "three_leg_pressure": 1.0 if use_three_leg else 0.0,
        "waiting_seconds": float(wait_info["waiting_seconds"]),
        "vehicle_time_exposure": float(wait_info["vehicle_time_exposure"]),
        "n_wait": float(wait_info["n_wait"]),
        "n_veh": float(wait_info["n_veh"]),
        "dt": float(wait_info["dt"]),
        "pressure": float(pressure),
        "n_in": float(pressure_info.get("n_in", 0.0)),
        "n_out": float(pressure_info.get("n_out", 0.0)),
    }
    return float(total), comps
