"""Longitudinal reward: safety / efficiency / comfort / platoon maintenance."""
from __future__ import annotations

import math
import os
from typing import Any, Dict, Mapping, Optional, Sequence

import numpy as np

from environment.platoon_manager import gap_band_reward

# VLM soft-start / L2 baseline (safe, efficiency, comfort, platoon).
DEFAULT_LONG_WEIGHTS = np.asarray([0.24, 0.38, 0.18, 0.20], dtype=np.float32)
LEGACY_LONG_WEIGHTS = np.asarray([0.30, 0.30, 0.15, 0.25], dtype=np.float32)
DANGER_TTC = 1.5
# Gentle 130m linear glide-to-stop deceleration aligned with comfort deadband.
RED_BRAKE_DECEL = 1.25
RED_GLIDE_HORIZON_M = 130.0
RED_IDLE_EXEMPT_M = 8.0
# Tightened stop pocket & buffer aligned with SUMO IDM 0m stop-line target (no 5m early stop!).
STOP_ZONE_M = 1.2
LEADER_STOP_POCKET_M = 1.4
# TraCI leader_gap = bumper_gap - minGap (CAV minGap = 1.0 m): 0.35 m net = 1.35 m bumper gap.
LEADER_STOP_OFFSET_M = 0.35
IDLING_SPEED_MS = 0.8
STOP_BUFFER_M = 0.25
BRAKE_EXCESS_TOL_MS = 0.6
BRAKE_DEFICIT_TOL_MS = 1.0
MIDGAP_CREEP_V = 0.65
MIDGAP_CREEP_D = 3.0
LEADER_STOP_SPEED = 1.8
LEADER_STOP_GAP = 85.0
# Preserve zero magnitude penalty for steady -1.25 m/s^2 glide, while tightening jerk
# and penalizing throttle-brake sign reversals to eliminate tap-braking chattering.
COMFORT_POS_DEADBAND = 1.30
COMFORT_NEG_DEADBAND = 1.30
COMFORT_JERK_DEADZONE = 0.80

# Red-light GLOSA (Green Light Optimal Speed Advisory) steady eco-gliding parameters.
GLOSA_MIN_DIST_M = 16.0
GLOSA_MAX_DIST_M = 220.0
GLOSA_MAX_TTG_S = 28.0
GLOSA_ARRIVAL_BUFFER_S = 1.2
GLOSA_MIN_SPEED_MS = 3.5
GLOSA_SHORT_TTG_MIN_SPEED_MS = 2.2
GLOSA_STEADY_BONUS = 0.08
LON_DECISION_DT = 0.4
EFF_A_DEC_MAX = 2.0
# Net leader_gap queue-packing band [0.0, 1.8] m -> [1.0, 2.8] m physical bumper spacing.
# Keep IDLE_LEADER_EXEMPT_M = 2.8 exported for red_gap_diag compatibility, while applying
# hard -1.0 idling only beyond IDLE_HARD_GAP_M (8.0 m) so 2.8 m has zero cliff jump.
QUEUE_PACK_LO_M = 0.0
QUEUE_PACK_HI_M = 1.8
QUEUE_ATTRACT_HI_M = 14.0
IDLE_LEADER_EXEMPT_M = 2.8
IDLE_HARD_GAP_M = 8.0

# Green-tail discharge window shaping (kinematic acceleration-aware reachability).
GREEN_WINDOW_HORIZON_S = 8.0
GREEN_UNREACHABLE_HORIZON_S = 3.5
GREEN_SAFETY_MARGIN_S = 0.5
GREEN_HIT_BONUS = 0.10
GREEN_LATE_MISS_WEIGHT = 0.35
GREEN_COMFORT_ACCEL_MS2 = 2.0

# Follower string-stability damping when ego leader brakes abruptly ahead of a close follower.
STRING_STABILITY_GAP_MAX_M = 25.0
STRING_STABILITY_BRAKE_THR = -2.0


def _finite_float(value: Any, default: float = 0.0) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError):
        return float(default)
    return result if np.isfinite(result) else float(default)


def _resolve_lane_desired_speed(vinfo: Mapping[str, Any], desired_speed: float = 16.67) -> float:
    """Honor per-lane speed limits (e.g. 5-leg Fazhi 11.11 m/s) over global 16.67 m/s."""
    global_vmax = max(_finite_float(desired_speed, 16.67), 1e-3)
    for key in ("lane_max_speed", "lane_speed_limit", "speed_limit", "lane_speed", "edge_max_speed", "max_speed"):
        if key in vinfo and vinfo.get(key) is not None:
            cand = _finite_float(vinfo.get(key), -1.0)
            if cand > 0.5:
                return max(min(global_vmax, cand), 1e-3)
    return global_vmax


def _kinematic_eta_seconds(dist_m: float, v_ms: float, vmax_ms: float, a_acc: float = GREEN_COMFORT_ACCEL_MS2) -> float:
    """Minimum realistic time to cover ``dist_m`` from ``v_ms`` accelerating at ``a_acc`` up to ``vmax_ms``."""
    d = max(float(dist_m), 0.0)
    if d <= 1e-6:
        return 0.0
    v = max(float(v_ms), 0.0)
    vmax = max(float(vmax_ms), max(v, 0.5))
    a = max(float(a_acc), 1e-3)
    if v >= vmax - 1e-6:
        return d / vmax
    t_to_vmax = (vmax - v) / a
    d_to_vmax = v * t_to_vmax + 0.5 * a * t_to_vmax * t_to_vmax
    if d <= d_to_vmax:
        disc = max(0.0, v * v + 2.0 * a * d)
        return (-v + math.sqrt(disc)) / a
    return t_to_vmax + (d - d_to_vmax) / vmax


def _normalize_weights(
    weights: Optional[Sequence[float]],
    fallback: Optional[Sequence[float]] = None,
    *,
    allow_eff_drop: bool = False,
) -> np.ndarray:
    fb = np.asarray(
        DEFAULT_LONG_WEIGHTS if fallback is None else fallback, dtype=np.float32
    ).reshape(-1)
    if fb.size < 4:
        fb = np.pad(fb, (0, 4 - fb.size))
    fb = np.nan_to_num(fb[:4], nan=0.0, posinf=0.0, neginf=0.0)
    fb = np.clip(fb, 0.0, None)
    if float(fb.sum()) <= 1e-8:
        fb = np.full(4, 0.25, dtype=np.float32)
    else:
        fb /= float(fb.sum())
    if weights is None:
        return fb.astype(np.float32)
    try:
        w = np.asarray(weights, dtype=np.float32).reshape(-1)
    except (TypeError, ValueError, OverflowError):
        return fb.astype(np.float32)
    if w.size < 4:
        w = np.pad(w, (0, 4 - w.size))
    w = np.nan_to_num(w[:4], nan=0.0, posinf=0.0, neginf=0.0)
    w = np.clip(w, 0.0, None)
    total = float(w.sum())
    if not np.isfinite(total) or total <= 1e-8:
        return fb.astype(np.float32)
    proposed = (w / total).astype(np.float64)
    anchor = np.asarray(DEFAULT_LONG_WEIGHTS, dtype=np.float64).reshape(-1)
    if anchor.size < 4:
        anchor = np.pad(anchor, (0, 4 - anchor.size))
    anchor = anchor[:4]
    anchor = anchor / max(float(anchor.sum()), 1e-8)
    if float(proposed[0]) > float(anchor[0]) + 0.02:
        allow_eff_drop = True
    anchored = np.clip(
        anchor + np.clip(proposed - anchor, -0.12, 0.12),
        0.05,
        0.75,
    )
    if not allow_eff_drop:
        anchored[1] = max(float(anchored[1]), float(anchor[1]))
    anchored_sum = float(anchored.sum())
    if not np.isfinite(anchored_sum) or anchored_sum <= 1e-8:
        return fb.astype(np.float32)
    return (anchored / anchored_sum).astype(np.float32)


def _is_unjustified_idling(vinfo: Mapping[str, Any]) -> bool:
    """True only when CAV stops in genuinely clear open road (> IDLE_HARD_GAP_M).

    Intermediate gaps (2.8..8.0 m) are scored continuously in ``_r_eff_kinematic_stop``
    instead of triggering a -1.0 cliff that causes stop-then-lunge oscillations.
    """
    v = max(_finite_float(vinfo.get("speed", 0.0), 0.0), 0.0)
    if v >= IDLING_SPEED_MS:
        return False
    leader_gap = max(_finite_float(vinfo.get("leader_gap", 100.0), 100.0), 0.0)
    raw_d = vinfo.get("dist_to_stopline", -1.0)
    dist = -1.0 if raw_d is None else _finite_float(raw_d, -1.0)
    tls = str(vinfo.get("tls_state", "n") or "n").lower()
    if (tls in ("r", "y")) and (0.0 <= dist <= RED_IDLE_EXEMPT_M) and (leader_gap > dist):
        return False
    if leader_gap <= IDLE_HARD_GAP_M:
        raw_ls = vinfo.get("leader_speed")
        if raw_ls is not None and _finite_float(raw_ls, 10.0) < 2.5:
            return False
    return bool(leader_gap > IDLE_HARD_GAP_M)


def r_safe(vinfo: Mapping[str, Any]) -> float:
    """Continuous-gradient TTC + minGap safety score in [-1.0, 1.0].

    Note: TraCI ``leader_gap`` already subtracts ``minGap`` (1.0 m for CAV), and
    SUMO registers an IDM collision at ``leader_gap < -0.50 m`` (0.5 * minGap).
    Starting smooth negative pressure below ``0.30 m`` net gap keeps CAVs safely
    outside the collision boundary without relying solely on emergency shields.
    """
    leader_gap = _finite_float(vinfo.get("leader_gap", 100.0), 100.0)
    if vinfo.get("leader_id") is not None:
        if leader_gap < -0.05:
            return -1.0
        v_ego = max(_finite_float(vinfo.get("speed", 0.0), 0.0), 0.0)
        v_lead = max(_finite_float(vinfo.get("leader_speed", v_ego), v_ego), 0.0)
        closing = v_ego - v_lead
        if leader_gap < 0.30:
            # Smoothly ramp from -0.85 at gap=-0.05 up to +0.25 at gap=0.30;
            # extra penalty if actively closing into the tight buffer.
            frac = (leader_gap + 0.05) / 0.35
            score = -0.85 + 1.10 * frac
            if closing > 0.15:
                score -= min(0.40, 0.50 * closing)
            return float(np.clip(score, -1.0, 0.25))
    ttc = vinfo.get("ttc")
    if ttc is not None:
        try:
            ttc_f = float(ttc)
        except (TypeError, ValueError, OverflowError):
            ttc_f = 10.0
        if np.isfinite(ttc_f) and ttc_f > 0.0:
            if ttc_f < DANGER_TTC:
                return float(np.clip(-1.0 + 0.8 * (ttc_f / DANGER_TTC), -1.0, -0.2))
            if ttc_f < 2.5:
                return float(ttc_f - 1.5)
    if _is_unjustified_idling(vinfo):
        return 0.0
    return 1.0


def _speed_track(v: float, v_tgt: float, vmax: float) -> float:
    tol = 0.5
    err = max(0.0, abs(v - v_tgt) - tol)
    return float(np.clip(0.80 - err / max(vmax, 1e-3), -1.0, 1.0))


def _r_eff_stop_pocket(v: float, d_stop: float, pocket_m: float) -> float:
    """Reward full stop cleanly inside the tight target pocket."""
    pos_quality = 1.0 - 0.15 * float(np.clip(d_stop / max(pocket_m, 0.3), 0.0, 1.0))
    if v <= 0.15:
        return float(pos_quality)
    if v <= 0.60:
        return float(0.65 * pos_quality - 0.45 * v)
    return float(np.clip(0.35 - (v / 3.5), -0.8, 0.35))


def _r_eff_kinematic_stop(
    v: float,
    d_stop: float,
    vmax: float,
    accel: float = 0.0,
) -> float:
    d_eff = max(float(d_stop) - STOP_BUFFER_M, 0.0)
    v_kin = float(np.sqrt(2.0 * RED_BRAKE_DECEL * d_eff))
    if d_stop > MIDGAP_CREEP_D and v < MIDGAP_CREEP_V:
        # Smooth distance-proportional premature-stop penalty (no cliff at 2.8m):
        # gentle -0.15 near 3m ramping smoothly toward -0.65 beyond 10m.
        dist_pen = float(np.clip((d_stop - MIDGAP_CREEP_D) / 8.0, 0.0, 1.0))
        spd_credit = float(np.clip(v / max(MIDGAP_CREEP_V, 1e-3), 0.0, 1.0))
        return float(np.clip(-0.15 - 0.50 * dist_pen + 0.25 * spd_credit, -0.75, 0.05))
    excess = max(0.0, v - v_kin - BRAKE_EXCESS_TOL_MS)
    deficit = max(0.0, v_kin - v - BRAKE_DEFICIT_TOL_MS)
    denom_def = max(v_kin, 2.5)
    score = 0.85 - 1.8 * (excess / max(vmax, 1e-3)) - 0.45 * (deficit / denom_def)
    a_f = _finite_float(accel, 0.0)
    if d_stop > 8.0 and a_f < -2.2:
        harsh = float(np.clip((-a_f - 2.2) / 1.8, 0.0, 1.0))
        score -= 0.25 * harsh
    return float(np.clip(score, -1.0, 1.0))


def glosa_min_speed() -> float:
    """GLOSA speed floor (m/s), read at RUN time from LON_GLOSA_MIN_SPEED (v5.2).

    Module constants are frozen in forked workers, so the CLI value
    (--glosa-min-speed, set in os.environ before envs start) is read here.
    Default 3.5 m/s = v1; the smoke tests suggest >= 6 m/s in mixed traffic.
    """
    raw = os.environ.get("LON_GLOSA_MIN_SPEED", "")
    try:
        val = float(raw) if raw not in ("", None) else float(GLOSA_MIN_SPEED_MS)
    except (TypeError, ValueError):
        val = float(GLOSA_MIN_SPEED_MS)
    return max(0.5, val)


def _glosa_shaping_enabled() -> bool:
    import os

    raw = os.environ.get("LON_GLOSA_SHAPING")
    if raw is None or not str(raw).strip():
        return True
    return str(raw).strip().lower() not in ("0", "false", "no", "off", "disabled")


def compute_glosa_target_speed(
    vinfo: Mapping[str, Any],
    vmax: float,
) -> Optional[float]:
    """Return steady green-wave glide speed when upcoming green allows non-stop arrival."""
    if not _glosa_shaping_enabled():
        return None
    tls = str(vinfo.get("tls_state", "n") or "n").lower()
    if tls != "r":
        return None
    raw_d = vinfo.get("dist_to_stopline", -1.0)
    dist = -1.0 if raw_d is None else _finite_float(raw_d, -1.0)
    if not (GLOSA_MIN_DIST_M <= dist <= GLOSA_MAX_DIST_M):
        return None
    ttg = _finite_float(vinfo.get("time_to_green", -1.0), -1.0)
    if not (0.5 <= ttg <= GLOSA_MAX_TTG_S):
        return None
    leader_gap = max(_finite_float(vinfo.get("leader_gap", 100.0), 100.0), 0.0)
    raw_ls = vinfo.get("leader_speed")
    ls = _finite_float(raw_ls, -1.0) if raw_ls is not None else None
    if leader_gap <= dist and not (leader_gap > 30.0 and (ls is None or ls >= glosa_min_speed())):
        return None
    v_glosa = float(dist) / (float(ttg) + float(GLOSA_ARRIVAL_BUFFER_S))
    min_v = GLOSA_SHORT_TTG_MIN_SPEED_MS if ttg <= 4.0 else glosa_min_speed()
    if min_v <= v_glosa <= float(vmax):
        return float(v_glosa)
    return None


def _green_window_shaping_enabled() -> bool:
    import os

    raw = os.environ.get("LON_GREEN_WINDOW_SHAPING")
    if raw is None or not str(raw).strip():
        return True
    return str(raw).strip().lower() in ("1", "true", "yes", "on", "enabled")


def _remaining_green_seconds(
    vinfo: Mapping[str, Any],
    state: Optional[Mapping[str, Any]],
) -> Optional[float]:
    if isinstance(state, Mapping):
        signals = state.get("signals")
        tls_id = vinfo.get("tls_id")
        if isinstance(signals, Mapping) and tls_id and tls_id in signals:
            sinfo = signals.get(tls_id)
            if isinstance(sinfo, Mapping) and sinfo.get("remaining_time") is not None:
                rem = _finite_float(sinfo.get("remaining_time"), -1.0)
                if rem >= 0.0:
                    return float(rem)
    if vinfo.get("remaining_time") is not None:
        rem = _finite_float(vinfo.get("remaining_time"), -1.0)
        if rem >= 0.0:
            return float(rem)
    return None


def r_eff(
    vinfo: Mapping[str, Any],
    state: Mapping[str, Any],
    desired_speed: float = 16.67,
) -> float:
    """Cruise at lane vmax until kinematic brake; follow moving leaders; stop in pocket."""
    v = max(_finite_float(vinfo.get("speed", 0.0), 0.0), 0.0)
    vmax = _resolve_lane_desired_speed(vinfo, desired_speed)
    if _is_unjustified_idling(vinfo):
        return -1.0

    leader_speed = vinfo.get("leader_speed")
    leader_gap = max(_finite_float(vinfo.get("leader_gap", 100.0), 100.0), 0.0)
    raw_d = vinfo.get("dist_to_stopline", -1.0)
    dist = -1.0 if raw_d is None else _finite_float(raw_d, -1.0)
    tls = str(vinfo.get("tls_state", "n") or "n").lower()
    accel = _finite_float(vinfo.get("acceleration", 0.0), 0.0)

    follow_band = max(15.0, 1.8 * v)
    ls = (
        max(_finite_float(leader_speed, 0.0), 0.0)
        if leader_speed is not None
        else None
    )
    following_moving = (
        ls is not None and leader_gap < follow_band and ls >= LEADER_STOP_SPEED
    )

    # 1. Red-light GLOSA steady green-wave glide
    v_glosa = compute_glosa_target_speed(vinfo, vmax)
    if v_glosa is not None:
        r_g = _speed_track(v, v_glosa, vmax)
        if abs(v - v_glosa) <= 1.0 and abs(accel) <= 0.5:
            r_g = float(min(1.0, r_g + float(GLOSA_STEADY_BONUS)))
        return float(r_g)

    # 2. Far-horizon gentle glide-to-stop (0..130m at -1.25 m/s^2) toward red/yellow
    #    stop line or stopped/slow queue tail.
    d_stop: Optional[float] = None
    pocket_m = float(STOP_ZONE_M)
    if tls in ("r", "y") and 0.0 <= dist <= RED_GLIDE_HORIZON_M:
        d_stop = max(0.0, dist)
    if ls is not None and ls < LEADER_STOP_SPEED and leader_gap < LEADER_STOP_GAP:
        d_leader_stop = max(0.0, leader_gap - LEADER_STOP_OFFSET_M)
        if d_stop is None or d_leader_stop < float(d_stop):
            d_stop = d_leader_stop
            pocket_m = float(LEADER_STOP_POCKET_M)

    if d_stop is not None:
        if d_stop <= pocket_m:
            return float(
                max(
                    _r_eff_stop_pocket(v, d_stop, pocket_m),
                    _r_eff_kinematic_stop(v, d_stop, vmax, accel=accel),
                )
            )
        d_eff = max(float(d_stop) - STOP_BUFFER_M, 0.0)
        v_kin = float(np.sqrt(2.0 * RED_BRAKE_DECEL * d_eff))
        if v_kin >= vmax:
            return float(_speed_track(v, vmax, vmax))
        return float(_r_eff_kinematic_stop(v, d_stop, vmax, accel=accel))

    if following_moving and ls is not None:
        v_tgt = min(vmax, max(float(ls), IDLING_SPEED_MS))
        r_v = _speed_track(v, v_tgt, vmax)
        r_gap = float(np.clip(gap_band_reward(leader_gap, v), -1.0, 1.0))
        return float(np.clip(0.70 * r_v + 0.30 * r_gap, -1.0, 1.0))

    r_v = _speed_track(v, vmax, vmax)
    if tls == "g" and 0.0 < dist <= 120.0 and _green_window_shaping_enabled():
        rem_g = _remaining_green_seconds(vinfo, state)
        if rem_g is not None and rem_g > 0.0:
            eta_best = _kinematic_eta_seconds(dist, v, vmax, a_acc=GREEN_COMFORT_ACCEL_MS2)
            tau_eff = max(rem_g - float(GREEN_SAFETY_MARGIN_S), 0.2)
            if (
                rem_g <= float(GREEN_UNREACHABLE_HORIZON_S)
                and eta_best > rem_g + float(GREEN_SAFETY_MARGIN_S)
                and dist <= 80.0
            ):
                d_eff = max(float(dist) - STOP_BUFFER_M, 0.0)
                v_kin = min(vmax, float(np.sqrt(2.0 * RED_BRAKE_DECEL * d_eff)))
                return float(_speed_track(v, v_kin, vmax))
            if rem_g <= float(GREEN_WINDOW_HORIZON_S) and eta_best <= tau_eff:
                eta_cruise = dist / max(v, 0.5)
                if eta_cruise <= tau_eff or (accel >= 1.0 and eta_best <= tau_eff):
                    r_v = float(min(1.0, r_v + float(GREEN_HIT_BONUS)))
                else:
                    v_catch = min(vmax, dist / tau_eff)
                    late_deficit = float(
                        np.clip((v_catch - v) / max(vmax, 1e-3), 0.0, 1.0)
                    )
                    r_v = float(
                        np.clip(
                            r_v - float(GREEN_LATE_MISS_WEIGHT) * late_deficit,
                            -1.0,
                            1.0,
                        )
                    )
    if tls == "g" and 0.0 <= dist <= 120.0 and accel < -0.5:
        r_false_brake = float(np.clip((-accel - 0.5) / EFF_A_DEC_MAX, 0.0, 1.0))
        return float(np.clip(r_v - 0.25 * r_false_brake, -1.0, 1.0))
    return float(r_v)


def r_comfort(accel: float, jerk: float, prev_accel: Optional[float] = None) -> float:
    """Comfort with steady-glide deadband, undiluted jerk, and sign-flip anti-chatter."""
    raw_a = _finite_float(accel, 0.0)
    if raw_a >= 0.0:
        eff_a = max(0.0, raw_a - COMFORT_POS_DEADBAND)
    else:
        eff_a = max(0.0, -raw_a - COMFORT_NEG_DEADBAND)
    j = abs(_finite_float(jerk, 0.0))
    j_eff = max(0.0, j - float(COMFORT_JERK_DEADZONE))
    pen = -0.45 * (eff_a / 2.5) - 0.55 * (j_eff / 6.0)
    # Explicit anti-chatter penalty when alternating throttle <-> brake across steps.
    if prev_accel is not None:
        pa = _finite_float(prev_accel, raw_a)
        if raw_a * pa < -0.05 and abs(raw_a - pa) > 0.55:
            swing = float(np.clip((abs(raw_a - pa) - 0.55) / 2.0, 0.0, 1.0))
            pen -= 0.35 * swing
    return float(np.clip(pen, -1.0, 0.0))


def r_platoon_maintain(vinfo: Mapping[str, Any]) -> float:
    """Leader gap maintenance plus follower shockwave damping for string stability."""
    v = max(_finite_float(vinfo.get("speed", 0.0), 0.0), 0.0)
    accel = _finite_float(vinfo.get("acceleration", 0.0), 0.0)
    terms = []
    leader_gap = max(_finite_float(vinfo.get("leader_gap", 100.0), 100.0), 0.0)
    leader_speed = _finite_float(vinfo.get("leader_speed", v), v)
    if vinfo.get("leader_id") is not None and leader_gap < 99.0:
        if v < 1.5 and leader_speed < 1.5:
            if 0.25 <= leader_gap <= QUEUE_PACK_HI_M:
                terms.append(1.0)
            elif 0.0 <= leader_gap < 0.25:
                # Discourage hugging <0.25m net gap where IDM collision risk rises.
                terms.append(float(0.2 + 3.2 * leader_gap))
            elif leader_gap < QUEUE_PACK_LO_M:
                terms.append(-1.0)
            elif leader_gap < QUEUE_ATTRACT_HI_M:
                span = max(QUEUE_ATTRACT_HI_M - QUEUE_PACK_HI_M, 1e-3)
                terms.append(
                    float(max(0.0, 1.0 - ((leader_gap - QUEUE_PACK_HI_M) / span)))
                )
            else:
                terms.append(0.0)
        else:
            terms.append(_finite_float(gap_band_reward(leader_gap, v), 0.0))

    base = float(np.mean(terms)) if terms else 0.0
    fol_id = vinfo.get("follower_id")
    fol_gap = _finite_float(vinfo.get("follower_gap", 100.0), 100.0)
    if (
        fol_id is not None
        and 0.0 < fol_gap < STRING_STABILITY_GAP_MAX_M
        and accel < STRING_STABILITY_BRAKE_THR
        and leader_gap > 15.0
    ):
        shock_pen = float(np.clip((-accel + STRING_STABILITY_BRAKE_THR) / 2.5, 0.0, 0.5))
        base -= shock_pen
    return float(np.clip(base, -1.0, 1.0))


# ---------------------------------------------------------------------------
# v5.2 reward v2 (switch: LON_REWARD_VERSION=v2 / --lon-reward-version v2)
# Smoke tests: v1 paid +0.79/step for standing in a queue vs +0.54 for free
# cruising, and the episode CAV reward was HIGHER in a 4-leg gridlock
# (0.52-0.58) than in fluid 3-leg traffic (0.31-0.43). v2 prices delay.
# ---------------------------------------------------------------------------
V2_LONG_WEIGHTS = np.asarray([0.25, 0.45, 0.15, 0.15], dtype=np.float32)  # safe, delay, comfort, platoon
V2_EFF_SHAPING = 0.25          # share of the v1 efficiency shaping kept (mapped to [-1, 0])
# v6-P0: single source in environment.gap_policy (values unchanged).
from environment.gap_policy import REWARD_BAND_CAV_S as V2_HEADWAY_CAV_S  # behind a CAV (CACC)
from environment.gap_policy import REWARD_BAND_HDV_S as V2_HEADWAY_HDV_S  # behind an HDV (ACC-like)


def lon_reward_version() -> str:
    # v5.2.4: module default follows train_RL / config (v2). Set
    # LON_REWARD_VERSION=v1 (or --lon-reward-version v1) for the legacy reward.
    raw = str(os.environ.get("LON_REWARD_VERSION", "v2") or "v2").strip().lower()
    return "v1" if raw == "v1" else "v2"


def r_delay(vinfo: Mapping[str, Any], desired_speed: float = 16.67) -> float:
    """Delay rate in [-1, 0]: -(1 - v/v_free); its time integral is the delay."""
    v = max(_finite_float(vinfo.get("speed", 0.0), 0.0), 0.0)
    v_ref = max(_resolve_lane_desired_speed(vinfo, desired_speed), 1.0)
    return -float(np.clip(1.0 - v / v_ref, 0.0, 1.0))


def r_eff_v2(vinfo: Mapping[str, Any], state: Mapping[str, Any], desired_speed: float = 16.67) -> float:
    shaping = float(np.clip(r_eff(vinfo, state, desired_speed), -1.0, 1.0))
    val = (1.0 - V2_EFF_SHAPING) * r_delay(vinfo, desired_speed) + V2_EFF_SHAPING * 0.5 * (shaping - 1.0)
    return float(np.clip(val, -1.0, 0.0))


def r_safe_v2(vinfo: Mapping[str, Any]) -> float:
    """Penalty-only safety: 0 when safe (v1 paid +1 every safe step)."""
    return float(min(0.0, float(np.clip(r_safe(vinfo), -1.0, 1.0))))


def _leader_is_cav(vinfo: Mapping[str, Any], state: Optional[Mapping[str, Any]]) -> Optional[bool]:
    lid = vinfo.get("leader_id")
    if lid is None or not isinstance(state, Mapping):
        return None
    if lid in (state.get("cavs") or {}):
        return True
    if lid in (state.get("hdvs") or {}):
        return False
    return None


def r_platoon_v2(vinfo: Mapping[str, Any], state: Optional[Mapping[str, Any]] = None) -> float:
    """Penalty-only platoon/queue term in [-1, 0].

    * standstill queue: 0 for a packed gap (0.25-1.8 m net), linear penalty for
      wasted storage up to -1 at 14 m (v1 still paid +0.74 at 5 m); skipped when
      the leader is beyond the stop line;
    * moving: net time headway band by leader type (CAV 0.6-1.0 s, HDV 1.2-2.0 s);
      closer than the band -> penalty; mild pull towards a CAV leader within 25 m;
    * the v1 string-stability shock penalty is kept.
    """
    v = max(_finite_float(vinfo.get("speed", 0.0), 0.0), 0.0)
    accel = _finite_float(vinfo.get("acceleration", 0.0), 0.0)
    leader_gap = max(_finite_float(vinfo.get("leader_gap", 100.0), 100.0), 0.0)
    leader_speed = _finite_float(vinfo.get("leader_speed", v), v)
    pen = 0.0
    if vinfo.get("leader_id") is not None and leader_gap < 99.0:
        if v < 1.5 and leader_speed < 1.5:
            raw_d = vinfo.get("dist_to_stopline", -1.0)
            d_stop = -1.0 if raw_d is None else _finite_float(raw_d, -1.0)
            leader_past_stopline = 0.0 <= d_stop <= leader_gap
            if leader_gap < 0.25:
                pen = -0.5 * (1.0 - leader_gap / 0.25)
            elif leader_gap > QUEUE_PACK_HI_M and not leader_past_stopline:
                span = max(QUEUE_ATTRACT_HI_M - QUEUE_PACK_HI_M, 1e-3)
                pen = -min(1.0, (leader_gap - QUEUE_PACK_HI_M) / span)
        else:
            is_cav = _leader_is_cav(vinfo, state)
            lo, hi = V2_HEADWAY_CAV_S if is_cav else V2_HEADWAY_HDV_S
            h = leader_gap / max(v, 0.5)
            if h < lo:
                pen = -min(1.0, (lo - h) / lo)
            elif is_cav and h > hi and leader_gap < 25.0:
                pen = -0.3 * min(1.0, (h - hi) / hi)
    fol_id = vinfo.get("follower_id")
    fol_gap = _finite_float(vinfo.get("follower_gap", 100.0), 100.0)
    if (
        fol_id is not None
        and 0.0 < fol_gap < STRING_STABILITY_GAP_MAX_M
        and accel < STRING_STABILITY_BRAKE_THR
        and leader_gap > 15.0
    ):
        pen -= float(np.clip((-accel + STRING_STABILITY_BRAKE_THR) / 2.5, 0.0, 0.5))
    return float(np.clip(pen, -1.0, 0.0))


class LongitudinalReward:
    def __init__(
        self,
        weights: Optional[Sequence[float]] = None,
        desired_speed: float = 16.67,
        decision_dt: float = LON_DECISION_DT,
    ):
        try:
            valid_size = weights is None or np.asarray(weights).reshape(-1).size == 4
        except (TypeError, ValueError, OverflowError):
            valid_size = False
        self.weights = _normalize_weights(weights if valid_size else None)
        self.desired_speed = max(_finite_float(desired_speed, 16.67), 1e-3)
        self.decision_dt = max(_finite_float(decision_dt, LON_DECISION_DT), 1e-6)
        self.platoon_enabled = True
        self.version = lon_reward_version()  # 'v2' (default since v5.2.2) | 'v1'

    def set_weights(self, weights: Sequence[float], *, allow_eff_drop: bool = False):
        self.weights = _normalize_weights(
            weights, fallback=self.weights, allow_eff_drop=allow_eff_drop
        )

    def set_platoon_enabled(self, enabled: bool):
        self.platoon_enabled = bool(enabled)

    def compute(
        self,
        vinfo: Mapping[str, Any],
        state: Mapping[str, Any],
        prev_accel: Optional[float] = None,
        dt: float = 0.2,
        decision_dt: Optional[float] = None,
    ) -> tuple[float, Dict[str, float]]:
        accel = _finite_float(vinfo.get("acceleration", 0.0), 0.0)
        prev = _finite_float(prev_accel if prev_accel is not None else accel, accel)
        sim_dt = max(_finite_float(dt, 0.2), 1e-6)
        dec_dt = max(
            _finite_float(decision_dt if decision_dt is not None else self.decision_dt, LON_DECISION_DT),
            sim_dt,
        )
        # Compute true decision-step jerk without artificial 0.5x dilution.
        step_jerk = (accel - prev) / dec_dt
        if "jerk" in vinfo and vinfo.get("jerk") is not None:
            raw_j = _finite_float(vinfo.get("jerk"), 0.0)
            jerk = raw_j if abs(raw_j) >= abs(step_jerk) else step_jerk
        else:
            jerk = step_jerk

        if getattr(self, "version", "v1") == "v2":
            comps = {
                "safe": r_safe_v2(vinfo),
                "eff": r_eff_v2(vinfo, state, self.desired_speed),
                "comfort": float(np.clip(r_comfort(accel, jerk, prev_accel=prev), -1.0, 0.0)),
                "platoon": r_platoon_v2(vinfo, state) if self.platoon_enabled else 0.0,
            }
            w2 = V2_LONG_WEIGHTS.astype(np.float64).copy()
            if not self.platoon_enabled:
                w2[3] = 0.0
                w2 /= max(float(w2.sum()), 1e-8)
            total2 = float(
                w2[0] * comps["safe"] + w2[1] * comps["eff"]
                + w2[2] * comps["comfort"] + w2[3] * comps["platoon"]
            )
            return float(np.clip(total2, -1.0, 0.0)), comps
        comps = {
            "safe": float(np.clip(r_safe(vinfo), -1.0, 1.0)),
            "eff": float(np.clip(r_eff(vinfo, state, self.desired_speed), -1.0, 1.0)),
            "comfort": float(np.clip(r_comfort(accel, jerk, prev_accel=prev), -1.0, 0.0)),
            "platoon": (
                r_platoon_maintain(vinfo) if self.platoon_enabled else 0.0
            ),
        }
        w = self.weights.copy()
        if not self.platoon_enabled:
            w[3] = 0.0
            total_w = float(w.sum())
            if total_w > 1e-8:
                w /= total_w
            else:
                w = _normalize_weights(DEFAULT_LONG_WEIGHTS)

        total = float(
            w[0] * comps["safe"]
            + w[1] * comps["eff"]
            + w[2] * comps["comfort"]
            + w[3] * comps["platoon"]
        )
        return float(np.clip(total, -1.0, 1.0)), comps
