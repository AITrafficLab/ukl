import threading
import numpy as np

from environment.platoon_manager import platoon_gap, safe_gap
from reward.signal_reward import compute_signal_reward, signal_waiting_increment_reward


class BaseReward:
    """Bounded physical reward components for cooperative traffic control.

    CAV: safe / eff / comfort + optional coop (flow + platoon).
    Macro weights (safe/eff/comfort) may come from VLM; λ_flow / λ_plat are
    either fixed or a density occupancy map — never learned by the policy.
    """

    DESIRED_SPEED = 16.67
    DANGER_TTC = 1.5
    COMFORT_ACCEL = 3.0
    TIME_GAP_MIN = 0.8
    VEL_BONUS = 0.1
    # Anti-crawl: idle floor and "clear road" gap for green tracking / idle penalty.
    V_MIN_IDLE = 3.0
    CLEAR_ROAD_GAP_M = 50.0
    # Red approach: kinematic stop (comfort decel), not stretch over full T_R.
    RED_BRAKE_DECEL = 2.0
    # Red distant idle: hard -1 only when still far from stop target (protect near-queue creep).
    RED_DISTANT_IDLE_M = 12.0
    RED_DISTANT_IDLE_V = 1.0
    # Soft-track deadzone (±m/s); hard overspeed wall is v_target + same tol (aligned).
    SPEED_TRACK_TOL_MPS = 1.5

    def __init__(self, desired_speed=16.67, danger_ttc=1.5, comfort_accel=3.0):
        self.DESIRED_SPEED = desired_speed
        self.DANGER_TTC = danger_ttc
        self.COMFORT_ACCEL = comfort_accel
        self.V_MIN_IDLE = float(self.V_MIN_IDLE)
        self.CLEAR_ROAD_GAP_M = float(self.CLEAR_ROAD_GAP_M)
        self._w_safe = 1.0 / 3.0
        self._w_eff = 1.0 / 3.0
        self._w_comfort = 1.0 / 3.0
        self._w_coop = 0.0
        self._w_coop_target = 0.25
        self.lambda_flow = 0.6
        self.lambda_plat = 0.4
        self.lambda_mode = 'fixed'  # 'fixed' | 'adaptive'
        self.lambda_ema = 0.9
        self.lambda_flow_min = 0.3
        self.lambda_flow_max = 1.0
        self.jam_vehicle_space_m = 7.0  # 4.5 m length + 2.5 m minGap
        self.k_jam = None  # veh/km/lane; None → occupancy vs zone jam count
        self._lambda_flow_ema = None
        self._last_zone_occupancy = 0.0
        self._last_zone_vehicles = 0
        self.flow_window_steps = 5  # 1.0 s @ 0.2 s
        self.team_leader_weight = 0.5
        self.team_signal_weight = 0.5
        self.max_road_capacity = 160.0
        self.control_zone_length = 200.0
        self.default_green_duration = 10.0
        self.signal_incoming_edges = set()
        self.signal_outgoing_edges = set()
        self._follower_speed_hist = {}
        self._hist_lock = threading.Lock()
        self._scenario_key = ""

    def set_scenario(self, scenario_key=None):
        """Store scenario key (VLM interval / topology tags; formal is unified)."""
        self._scenario_key = str(scenario_key or "").strip()
        return self._scenario_key

    def set_signal_edges(self, incoming=None, outgoing=None):
        self.signal_incoming_edges = set(incoming or ())
        self.signal_outgoing_edges = set(outgoing or ())

    def set_coop_enabled(self, enabled, w_coop=None):
        """Enable the legacy coop channel (unused by hierarchical R_lat/R_long)."""
        if enabled:
            self._w_coop = float(self._w_coop_target if w_coop is None else w_coop)
        else:
            self._w_coop = 0.0

    def configure_coop(
        self,
        w_coop_target=None,
        lambda_flow=None,
        lambda_plat=None,
        lambda_mode=None,
        lambda_ema=None,
        lambda_flow_min=None,
        lambda_flow_max=None,
        k_jam=None,
        jam_vehicle_space_m=None,
    ):
        if w_coop_target is not None:
            self._w_coop_target = float(w_coop_target)
            # Keep live weight in sync when coop is already enabled.
            if self._w_coop > 0.0:
                self._w_coop = float(self._w_coop_target)
        if lambda_mode is not None:
            mode = str(lambda_mode).strip().lower()
            if mode not in ('adaptive', 'fixed'):
                raise ValueError("lambda_mode must be 'adaptive' or 'fixed'")
            self.lambda_mode = mode
        if lambda_ema is not None:
            self.lambda_ema = float(np.clip(lambda_ema, 0.0, 0.999))
        if lambda_flow_min is not None:
            self.lambda_flow_min = float(lambda_flow_min)
        if lambda_flow_max is not None:
            self.lambda_flow_max = float(lambda_flow_max)
        if k_jam is not None:
            kj = float(k_jam)
            self.k_jam = kj if kj > 1e-6 else None
        if jam_vehicle_space_m is not None:
            self.jam_vehicle_space_m = max(float(jam_vehicle_space_m), 1e-3)
        if lambda_flow is not None:
            self.lambda_flow = float(lambda_flow)
        if lambda_plat is not None:
            self.lambda_plat = float(lambda_plat)
        if self.lambda_mode == 'fixed':
            s = self.lambda_flow + self.lambda_plat
            if s > 1e-8:
                self.lambda_flow /= s
                self.lambda_plat /= s

    def reset_coop_state(self):
        self._follower_speed_hist.clear()
        self._lambda_flow_ema = None
        self._last_zone_occupancy = 0.0
        self._last_zone_vehicles = 0

    def _zone_vehicle_count(self, state):
        n = 0
        for group in ('cavs', 'hdvs'):
            for vinfo in (state.get(group) or {}).values():
                if vinfo.get('in_control_zone', False):
                    n += 1
        return int(n)

    def _zone_jam_count(self):
        """Approximate jam occupancy (vehicles) in the control zone."""
        cap = float(self.max_road_capacity) if self.max_road_capacity else 0.0
        if cap > 1e-6:
            return cap
        L = max(float(self.control_zone_length), 1e-3)
        space = max(float(self.jam_vehicle_space_m), 1e-3)
        return max(L / space, 1.0)

    def _occupancy_ratio(self, state):
        n_zone = self._zone_vehicle_count(state)
        self._last_zone_vehicles = n_zone
        if self.k_jam is not None and float(self.k_jam) > 1e-6:
            L_km = max(float(self.control_zone_length), 1e-3) / 1000.0
            n_jam = self._zone_jam_count()
            n_lanes = max(n_jam * float(self.jam_vehicle_space_m) / max(float(self.control_zone_length), 1e-3), 1.0)
            k = float(n_zone) / max(n_lanes * L_km, 1e-6)
            occ = k / float(self.k_jam)
        else:
            occ = float(n_zone) / max(self._zone_jam_count(), 1e-6)
        occ = float(np.clip(occ, 0.0, 2.0))
        self._last_zone_occupancy = occ
        return occ

    def _update_coop_lambdas(self, state):
        """Density-adaptive λ_f / λ_p. Congestion → more flow; free-flow → more platoon."""
        if self.lambda_mode != 'adaptive':
            return
        occ = self._occupancy_ratio(state)
        lo = float(self.lambda_flow_min)
        hi = float(self.lambda_flow_max)
        if hi < lo:
            lo, hi = hi, lo
        raw = float(np.clip(occ, lo, hi))
        alpha = float(self.lambda_ema)
        if self._lambda_flow_ema is None:
            smoothed = raw
        else:
            smoothed = alpha * float(self._lambda_flow_ema) + (1.0 - alpha) * raw
        self._lambda_flow_ema = smoothed
        self.lambda_flow = float(np.clip(smoothed, lo, hi))
        self.lambda_plat = float(1.0 - self.lambda_flow)

    def _signal_edge_bucket(self, edge):
        if not edge or edge.startswith(':'):
            return ''
        incoming = self.signal_incoming_edges
        outgoing = self.signal_outgoing_edges
        if incoming or outgoing:
            if edge in incoming:
                return 'in'
            if edge in outgoing:
                return 'out'
            return ''
        if edge.endswith('A0'):
            return 'in'
        if edge.startswith('A0'):
            return 'out'
        return ''

    @property
    def w_safe(self):
        return self._w_safe

    @w_safe.setter
    def w_safe(self, value):
        self._w_safe = value

    @property
    def w_eff(self):
        return self._w_eff

    @w_eff.setter
    def w_eff(self, value):
        self._w_eff = value

    @property
    def w_comfort(self):
        return self._w_comfort

    @w_comfort.setter
    def w_comfort(self, value):
        self._w_comfort = value

    @property
    def w_coop(self):
        return float(self._w_coop)

    @w_coop.setter
    def w_coop(self, value):
        self._w_coop = float(value)

    @staticmethod
    def _is_relevant(vinfo):
        return bool(vinfo.get('in_control_zone', False))

    def _zone_progress(self, vinfo):
        L = max(float(self.control_zone_length), 1e-3)
        if vinfo.get('is_in_junction', False):
            return L
        dist = float(vinfo.get('dist_to_stopline', -1.0))
        if dist < 0.0:
            return 0.0
        return float(np.clip(L - dist, 0.0, L))

    def _signal_windows(self, vinfo, state):
        tls_state = str(vinfo.get('tls_state', 'n') or 'n').lower()
        tls_id = vinfo.get('tls_id')
        remaining = 0.0
        if tls_id and tls_id in state.get('signals', {}):
            remaining = float(state['signals'][tls_id].get('remaining_time', 0.0) or 0.0)
        ttg = float(vinfo.get('time_to_green', -1.0) or -1.0)
        default_tg = max(float(self.default_green_duration), 1e-3)

        if tls_state == 'g':
            return 0.0, max(remaining, 0.0)
        if tls_state in ('r', 'y'):
            tr = ttg if ttg >= 0.0 else remaining
            return max(tr, 0.0), default_tg
        return 0.0, max(remaining, 0.0)

    def _rtb_efficiency(self, vinfo, state):
        L = max(float(self.control_zone_length), 1e-3)
        pt = self._zone_progress(vinfo)
        cv = float(vinfo.get('control_time', 0.0) or 0.0)
        tr, tg = self._signal_windows(vinfo, state)

        if tr > 1e-6:
            if pt >= L - 1e-3:
                return -1.0
            if cv <= tr + tg:
                return float(pt / L)
            return -1.0
        if cv <= tg:
            return float(pt / L)
        return -1.0

    def _front_gap_m(self, vinfo):
        """Nearest forward constraint: leader bumper gap or stop-line distance."""
        gap = float(vinfo.get('leader_gap', 100.0) or 100.0)
        raw_d = vinfo.get('dist_to_stopline', -1.0)
        d_stop = -1.0 if raw_d is None else float(raw_d)
        if d_stop < 0.0:
            d_stop = 1e9
        return float(min(gap, d_stop))

    def _red_valid_distance(self, vinfo, fallback_zone_m=None):
        """Clear distance to the desired red stop point (queue-aware).

        ``d_valid = min(d_stopline, d_leader - d_margin)`` when a real leader
        exists, so the stop target is the queue tail, not a far stop-line.
        No leader → stop-line only (empty approach).
        """
        L = max(float(fallback_zone_m if fallback_zone_m is not None else self.control_zone_length), 1e-3)
        raw_d = vinfo.get('dist_to_stopline', -1.0)
        d_stop = -1.0 if raw_d is None else float(raw_d)
        if d_stop < 0.0:
            d_stop = L
        d_valid = float(d_stop)
        leader_gap = float(vinfo.get('leader_gap', 100.0) or 100.0)
        has_leader = (
            vinfo.get('leader_id') is not None
            and leader_gap < 99.0
        )
        if has_leader:
            v = float(vinfo.get('speed', 0.0) or 0.0)
            # Align with platoon safe gap (_gap_band): leave space behind leader.
            d_margin = safe_gap(v)
            d_valid = min(d_valid, leader_gap - d_margin)
        return float(max(0.0, d_valid))

    def _red_speed_limit(self, d_valid, tr, vmax):
        """Max safe approach speed on red/yellow toward ``d_valid``.

        Uses kinematic stop ``sqrt(2 a d)`` so long ``T_R`` does **not** force
        a crawl / early stop far behind the queue. Missing clock → hold.
        """
        if float(tr) <= 1e-6:
            return 0.0
        d = max(float(d_valid), 0.0)
        if d <= 1e-6:
            return 0.0
        a_brake = float(getattr(self, 'RED_BRAKE_DECEL', 2.0) or 2.0)
        a_brake = max(a_brake, 1e-3)
        v_kin = float(np.sqrt(2.0 * a_brake * d))
        return float(min(v_kin, float(vmax)))

    def _speed_track_tol(self):
        return float(getattr(self, 'SPEED_TRACK_TOL_MPS', 1.5) or 0.0)

    def _speed_track_bonus(self, v, v_target, vmax, bonus, tol=None):
        """Peak at v_target with optional deadzone; excess error soft-penalized.

        Inside ``±tol`` → full ``bonus``. Outside →
        ``bonus - (|v-v_target| - tol) / v_max`` (may be negative).
        Hard overspeed uses the same ``tol`` so soft corridor and hard wall agree.
        """
        err = abs(float(v) - float(v_target))
        band = float(self._speed_track_tol() if tol is None else tol)
        band = max(0.0, band)
        if err <= band + 1e-12:
            return float(bonus)
        return float(bonus) - (err - band) / max(float(vmax), 1e-3)

    def _combine_efficiency(self, r_tb, r_td):
        """Keep r_eff in [-1, 1]: average time-budget and speed terms (not sum)."""
        return 0.5 * float(r_tb) + 0.5 * float(r_td)

    def _green_motion_context(self, vinfo):
        """Shared green tracking / idle inputs: gaps, leader, v_target, can_move."""
        v = float(vinfo.get('speed', 0.0) or 0.0)
        vmax = max(float(self.DESIRED_SPEED), 1e-3)
        v_min = float(getattr(self, 'V_MIN_IDLE', 3.0) or 3.0)
        clear_gap = float(getattr(self, 'CLEAR_ROAD_GAP_M', 50.0) or 50.0)
        front = self._front_gap_m(vinfo)
        road_clear = front > clear_gap
        leader_gap = float(vinfo.get('leader_gap', 100.0) or 100.0)
        leader_id = vinfo.get('leader_id')
        leader_speed = vinfo.get('leader_speed')
        has_leader = (
            leader_id is not None
            and leader_gap < 99.0
            and leader_speed is not None
        )
        d_que = platoon_gap(v)
        if has_leader and not road_clear:
            ls = max(float(leader_speed), 0.0)
            # Green + open join gap: do not mirror a stopped leader (late start).
            if ls < v_min - 1e-9 and leader_gap > d_que:
                v_target = vmax
            else:
                v_target = min(vmax, ls)
        else:
            v_target = vmax
        can_move = road_clear or (has_leader and leader_gap > d_que)
        return {
            'v': v,
            'vmax': vmax,
            'v_min': v_min,
            'v_target': float(v_target),
            'can_move': bool(can_move),
        }

    def _is_idling_hard_penalty(self, vinfo, state):
        """True when red/green idle hard -1 on r_td would fire (not overspeed).

        Red/yellow: ``d_valid > RED_DISTANT_IDLE_M`` and ``v < RED_DISTANT_IDLE_V``.
        Green: able to move but ``v < V_MIN_IDLE``.
        """
        v = float(vinfo.get('speed', 0.0) or 0.0)
        if v < 0.0:
            return False
        tr, _tg = self._signal_windows(vinfo, state)
        tls = str(vinfo.get('tls_state', 'n') or 'n').lower()
        on_red = tls in ('r', 'y') or tr > 1e-6
        if on_red and tls != 'g':
            L = max(float(self.control_zone_length), 1e-3)
            d_valid = self._red_valid_distance(vinfo, fallback_zone_m=L)
            d_idle = float(getattr(self, 'RED_DISTANT_IDLE_M', 12.0) or 12.0)
            v_idle = float(getattr(self, 'RED_DISTANT_IDLE_V', 1.0) or 1.0)
            return bool(d_valid > d_idle and v < v_idle - 1e-9)

        ctx = self._green_motion_context(vinfo)
        return bool(ctx['can_move'] and v < ctx['v_min'] - 1e-9)

    def _rtd_velocity(self, vinfo, state):
        """Speed efficiency: hard idle floor + soft kinematic / desired tracking.

        Red / yellow (same branch):
          1) ``d_valid``, ``v_kin`` (via ``_red_speed_limit``);
          2) hard ``-1`` if far idle (``d_valid > 12`` and ``v < 1``) or
             overspeed ``v > v_kin + SPEED_TRACK_TOL``;
          3) else soft-track ``v_kin`` with the same ±tol deadzone
             (hold at 0 when within a few metres).
        Green: hard idle if crawling while able to move; hard overspeed above
        ``v_max + tol``; else soft-track target with deadzone.
        """
        v = float(vinfo.get('speed', 0.0) or 0.0)
        vmax = max(float(self.DESIRED_SPEED), 1e-3)
        bonus = float(self.VEL_BONUS)
        tol = self._speed_track_tol()
        tr, _tg = self._signal_windows(vinfo, state)
        L = max(float(self.control_zone_length), 1e-3)

        # --- Red / yellow: hard floor then soft v_kin track (complementary) ---
        tls = str(vinfo.get('tls_state', 'n') or 'n').lower()
        on_red = tls in ('r', 'y') or tr > 1e-6
        if on_red and tls != 'g':
            d_valid = self._red_valid_distance(vinfo, fallback_zone_m=L)
            v_kin = self._red_speed_limit(d_valid, tr, vmax)  # min(sqrt(2ad), vmax)
            # Hard wall aligned with soft deadzone (not a tighter wall at bare v_kin).
            if v > v_kin + tol + 1e-6:
                return -1.0
            if v < 0.0:
                return -1.0
            # Gate 1 — hard whip: distant idle (soft track alone cannot escape +safe mask).
            if self._is_idling_hard_penalty(vinfo, state):
                return -1.0
            # Gate 2 — soft navigator: track v_kin; near stop hold at 0.
            hold_m = 3.0
            v_target = 0.0 if d_valid <= hold_m else v_kin
            return self._speed_track_bonus(v, v_target, vmax, bonus, tol=tol)

        # --- Green / free: hard idle if movable, else soft track ---
        if v > vmax + tol + 1e-6:
            return -1.0
        if v < 0.0:
            return -1.0

        ctx = self._green_motion_context(vinfo)
        if self._is_idling_hard_penalty(vinfo, state):
            return -1.0
        return self._speed_track_bonus(v, ctx['v_target'], vmax, bonus, tol=tol)

    def _rte_collision(self, vinfo, state=None):
        """Safety score in [-1, 1]; idle hard-penalty revokes the +1 bonus only.

        TTC-danger stays ``-1``. Far/green idle is not "earned" safety: when
        ``state`` is provided and idle hard-penalty triggers, return ``0``
        instead of ``+1`` so safety weight cannot mask efficiency hard ``-1``.
        """
        ttc = vinfo.get('ttc')
        if ttc is None:
            base = 1.0
        else:
            ttc_f = float(ttc)
            if not np.isfinite(ttc_f) or ttc_f <= 0.0:
                base = 1.0
            elif ttc_f >= float(self.DANGER_TTC):
                base = 1.0
            else:
                base = -1.0
        if base < 0.0:
            return -1.0
        if state is not None and self._is_idling_hard_penalty(vinfo, state):
            return 0.0
        return float(base)

    @staticmethod
    def _gap_band(d_cur, v):
        d_saf = safe_gap(v)
        d_que = platoon_gap(v)
        r_saf = 1.0 if d_cur > d_saf else -1.0
        r_joi = 1.0 if d_saf < d_cur < d_que else 0.0
        return 0.5 * r_saf + 0.5 * r_joi

    def _r_plat(self, vinfo):
        v = float(vinfo.get('speed', 0.0) or 0.0)
        leader_gap = float(vinfo.get('leader_gap', 100.0) or 100.0)
        follower_gap = float(vinfo.get('follower_gap', 100.0) or 100.0)
        has_leader = vinfo.get('leader_id') is not None and leader_gap < 99.0
        has_follower = vinfo.get('follower_id') is not None and follower_gap < 99.0
        terms = []
        if has_leader:
            terms.append(self._gap_band(leader_gap, v))
        if has_follower:
            terms.append(self._gap_band(follower_gap, v))
        if not terms:
            return 0.0
        return float(np.mean(terms))

    def _r_flow(self, vid, vinfo, state):
        cluster_id = vinfo.get('cluster_id')
        followers = []
        if cluster_id:
            for group in ('cavs', 'hdvs'):
                for oid, oinfo in (state.get(group) or {}).items():
                    if oid == vid:
                        continue
                    if oinfo.get('cluster_id') != cluster_id:
                        continue
                    if not oinfo.get('in_control_zone', False):
                        continue
                    raw_od = oinfo.get('dist_to_stopline', -1.0)
                    if (-1.0 if raw_od is None else float(raw_od)) >= float(
                        vinfo.get('dist_to_stopline', 0.0) or 0.0
                    ):
                        followers.append(float(oinfo.get('speed', 0.0) or 0.0))
        if not followers:
            fid = vinfo.get('follower_id')
            if fid:
                for group in ('cavs', 'hdvs'):
                    oinfo = (state.get(group) or {}).get(fid)
                    if oinfo is not None:
                        followers.append(float(oinfo.get('speed', 0.0) or 0.0))
                        break
        if len(followers) < 1:
            self._follower_speed_hist.pop(vid, None)
            return 0.0

        var_t = float(np.var(followers)) if len(followers) > 1 else 0.0
        hist = self._follower_speed_hist.setdefault(vid, [])
        hist.append(var_t)
        if len(hist) > self.flow_window_steps:
            del hist[:-self.flow_window_steps]
        if len(hist) < 2:
            return 0.0
        delta = hist[0] - hist[-1]
        return float(np.clip(delta / (hist[0] + 1e-3), -1.0, 1.0))

    def summarize_for_vlm(self, state):
        L = max(float(self.control_zone_length), 1e-3)
        vmax = max(float(self.DESIRED_SPEED), 1e-3)
        cavs = [
            v for v in (state.get('cavs') or {}).values()
            if self._is_relevant(v)
        ]
        n = len(cavs)
        stats = state.get('stats') or {}

        progress_ratios = []
        control_times = []
        n_red_run = 0
        n_cycle_timeout = 0
        n_tb_pen = 0
        n_td_pen = 0
        n_unsafe_ttc = 0
        n_red_overspeed = 0
        n_green_overspeed = 0
        n_on_red = 0
        n_idling = 0
        mean_abs_accel = 0.0
        v_min_idle = float(getattr(self, 'V_MIN_IDLE', 3.0) or 3.0)
        clear_gap = float(getattr(self, 'CLEAR_ROAD_GAP_M', 50.0) or 50.0)

        for v in cavs:
            pt = self._zone_progress(v)
            cv = float(v.get('control_time', 0.0) or 0.0)
            tr, tg = self._signal_windows(v, state)
            speed = float(v.get('speed', 0.0) or 0.0)
            accel = float(v.get('acceleration', 0.0) or 0.0)
            progress_ratios.append(pt / L)
            control_times.append(cv)
            mean_abs_accel += abs(accel)

            r_tb = self._rtb_efficiency(v, state)
            r_td = self._rtd_velocity(v, state)
            r_te = self._rte_collision(v, state)
            if r_tb < 0.0:
                n_tb_pen += 1
            if r_td < 0.0:
                n_td_pen += 1
            if r_te < 0.0:
                n_unsafe_ttc += 1

            if tr > 1e-6:
                n_on_red += 1
                if pt >= L - 1e-3 and cv < tr:
                    n_red_run += 1
                # Same red limit as _rtd_velocity (queue-aware kinematic + tol).
                d_valid = self._red_valid_distance(v, fallback_zone_m=L)
                v_lim = self._red_speed_limit(d_valid, tr, vmax)
                tol = self._speed_track_tol()
                if speed > v_lim + tol + 1e-6:
                    n_red_overspeed += 1
                d_idle = float(getattr(self, 'RED_DISTANT_IDLE_M', 12.0) or 12.0)
                v_idle = float(getattr(self, 'RED_DISTANT_IDLE_V', 1.0) or 1.0)
                if d_valid > d_idle and speed < v_idle - 1e-9:
                    n_idling += 1
            else:
                if cv > tg + 1e-6:
                    n_cycle_timeout += 1
                if speed > vmax + self._speed_track_tol() + 1e-6:
                    n_green_overspeed += 1
                # Same movable-idle definition as _rtd_velocity anti-crawl.
                front = self._front_gap_m(v)
                lg = float(v.get('leader_gap', 100.0) or 100.0)
                d_que = platoon_gap(speed)
                has_ld = v.get('leader_id') is not None and lg < 99.0
                can_move = front > clear_gap or (has_ld and lg > d_que)
                tls = str(v.get('tls_state', 'n') or 'n').lower()
                on_green = tls == 'g' or tr <= 1e-6
                if on_green and can_move and speed < v_min_idle - 1e-9:
                    n_idling += 1

        if n > 0:
            mean_abs_accel /= n

        queue_keys = [k for k in stats if str(k).startswith('queue_') and k != 'queue_length']
        queue_by_approach = {
            k.replace('queue_', ''): int(stats.get(k, 0) or 0) for k in sorted(queue_keys)
        }
        queue_total = int(sum(queue_by_approach.values()))
        queue_td_s = float(queue_total) * 1.5
        stop_line_buffer_m = float(queue_total) * 7.5

        n_near_queue_tail = 0
        if stop_line_buffer_m > 1e-3:
            for v in cavs:
                raw_vd = v.get('dist_to_stopline', -1.0)
                dist = -1.0 if raw_vd is None else float(raw_vd)
                if 0.0 <= dist <= stop_line_buffer_m + 5.0:
                    n_near_queue_tail += 1

        def _rate(count):
            return float(count) / float(n) if n > 0 else 0.0

        # Pass through live corridor stats (DLC / platoon / lane-change) so
        # VLM decision rules see real values instead of 0.0 defaults.
        platoon_n = sum(
            1 for v in cavs if (v.get('cluster_id') is not None)
        )
        return {
            'n_cav_zone': n,
            'platoon_rate': (float(platoon_n) / float(n)) if n > 0 else float(stats.get('platoon_rate', 0.0) or 0.0),
            'lane_change_rate': float(stats.get('lane_change_rate', 0.0) or 0.0),
            'thru_dlc_queue_diff': float(stats.get('thru_dlc_queue_diff', 0.0) or 0.0),
            'n_dlc': int(stats.get('n_dlc', 0) or 0),
            'avg_zone_progress': float(np.mean(progress_ratios)) if progress_ratios else 0.0,
            'avg_control_time_s': float(np.mean(control_times)) if control_times else 0.0,
            'n_red_run': n_red_run,
            'n_cycle_timeout': n_cycle_timeout,
            'n_tb_penalty': n_tb_pen,
            'n_td_penalty': n_td_pen,
            'n_unsafe_ttc': n_unsafe_ttc,
            'frac_unsafe_ttc': _rate(n_unsafe_ttc),
            'frac_tb_penalty': _rate(n_tb_pen),
            'frac_td_penalty': _rate(n_td_pen),
            'n_on_red': n_on_red,
            'n_idling': n_idling,
            'n_red_overspeed': n_red_overspeed,
            'n_green_overspeed': n_green_overspeed,
            'frac_red_overspeed': (
                float(n_red_overspeed) / float(n_on_red) if n_on_red > 0 else 0.0
            ),
            'mean_abs_accel': float(mean_abs_accel),
            'queue_total': queue_total,
            'queue_by_approach': queue_by_approach,
            'queue_td_est_s': queue_td_s,
            'queue_tail_m': stop_line_buffer_m,
            'n_near_queue_tail': n_near_queue_tail,
            'control_zone_m': float(L),
            'v_max': float(vmax),
            'ttc_threshold_s': float(self.DANGER_TTC),
        }

    def compute_meta_reward(self, state, previous_state):
        vehicles = [
            v for group in ('hdvs', 'cavs')
            for v in state.get(group, {}).values()
            if self._is_relevant(v)
        ]
        delays = [float(v.get('waiting_time', 0.0)) for v in vehicles]
        avg_delay = float(np.mean(delays)) if delays else 0.0
        passed_vehicles = 0
        if previous_state:
            prev_vids = set(previous_state.get('cavs', {}).keys()).union(
                previous_state.get('hdvs', {}).keys()
            )
            curr_vids = set(state.get('cavs', {}).keys()).union(state.get('hdvs', {}).keys())
            passed_vehicles = len(prev_vids - curr_vids)
        collisions = 0
        actual_collisions = int(state.get('collisions', 0))
        for v in state.get('cavs', {}).values():
            if self._is_relevant(v):
                ttc = v.get('ttc')
                if ttc is not None and 0.0 < float(ttc) < 1.0:
                    collisions += 1
        jerks = []
        previous_cavs = previous_state.get('cavs', {}) if previous_state else {}
        for vid, v in state.get('cavs', {}).items():
            if self._is_relevant(v):
                accel = float(v.get('acceleration', 0.0))
                prev_accel = float(previous_cavs.get(vid, {}).get('acceleration', accel))
                jerks.append(abs(accel - prev_accel))
        avg_jerk = float(np.mean(jerks)) if jerks else 0.0
        alpha, beta, gamma_c, eta = 0.05, 1.0, 10.0, 0.1
        return float(
            -alpha * avg_delay
            + beta * passed_vehicles
            - gamma_c * (collisions + actual_collisions * 10.0)
            - eta * avg_jerk
        )

    def compute_agent_rewards(
        self, state, previous_state=None, actions=None, lambdas=None, dt=0.2
    ):
        """Legacy reward entry point with signal reward aligned to AdaptiveReward."""
        del lambdas
        try:
            dt = max(float(dt), 0.0)
            if not np.isfinite(dt):
                dt = 0.2
        except (TypeError, ValueError, OverflowError):
            dt = 0.2
        self._update_coop_lambdas(state)
        global_reward_dict = {
            'eff': 0.0,
            'safe': 0.0,
            'comfort': 0.0,
            'coop': 0.0,
            'coop_terms': np.zeros(2, dtype=np.float32),
            'lambda_flow': float(self.lambda_flow),
            'lambda_plat': float(self.lambda_plat),
            'zone_occupancy': float(self._last_zone_occupancy),
            'zone_vehicles': int(self._last_zone_vehicles),
            'sig_waiting_increment': 0.0,
            'sig_waiting_seconds': 0.0,
            'sig_vehicle_time_exposure': 0.0,
            'sig_waiting_vehicles': 0.0,
            'sig_incoming_vehicles': 0.0,
        }

        agent_rewards = {}
        actions = actions or {}
        cav_effs, cav_safes, cav_comforts, cav_coops = [], [], [], []
        flow_terms, plat_terms = [], []
        leader_rewards, signal_rewards = [], []
        previous_cavs = previous_state.get('cavs', {}) if previous_state else {}

        for agent_id in actions:
            if agent_id.startswith('cav_'):
                vid = agent_id[4:]
                vinfo = state.get('cavs', {}).get(vid)
                if not vinfo:
                    agent_rewards[agent_id] = 0.0
                    continue

                r_safe_i = self._rte_collision(vinfo, state)
                r_eff_i = self._combine_efficiency(
                    self._rtb_efficiency(vinfo, state),
                    self._rtd_velocity(vinfo, state),
                )
                accel = float(vinfo.get('acceleration', 0.0))
                prev_accel = float(previous_cavs.get(vid, {}).get('acceleration', accel))
                jerk = accel - prev_accel
                r_com_i = float(np.clip(
                    -(np.sqrt(abs(accel) / 3.0) + np.sqrt(abs(jerk))),
                    -1.0,
                    1.0,
                ))

                r_flow = self._r_flow(vid, vinfo, state)
                r_plat = self._r_plat(vinfo)
                r_coop_i = float(self.lambda_flow * r_flow + self.lambda_plat * r_plat)

                total_scalar_reward = (
                    self.w_safe * r_safe_i
                    + self.w_eff * r_eff_i
                    + self.w_comfort * r_com_i
                    + self.w_coop * r_coop_i
                )
                agent_rewards[agent_id] = float(total_scalar_reward)
                cav_effs.append(r_eff_i)
                cav_safes.append(r_safe_i)
                cav_comforts.append(r_com_i)
                cav_coops.append(r_coop_i)
                flow_terms.append(r_flow)
                plat_terms.append(r_plat)
                if vinfo.get('is_leader', True):
                    leader_rewards.append(float(total_scalar_reward))

            elif agent_id.startswith('signal_'):
                r_sig_total, sig_info = compute_signal_reward(
                    state,
                    incoming_edges=self.signal_incoming_edges,
                    outgoing_edges=self.signal_outgoing_edges,
                    capacity=float(getattr(self, "max_road_capacity", 160.0) or 160.0),
                    dt=dt,
                    scenario_key=str(getattr(self, "_scenario_key", "") or ""),
                )
                agent_rewards[agent_id] = float(r_sig_total)
                signal_rewards.append(float(r_sig_total))
                global_reward_dict['sig_waiting_increment'] = float(
                    sig_info.get('waiting_increment', 0.0)
                )
                global_reward_dict['sig_speed_term'] = float(
                    sig_info.get('speed_term', 0.0)
                )
                global_reward_dict['sig_waiting_seconds'] = float(
                    sig_info.get('waiting_seconds', 0.0)
                )
                global_reward_dict['sig_vehicle_time_exposure'] = float(
                    sig_info.get('vehicle_time_exposure', 0.0)
                )
                global_reward_dict['sig_waiting_vehicles'] = float(
                    sig_info.get('n_wait', 0.0)
                )
                global_reward_dict['sig_incoming_vehicles'] = float(
                    sig_info.get('n_veh', 0.0)
                )
                global_reward_dict['sig_pressure_diagnostic'] = float(
                    sig_info.get('pressure', 0.0)
                )
                global_reward_dict['sig_ql_norm'] = float(
                    sig_info.get('r_ql_norm', 0.0)
                )
                global_reward_dict['sig_wt_norm'] = float(
                    sig_info.get('r_wt_norm', 0.0)
                )
                global_reward_dict['sig_raw_ql_m'] = float(
                    sig_info.get('raw_r_ql_m', 0.0)
                )
                global_reward_dict['sig_raw_wt_s'] = float(
                    sig_info.get('raw_r_wt_s', 0.0)
                )
                global_reward_dict['sig_formal'] = float(
                    sig_info.get('formal', sig_info.get('waiting_increment', r_sig_total))
                )
                global_reward_dict['sig_residual'] = float(
                    sig_info.get('residual', 0.0)
                )
                global_reward_dict['sig_queue'] = float(
                    sig_info.get('queue', r_sig_total)
                )

        if cav_effs:
            global_reward_dict['eff'] = float(np.mean(cav_effs))
            global_reward_dict['safe'] = float(np.mean(cav_safes))
            global_reward_dict['comfort'] = float(np.mean(cav_comforts))
            global_reward_dict['coop'] = float(np.mean(cav_coops)) if cav_coops else 0.0
            global_reward_dict['coop_terms'] = np.asarray(
                [
                    float(np.mean(flow_terms)) if flow_terms else 0.0,
                    float(np.mean(plat_terms)) if plat_terms else 0.0,
                ],
                dtype=np.float32,
            )

        global_reward_dict['lambda_flow'] = float(self.lambda_flow)
        global_reward_dict['lambda_plat'] = float(self.lambda_plat)
        global_reward_dict['zone_occupancy'] = float(self._last_zone_occupancy)
        global_reward_dict['zone_vehicles'] = int(self._last_zone_vehicles)

        mean_leader = float(np.mean(leader_rewards)) if leader_rewards else 0.0
        mean_signal = float(np.mean(signal_rewards)) if signal_rewards else 0.0
        # Renormalize when one side is absent (e.g. Stage-S has no Leader actions).
        if leader_rewards and signal_rewards:
            global_reward_scalar = (
                self.team_leader_weight * mean_leader
                + self.team_signal_weight * mean_signal
            )
        elif leader_rewards:
            global_reward_scalar = mean_leader
        elif signal_rewards:
            global_reward_scalar = mean_signal
        elif agent_rewards:
            global_reward_scalar = float(
                sum(agent_rewards.values()) / max(len(agent_rewards), 1)
            )
        else:
            global_reward_scalar = 0.0
        return global_reward_scalar, global_reward_dict, agent_rewards
