"""Lateral (lane-change / formation) reward terms for hierarchical CAV."""
from __future__ import annotations

import os
from typing import Any, Dict, Mapping, Optional, Sequence

import numpy as np

from environment.platoon_manager import (
    formation_weight,
    gap_band_reward,
    platoon_type_code,
    safe_gap,
)
from environment.zone_manager import ZONE_PLATOON

# Fixed / VLM soft-start lateral weights: lane, safe_lc, eff_lc, form, comfort_lc.
DEFAULT_LAT_WEIGHTS = np.asarray([0.22, 0.24, 0.22, 0.20, 0.12], dtype=np.float32)
LEGACY_LAT_WEIGHTS = np.asarray([0.25, 0.25, 0.20, 0.20, 0.10], dtype=np.float32)

# One-shot penalty when a CAV must escape a route-illegal lane in the control zone.
CONTROL_ESCAPE_PENALTY = 2.0


def _env_float(name: str, default: float) -> float:
    raw = os.environ.get(name)
    if raw is None or not str(raw).strip():
        return float(default)
    try:
        val = float(str(raw).strip())
    except (TypeError, ValueError, OverflowError):
        return float(default)
    return float(val) if np.isfinite(val) else float(default)


LAT_NET_EXT_COEF = _env_float("LAT_NET_EXT_COEF", 0.15)
LAT_NET_EXT_SCALE = _env_float("LAT_NET_EXT_SCALE", 20.0)
LAT_NET_EXT_EMA_ALPHA = _env_float("LAT_NET_EXT_EMA_ALPHA", 0.05)


def _finite_float(value: Any, default: float = 0.0) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError):
        return float(default)
    return result if np.isfinite(result) else float(default)


def _normalize_weights(
    weights: Optional[Sequence[float]],
    *,
    size: int = 5,
    fallback: Optional[Sequence[float]] = None,
    allow_eff_drop: bool = False,
) -> np.ndarray:
    fb = np.asarray(
        DEFAULT_LAT_WEIGHTS if fallback is None else fallback, dtype=np.float32
    ).reshape(-1)
    if fb.size < size:
        fb = np.pad(fb, (0, size - fb.size))
    fb = np.nan_to_num(fb[:size], nan=0.0, posinf=0.0, neginf=0.0)
    fb = np.clip(fb, 0.0, None)
    if float(fb.sum()) <= 1e-8:
        fb = np.full(size, 1.0 / size, dtype=np.float32)
    else:
        fb = fb / float(fb.sum())

    if weights is None:
        return fb.astype(np.float32)
    try:
        w = np.asarray(weights, dtype=np.float32).reshape(-1)
    except (TypeError, ValueError, OverflowError):
        return fb.astype(np.float32)
    if w.size < size:
        w = np.pad(w, (0, size - w.size))
    w = np.nan_to_num(w[:size], nan=0.0, posinf=0.0, neginf=0.0)
    w = np.clip(w, 0.0, None)
    total = float(w.sum())
    if not np.isfinite(total) or total <= 1e-8:
        return fb.astype(np.float32)
    proposed = (w / total).astype(np.float64)
    anchor = np.asarray(DEFAULT_LAT_WEIGHTS, dtype=np.float64).reshape(-1)
    if anchor.size < size:
        anchor = np.pad(anchor, (0, size - anchor.size))
    anchor = anchor[:size]
    anchor = anchor / max(float(anchor.sum()), 1e-8)
    anchored = np.clip(
        anchor + np.clip(proposed - anchor, -0.10, 0.10),
        0.02,
        0.70,
    )
    if size > 2 and not allow_eff_drop:
        anchored[2] = max(float(anchored[2]), float(anchor[2]))
    anchored_sum = float(anchored.sum())
    if not np.isfinite(anchored_sum) or anchored_sum <= 1e-8:
        return fb.astype(np.float32)
    return (anchored / anchored_sum).astype(np.float32)


def lc_safe_bumper_gap(speed: float) -> float:
    """Physical bumper-to-bumper safety threshold (m) for discretionary lane changes."""
    return max(2.0, 0.65 * max(_finite_float(speed, 0.0), 0.0))


def r_lane(l_cur: float, l_tgt: float, action: int) -> float:
    """Incentive-compatible lane-balance score eliminating passive keep inversion.

    - Balanced lanes (``dl <= 0.5``): keep scores ``+0.85`` while pointless LC scores ``-0.75``.
    - Imbalanced lanes (``dl >= 1.5``): passive keep decays sharply (``+0.175`` at ``dl=2``,
      ``-0.275`` at ``dl=3``) while safe LC into the lighter lane scores ``+0.80 .. +1.0``.
    """
    cur = max(_finite_float(l_cur, 0.0), 0.0)
    tgt = max(_finite_float(l_tgt, cur), 0.0)
    dl = cur - tgt
    try:
        act = int(action)
    except (TypeError, ValueError, OverflowError):
        act = 0
    if act == 0:
        if dl <= 0.5:
            return 0.85
        return float(np.clip(0.85 - 0.45 * (dl - 0.5), -0.85, 0.85))
    if dl >= 0.8:
        return float(np.clip(0.65 + 0.35 * (dl / max(cur, 2.0)), 0.65, 1.0))
    if dl > 0.0:
        return -0.15
    return -0.75


def r_safe_lc(
    target_gap: float,
    speed: float,
    rear_ttc: Optional[float] = None,
    rear_closing: float = 0.0,
) -> float:
    """Safety score in [-1, 1] accounting for both bumper gap and rear-follower TTC."""
    gap = max(_finite_float(target_gap, 0.0), 0.0)
    v = max(_finite_float(speed, 0.0), 0.0)
    req = float(lc_safe_bumper_gap(v))
    if gap <= req:
        return -1.0
    gap_score = float(np.clip((gap - req) / max(req, 4.0), 0.25, 1.0)) if gap < 2.0 * req else 1.0
    if rear_ttc is not None and _finite_float(rear_closing, 0.0) > 0.1:
        ttc_r = max(_finite_float(rear_ttc, 99.0), 0.0)
        if ttc_r < 2.0:
            return -1.0
        if ttc_r < 3.5:
            ttc_score = float(np.clip((ttc_r - 2.0) / 1.5, -1.0, 1.0))
            return float(min(gap_score, 2.0 * ttc_score - 1.0))
    return float(gap_score)


def r_eff_lc(t_before: float, t_after: float, l_cur: float = 0.0) -> float:
    """Travel-time improvement over the local queue time scale, in [-1, 1]."""
    tb = max(_finite_float(t_before, 0.0), 0.0)
    ta = max(_finite_float(t_after, tb), 0.0)
    q = max(_finite_float(l_cur, 0.0), 0.0)
    denom = 1.5 * q + 5.0
    return float(np.clip((tb - ta) / denom, -1.0, 1.0))


def r_form(d: float, speed: float, partner_is_cav: Optional[bool]) -> float:
    distance = max(_finite_float(d, 100.0), 0.0)
    v = max(_finite_float(speed, 0.0), 0.0)
    rd = _finite_float(gap_band_reward(distance, v), 0.0)
    ptype = platoon_type_code(True, partner_is_cav)
    return float(np.clip(float(formation_weight(ptype)) * rd, -1.0, 1.0))


def r_comfort_lc(a_y: float, j_y: float) -> float:
    """Kinematic comfort reward in [-1, 0]; no lane change returns 0."""
    ay = abs(_finite_float(a_y, 0.0))
    jy = abs(_finite_float(j_y, 0.0))
    if ay < 1e-9 and jy < 1e-9:
        return 0.0
    return float(np.clip(-(ay + jy) / 3.0, -1.0, 0.0))


def _estimate_lateral_kinematics(
    act: int,
    speed: float,
    lane_width_m: float = 3.2,
    already_changed_prev_step: bool = False,
) -> tuple[float, float]:
    """Speed-aware lateral acceleration & jerk proxy for a 3.0-3.5s S-curve maneuver."""
    if act == 0:
        return 0.0, 0.0
    v_ratio = float(np.clip(_finite_float(speed, 0.0) / 16.67, 0.0, 1.25))
    t_lc = max(2.6, 3.6 - 0.6 * v_ratio)
    # Peak lateral accel of sinusoidal lane change y(t) = w*(t/T - sin(2pi*t/T)/(2pi)):
    # a_y_max = 2*pi * w / T^2 ~= 20.1 / T^2; damped for smooth cooperative steering.
    a_y = float(np.clip((2.0 * float(lane_width_m) / (t_lc * t_lc)) * (1.2 + 0.8 * v_ratio), 0.55, 1.85))
    j_y = float(0.45 + 0.45 * v_ratio + (0.60 if already_changed_prev_step else 0.0))
    return a_y, j_y


def estimate_travel_time(dist: float, speed: float, queue: float) -> float:
    d = max(_finite_float(dist, 0.0), 0.0)
    v = max(_finite_float(speed, 0.0), 1.0)
    q = max(_finite_float(queue, 0.0), 0.0)
    return float(d / v + 1.5 * q)


def r_net_queue_externality(
    queue_now: float,
    queue_ref: float,
    *,
    scale: Optional[float] = None,
) -> float:
    """Network congestion externality in [-1, 0]."""
    q = max(_finite_float(queue_now, 0.0), 0.0)
    ref = max(_finite_float(queue_ref, 0.0), 1.0)
    sc = _finite_float(scale, LAT_NET_EXT_SCALE)
    if sc <= 1e-6:
        sc = float(LAT_NET_EXT_SCALE) if LAT_NET_EXT_SCALE > 1e-6 else 20.0
    excess = max(0.0, q - ref)
    return float(np.clip(-excess / sc, -1.0, 0.0))


class LateralReward:
    def __init__(self, weights: Optional[Sequence[float]] = None):
        try:
            valid_size = weights is None or np.asarray(weights).reshape(-1).size == 5
        except (TypeError, ValueError, OverflowError):
            valid_size = False
        self.weights = _normalize_weights(weights if valid_size else None)
        self.form_enabled = True

    def set_weights(self, weights: Sequence[float], *, allow_eff_drop: bool = False):
        self.weights = _normalize_weights(
            weights, fallback=self.weights, allow_eff_drop=allow_eff_drop
        )

    def set_form_enabled(self, enabled: bool):
        self.form_enabled = bool(enabled)

    def compute(
        self,
        vinfo: Mapping[str, Any],
        action: int,
        meta: Optional[Mapping[str, Any]] = None,
        prev_lane: Optional[str] = None,
        *,
        network_queue: Optional[float] = None,
        network_queue_ref: Optional[float] = None,
        net_ext_coef: Optional[float] = None,
    ) -> tuple[float, Dict[str, float]]:
        if str(vinfo.get("zone_type", "")) != ZONE_PLATOON:
            zero = {
                k: 0.0
                for k in (
                    "lane",
                    "safe_lc",
                    "eff_lc",
                    "form",
                    "comfort_lc",
                    "net_ext",
                )
            }
            return 0.0, zero

        meta = meta or {}
        l_cur = max(_finite_float(meta.get("current_lane_queue", 0.0), 0.0), 0.0)
        l_tgt = max(_finite_float(meta.get("target_lane_queue", l_cur), l_cur), 0.0)
        try:
            act = int(action)
        except (TypeError, ValueError, OverflowError):
            act = 0
        if act == 0:
            l_tgt = max(_finite_float(meta.get("min_lane_queue", l_cur), l_cur), 0.0)

        speed = max(_finite_float(vinfo.get("speed", 0.0), 0.0), 0.0)
        dist = max(_finite_float(vinfo.get("dist_to_stopline", 0.0), 0.0), 0.0)
        t_before = estimate_travel_time(dist, speed, l_cur)
        t_after = estimate_travel_time(dist, speed, l_tgt if act != 0 else l_cur)
        measured = "p1_tt_delta" in meta

        l_min = max(_finite_float(meta.get("min_lane_queue", l_cur), l_cur), 0.0)
        tgt_gap = max(_finite_float(meta.get("target_lane_gap", 100.0), 100.0), 0.0)
        rear_ttc = _finite_float(meta.get("target_rear_ttc", 99.0), 99.0)
        rear_closing = _finite_float(meta.get("target_rear_closing", 0.0), 0.0)
        if act != 0 and tgt_gap >= 99.0 and rear_ttc >= 3.5:
            safe_lc = 1.0
        else:
            safe_lc = (
                r_safe_lc(tgt_gap, speed, rear_ttc=rear_ttc, rear_closing=rear_closing)
                if act != 0
                else 1.0
            )

        if "target_form_gap" in meta:
            form_d = max(_finite_float(meta.get("target_form_gap"), 100.0), 0.0)
            raw_cav = meta.get("target_form_is_cav", None)
            if form_d >= 99.0 or raw_cav is None:
                partner_cav = None
            else:
                partner_cav = bool(raw_cav)
        else:
            form_d = 100.0
            partner_cav = None

        cur_lane = str(vinfo.get("lane") or "")
        oscillating = bool(
            prev_lane and cur_lane and str(prev_lane) != cur_lane and act != 0
        )
        lane_w = max(_finite_float(vinfo.get("lane_width", 3.2), 3.2), 2.5)
        a_y, j_y = _estimate_lateral_kinematics(
            act, speed, lane_width_m=lane_w, already_changed_prev_step=oscillating
        )

        # Gate formation bonus when the current/target lane suffers queue imbalance
        # so platoon clustering never fights lane queue balancing.
        imbalance = max(0.0, l_cur - l_min)
        form_gate = float(np.clip(1.0 - max(0.0, imbalance - 1.5) / 3.0, 0.20, 1.0))
        if act != 0 and l_tgt > l_cur + 1.0:
            form_gate = 0.0
        raw_form = r_form(form_d, speed, partner_cav) if self.form_enabled else 0.0

        raw_comfort_lc = r_comfort_lc(a_y, j_y)
        # Relieving a genuinely congested lane (>= 1.0 load delta) via a smooth single
        # S-curve maneuver incurs damped steering friction so beneficial LC beats passive keep.
        beneficial_lc = bool(act != 0 and (l_cur - l_tgt) >= 1.0 and not oscillating and safe_lc > 0.1)
        eff_comfort_lc = float(0.35 * raw_comfort_lc) if beneficial_lc else float(raw_comfort_lc)
        balance_gain_bonus = (
            float(0.12 * np.clip((l_cur - l_tgt - 0.8) / 3.0, 0.0, 1.0))
            if beneficial_lc
            else 0.0
        )

        comps = {
            "lane": r_lane(l_cur, l_tgt, act),
            "safe_lc": safe_lc,
            "eff_lc": (
                float(np.clip(
                    -float(meta.get("p1_tt_delta", 0.0)) / (1.5 * max(l_cur, 0.0) + 5.0),
                    -1.0, 1.0,
                ))
                if measured
                else (r_eff_lc(t_before, t_after, l_cur) if act != 0 else 0.0)
            ),
            "form": float(raw_form * form_gate),
            "comfort_lc": eff_comfort_lc,
            "net_ext": 0.0,
        }
        w = self.weights.copy()
        if not self.form_enabled:
            w[3] = 0.0
            total_w = float(w.sum())
            if total_w > 1e-8:
                w /= total_w
            else:
                w = _normalize_weights(DEFAULT_LAT_WEIGHTS)
        total = float(
            sum(
                float(w[i]) * comps[key]
                for i, key in enumerate(
                    ("lane", "safe_lc", "eff_lc", "form", "comfort_lc")
                )
            )
            + balance_gain_bonus
        )
        coef = (
            float(LAT_NET_EXT_COEF)
            if net_ext_coef is None
            else _finite_float(net_ext_coef, LAT_NET_EXT_COEF)
        )
        if measured and "p1_mobil" in meta:
            comps["net_ext"] = float(np.clip(float(meta.get("p1_mobil", 0.0)), -1.0, 0.0))
            total = float(total) + comps["net_ext"]
        elif act != 0 and coef > 1e-12 and network_queue is not None:
            q_now = _finite_float(network_queue, 0.0)
            q_ref = (
                _finite_float(network_queue_ref, q_now)
                if network_queue_ref is not None
                else q_now
            )
            net_ext = r_net_queue_externality(q_now, q_ref)
            comps["net_ext"] = float(net_ext)
            total = float(total) + float(coef) * float(net_ext)
        return float(np.clip(total, -1.0, 1.0)), comps
